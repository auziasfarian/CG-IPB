#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void h() {
    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(69, 234); //1
    glVertex2d(101, 234); //2
    glVertex2d(101,394); //11
    glVertex2d(69,394); //12
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(101,295); //3
    glVertex2d(161,295); //4
    glVertex2d(161,327); //9
    glVertex2d(101,327); //10
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(161,234); //5
    glVertex2d(192,234); //6
    glVertex2d(192,394); //7
    glVertex2d(161,394); //8
    glEnd();
}

void shadowh() {
    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(101, 245); //1
    glVertex2d(108, 245); //2
    glVertex2d(108,295); //11
    glVertex2d(101,295); //12
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(167,245); //3
    glVertex2d(200,245); //4
    glVertex2d(200,406); //9
    glVertex2d(167,406); //10
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(76,325); //5
    glVertex2d(161,325); //6
    glVertex2d(161,339); //7
    glVertex2d(108,339); //8
    glVertex2d(108,406); //7
    glVertex2d(76,406); //8
    glEnd();
}

void LingkaranU(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=-50; i<51;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void u(){

    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(206,324);
    glVertex2d(238,324);
    glVertex2d(238,429);
    glVertex2d(206,429);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(298,324);
    glVertex2d(330,324);
    glVertex2d(330,429);
    glVertex2d(298,429);
    glEnd();

    glColor3f(0.87,0.0,0.14);
    LingkaranU(268,429,62.5); // Lingkaran Luar Atas
    glColor3f(0.85f, 0.85f, 0.85f);
    LingkaranU(268,429,30); // Lingkaran Dalam Atas
}

void shadowu(){

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(219,336);
    glVertex2d(245,336);
    glVertex2d(245,442);
    glVertex2d(219,442);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(313,336);
    glVertex2d(337,336);
    glVertex2d(337,442);
    glVertex2d(313,442);
    glEnd();

    glColor3f(0.08,0.08,0.08);
    LingkaranU(275,439,62.5); // Lingkaran Luar Atas
    glColor3f(0.85f, 0.85f, 0.85f);
    LingkaranU(268,429,30); // Lingkaran Dalam Atas
}

void LingkaranS(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=-120; i<0;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void LingkaranS2(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=-25; i<95;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void s(){
    glColor3f(0.87,0.0,0.14);
    LingkaranS(410,312,65); // Lingkaran Luar Atas
    glColor3f(0.85f, 0.85f, 0.85f);
    LingkaranS(410,312,30); // Lingkaran Dalam Atas

    glColor3f(0.87,0.0,0.14);
    LingkaranS2(390,405,65); // Lingkaran Luar Atas
    glColor3f(0.85f, 0.85f, 0.85f);
    LingkaranS2(390,405,30); // Lingkaran Dalam Atas
}

void a() {
    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(662, 300); //1
    glVertex2d(671, 300); //2
    glVertex2d(747,459); //11
    glVertex2d(712,459); //12
    glVertex2d(666, 362); //2
    glVertex2d(617,459); //11
    glVertex2d(582,459); //12
    glEnd();
}

void shadowa() {
    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(678, 310); //1
    glVertex2d(755, 470); //2
    glVertex2d(719,470); //11
    glVertex2d(673,371); //12
    glVertex2d(623,470); //11
    glVertex2d(587,470); //12
    glVertex2d(669,310); //12
    glEnd();
}

void n() {
    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(466, 225); //1
    glVertex2d(475,225); //2
    glVertex2d(596,350); //11
    glVertex2d(596,385); //11
    glVertex2d(587,385); //12
    glVertex2d(497,293); //2
    glVertex2d(497,385); //11
    glVertex2d(466,385); //12
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.87,0.0,0.14);
    glVertex2d(564,225); //12
    glVertex2d(596,225); //2
    glVertex2d(596,357); //12
    glVertex2d(564,357); //2
    glEnd();
}

void shadown() {
    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(472, 290); //1
    glVertex2d(505, 290); //2
    glVertex2d(505,396); //11
    glVertex2d(472,396); //12
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(505,288); //3
    glVertex2d(604,371); //4
    glVertex2d(604,396); //9
    glVertex2d(594,396); //10
    glVertex2d(505,305); //10
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(576,236); //5
    glVertex2d(604,236); //6
    glVertex2d(604,371); //7
    glVertex2d(576,371); //8
    glEnd();
}

void garis() {
    glBegin(GL_POLYGON);
    glColor3ub(63,188,240);
    glVertex2d(0, 504); //1
    glVertex2d(503,504); //2
    glVertex2d(503,523); //11
    glVertex2d(0,523); //11
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(523,504); //12
    glVertex2d(576,504); //2
    glVertex2d(576,523); //12
    glVertex2d(523,523); //2
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63,188,240);
    glVertex2d(593,504); //12
    glVertex2d(702,504); //2
    glVertex2d(702,523); //12
    glVertex2d(593,523); //2
    glEnd();
}

void garis2() {
    glBegin(GL_POLYGON);
    glColor3ub(63,188,240);
    glVertex2d(91, 541); //1
    glVertex2d(179,541); //2
    glVertex2d(179,558); //11
    glVertex2d(91,558); //11
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.08,0.08,0.08);
    glVertex2d(199,541); //12
    glVertex2d(270,541); //2
    glVertex2d(270,558); //12
    glVertex2d(199,558); //2
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63,188,240);
    glVertex2d(287,541); //12
    glVertex2d(791,541); //2
    glVertex2d(791,558); //12
    glVertex2d(287,558); //2
    glEnd();
}

//lingkaran

void circle(float size){
    int N =30;
    float pX, pY;
    glBegin(GL_POLYGON);
    glColor3f(0.94,0.9,0.19);
    for(int i=0; i<N; i++){
        pX = sin(i*2*3.14/N);
        pY = cos(i*2*3.14/N);
        glVertex2f(pX*size, pY*size);
    }
    glEnd();
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "Simple example", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,800,0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glColor3f(0.85f, 0.85f, 0.85f);
    glVertex2d(0, 0); //8
    glVertex2d(800, 0); //9
    glVertex2d(800, 800); //10
    glVertex2d(0, 800); //11
    glEnd();
    shadowh();
    h();
    shadowu();
    u();
    s();
    shadown();
    n();
    shadowa();
    a();
    garis();
    garis2();
    glfwSwapBuffers(window);
    glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
