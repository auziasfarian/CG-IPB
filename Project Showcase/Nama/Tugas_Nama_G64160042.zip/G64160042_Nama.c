#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void Belakang(){
    glBegin(GL_POLYGON);
    float cz = 255 - 255*cos(glfwGetTime());
    glColor3ub(cz,cz,cz);
    //glColor3ub(5,89,211);
    glVertex2d(0,0);
    float dz = 0 - 255*sin(glfwGetTime());
    glColor3ub(dz,dz,dz);
    //glColor3ub(255,255,255);
    glVertex2d(0,800);
    glVertex2d(800,800);
    glVertex2d(800,0);
    glEnd();
}

void Tenda(){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(10,240);
    glVertex2d(10,300);
    glVertex2d(416,193);
    glVertex2d(394,150);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(35,245);
    glVertex2d(27,283);
    glVertex2d(393,191);
    glVertex2d(384,170);
    glVertex2d(386,161);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(32,247);
    glVertex2d(32,253);
    glVertex2d(66,243);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(30,258);
    glVertex2d(30,267);
    glVertex2d(91,251);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(392,188);
    glVertex2d(388,180);
    glVertex2d(345,195);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(387,178);
    glVertex2d(384,169);
    glVertex2d(347,184);
    glEnd();
}

void Tenda1(){
glBegin(GL_POLYGON);
glColor3ub(116,76,40);
glVertex2d(385,193);
glVertex2d(407,149);
glVertex2d(791,244);
glVertex2d(792,302);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(138,93,59);
glVertex2d(773,287);
glVertex2d(766,262);
glVertex2d(766,248);
glVertex2d(415,161);
glVertex2d(416,170);
glVertex2d(418,191);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(116,76,40);
glVertex2d(416,170);
glVertex2d(415,177);
glVertex2d(454,184);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(116,76,40);
glVertex2d(456,196);
glVertex2d(413,181);
glVertex2d(409,189);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(116,76,40);
glVertex2d(767,251);
glVertex2d(767,256);
glVertex2d(735,246);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(116,76,40);
glVertex2d(709,254);
glVertex2d(770,262);
glVertex2d(772,272);
glEnd();
}

void Titik1(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+400,y+184);
    glVertex2d(x+396,y+186);
    glVertex2d(x+400,y+189);
    glVertex2d(x+403,y+186);
    glEnd();
}

void Titik(){
    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(400,184);
    glVertex2d(396,186);
    glVertex2d(400,189);
    glVertex2d(403,186);
    glEnd();
}

void I(int x){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+203,328);
    glVertex2d(x+251,333);
    glVertex2d(x+251,519);
    glVertex2d(x+195,525);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(x+211,338);
    glVertex2d(x+233,340);
    glVertex2d(x+241,338);
    glVertex2d(x+241,507);
    glVertex2d(x+205,515);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+212,337);
    glVertex2d(x+221,337);
    glVertex2d(x+217,361);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+225,338);
    glVertex2d(x+233,338);
    glVertex2d(x+228,359);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+238,510);
    glVertex2d(x+233,510);
    glVertex2d(x+235,493);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+227,511);
    glVertex2d(x+219,522);
    glVertex2d(x+222,482);
    glEnd();
}

void bar(int y){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(46,y+226);
    glVertex2d(2,y+282);
    glVertex2d(798,y+289);
    glVertex2d(791,y+240);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(758,y+280);
    glVertex2d(757,y+265);
    glVertex2d(767,y+249);
    glVertex2d(87,y+237);
    glVertex2d(77,y+250);
    glVertex2d(46,y+272);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(765,y+278);
    glVertex2d(765,y+269);
    glVertex2d(670,y+272);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(768,y+265);
    glVertex2d(768,y+257);
    glVertex2d(682,y+261);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(60,y+258);
    glVertex2d(60,y+250);
    glVertex2d(181,y+258);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(75,y+245);
    glVertex2d(80,y+240);
    glVertex2d(143,y+244);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(259,y+258);
    glVertex2d(462,y+257);
    glVertex2d(590,y+268);
    glEnd();
}

void H(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+259,y+461);
    glVertex2d(x+260,y+521);
    glVertex2d(x+425,y+499);
    glVertex2d(x+416,y+448);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(x+266,y+512);
    glVertex2d(x+297,y+508);
    glVertex2d(x+420,y+494);
    glVertex2d(x+411,y+456);
    glVertex2d(x+264,y+469);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+264,y+476);
    glVertex2d(x+265,y+482);
    glVertex2d(x+285,y+477);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+265,y+489);
    glVertex2d(x+265,y+496);
    glVertex2d(x+280,y+492);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+415,y+460);
    glVertex2d(x+415,y+468);
    glVertex2d(x+384,y+467);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+419,y+473);
    glVertex2d(x+420,y+480);
    glVertex2d(x+387,y+479);
    glEnd();
}

void M(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+467,y+333);
    glVertex2d(x+420,y+513);
    glVertex2d(x+476,y+530);
    glVertex2d(x+521,y+359);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(x+475,y+343);
    glVertex2d(x+428,y+508);
    glVertex2d(x+465,y+522);
    glVertex2d(x+514,y+363);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+475,y+343);
    glVertex2d(x+490,y+348);
    glVertex2d(x+483,y+376);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+499,y+355);
    glVertex2d(x+504,y+355);
    glVertex2d(x+491,y+378);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+461,y+520);
    glVertex2d(x+451,y+522);
    glVertex2d(x+462,y+488);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+444,y+515);
    glVertex2d(x+436,y+515);
    glVertex2d(x+449,y+479);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+465,y+461);
    glVertex2d(x+481,y+410);
    glVertex2d(x+486,y+430);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+468,y+396);
    glVertex2d(x+450,y+454);
    glVertex2d(x+462,y+428);
    glEnd();
}

void m(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+655,y+524);
    glVertex2d(x+700,y+491);
    glVertex2d(x+630,y+344);
    glVertex2d(x+577,y+363);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(138,93,59);
    glVertex2d(x+586,y+368);
    glVertex2d(x+627,y+353);
    glVertex2d(x+693,y+489);
    glVertex2d(x+658,y+514);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+663,y+512);
    glVertex2d(x+668,y+507);
    glVertex2d(x+653,y+486);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+673,y+503);
    glVertex2d(x+679,y+501);
    glVertex2d(x+668,y+480);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+599,y+362);
    glVertex2d(x+604,y+360);
    glVertex2d(x+609,y+380);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116,76,40);
    glVertex2d(x+609,y+359);
    glVertex2d(x+614,y+356);
    glVertex2d(x+621,y+377);
    glEnd();
}

int buff=0, clindex=0;
int colorctrl1[4][3]={{244, 205, 118},{255,255,255},{244, 205, 118},{255,255,255}};
int i=0,j=0,k=0,a=0;
const float DEG2RAD = 3.14159/180;
void circle(float radius, float jumlah_titik, float x_tengah, float y_tengah){
    glBegin(GL_POLYGON);
    int i;
    for(i=0; i<=360; i++){
        //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
        glColor3ub(colorctrl1[clindex%4][0],colorctrl1[clindex%4][1],colorctrl1[clindex%4][2]);
        //glColor3ub(0+i,0+j,0+k);
        float sudut = i*(2*3.14/jumlah_titik);
        float x = x_tengah+radius*cos(sudut);
        float y = y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}
void circle1(float radius, float jumlah_titik, float x_tengah, float y_tengah){
    glBegin(GL_POLYGON);
    int i;
    for(i=0; i<=360; i++){
        //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
        //glColor3ub(colorctrl1[clindex%4][0],colorctrl1[clindex%4][1],colorctrl1[clindex%4][2]);
        glColor3ub(0+i,0+j,0+k);
        float sudut = i*(2*3.14/jumlah_titik);
        float x = x_tengah+radius*cos(sudut);
        float y = y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}
int pecah=0;
void awan(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        //glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        glPushMatrix();
        glTranslated(pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        glPopMatrix();
    }
}

void awan1(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        //glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        glPushMatrix();
        glTranslated(-pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        glPopMatrix();
    }
}

void awankinton(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        //glPushMatrix();
        //glTranslated(pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        //glPopMatrix();
    }
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();// your code here, maybe
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Hilmi Farhan Ramadhani - <G64160042>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        Belakang();
        Tenda1(); // /|
        bar(0); // -
        Tenda(); // /|
        Titik1(-305,70); //-
        Titik1(275,70); //-

        I(-162); //H
        H(-235,-48); //H
        I(-82); //H
        I(0); //I
        H(0,0); //L
        I(84); //L
        M(120,0); // M
        m(-115,0); // M
        M(15,0); // M
        m(0,0); // M
        I(521); //I
        Titik1(-335,250); //H
        Titik1(-260,240); //H
        Titik1(-92,290); //L
        Titik1(100,200); //M
        Titik1(160,290); //M
        Titik1(215,200); //M
        Titik(0,0); //Tenda

        // Pagar
        M(-300,220); // M
        m(-420,220); // M

        M(-80,220); // M
        m(-200,220); // M

        M(140,220); // M
        m(20,220); // M

        //bar
        bar(340); // -
        bar(450); // -

        m(-535,220); // M
        M(-405,220); // M

        m(-315,220); // M
        M(-185,220); // M

        m(-95,220); // M
        M(35,220); // M

        M(255,220); // M

        Titik1(-345,510); //M

        Titik1(-320,420); //M
        Titik1(-260,510); //M
        Titik1(-205,410); //M

        Titik1(-125,510); //M

        Titik1(-100,420); //M
        Titik1(-40,510); //M
        Titik1(15,420); //M

        Titik1(95,510); //M

        Titik1(120,420); //M
        Titik1(180,510); //M
        Titik1(235,420); //M

        Titik1(310,510); //M

        Titik1(340,420); //M

        circle1(150, 70, 0, 0);
        awan1(780, 0);
        awan(-210, 60);
        awankinton(560, 60);

        if(a<190){
            a++;i++;j++;k++;
        }
        else if(a>=190){
            i--;j--;k--;
            a++;
            if(a==380){a=0;}
        }

        double currentTime = glfwGetTime();
        int ticks=0, c=0, b=0;
        while (currentTime / 1 > ticks) {
            ticks++;
            currentTime = glfwGetTime();
            c++;
            if(b<5){
                pecah++;
                b++;
            }
            else if(b>=5){
                pecah--;
                b++;
                if(b==10){
                    b=0;}
            }
            if(pecah==1000)
                pecah=0;

        }

        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%10;

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
