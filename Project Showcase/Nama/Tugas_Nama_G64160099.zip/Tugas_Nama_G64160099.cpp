#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your code here, maybe
    glBegin(GL_POLYGON);
    glVertex2f(106.11,482.93);
    glVertex2f(106.11,272.12);
    glVertex2f(122.86,288.76);
    glVertex2f(122.86,466.28);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(122.86,288.76);
    glVertex2f(106.11,272.12);
    glVertex2f(174.98,272.12);
    glVertex2f(185.89,276.27);
    glVertex2f(189.89,287.1);
    glVertex2f(170.34,288.76);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(170.34,353.3);
    glVertex2f(170.34,288.76);
    glVertex2f(189.89,287.1);
    glVertex2f(189.89,350.08);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(151.15,366.43);
    glVertex2f(170.34,353.5);
    glVertex2f(189.89,349.08);
    glVertex2f(182.48,364.17);
    glVertex2f(167.48,373.11);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(122.86,380.29);
    glVertex2f(122.86,366.43);
    glVertex2f(151.15,366.43);
    glVertex2f(151.1,380.29);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(151.1,380.29);
    glVertex2f(151.15,366.43);
    glVertex2f(167.48,373.11);
    glVertex2f(183.58,383.4);
    glVertex2f(192.68,396.95);
    glVertex2f(170.34,392.79);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(170.34,466.28);
    glVertex2f(170.34,392.79);
    glVertex2f(192.68,396.95);
    glVertex2f(192.68,469);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(175.53,482.93);
    glVertex2f(170.34,466.28);
    glVertex2f(192.68,469);
    glVertex2f(186.44,479.83);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(106.11,482.93);
    glVertex2f(122.86,466.28);
    glVertex2f(170.34,466.28);
    glVertex2f(175.53,482.93);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(215.02,485.15);
    glVertex2f(253.26,272.12);
    glVertex2f(262.39,304.27);
    glVertex2f(231.92,485.7);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(292.73,485.7);
    glVertex2f(253.26,272.12);
    glVertex2f(273.03,272.12);
    glVertex2f(310,485.7);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(239.86,435.77);
    glVertex2f(233.57,419.13);
    glVertex2f(281.07,419.13);
    glVertex2f(284.79,435.77);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(350.38,482.93);
    glVertex2f(339.4,478.73);
    glVertex2f(335.11,467.89);
    glVertex2f(335.11,413.58);
    glVertex2f(354.66,413.58);
    glVertex2f(354.66,466.28);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(350.38,482.93);
    glVertex2f(354.66,466.28);
    glVertex2f(399.34,466.28);
    glVertex2f(404.07,482.93);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(404.07,482.93);
    glVertex2f(399.34,466.28);
    glVertex2f(418.89,467.98);
    glVertex2f(414.78,478.75);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(399.34,466.28);
    glVertex2f(399.34,415.76);
    glVertex2f(413.1,403.48);
    glVertex2f(418.89,419.24);
    glVertex2f(418.89,467.98);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(80,109,18);
    glVertex2f(399.34,415.76);
    glVertex2f(413.1,403.48);
    glVertex2f(354.66,333.19);
    glVertex2f(335.11,328.95);
    glVertex2f(341.17,345.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(80,109,18);
    glVertex2f(335.11,328.95);
    glVertex2f(335.11,287.15);
    glVertex2f(339.39,276.31);
    glVertex2f(350.34,272.12);
    glVertex2f(354.66,288.76);
    glVertex2f(354.66,333.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(80,109,18);
    glVertex2f(354.66,288.76);
    glVertex2f(350.34,272.12);
    glVertex2f(403.93,272.12);
    glVertex2f(399.34,288.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(80,109,18);
    glVertex2f(399.34,335.91);
    glVertex2f(399.34,288.76);
    glVertex2f(403.93,272.12);
    glVertex2f(414.74,276.31);
    glVertex2f(418.89,287.15);
    glVertex2f(418.89,335.91);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(59,168,67);
    glVertex2f(480.33,402.3);
    glVertex2f(474.43,379.74);
    glVertex2f(467.29,358.59);
    glVertex2f(441.23,273.33);
    glVertex2f(441.73,272.12);
    glVertex2f(461.05,272.12);
    glColor3ub(163,224,54);
    glVertex2f(490.55,377.59);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(59,168,67);
    glVertex2f(480.33,401.3);
    glColor3ub(163,224,54);
    glVertex2f(490.55,377.59);
    glVertex2f(499.88,401.3);
    glVertex2f(499.88,482.93);
    glVertex2f(480.33,482.93);
    glColor3ub(163,224,54);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(490.55,377.59);
    glVertex2f(519.77,272.12);
    glColor3ub(59,168,67);
    glVertex2f(538.97,272.12);
    glVertex2f(538.97,273.33);
    glVertex2f(512.91,358.59);
    glVertex2f(499.88,401.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(198,16,34);
    glVertex2f(561.31,482.93);
    glColor3ub(216,111,38);
    glVertex2f(561.31,272.12);
    glVertex2f(580.86,272.12);
    glVertex2f(580.86,482.93);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(617.17,482.93);
    glColor3ub(226,12,7);
    glVertex2f(617.17,272.12);
    glVertex2f(636.73,288.76);
    glVertex2f(636.72,482.93);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,12,7);
    glVertex2f(636.73,288.76);
    glVertex2f(617.17,272.12);
    glVertex2f(688.61,272.12);
    glVertex2f(699.52,276.29);
    glVertex2f(703.74,287.07);
    glVertex2f(684.19,288.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,12,7);
    glVertex2f(703.74,367.08);
    glVertex2f(684.19,366.43);
    glVertex2f(684.19,288.76);
    glVertex2f(703.74,287.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,12,7);
    glVertex2f(703.74,367.08);
    glVertex2f(699.52,373.11);
    glVertex2f(688.61,382.3);
    glVertex2f(683.02,382.3);
    glVertex2f(677.02,382.1);
    glVertex2f(671.29,381.9);
    glVertex2f(648.03,370.19);
    glVertex2f(650.6,366.43);
    glVertex2f(684.19,366.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,12,7);
    glVertex2f(648.03,370.19);
    glVertex2f(671.29,381.9);
    glColor3ub(252,252,252);
    glVertex2f(707.97,482.93);
    glVertex2f(687.44,482.93);
    glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 480, "Tugas Nama - <G64160099>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
