// g++ -Wall -o "zaki" "zaki.cxx" -lglfw3 -lGL -lX11 -lXi -lXrandr -lXxf86vm -lXinerama -lXcursor -lrt -lm -pthread
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void background() {
    glBegin(GL_POLYGON);
        glColor3ub(0,191,191);
        glVertex2d(0, 0);
        glVertex2d(0, 800);
        glVertex2d(800, 800);
        glVertex2d(800, 0);
    glEnd();
}

void shape1() {
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(50.11, 41.57);
        glVertex2d(60.11, 41.57);
        glVertex2d(60.11, 241.57);
        glVertex2d(50.11, 241.57);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(70.72, 41.57);
        glVertex2d(65.72, 41.57);
        glVertex2d(65.72, 141.57);
        glVertex2d(70.72, 141.57);
    glEnd();
}

void shape2() {
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(650, 41.57);
        glVertex2d(750, 41.57);
        glVertex2d(750, 51.57);
        glVertex2d(650, 51.57);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(752, 41.57);
        glVertex2d(757, 41.57);
        glVertex2d(757, 141.57);
        glVertex2d(752, 141.57);
    glEnd();
}

void shape3() {
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(177.27, 433.04);
        glVertex2d(230.3, 380);
        glVertex2d(235.61, 385.31);
        glVertex2d(182.57, 438.34);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(292.44, 433.04);
        glVertex2d(239.41, 380);
        glVertex2d(234.11, 385.31);
        glVertex2d(287.14, 438.34);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(290.94, 433.04);
        glVertex2d(343.98, 380);
        glVertex2d(349.28, 385.31);
        glVertex2d(296.25, 438.34);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(406.12, 433.04);
        glVertex2d(353.08, 380);
        glVertex2d(347.78, 385.31);
        glVertex2d(400.81, 438.34);
    glEnd();

    // ====================================

    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(177.27, 433.04-30.0);
        glVertex2d(230.3, 380-30.0);
        glVertex2d(235.61, 385.31-30.0);
        glVertex2d(182.57, 438.34-30.0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(292.44, 433.04-30.0);
        glVertex2d(239.41, 380-30.0);
        glVertex2d(234.11, 385.31-30.0);
        glVertex2d(287.14, 438.34-30.0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(290.94, 433.04-30.0);
        glVertex2d(343.98, 380-30.0);
        glVertex2d(349.28, 385.31-30.0);
        glVertex2d(296.25, 438.34-30.0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(406.12, 433.04-30.0);
        glVertex2d(353.08, 380-30.0);
        glVertex2d(347.78, 385.31-30.0);
        glVertex2d(400.81, 438.34-30.0);
    glEnd();
}

void Z() {
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(177.27, 540.37);
        glVertex2d(319.02, 540.37);
        glVertex2d(299.74, 580.49);
        glVertex2d(177.27, 580.49);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(254.77, 580.49);
        glVertex2d(299.74, 580.49);
        glVertex2d(241.52, 701.62);
        glVertex2d(196.6, 701.62);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(196.6, 701.62);
        glVertex2d(319.02, 701.62);
        glVertex2d(319.02, 741.87);
        glVertex2d(177.27, 741.87);
    glEnd();
}

void A() {
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(329.02, 741.87);
        glVertex2d(420.9, 536.24);
        glVertex2d(421.02, 632.87);
        glVertex2d(372.77, 741.87);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(420.9, 536.24);
        glVertex2d(421.02, 632.87);
        glVertex2d(469.02, 741.87);
        glVertex2d(512.9, 741.87);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(440.4, 675.49);
        glVertex2d(410.33, 675.49);
        glVertex2d(394.4, 711.24);
        glVertex2d(456.4, 711.24);
    glEnd();
}

void K() {
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(530.4, 540.37);
        glVertex2d(570.77, 540.37);
        glVertex2d(570.77, 741.87);
        glVertex2d(530.4, 741.87);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(622.4, 540.37);
        glVertex2d(669.15, 540.37);
        glVertex2d(609.52, 642.74);
        glVertex2d(570.77, 657.37);
        glVertex2d(570.77, 629.49);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,255,0);
        glVertex2d(570.77, 657.37);
        glVertex2d(570.77, 629.49);
        glVertex2d(609.52, 642.74);
        glVertex2d(678.77, 741.87);
        glVertex2d(629.52, 741.87);
    glEnd();
}

void I() {
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(696.27, 540.37);
        glVertex2d(736.77, 540.37);
        glVertex2d(736.77, 706.12);
        glVertex2d(728.83, 706.12);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(696.27, 540.37);
        glVertex2d(728.83, 706.12);
        glVertex2d(712.83, 741.87);
        glVertex2d(696.27, 741.87);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(255,0,0);
        glVertex2d(736.77, 706.12);
        glVertex2d(736.77, 741.87);
        glVertex2d(720.83, 741.87);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "G64160046 Zaki Geyan", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800, 0, 1.f, -1.f);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        background();
        shape1();
        shape2();
        shape3();
        Z();
        A();
        K();
        I();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
