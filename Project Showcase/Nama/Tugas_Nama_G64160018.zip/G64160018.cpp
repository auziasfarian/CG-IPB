#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double xx=0,yy=0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,900,900,0, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void kembang_kecil(double x, double y, double z, double a, double b, double c) {
//kembang api
    glBegin(GL_POLYGON);
    glVertex2f(x , y);
    glVertex2f(z, a);
    glVertex2f(b, c);
    glEnd();
       }
void kembang_besar(double x, double y, double z, double a, double b, double c) {
//kembang api
    glBegin(GL_POLYGON);
    glVertex2f(x , y);
    glVertex2f(z , a);
    glVertex2f(b, c);
    glEnd();
       }
void circle(double x, double y){
    double posX=x, posY=y;
    glBegin(GL_POLYGON);
    for (int i=0; i <= 360; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(posX+cos(rad)*20,posY+sin(rad)*20);
        }
    glEnd();
}
void circle_kecil(double x, double y){
    double posX=x, posY=y;
    glBegin(GL_POLYGON);
    for (int i=0; i <= 360; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(posX+cos(rad)*12,posY+sin(rad)*12);
        }
    glEnd();
}

void display()
{
double s=156.39, b=107.88;
    //latar gambar
    glBegin(GL_POLYGON);
    glColor3ub(44,68,79);
    glVertex2f(-156.39+s, -107.88+b);
    glVertex2f(733.89+s,  -107.88+b);
    glVertex2f(733.89+s , 793.14+b);
    glVertex2f(-156.39+s , 793.14+b);
    glEnd();

    //N
    glBegin(GL_POLYGON);
    glColor3ub(206,136,127);
    glVertex2f(163.23+s ,131.08+b);
    glVertex2f(138.82+s, 201.51+b);
    glVertex2f(257.66+s,379.99+b);
    glVertex2f(281.72+s,311.68+b);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(206,136,127);
    glVertex2f(138.82+s,201.51+b);
    glVertex2f(179+s, 260.98+b);
    glVertex2f(83.02+s, 548.1+b);
    glVertex2f(27.22+s, 548.1+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(206,136,127);
    glVertex2f(245.26+s , 256.1+b);
    glVertex2f(281.72+s, 311.68+b);
    glVertex2f(365.01+s, 75.26+b);
    glVertex2f(311.38+s , 75.26+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,239,189);
    glVertex2f(163.23+s , 131.08+b);
    glVertex2f(178.45+s , 124.85+b);
    glVertex2f(252.61+s, 236.92+b);
    glVertex2f(245.26+s , 256.1+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,239,189);
    glVertex2f(311.38+s, 75.26+b);
    glVertex2f(365.01+s, 75.26+b);
    glVertex2f(380.22+s , 69.04+b);
    glVertex2f(326.6+s , 69.04+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,239,189);
    glVertex2f(365.01+s , 75.26+b);
    glVertex2f(380.22+s , 69.04+b);
    glVertex2f(272.88+s , 373.76+b);
    glVertex2f(257.66 +s, 379.99+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,239,189);
    glVertex2f(178+s , 257.98+b);
    glVertex2f(187.38+s , 274.05+b);
    glVertex2f(98.24+s , 541.88+b);
    glVertex2f(83.02+s , 548.1+b);
    glEnd();

//bagian A
    int i=-9.31;
    glBegin(GL_POLYGON);
    glColor3ub(226,172,136);
    glVertex2f(344.75-i+s , 260.08+b);
    glVertex2f(361.1-i+s , 260.08+b);
    glVertex2f(360.53-i+s , 289.42+b);
    glVertex2f(340.42-i+s , 388.49+b);
    glVertex2f(310.87-i +s, 388.49+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,172,136);
    glVertex2f(361.1-i +s, 260.08+b);
    glVertex2f(377.46-i+s , 260.08+b);
    glVertex2f(411.51-i+s, 388.49+b);
    glVertex2f(381.21-i+s , 388.49+b);
    glVertex2f(360.53-i+s , 289.42+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,172,136);
    glVertex2f(348.81-i+s, 343.96+b);
    glVertex2f(343.52-i+s , 367.04+b);
    glVertex2f(380.22-i+s, 367.04+b);
    glVertex2f(374.5-i+s , 343.96+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(182,112,116);
    glVertex2f(344.75+s , 260.08+b);
    glVertex2f(361.1+s , 260.08+b);
    glVertex2f(360.53+s , 289.42+b);
    glVertex2f(340.42+s , 388.49+b);
    glVertex2f(310.87+s , 388.49+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(182,112,116);
    glVertex2f(361.1+s , 260.08+b);
    glVertex2f(377.46+s , 260.08+b);
    glVertex2f(411.51+s, 388.49+b);
    glVertex2f(381.21+s , 388.49+b);
    glVertex2f(360.53+s , 289.42+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(182,112,116);
    glVertex2f(348.81+s, 343.96+b);
    glVertex2f(343.52+s , 367.04+b);
    glVertex2f(380.22+s, 367.04+b);
    glVertex2f(374.5+s , 343.96+b);
    glEnd();



    //bagian D
    glBegin(GL_POLYGON);
     glColor3ub(226,172,136);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(540.55+75+cos(rad)*64,324+b+sin(rad)*64);
        }
    glEnd();
    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(532+75+cos(rad)*64,324+b+sin(rad)*64);
        }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(44,68,79);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(515+75+cos(rad)*53,324+b+sin(rad)*41);
        }
    glEnd();



    //bagian kotak
    glBegin(GL_POLYGON);
    glColor3ub(182,112,116);
    glVertex2f(426+s , 260+b);
    glVertex2f(426+s, 388+b);
    glVertex2f(454.48+s, 388+b );
    glVertex2f(454.13+s , 260+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(450+s, 284.5+b);
    glVertex2f(462.07+s, 288.5+b);
    glVertex2f(462.07+s , 359+b );
    glVertex2f(450 +s, 362.9+b);
    glEnd();


    //bagian Y
    int n=17.5;
     //bagian kotak
     glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(154.81+n+s, 409+b);
    glVertex2f(187.42+n+s , 409+b);
    glVertex2f(220.03+n +s, 479.5+b);
    glVertex2f(187.42+n+s , 479.5+b);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(154.81+i+n+s , 409+b);
    glVertex2f(187.42+i+n +s, 409+b);
    glVertex2f(220.03+i+n+s, 479.5+b);
    glVertex2f(187.42+i +n+s, 479.5+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(220.03+n+s , 409+b);
    glVertex2f(205.47+n +s, 448.02+b);
    glVertex2f(220.03+n+s , 479.5+b);
    glVertex2f(254+n+s , 409+b);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(220.03+i+n+s , 409+b);
    glVertex2f(205.47+i+n+s , 448.02+b);
    glVertex2f(220.03+i+n+s , 479.5+b);
    glVertex2f(254+i+n+s , 409+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(187.42+n+s , 479.5+b);
    glVertex2f(220.03+n+s , 479.5+b);
    glVertex2f(220.03+n+s, 537.54+b);
    glVertex2f(187.42+n+s , 537.54+b);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(187.42+i+n+s , 479.5+b);
    glVertex2f(220.03+i+n+s , 479.5+b);
    glVertex2f(220.03+i+n+s, 537.54+b);
    glVertex2f(187.42+i+n+s , 537.54+b);
    glEnd();



    //bagian A

     glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(283.38+n+s , 409+b);
    glVertex2f(297.64+n+s , 438.5+b);
    glVertex2f(279+n+s , 537.54+b);
    glVertex2f(248+n+s ,  537.54+b);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226,171,136);
    glVertex2f(283.38+n+s , 409+b);
    glVertex2f(297.64+n+s , 438.5+b);
    glVertex2f(319.39+n+s , 537.54+b);
    glVertex2f(349.5+n+s , 537.54+b);
    glVertex2f(315.5+n+s , 409+b);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(283.38+i+n+s , 409+b);
    glVertex2f(297.64+i+n+s , 415.5+b);
    glVertex2f(319.39+i+n+s , 537.54+b);
    glVertex2f(349.5+i+n+s , 537.54+b);
    glVertex2f(315.5+i+n+s , 409+b);
    glEnd();


    glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(283.38+i+n+s , 409+b);
    glVertex2f(297.64+i+n+s , 438.5+b);
    glVertex2f(279+i+n+s , 537.54+b);
    glVertex2f(248+i+n+s ,  537.54+b);
    glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(182,112,116);
    glVertex2f(287.67+i+n+s , 491.44+b);
    glVertex2f(309.4+n+s , 491.44+b);
    glVertex2f(314.91+n+s , 517.13+b);
    glVertex2f(282.37+i+n+s , 517.13+b);
    glEnd();


}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(900, 900, "Tugas Nama - G64160018", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
     double  c=224.0;
        int  s=130,y=130,e=0, d=0, a=251, b=247;

    while (!glfwWindowShouldClose(window))
    {

        setup_viewport(window);

        display();

        if(e==0){
        d++;
        d=d%100;
        }
        e++;
        e=e%1;

        if(b==0){
        a++;
        a=a%100;
        }
        b++;
        b=b%1;

     //besar
    glColor3ub(a,b,d);
    circle(636.8+xx, 50.98-yy);
    circle(208.03-xx, 102.82-yy);
    circle(70.63-xx, 434.19);
    circle(224.79-xx, 819.86+yy);
    circle(579.43+xx, 805.39+yy);
    circle(760.58+xx, 679+yy);
    circle(838.14+xx, 518.93);
    circle(764.97+xx, 206.59-yy);
    kembang_besar(560.89+xx , 140.29-yy, 652.25+xx , 64.3-yy, 621.35+xx, 37.65-yy);
    kembang_besar(288.87-xx, 189.78-yy, 192.77-xx, 116.37-yy, 223.28-xx, 89.27-yy);
    kembang_besar(185.91-xx, 459.36, 74.86-xx, 414.37, 66.4-xx, 454.01);
    kembang_besar(287.31-xx , 720.98+yy, 207.34-xx, 809.2+yy, 242.24-xx, 830.51+yy);
    kembang_besar(510.22+xx, 710.62+yy,562.89+xx, 817.29+yy, 595.98+xx, 793.49+yy);
    kembang_besar(674.08+xx, 599.71+yy, 746.71+xx, 693.93+yy, 774.46+xx, 664.08+yy);
    kembang_besar(721.18+xx, 504.39, 840.4+xx, 498.76, 835.87+xx, 539.09);
    kembang_besar(660.16+xx, 260.16-yy, 774.47+xx, 224.55-yy, 755.46+xx, 188.63-yy);


    if (xx <= 200) {
    xx+=0.75;
    yy+=0.75;
    }

    else{
        xx=0;
        yy=0;
    }

    //kecil
    glColor3ub(a,d,d);
    circle_kecil(374.38, 72.13);
    circle_kecil(117.47, 251.55);
    circle_kecil(72.93,664.58);
    circle_kecil(415.91, 793.87);
    circle_kecil(792.07, 357.53);
    kembang_kecil(397.01, 129.88, 365.27, 80.13, 385.95, 67.68);
    kembang_kecil(173.54, 278.87, 112.06, 262.62, 122.88, 240.47);
    kembang_kecil(131.24, 643.02, 77.42, 676.11, 68.44, 653.06);
    kembang_kecil(423.72, 731.96, 405.14, 788.37, 428.15, 795.28);
    kembang_kecil(731.14, 370.96, 789.29, 345.52, 794.85, 369.53);


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    exit(EXIT_SUCCESS);
}
