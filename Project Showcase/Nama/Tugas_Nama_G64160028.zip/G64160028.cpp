#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;
int colorf[3][3]={{147,9,32},{239,80,0},{0,0,0}};


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear (GL_COLOR_BUFFER_BIT);

    glFlush();
}

void Background()
{
    glBegin(GL_POLYGON);
    glColor3ub(225,225,225);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(0,0,0);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

    glBegin(GL_POLYGON);
}

void segi6()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(296,216);
    glVertex2d(495,216);
    glVertex2d(594,395);
    glVertex2d(495,575);
    glVertex2d(296,575);
    glVertex2d(197,395);

    glEnd();

    glBegin(GL_POLYGON);
}

void s31()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(80,210);
    glVertex2d(301,214);
    glVertex2d(201,395);

    glEnd();

    glBegin(GL_POLYGON);
}

void s32()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(397,23);
    glVertex2d(495,219);
    glVertex2d(296,218);

    glEnd();

    glBegin(GL_POLYGON);
}

void s33()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(494,215);
    glVertex2d(712,212);
    glVertex2d(594,395);

    glEnd();

    glBegin(GL_POLYGON);
}

void s34()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(593,392);
    glVertex2d(716,574);
    glVertex2d(495,574);

    glEnd();

    glBegin(GL_POLYGON);
}

void s35()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(298,574);
    glVertex2d(498,574);
    glVertex2d(398,771);

    glEnd();

    glBegin(GL_POLYGON);
}

void s36()
{
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(81,576);
    glVertex2d(197,395);
    glVertex2d(296,574);

    glEnd();

    glBegin(GL_POLYGON);
}

void s361()
{
    glBegin(GL_POLYGON);

    glColor3ub(249,11,11);
    glVertex2d(209,85);
    glVertex2d(396,172);
    glColor3ub(0,0,0);
    glVertex2d(224,291);


    glEnd();

    glBegin(GL_POLYGON);
}

void s362()
{
    glBegin(GL_POLYGON);

    glColor3ub(249,11,11);
    glVertex2d(397,172);
    glVertex2d(589,74);
    glColor3ub(0,0,0);
    glVertex2d(591,290);
    glEnd();

    glBegin(GL_POLYGON);
}

void s363()
{
    glBegin(GL_POLYGON);

    glColor3ub(249,11,11);
    glVertex2d(591,290);
    glVertex2d(773,392);
    glColor3ub(0,0,0);
    glVertex2d(591,494);

    glEnd();

    glBegin(GL_POLYGON);
}

void s364()
{
    glBegin(GL_POLYGON);

   glColor3ub(249,11,11);
    glVertex2d(397,597);
    glVertex2d(592,492);
    glColor3ub(0,0,0);
    glVertex2d(580,703);

    glEnd();

    glBegin(GL_POLYGON);
}

void s365()
{
    glBegin(GL_POLYGON);

    glColor3ub(249,11,11);
    glVertex2d(224,491);
    glVertex2d(397,597);
    glColor3ub(0,0,0);
    glVertex2d(218,696);

    glEnd();

    glBegin(GL_POLYGON);
}

void s366()
{
    glBegin(GL_POLYGON);

   glColor3ub(249,11,11);
    glVertex2d(35,392);
    glVertex2d(224,290);
    glColor3ub(0,0,0);
    glVertex2d(224,494);

    glEnd();

    glBegin(GL_POLYGON);

}

void v1()
{
    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(21,23);
    glVertex2d(43,23);
    glVertex2d(43,195);
    glVertex2d(21,195);

    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(21,21);
    glVertex2d(193,21);
    glVertex2d(193,43);
    glVertex2d(21,43);

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(21,23);
    glVertex2d(43,23);
    glVertex2d(43,195);
    glVertex2d(21,195);

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(21,21);
    glVertex2d(193,21);
    glVertex2d(193,43);
    glVertex2d(21,43);
    glEnd();
}

void v2()
{
    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(605,21);
    glVertex2d(777,21);
    glVertex2d(777,43);
    glVertex2d(605,43);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(779,23);
    glVertex2d(779,195);
    glVertex2d(757,195);
    glVertex2d(757,23);

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(605,21);
    glVertex2d(777,21);
    glVertex2d(777,43);
    glVertex2d(605,43);


    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(779,23);
    glVertex2d(779,195);
    glVertex2d(757,195);
    glVertex2d(757,23);

    glEnd();
}

void v3()
{
    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(757,610);
    glVertex2d(779,610);
    glVertex2d(779,782);
    glVertex2d(757,782);

    glBegin(GL_POLYGON);
    glEnd();

    glColor3ub(127,6,6);
    glVertex2d(777,760);
    glVertex2d(777,782);
    glVertex2d(605,782);
    glVertex2d(605,760);


    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(757,610);
    glVertex2d(779,610);
    glVertex2d(779,782);
    glVertex2d(757,782);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(777,760);
    glVertex2d(777,782);
    glVertex2d(605,782);
    glVertex2d(605,760);

    glEnd();
}

void v4()
{
    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(21,610);
    glVertex2d(43,610);
    glVertex2d(43,782);
    glVertex2d(21,782);

    glBegin(GL_POLYGON);
    glEnd();
    glColor3ub(127,6,6);
    glVertex2d(21,782);
    glVertex2d(21,760);
    glVertex2d(193,760);
    glVertex2d(193,782);


    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(21,610);
    glVertex2d(43,610);
    glVertex2d(43,782);
    glVertex2d(21,782);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(21,782);
    glVertex2d(21,760);
    glVertex2d(193,760);
    glVertex2d(193,782);

    glEnd();
}

void M()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(251,364);
    glVertex2d(261,364);
    glVertex2d(252,415);
    glColor3ub(0,0,0);
    glVertex2d(245,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(251,364);
    glVertex2d(261,364);
    glVertex2d(273,406);
    glColor3ub(0,0,0);
    glVertex2d(269,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(287,364);
    glVertex2d(296,364);
    glVertex2d(275,415);
    glColor3ub(0,0,0);
    glVertex2d(269,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(287,364);
    glVertex2d(296,364);
    glVertex2d(300,415);
    glColor3ub(0,0,0);
    glVertex2d(293,415);

    glEnd();
}

void O(double poX, double poY, double rad) {
    double cons=(3.14/100);
    double px,py;
    double posX=poX, posY=poY;
    double radius1=0;
    double radius2=rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(int i=0;i<=360;i++)
        {
            px=sin(i*cons)*radius1+posX;
            py=cos(i*cons)*radius1+posY;
            glVertex2f(px,py);
            px=sin(i*cons)*radius2+posX;
            py=cos(i*cons)*radius2+posY;
            glVertex2f(px,py);
        }
    glEnd();
}

void O2() {
    glColor3ub(244,75,0);
    O(333,390,27);
}

void O3() {
    glColor3ub(0,0,0);
    O(333,390,20);

}

void N()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(367,364);
    glVertex2d(374,364);
    glVertex2d(373,415);
    glColor3ub(0,0,0);
    glVertex2d(367,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(367,364);
    glVertex2d(374,364);
    glVertex2d(405,415);
    glColor3ub(0,0,0);
    glVertex2d(400,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(399,364);
    glVertex2d(405,364);
    glVertex2d(405,415);
    glColor3ub(0,0,0);
    glVertex2d(400,415);

    glEnd();
}

void I()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(419,364);
    glVertex2d(427,364);
    glVertex2d(427,415);
    glColor3ub(0,0,0);
    glVertex2d(419,415);

    glEnd();
}
void T()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(435,364);
    glVertex2d(472,364);
    glVertex2d(472,370);
    glColor3ub(0,0,0);
    glVertex2d(434,370);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(450,369);
    glVertex2d(457,369);
    glVertex2d(457,415);
    glColor3ub(0,0,0);
    glVertex2d(450,415);

    glEnd();
}

void H()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(480,364);
    glVertex2d(487,364);
    glVertex2d(487,415);
    glColor3ub(0,0,0);
    glVertex2d(480,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(487,386);
    glVertex2d(510,386);
    glVertex2d(510,391);
    glColor3ub(0,0,0);
    glVertex2d(487,391);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(509,364);
    glVertex2d(517,364);
    glVertex2d(517,415);
    glColor3ub(0,0,0);
    glVertex2d(509,415);

    glEnd();
}

void A()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(524,415);
    glVertex2d(544,364);
    glVertex2d(552,364);
    glColor3ub(0,0,0);
    glVertex2d(532,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(255,91,0);
    glVertex2d(544,364);
    glVertex2d(552,364);
    glVertex2d(571,415);
    glColor3ub(0,0,0);
    glVertex2d(563,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(244,75,0);
    glVertex2d(538,393);
    glVertex2d(557,393);
    glVertex2d(558,398);
    glColor3ub(0,0,0);
    glVertex2d(536,398);

    glEnd();
}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Annisa Monitha - <G64160028>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        setup_viewport(window);

        display();

        Background();
        segi6();
        s31();
        s32();
        s33();
        s34();
        s35();
        s36();
        s361();
        s362();
        s363();
        s364();
        s365();
        s366();
        M();
        O2();
        O3();
        N();
        I();
        T();
        H();
        A();
        v1();
        v2();
        v3();
        v4();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
