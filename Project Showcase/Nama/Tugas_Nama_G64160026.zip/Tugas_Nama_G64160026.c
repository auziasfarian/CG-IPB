#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

const double PI = 3.141592653589793;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,800,0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void bg (){
    glBegin(GL_POLYGON);
    glColor3ub(52,38,71);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glVertex2d(800,800);
    glVertex2d(0,800);
    glEnd();}

void tri (){
    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(777,605);
    glVertex2d(800,605);
    glVertex2d(800,651);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(652,600);
    glVertex2d(723,596);
    glVertex2d(695,637);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(727,644);
    glVertex2d(737,706);
    glVertex2d(667,688);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235);
    glVertex2d(660,705);
    glVertex2d(786,731);
    glVertex2d(665,793);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3);
    glVertex2d(649,679);
    glVertex2d(649,783);
    glVertex2d(566,726);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,51,93); //pink
    glVertex2d(661,627);
    glVertex2d(574,715);
    glVertex2d(543,611);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235);
    glVertex2d(515,602);
    glVertex2d(566,715);
    glVertex2d(429,679);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,51,93); //pink
    glVertex2d(551,711);
    glVertex2d(491,759);
    glVertex2d(462,689);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3);
    glVertex2d(493,611);
    glVertex2d(391,692);
    glVertex2d(400,583);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(566,715);
    glVertex2d(567,800);
    glVertex2d(495,800);
    glVertex2d(466,778);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(414,679);
    glVertex2d(466,778);
    glVertex2d(330,748);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(60,623);
    glVertex2d(77,725);
    glVertex2d(0,700);
    glVertex2d(0,661);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(761,747);
    glVertex2d(800,737);
    glVertex2d(800,786);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(161,715);
    glVertex2d(140,808);
    glVertex2d(75,741);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(75,741);
    glVertex2d(75,800);
    glVertex2d(-20,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(30,579);
    glVertex2d(0,623);
    glVertex2d(0,581);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(763,623);
    glVertex2d(850,722);
    glVertex2d(753,722);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(99,725);
    glVertex2d(0,776);
    glVertex2d(0,706);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(66,753);
    glVertex2d(161,800);
    glVertex2d(75,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(202,623);
    glVertex2d(267,666);
    glVertex2d(172,710);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(277,635);
    glVertex2d(373,669);
    glVertex2d(286,744);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(391,571);
    glVertex2d(391,692);
    glVertex2d(300,632);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(110,238,235); // biru
    glVertex2d(449,787);
    glVertex2d(428,800);
    glVertex2d(352,800);
    glVertex2d(330,726);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(328,710);
    glVertex2d(340,800);
    glVertex2d(252,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,51,93); //pink
    glVertex2d(77,616);
    glVertex2d(161,715);
    glVertex2d(66,715);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,51,93); //pink
    glVertex2d(186,714);
    glVertex2d(254,745);
    glVertex2d(178,784);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(200,600);
    glVertex2d(154,722);
    glVertex2d(96,606);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(761,747);
    glVertex2d(762,800);
    glVertex2d(665,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(108,77,153); //ungu
    glVertex2d(566,726);
    glVertex2d(663,815);
    glVertex2d(570,815);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(245,158,3); //orange
    glVertex2d(278,650);
    glVertex2d(290,748);
    glVertex2d(180,710);
    glEnd();

}

void A (){
    glBegin(GL_POLYGON);
    glColor3ub(16,170,227);
    glVertex2d(230,310);
    glVertex2d(282,431);
    glVertex2d(250,447);
    glVertex2d(202,315);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(16,170,227);
    glVertex2d(230,310);
    glVertex2d(200,461);
    glVertex2d(157,443);
    glVertex2d(202,315);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(16,170,227);
    glVertex2d(262,384);
    glVertex2d(272,408);
    glVertex2d(161,431);
    glVertex2d(171,404);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(233,316);
    glVertex2d(237,328);
    glVertex2d(192,344);
    glVertex2d(199,324);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(241,336);
    glVertex2d(246,347);
    glVertex2d(186,362);
    glVertex2d(190,351);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(252,360);
    glVertex2d(256,370);
    glVertex2d(227,379);
    glVertex2d(223,370);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(217,370);
    glVertex2d(216,383);
    glVertex2d(175,391);
    glVertex2d(181,376);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(262,384);
    glVertex2d(267,398);
    glVertex2d(166,418);
    glVertex2d(171,404);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(272,408);
    glVertex2d(277,421);
    glVertex2d(245,431);
    glVertex2d(237,415);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,87,152);
    glVertex2d(210,422);
    glVertex2d(205,437);
    glVertex2d(157,443);
    glVertex2d(161,431);
    glEnd();
}
void D1 (){

    int N = 30;
    float pX, pY;
    glTranslatef(332.0f,383.0f,0.f);
    glColor3ub(237,13,129);
    glBegin(GL_POLYGON);
    for(int i = 0; i <= N/2; i++){
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * 66, pY * 66);
    }
    glEnd();
}

void D2 (){

    int N = 30;
    float pX, pY;
    glColor3ub(52,38,71);
    glBegin(GL_POLYGON);
    for(int i = 0; i <= N/2; i++){
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * 40, pY * 40);
    }
    glEnd();
}


void D (){
    glBegin(GL_POLYGON);
    glColor3ub(237,13,129);
    glVertex2d(341,313);
    glVertex2d(341,454);
    glVertex2d(310,454);
    glVertex2d(310,313);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,0,100);
    glVertex2d(320,313);
    glVertex2d(320,454);
    glVertex2d(315,454);
    glVertex2d(315,313);
    glEnd();


}

void E (){
    glBegin(GL_POLYGON);
    glColor3ub(235,39,60);
    glVertex2d(522,307);
    glVertex2d(522,345);
    glVertex2d(429,345);
    glVertex2d(429,306);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(50,53,145);
    glVertex2d(522,326);
    glVertex2d(522,345);
    glVertex2d(429,345);
    glVertex2d(429,326);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(235,39,60);
    glVertex2d(462,345);
    glVertex2d(462,370);
    glVertex2d(429,370);
    glVertex2d(429,345);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(50,53,145);
    glVertex2d(492,370);
    glVertex2d(492,400);
    glVertex2d(429,400);
    glVertex2d(429,370);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(235,39,60);
    glVertex2d(464,400);
    glVertex2d(464,416);
    glVertex2d(429,416);
    glVertex2d(429,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(50,53,145);
    glVertex2d(516,416);
    glVertex2d(516,458);
    glVertex2d(429,458);
    glVertex2d(429,416);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(235,39,60);
    glVertex2d(516,441);
    glVertex2d(516,458);
    glVertex2d(429,458);
    glVertex2d(429,441);
    glEnd();
}

void L (){
    glBegin(GL_POLYGON);
    glColor3ub(248,234,39);
    glVertex2d(585,306);
    glVertex2d(589,420);
    glVertex2d(554,460);
    glVertex2d(546,308);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(240,127,47);
    glVertex2d(620,419);
    glVertex2d(621,457);
    glVertex2d(554,460);
    glVertex2d(589,420);
    glEnd();

    //garis zig zag
    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(562,308);
    glVertex2d(572,329);
    glVertex2d(570,331);
    glVertex2d(557,308);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(572,329);
    glVertex2d(563,356);
    glVertex2d(559,356);
    glVertex2d(570,331);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(563,356);
    glVertex2d(579,376);
    glVertex2d(574,376);
    glVertex2d(559,356);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(579,376);
    glVertex2d(566,400);
    glVertex2d(560,400);
    glVertex2d(574,376);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(566,400);
    glVertex2d(578,416);
    glVertex2d(574,418);
    glVertex2d(560,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(578,416);
    glVertex2d(567,438);
    glVertex2d(563,438);
    glVertex2d(574,418);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,161,84);
    glVertex2d(567,438);
    glVertex2d(580,459);
    glVertex2d(576,459);
    glVertex2d(563,438);
    glEnd();
}
int main(void)
{
    float radius;
    int i;
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(600, 600, "Tugas Nama - G64160026", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        bg();
        tri();
        glPushMatrix();
        glRotatef((float) glfwGetTime() * 20.f, 0.f, 0.f, 0.f);
        A();
        D();
        E();
        L();
        D1();
        D2();
        glPopMatrix();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
