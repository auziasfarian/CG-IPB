#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>

int clindex=0,buff=0;
int colorf[3][3]={{255,255,255},{0,0,0},{68,226,214}};
int llindex=0,luff=0;
int colorl[3][3]={{249,82,133},{68,226,214},  {249,82,133}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.0f, -1.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_POLYGON);
    glColor3ub(249,82,133);
    glVertex2d(0,0);
    glColor3ub(249,82,133);
    glVertex2d(800,0);
    glColor3ub(249,82,133);
    glVertex2d(800,800);
    glColor3ub(249,82,133);
    glVertex2d(0,800);
    glEnd();
    glFlush();


}

void Hijau() {
  glBegin(GL_POLYGON);
  glColor3ub(68,226,214);
  glVertex2d(0,336);
  glVertex2d(0,800);
  glVertex2d(194,524);
  glVertex2d(800,457);
  glVertex2d(619,204);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(619,204);
  glVertex2d(800,457);
  glVertex2d(800,0);
  glEnd();
}


void Chat() {
  glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
  glVertex2d(149,157);
  glVertex2d(133,377);
  glVertex2d(646,390);
  glVertex2d(633,90);
  glEnd();
}

void Ekor() {
  glBegin(GL_POLYGON);
  glColor3ub(232,219,221);
  glVertex2d(133,377);
  glVertex2d(474,357);
  glVertex2d(439,489);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(232,219,221);
  glVertex2d(439,489);
  glVertex2d(322,447);
  glVertex2d(263,523);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(232,219,221);
  glVertex2d(318,606);
  glVertex2d(263,523);
  glVertex2d(315,507);
  glEnd();
}

void Bayangan() {
  glBegin(GL_POLYGON);
  glColor3ub(72,198,186);
  glVertex2d(149+10,157+10);
  glVertex2d(133+10,377+10);
  glVertex2d(646+10,390+10);
  glVertex2d(633+10,90+10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(72,198,186);
  glVertex2d(133+10,377+10);
  glVertex2d(474+10,357+10);
  glVertex2d(439+10,489+10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(72,198,186);
  glVertex2d(439+10,489+10);
  glVertex2d(322+10,447+10);
  glVertex2d(263+10,523+10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(72,198,186);
  glVertex2d(318+10,606+10);
  glVertex2d(263+10,523+10);
  glVertex2d(315+10,507+10);
  glEnd();
}

void Y1(){
 glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(271,215);
  glVertex2d(271,232);
  glVertex2d(283,231);
  glVertex2d(282,214);
  glVertex2d(292,164);
  glVertex2d(281,166);
  glVertex2d(276,197);
  glVertex2d(271,167);
  glVertex2d(260,168);
  glEnd();
}

void A1(){  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(339,227);
  glVertex2d(351,227);
  glVertex2d(356,182);
  glVertex2d(362,156);
  glVertex2d(348,157);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(375,225);
  glVertex2d(362,226);
  glVertex2d(356,182);
  glVertex2d(348,157);
  glVertex2d(362,156);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(353,207);
  glVertex2d(352,218);
  glVertex2d(361,217);
  glVertex2d(359,206);
  glEnd();
}

void M2(){
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(225+152,173-20);
  glVertex2d(235+152,171-20);
  glVertex2d(235+152,234-10);
  glVertex2d(226+152,235-10);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(235+152,171-20);
  glVertex2d(399,204-10);
  glVertex2d(399,229-10);
  glVertex2d(235+152,204-10);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(405,170-20);
  glVertex2d(407,203-20);
  glVertex2d(399,229-10);
  glVertex2d(399,204-10);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(405,170-20);
  glVertex2d(420,168-20);
  glVertex2d(422,232-10);
  glVertex2d(406,233-10);
  glEnd();
}

void N1(){
      glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(305,163);
  glVertex2d(306,229);
  glVertex2d(317,229);
  glVertex2d(316,201);
  glVertex2d(323,228);
  glVertex2d(322,188);
  glVertex2d(316,161);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(316,201);
  glVertex2d(322,188);
  glVertex2d(322,160);
  glVertex2d(334,159);
  glVertex2d(335,228);
  glVertex2d(323,228);
  glEnd();
}

void M1(){
      glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(225,173);
  glVertex2d(235,171);
  glVertex2d(235,234);
  glVertex2d(226,235);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(235,171);
  glVertex2d(241,197);
  glVertex2d(242,229);
  glVertex2d(235,204);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(246,170);
  glVertex2d(248,203);
  glVertex2d(242,229);
  glVertex2d(235,204);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(246,170);
  glVertex2d(257,168);
  glVertex2d(258,232);
  glVertex2d(248,233);
  glEnd();
}

void E1(){
      glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glBegin(GL_POLYGON);
  glVertex2d(425,148);
  glVertex2d(427,222);
  glVertex2d(442,222);
  glVertex2d(440,146);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(440,146);
  glVertex2d(453,144);
  glVertex2d(456,158);
  glVertex2d(440,160);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(441,178);
  glVertex2d(453,178);
  glVertex2d(453,189);
  glVertex2d(441,190);
  glEnd();

  glBegin(GL_POLYGON);
  glVertex2d(455,220);
  glVertex2d(457,206);
  glVertex2d(442,207);
  glVertex2d(442,221);
  glEnd();
}

void I1(){
  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(476,219);
  glVertex2d(492,218);
  glVertex2d(489,140);
  glVertex2d(474,142);
  glEnd();
}
void I(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(349,247);
  glVertex2d(351,354);
  glVertex2d(370,354);
  glVertex2d(367,246);
  glEnd();
}
void S1(){
  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(499,203);
  glVertex2d(502,217);
  glVertex2d(522,216);
  glVertex2d(532,212);
  glVertex2d(518,199);
  glVertex2d(516,210);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(532,212);
  glVertex2d(518,199);
  glVertex2d(517,185);
  glVertex2d(517,183);
  glVertex2d(525,169);
  glVertex2d(531,170);
  glVertex2d(533,176);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(525,169);
  glVertex2d(517,183);
  glVertex2d(503,184);
  glVertex2d(500,183);
  glVertex2d(498,180);
  glVertex2d(512,168);
  glVertex2d(513,169);
  glVertex2d(515,170);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(498,180);
  glVertex2d(512,168);
  glVertex2d(512,153);
  glVertex2d(514,152);
  glVertex2d(506,138);
  glVertex2d(498,141);
  glVertex2d(496,149);
  glVertex2d(497,176);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(colorl[(llindex+1)%3][0],colorl[(llindex+1)%3][1],colorl[(llindex+1)%3][2]);
  glVertex2d(514,152);
  glVertex2d(506,138);
  glVertex2d(529,135);
  glVertex2d(532,149);
  glEnd();
}

void A(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(265,354);
  glVertex2d(251,258);
  glVertex2d(235,256);
  glVertex2d(242,291);
  glVertex2d(249,354);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(220,354);
  glVertex2d(235,256);
  glVertex2d(251,258);
  glVertex2d(242,291);
  glVertex2d(235,354);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(235,326);
  glVertex2d(251,326);
  glVertex2d(251,341);
  glVertex2d(235,342);
  glEnd();
}

void As (){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(476,353);
  glVertex2d(451,240);
  glVertex2d(429,241);
  glVertex2d(442,281);
  glVertex2d(454,354);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(436,354);
  glVertex2d(442,281);
  glVertex2d(451,240);
  glVertex2d(429,241);
  glVertex2d(416,354);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(429,321);
  glVertex2d(451,321);
  glVertex2d(451,339);
  glVertex2d(429,339);
  glEnd();
}

void L(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(270,253);
  glVertex2d(286,252);
  glVertex2d(286,335);
  glVertex2d(270,354);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(304,334);
  glVertex2d(301,354);
  glVertex2d(270,354);
  glVertex2d(286,335);
  glEnd();
}
void H(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(497,236);
  glVertex2d(476,238);
  glVertex2d(482,353);
  glVertex2d(504,353);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(501,306);
  glVertex2d(500,285);
  glVertex2d(522,285);
  glVertex2d(514,305);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(509,235);
  glVertex2d(517,353);
  glVertex2d(540,353);
  glVertex2d(532,233);
  glEnd();

}

void Hiasan(){ {
    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glTranslatef(24,20,0);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
}
    {

       glPushMatrix();
       glTranslatef(24,20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(24,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);;
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(-20,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);;
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(-20,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glTranslatef(24,20,0);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }
}

void Hiasan2(){ glTranslatef(530,-70,0); {
    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glTranslatef(24,20,0);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
}
    {

       glPushMatrix();
       glTranslatef(24,20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(24,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);;
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(-20,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);;
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(-20,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glTranslatef(24,20,0);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }
}

void Hiasan3(){ glTranslatef(-500,650,0); {
    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glTranslatef(24,20,0);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
}
    {

       glPushMatrix();
       glTranslatef(24,20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(24,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);;
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(-20,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);;
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(-20,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glTranslatef(24,20,0);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }
}

void Hiasan4(){ glTranslatef(400,-20,0); {
    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glTranslatef(24,20,0);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
}
    {

       glPushMatrix();
       glTranslatef(24,20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(24,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(24,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);;
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }

        {

       glPushMatrix();
       glTranslatef(-20,-20,0);
        glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);;
        glVertex2d(67.86,135.76);
        glVertex2d(73.88,132.92);
        glVertex2d(80.26,133.16);
        glVertex2d(85.93,136.7);
        glVertex2d(79.91,139.54);
        glVertex2d(73.53,139.3);
        glEnd();
    glPopMatrix();

    glTranslatef(-20,-20,0);
    glBegin(GL_POLYGON);
        glPushMatrix();
        glTranslatef(24,20,0);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(77.31,127.25);
        glVertex2d(80.26,133.16);
        glVertex2d(79.91,139.54);
        glVertex2d(76.48,145.21);
        glVertex2d(73.53,139.3);
        glVertex2d(73.53,132.92);
        glPopMatrix();
     glEnd();
    }
}


void Ls(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(308,250);
  glVertex2d(309,354);
  glVertex2d(327,334);
  glVertex2d(326,249);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(309,354);
  glVertex2d(327,334);
  glVertex2d(345,334);
  glVertex2d(342,354);
  glEnd();
}
void F(){
  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(374,245);
  glVertex2d(377,354);
  glVertex2d(397,354);
  glVertex2d(394,264);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(374,245);
  glVertex2d(411,243);
  glVertex2d(415,263);
  glVertex2d(394,264);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(0,0,0);
  glVertex2d(395,290);
  glVertex2d(411,289);
  glVertex2d(412,308);
  glVertex2d(390,308);
  glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160001>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100   ;

        if(luff==0){
            llindex++;
        }
        luff++;
        luff=luff%20 ;

        setup_viewport(window);

        display();
//        pink();
        Hijau();
        Bayangan();
        Ekor();
        Chat();
        M1();
        Y1();
        N1();
        A1();
        M2();
        E1();
        I1();
        S1();
        A();
        L();
        Ls();
        I();
        F();
        As();
        H();
      //  bul();
        Hiasan();
        Hiasan2();
        Hiasan3();
        Hiasan4();




        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    exit(EXIT_SUCCESS);
}

