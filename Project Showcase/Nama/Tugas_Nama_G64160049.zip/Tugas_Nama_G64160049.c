#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h>

int clindex=0,buff=0,clindex1, buff1=0;
int colorf[3][3]={{44,222,221},{20,97,99},{0,242,219}};
int color1[2][3]={{69,75,78},{251,251,251}};
int ticks=0, gerak=0, trans=0, trig=0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void Bg() //Bacground
{
    glBegin(GL_POLYGON);
        glColor3ub(251,251,251);
        glVertex2d(0,0);
        glVertex2d(800,0);
        glVertex2d(800,800);
        glVertex2d(0,800);
    glEnd();
}

void PojokKiriAtas()
{
    glBegin(GL_POLYGON); //Horizontal
        glColor3ub(0,242,219);
        glVertex2d(22,22);
        glVertex2d(158,22);
        glVertex2d(158,55);
        glVertex2d(55,55);
    glEnd();

    glBegin(GL_POLYGON); //Vertikal
        glColor3ub(44,222,221);
        glVertex2d(22,22);
        glVertex2d(55,55);
        glVertex2d(55,158);
        glVertex2d(22,158);
    glEnd();
}

void PojokKananAtas()
{
    glBegin(GL_POLYGON); //Horizontal
        glColor3ub(0,242,219);
        glVertex2d(641,22);
        glVertex2d(777,22);
        glVertex2d(744,55);
        glVertex2d(641,55);
    glEnd();

    glBegin(GL_POLYGON); //Vertikal
        glColor3ub(44,222,221);
        glVertex2d(744,55);
        glVertex2d(777,22);
        glVertex2d(777,158);
        glVertex2d(744,158);
    glEnd();
}

void PojokKiriBawah()
{
    glBegin(GL_POLYGON); //Horizontal
        glColor3ub(0,242,219);
        glVertex2d(641,744);
        glVertex2d(744,744);
        glVertex2d(777,777);
        glVertex2d(641,777);
    glEnd();

    glBegin(GL_POLYGON); //Vertikal
        glColor3ub(44,222,221);
        glVertex2d(744,641);
        glVertex2d(777,641);
        glVertex2d(777,777);
        glVertex2d(744,744);
    glEnd();
}

void PojokKananBawah()
{
    glBegin(GL_POLYGON); //Horizontal
        glColor3ub(0,242,219);
        glVertex2d(22,777);
        glVertex2d(55,744);
        glVertex2d(158,744);
        glVertex2d(158,777);
    glEnd();

    glBegin(GL_POLYGON); //Vertikal
        glColor3ub(44,222,221);
        glVertex2d(22,641);
        glVertex2d(55,641);
        glVertex2d(55,744);
        glVertex2d(22,777);
    glEnd();
}

void GarisBawah() //Garis Bawah
{
    glBegin(GL_POLYGON);
        glColor3ub(20,97,99);
        glVertex2d(128,592);
        glVertex2d(671,592);
        glVertex2d(671,608);
        glVertex2d(128,608);
    glEnd();
}

void LingkaranQ(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<202;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void LingkaranB(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<101;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void I() //huruf I
{
    glBegin(GL_POLYGON);
        glColor3ub(69,75,78);
        glVertex2d(127,397);
        glVertex2d(141,397);
        glVertex2d(141,559);
        glVertex2d(127,559);
    glEnd();
}

void Q()
{
    glColor3ub(69,75,78);
    LingkaranQ(242,478,75); // Lingkaran Luar
    glColor3ub(251,251,251);
    LingkaranQ(242,478,60); // Lingkaan Dalam

    glBegin(GL_POLYGON); // Ekornya
        glColor3ub(69,75,78);
        glVertex2d(241,492);
        glVertex2d(259,492);
        glVertex2d(314,572);
        glVertex2d(296,572);
    glEnd();
}

void B()
{
    glColor3ub(69,75,78);
    LingkaranB(377,440,43); // Lingkaran Luar Atas
    glColor3ub(251,251,251);
    LingkaranB(377,440,27); // Lingkaran Dalam Atas

    glColor3ub(69,75,78);
    LingkaranB(379,513,47); // Lingkaran Luar Bawah
    glColor3ub(251,251,251);
    LingkaranB(379,513,30); // Lingkaran Dalam Bawah

    glBegin(GL_POLYGON); // Garis Vertikal
        glColor3ub(69,75,78);
        glVertex2d(349,397);
        glVertex2d(363,397);
        glVertex2d(363,559);
        glVertex2d(349,559);
    glEnd();

    glBegin(GL_POLYGON); // Garis atas
        glColor3ub(69,75,78);
        glVertex2d(349,397);
        glVertex2d(377,397);
        glVertex2d(377,413);
        glVertex2d(349,413);
    glEnd();

    glBegin(GL_POLYGON); // Garis tengah
        glColor3ub(69,75,78);
        glVertex2d(349,467);
        glVertex2d(377,467);
        glVertex2d(377,483);
        glVertex2d(349,483);
    glEnd();

    glBegin(GL_POLYGON); // Garis bawah
        glColor3ub(69,75,78);
        glVertex2d(349,543);
        glVertex2d(379,543);
        glVertex2d(379,560);
        glVertex2d(349,560);
    glEnd();
}

void A()
{
    glBegin(GL_POLYGON);
        glColor3ub(69,75,78);
        glVertex2d(517,397);
        glVertex2d(583,559);
        glVertex2d(567,559);
        glVertex2d(545,506);
        glVertex2d(484,506);
        glVertex2d(462,559);
        glVertex2d(446,559);
    glEnd();

    glBegin(GL_POLYGON); // Lubang di A
        glColor3ub(251,251,251);
        glVertex2d(515,432);
        glVertex2d(539,490);
        glVertex2d(491,490);
    glEnd();
}

void L()
{
    glBegin(GL_POLYGON); // Vertikal
        glColor3ub(69,75,78);
        glVertex2d(605,397);
        glVertex2d(619,397);
        glVertex2d(619,544);
        glVertex2d(605,559);
    glEnd();

    glBegin(GL_POLYGON); // Horizontal
        glColor3ub(69,75,78);
        glVertex2d(619,544);
        glVertex2d(673,544);
        glVertex2d(673,559);
        glVertex2d(605,559);
    glEnd();
}

void SegitigaKiriBawah()
{
    glBegin(GL_POLYGON);
        glColor3ub(69,75,78);
        glVertex2d(254,276);
        glVertex2d(369,376);
        glVertex2d(138,376);
    glEnd();glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

    glBegin(GL_POLYGON);
        glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
        glVertex2d(260,283);
        glVertex2d(375,383);
        glVertex2d(144,383);
    glEnd();
}

void SegitigaKananBawah()
{
    glBegin(GL_POLYGON);
        glColor3ub(69,75,78);
        glVertex2d(543,276);
        glVertex2d(658,376);
        glVertex2d(427,376);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2d(549,283);
        glVertex2d(664,383);
        glVertex2d(433,383);
    glEnd();
}

void SegitigaAtas()
{
    glBegin(GL_POLYGON);
        glColor3ub(69,75,78);
        glVertex2d(401,130);
        glVertex2d(531,245);
        glVertex2d(271,245);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(408,137);
        glVertex2d(538,252);
        glVertex2d(278,252);
    glEnd();
}

void SegitigaTengah()
{
    glBegin(GL_POLYGON);
        glColor3ub(20,97,99);
        glVertex2d(271,261);
        glVertex2d(531,261);
        glVertex2d(400,376);
    glEnd();

    glBegin(GL_POLYGON); // Lubangnya
        glColor3ub(251,251,251);
        glVertex2d(295,269);
        glVertex2d(505,269);
        glVertex2d(399,362);
    glEnd();
}

void silang()
{
    glBegin(GL_POLYGON); // silang 1
        glColor3ub(20,97,99);
        glVertex2d(97,202);
        glVertex2d(109,188);
        glVertex2d(182,257);
        glVertex2d(170,270);
    glEnd();

    glBegin(GL_POLYGON); // silang 1
        glColor3ub(20,97,99);
        glVertex2d(166,187);
        glVertex2d(180,200);
        glVertex2d(113,271);
        glVertex2d(99,259);
    glEnd();

    glBegin(GL_POLYGON); // silang 2
        glColor3ub(20,97,99);
        glVertex2d(357,35);
        glVertex2d(369,21);
        glVertex2d(442,90);
        glVertex2d(430,103);
    glEnd();

    glBegin(GL_POLYGON); // silanv 2
        glColor3ub(20,97,99);
        glVertex2d(426,20);
        glVertex2d(440,33);
        glVertex2d(373,104);
        glVertex2d(359,92);
    glEnd();

    glBegin(GL_POLYGON); // silang 3
        glColor3ub(20,97,99);
        glVertex2d(616,202);
        glVertex2d(628,188);
        glVertex2d(701,257);
        glVertex2d(689,270);
    glEnd();

    glBegin(GL_POLYGON); // silanv 3
        glColor3ub(20,97,99);
        glVertex2d(685,187);
        glVertex2d(699,200);
        glVertex2d(632,271);
        glVertex2d(618,259);
    glEnd();
}

void bulat()
{
    glColor3ub(20,97,99);
    LingkaranQ(76,345,44);
    LingkaranQ(254,130,44);
    LingkaranQ(543,130,44);
    LingkaranQ(716,345,44);
}

void segienamHorizontal(double x1, double x2, double x3, double x4, double y1, double y2, double y3)
{
    glBegin(GL_POLYGON);
        glVertex2d(x1,y2);
        glVertex2d(x2,y1);
        glVertex2d(x3,y1);
        glVertex2d(x4,y2);
        glVertex2d(x3,y3);
        glVertex2d(x2,y3);
    glEnd();
}

void segienamVertikal(double x1, double x2, double x3, double y1, double y2, double y3, double y4)
{
    glBegin(GL_POLYGON);
        glVertex2d(x1,y2);
        glVertex2d(x2,y1);
        glVertex2d(x3,y2);
        glVertex2d(x3,y3);
        glVertex2d(x2,y4);
        glVertex2d(x1,y3);
    glEnd();
}

void lima()
{
        glPushMatrix();
            glTranslated(-trans,0,0);
            segienamHorizontal(340,343,357,360,644,647,650);
            segienamHorizontal(362,365,378,381,644,647,650);
            segienamHorizontal(362,365,378,381,680,683,686);
            segienamHorizontal(340,343,357,360,680,683,686);
            segienamHorizontal(340,343,357,360,717,720,723);
            segienamHorizontal(362,365,378,381,717,720,723);
            segienamVertikal(336,339,342,648,652,679,683);
            segienamVertikal(380,383,386,685,689,716,720);
        glPopMatrix();

}

void tiga()
{
    glPushMatrix();
        glTranslated(trans,0,0);
        segienamHorizontal(399,402,416,419,644,647,650);
        segienamHorizontal(421,424,437,440,644,647,650);
        segienamHorizontal(421,424,437,440,680,684,687);
        segienamHorizontal(421,424,437,440,717,721,724);
        segienamHorizontal(399,402,416,419,717,721,724);
        segienamVertikal(439,441,444,648,652,679,683);
        segienamVertikal(439,441,444,685,689,716,720);
    glPopMatrix();
}

void C()
{
    glColor3ub(color1[clindex1%2][0],color1[(clindex1)%2][1],color1[(clindex1)%2][2]);
    segienamHorizontal(88,91,105,108,81,84,87);
    segienamHorizontal(88,91,105,108,144,147,150);
    segienamHorizontal(110,113,126,129,81,84,87);
    segienamHorizontal(110,113,126,129,144,147,150);
    segienamVertikal(84,87,90,85,88,112,115);
    segienamVertikal(84,87,90,117,120,143,146);
}

void S()
{
    glColor3ub(color1[clindex1%2][0],color1[(clindex1)%2][1],color1[(clindex1)%2][2]);
    segienamHorizontal(676,679,693,696,81,84,87);
    segienamHorizontal(676,679,693,696,113,116,119);
    segienamHorizontal(676,679,693,696,144,147,150);
    segienamHorizontal(698,701,714,717,81,84,87);
    segienamHorizontal(698,701,714,717,113,116,119);
    segienamHorizontal(698,701,714,717,144,147,150);
    segienamVertikal(672,675,678,84,87,112,115);
    segienamVertikal(716,719,722,117,120,143,146);
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Muhammad Iqbal Shiddiq - G64160049", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        if(buff1==0){
            clindex1++;
        }
        buff1++;
        buff1=buff1%2000;

        double tNow = glfwGetTime();

        while(tNow/0.01 > ticks)
        {
            ticks++;
            tNow = glfwGetTime();
            if(gerak<257){
                trans++;
                gerak++;
            } else if(gerak>=257){
                trans--;
                gerak++;
                if(gerak==514){
                    gerak=0;
                }
            }
        }

        setup_viewport(window);

        display();

        Bg();
        PojokKiriAtas();
        PojokKananAtas();
        PojokKiriBawah();
        PojokKananBawah();
        GarisBawah();
        SegitigaKiriBawah();
        SegitigaKananBawah();
        SegitigaAtas();
        SegitigaTengah();
        I();
        Q();
        B();
        A();
        L();
        lima();
        tiga();
        C();
        S();

        if(trig>=0 && trig<500)
        {
            silang();
        }
       else if(trig>=500 && trig<1000)
        {
            bulat();
        }
        trig++;
        if(trig==1000)
        {
            trig=0;
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
