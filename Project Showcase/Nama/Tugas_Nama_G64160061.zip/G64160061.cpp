#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,800,0,-1.f,1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void kotak(float x, float y, float xe, float ye, char col = 'd'){
    glBegin(GL_POLYGON);
        if(col == 'b') glColor3ub(0,0,0);
        else glColor3ub(112,79,15);
        glVertex2f(x,y);
        glVertex2f(x,ye);
        glVertex2f(xe,ye);
        glVertex2f(xe,y);
    glEnd();
}

void bulet(float r, float x, float y, char col = 'd'){
    glBegin(GL_POLYGON);
        if(col == 'b') glColor3ub(0,0,0);
        else glColor3ub(112,79,15);
        for (int i=0; i <= 360; i++){
            glVertex2f(x+cos(i)*r, y+sin(i)*r);
        }
   glEnd();
}

void segitiga(float ax, float ay, float bx, float by, float cx, float cy, char col = 'd'){
    glBegin(GL_POLYGON);
        if(col == 'b') glColor3ub(0,0,0);
        else glColor3ub(112,79,15);
        glVertex2d(ax,ay);
        glVertex2d(bx,by);
        glVertex2d(cx,cy);
    glEnd();
}

void display()
{
    // your drawing code here, maybe
    //background
    glBegin(GL_POLYGON);
        glColor3ub(112,79,15);
        glVertex2f(0,0);
        glVertex2f(0,800);
        glVertex2f(800,800);
        glVertex2f(800,0);
    glEnd();

    //Huruf L
    kotak(46.51,253.73,95,350.14,'b');
    kotak(57.76,253.73,95,339.7);

    //Huruf E
    kotak(107.54,253.73,156.55,350.14,'b');
    kotak(118.79,264.18,156.55,294.64);
    kotak(118.79,304.94,156.55,339);

    //Huruf O
    bulet(39.825,205.805,301.51,'b');
    bulet(28.825,205.805,301.51);

    //Huruf N
    kotak(260.24,253.73,325.67,350.14,'b');
    segitiga(270.84,350.14,269.94,269.18,314.29,350.14);
    segitiga(270.84,253.73,316.36,333.69,314.29,253.73);

    //Huruf A
    kotak(338.72,253.73,411.65,350.14,'b');
    segitiga(338.72,253.73,368.33,253.73,338.72,350.14);
    segitiga(381.91,253.73,411.65,350.14,411.65,253.73);
    segitiga(361.74,310.09,374.93,264.75,387.99,310.09);
    glBegin(GL_POLYGON);
        glVertex2d(350.36,350.14);
        glVertex2d(359.41,319.82);
        glVertex2d(390.31,319.82);
        glVertex2d(399.62,350.14);
    glEnd();

    //Huruf R
    kotak(424.45,253.73,470.21,350.14,'b');
    kotak(435.69,263.75,460.57,298.93);
    segitiga(455.57,350.14,435.69,308.37,435.69,350.14);
    segitiga(470.21,350.14,450.57,308.37,481.21,308.17);

    //Huruf D
    kotak(494.01,253.73,565.51,350.14,'b');
    kotak(505.26,264.18,535.51,339.14);
    glBegin(GL_POLYGON);
        glVertex2d(535.26,264.18);
        glVertex2d(535.26,339.14);
        glVertex2d(554.51,320.18);
        glVertex2d(554.51,283.18);
    glEnd();

    //Huruf I
    kotak(580.12,253.73,591.37,350.14,'b');

    //Huruf F
    kotak(164.88,370.15,214.97,463.16,'b');
    kotak(176.88,380.22,214.97,411.13);
    kotak(176.88,421.07,214.97,463.16);

    //Huruf A
    kotak(214.28,370.15,292.12,463.16,'b');
    segitiga(214.28,370.15,214.28,463.16,245.89,370.15);
    segitiga(238.85,424.52,266.86,424.52,252.92,380.77);
    segitiga(292.12,463.16,292.12,370.15,260.38,370.15);
    glBegin(GL_POLYGON);
        glVertex2d(225.28,463.16);
        glVertex2d(281.12,463.16);
        glVertex2d(270.12,435.50);
        glVertex2d(236.28,435.50);
    glEnd();

    //Huruf B
    kotak(305.78,370.15,360.98,463.16,'b');
    kotak(320.78,379.53,350.83,409.48);
    kotak(320.78,418.59,350.83,454.05);

    //Huruf I
    kotak(380.57,370.15,392.58,463.16,'b');

    //Huruf A
    kotak(406.52,370.15,484.35,463.16,'b');
    segitiga(406.52,370.15,406.52,463.16,438.12,370.15);
    segitiga(431.08,424.52,459.09,424.52,444.88,380.77);
    segitiga(484.35,370.15,484.35,463.16,452.16,370.15);
    glBegin(GL_POLYGON);
        glVertex2d(417.52,463.16);
        glVertex2d(473.16,463.16);
        glVertex2d(462.16,435.52);
        glVertex2d(428.52,435.52);
    glEnd();

    //Huruf N
    kotak(498.01,370.15,567.84,463.16,'b');
    segitiga(509.33,463.16,556.84,463.16,509.33,385.05);
    segitiga(511.12,370.15,556.52,370.15,557.9,447.29);

    //Huruf T
    kotak(578.19,370.15,647.05,463.16,'b');
    kotak(578.19,380.36,606.48,463.16);
    kotak(618.62,380.36,647.05,463.16);

    //Huruf O
    bulet(39.825,690.655,417.21,'b');
    bulet(28.825,690.655,417.21);
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(640, 480, "Hello Triangle", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
