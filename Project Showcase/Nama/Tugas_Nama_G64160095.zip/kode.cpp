#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void setup_viewport(GLFWwindow* window)
{

    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glEnable( GL_POLYGON_SMOOTH ) ;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
float gry=190;
float wht=255;
float bl =0;
float gr =0;
float bl3=255;
float gr3=190;
void katakana1(){
// start of kana
// graykana s
glBegin(GL_POLYGON);
        glColor3ub(gr,gr,gr);
        if (gr<190){
            if (glfwGetTime()>1){
        gr+=0.45;}}

        glVertex2d(168,300);

        glVertex2d(278,300);

        glVertex2d(278,321);

        glVertex2d(168,321);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(262,321);

        glVertex2d(278,321);

        glVertex2d(278,344);

        glVertex2d(262,344);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(246,343);

        glVertex2d(260,343);

        glVertex2d(260,387);

        glVertex2d(246,387);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(225,392);

        glVertex2d(241,392);

        glVertex2d(241,411);

        glVertex2d(225,411);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(241,411);

        glVertex2d(259,411);

        glVertex2d(259,433);

        glVertex2d(241,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(207,414);

        glVertex2d(223,414);

        glVertex2d(223,433);

        glVertex2d(207,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(189,436);

        glVertex2d(203,436);

        glVertex2d(203,455);

        glVertex2d(189,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(169,458);

        glVertex2d(185,458);

        glVertex2d(185,477);

        glVertex2d(169,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(260,434);

        glVertex2d(278,434);

        glVertex2d(278,477);

        glVertex2d(260,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(373,300);

        glVertex2d(390,300);

        glVertex2d(390,411);

        glVertex2d(373,411);
        glEnd();

glBegin(GL_POLYGON);        // part of ru grey

        glVertex2d(356,413);

        glVertex2d(372,413);

        glVertex2d(372,455);

        glVertex2d(356,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(353,412);

        glVertex2d(357,412);

        glVertex2d(357,414);

        glVertex2d(353,414);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(337,457);

        glVertex2d(352,457);

        glVertex2d(352,477);

        glVertex2d(337,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(335,456);

        glVertex2d(339,456);

        glVertex2d(339,458);

        glVertex2d(335,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(409,300);

        glVertex2d(427,300);

        glVertex2d(427,458);

        glVertex2d(409,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(427,456);

        glVertex2d(429,456);

        glVertex2d(429,457);

        glVertex2d(427,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(465,412);

        glVertex2d(483,412);

        glVertex2d(483,433);

        glVertex2d(465,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(449,436);

        glVertex2d(464,436);

        glVertex2d(464,455);

        glVertex2d(449,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(429,458);

        glVertex2d(445,458);

        glVertex2d(445,477);

        glVertex2d(429,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,322);

        glVertex2d(650,322);

        glVertex2d(650,344);

        glVertex2d(540,344);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(634,344);

        glVertex2d(650,344);

        glVertex2d(650,474);

        glVertex2d(634,474);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,388);

        glVertex2d(615,388);

        glVertex2d(615,391);

        glVertex2d(540,391);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,456);

        glVertex2d(615,456);

        glVertex2d(615,459);

        glVertex2d(540,459);
        glEnd();

//su white

glBegin(GL_POLYGON);
        glColor3ub(bl,bl,bl);
        if (bl<255){
            if (glfwGetTime()>1){
        glColor3ub(bl,bl,bl);bl+=0.8;}}
        glVertex2d(151,302);

        glVertex2d(262,302);

        glVertex2d(262,323);

        glVertex2d(151,323);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(245,323);

        glVertex2d(262,323);

        glVertex2d(262,345);

        glVertex2d(245,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(227,346);

        glVertex2d(246,346);

        glVertex2d(246,392);

        glVertex2d(227,392);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(208,392);

        glVertex2d(225,392);

        glVertex2d(225,414);

        glVertex2d(208,414);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(190,414);

        glVertex2d(207,414);

        glVertex2d(207,436);

        glVertex2d(190,436);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(170,436);

        glVertex2d(189,436);

        glVertex2d(189,458);

        glVertex2d(170,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(150,458);

        glVertex2d(169,458);

        glVertex2d(169,480);

        glVertex2d(150,480);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(224,411);

        glVertex2d(244,411);

        glVertex2d(244,435);

        glVertex2d(224,435);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(245,433);

        glVertex2d(263,433);

        glVertex2d(263,480);

        glVertex2d(245,480);
        glEnd();

//ru white

glBegin(GL_POLYGON);

        glVertex2d(356,302);

        glVertex2d(373,302);

        glVertex2d(373,413);

        glVertex2d(356,413);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(338,414);

        glVertex2d(356,414);

        glVertex2d(356,457);

        glVertex2d(338,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(318,458);

        glVertex2d(337,458);

        glVertex2d(337,481);

        glVertex2d(318,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(393,302);

        glVertex2d(411,302);

        glVertex2d(411,457);

        glVertex2d(393,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(393,457);

        glVertex2d(411,457);

        glVertex2d(411,481);

        glVertex2d(393,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(411,458);

        glVertex2d(429,458);

        glVertex2d(429,481);

        glVertex2d(411,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(430,436);

        glVertex2d(449,436);

        glVertex2d(449,458);

        glVertex2d(430,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(449,414);

        glVertex2d(466,414);

        glVertex2d(466,436);

        glVertex2d(449,436);
        glEnd();

// yo white

glBegin(GL_POLYGON);

        glVertex2d(523,324);

        glVertex2d(633,324);

        glVertex2d(633,345);

        glVertex2d(523,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,324);

        glVertex2d(634,324);

        glVertex2d(634,345);

        glVertex2d(615,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,345);

        glVertex2d(634,345);

        glVertex2d(634,391);

        glVertex2d(615,391);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(523,391);

        glVertex2d(634,391);

        glVertex2d(634,413);

        glVertex2d(523,413);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,413);

        glVertex2d(634,413);

        glVertex2d(634,458);

        glVertex2d(615,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(523,458);

        glVertex2d(634,458);

        glVertex2d(634,481);

        glVertex2d(523,481);
        glEnd();

        // END OF suryo KATAKANA //

// katakana ko

glBegin(GL_POLYGON);

    glVertex2d(316,598);

    glVertex2d(337,598);

    glVertex2d(337,601);

    glVertex2d(316,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(334,601);

    glVertex2d(337,601);

    glVertex2d(337,623);

    glVertex2d(334,623);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(316,620);

    glVertex2d(337,620);

    glVertex2d(337,623);

    glVertex2d(316,623);
    glEnd();

// katakana pi

glBegin(GL_POLYGON);

    glVertex2d(349,594);

    glVertex2d(352,594);

    glVertex2d(352,617);

    glVertex2d(349,617);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,598);

    glVertex2d(370,598);

    glVertex2d(370,601);

    glVertex2d(352,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,617);

    glVertex2d(356,617);

    glVertex2d(356,620);

    glVertex2d(352,620);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,620);

    glVertex2d(370,620);

    glVertex2d(370,623);

    glVertex2d(356,623);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(370,602);

    glVertex2d(374,602);

    glVertex2d(374,608);

    glVertex2d(370,608);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,598);

    glVertex2d(381,598);

    glVertex2d(381,601);

    glVertex2d(374,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(381,602);

    glVertex2d(385,602);

    glVertex2d(385,608);

    glVertex2d(381,608);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,609);

    glVertex2d(381,609);

    glVertex2d(381,612);

    glVertex2d(374,612);
    glEnd();

// katakana ra

glBegin(GL_POLYGON);

    glVertex2d(400,595);

    glVertex2d(418,595);

    glVertex2d(418,599);

    glVertex2d(400,599);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(396,602);

    glVertex2d(421,602);

    glVertex2d(421,606);

    glVertex2d(396,606);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(418,606);

    glVertex2d(421,606);

    glVertex2d(421,612);

    glVertex2d(418,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(414,613);

    glVertex2d(418,613);

    glVertex2d(418,616);

    glVertex2d(414,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(411,617);

    glVertex2d(415,617);

    glVertex2d(415,620);

    glVertex2d(411,620);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(403,620);

    glVertex2d(411,620);

    glVertex2d(411,623);

    glVertex2d(403,623);
    glEnd();

// katakana i

glBegin(GL_POLYGON);

    glVertex2d(450,595);

    glVertex2d(454,595);

    glVertex2d(454,601);

    glVertex2d(450,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(447,602);

    glVertex2d(450,602);

    glVertex2d(450,624);

    glVertex2d(447,624);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(444,606);

    glVertex2d(448,606);

    glVertex2d(448,609);

    glVertex2d(444,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(440,609);

    glVertex2d(444,609);

    glVertex2d(444,612);

    glVertex2d(440,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(434,613);

    glVertex2d(440,613);

    glVertex2d(440,616);

    glVertex2d(434,616);
    glEnd();

// katakana to

glBegin(GL_POLYGON);

    glVertex2d(466,595);

    glVertex2d(469,595);

    glVertex2d(469,624);

    glVertex2d(466,624);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(468,606);

    glVertex2d(476,606);

    glVertex2d(476,609);

    glVertex2d(468,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(476,609);

    glVertex2d(480,609);

    glVertex2d(480,612);

    glVertex2d(476,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(480,612);

    glVertex2d(484,612);

    glVertex2d(484,616);

    glVertex2d(480,616);
    glEnd();

// katakana little su

glBegin(GL_POLYGON);

    glVertex2d(348,653);

    glVertex2d(369,653);

    glVertex2d(369,656);

    glVertex2d(348,656);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(366,656);

    glVertex2d(369,656);

    glVertex2d(369,660);

    glVertex2d(366,660);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,660);

    glVertex2d(366,660);

    glVertex2d(366,666);

    glVertex2d(362,666);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(358,666);

    glVertex2d(362,666);

    glVertex2d(362,671);

    glVertex2d(358,671);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(355,670);

    glVertex2d(359,670);

    glVertex2d(359,674);

    glVertex2d(355,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(351,674);

    glVertex2d(355,674);

    glVertex2d(355,678);

    glVertex2d(351,678);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(348,677);

    glVertex2d(352,677);

    glVertex2d(352,681);

    glVertex2d(348,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,670);

    glVertex2d(366,670);

    glVertex2d(366,674);

    glVertex2d(362,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(366,674);

    glVertex2d(370,674);

    glVertex2d(370,681);

    glVertex2d(366,681);
    glEnd();

// little ru

glBegin(GL_POLYGON);

    glVertex2d(388,652);

    glVertex2d(391,652);

    glVertex2d(391,670);

    glVertex2d(388,670);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(385,671);

    glVertex2d(388,671);

    glVertex2d(388,677);

    glVertex2d(385,677);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(381,677);

    glVertex2d(384,677);

    glVertex2d(384,681);

    glVertex2d(381,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(395,652);

    glVertex2d(398,652);

    glVertex2d(398,681);

    glVertex2d(395,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(398,678);

    glVertex2d(402,678);

    glVertex2d(402,681);

    glVertex2d(398,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(402,675);

    glVertex2d(405,675);

    glVertex2d(405,678);

    glVertex2d(402,678);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(405,671);

    glVertex2d(408,671);

    glVertex2d(408,674);

    glVertex2d(405,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,656);

    glVertex2d(442,656);

    glVertex2d(442,659);

    glVertex2d(421,659);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(439,659);

    glVertex2d(442,659);

    glVertex2d(442,681);

    glVertex2d(439,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,667);

    glVertex2d(442,667);

    glVertex2d(442,670);

    glVertex2d(421,670);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,678);

    glVertex2d(442,678);

    glVertex2d(442,681);

    glVertex2d(421,681);
    glEnd();

// number 2

glBegin(GL_POLYGON);

    glVertex2d(342,711);

    glVertex2d(355,711);

    glVertex2d(355,714);

    glVertex2d(342,714);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(339,714);

    glVertex2d(342,714);

    glVertex2d(342,721);

    glVertex2d(339,721);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(355,714);

    glVertex2d(358,714);

    glVertex2d(358,724);

    glVertex2d(355,724);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(353,725);

    glVertex2d(356,725);

    glVertex2d(356,728);

    glVertex2d(353,728);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(350,729);

    glVertex2d(353,729);

    glVertex2d(353,732);

    glVertex2d(350,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(346,732);

    glVertex2d(349,732);

    glVertex2d(349,735);

    glVertex2d(346,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(339,736);

    glVertex2d(359,736);

    glVertex2d(359,739);

    glVertex2d(339,739);
    glEnd();

// number 0

glBegin(GL_POLYGON);

    glVertex2d(374,711);

    glVertex2d(389,711);

    glVertex2d(389,714);

    glVertex2d(374,714);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(371,714);

    glVertex2d(374,714);

    glVertex2d(374,735);

    glVertex2d(371,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(389,714);

    glVertex2d(392,714);

    glVertex2d(392,735);

    glVertex2d(389,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,736);

    glVertex2d(389,736);

    glVertex2d(389,739);

    glVertex2d(374,739);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,714);

    glVertex2d(414,714);

    glVertex2d(414,717);

    glVertex2d(404,717);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(411,710);

    glVertex2d(414,710);

    glVertex2d(414,739);

    glVertex2d(411,739);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,736);

    glVertex2d(418,736);

    glVertex2d(418,739);

    glVertex2d(404,739);
    glEnd();

// number 8

glBegin(GL_POLYGON);

    glVertex2d(433,711);

    glVertex2d(448,711);

    glVertex2d(448,714);

    glVertex2d(433,714);
    glEnd();

for(int em=430, en=714, eks=433, ye=724 ,i=0; i<2; i++, em+=18, eks+=18){
    glBegin(GL_POLYGON);

    glVertex2d(em,en);

    glVertex2d(eks,en);

    glVertex2d(eks,ye);

    glVertex2d(em,ye);
    glEnd();

}

for(int x1=430, y1=728, x2=433, y2=735 ,i=0; i<2; i++, x1+=18, x2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=433, y1=725, x2=448, y2=728 ,i=0; i<2; i++, y1+=11, y2+=11){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

}

// end of kana

void katakana2(){
// start of kana
// graykana s
glBegin(GL_POLYGON);                //persegi atas grey
        glColor3ub(gry,gry,gry);
        if (gry>0){
            if (glfwGetTime()>2){
        gry-=0.45;}}

        glVertex2d(168,300);

        glVertex2d(278,300);

        glVertex2d(278,321);

        glVertex2d(168,321);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(262,321);

        glVertex2d(278,321);

        glVertex2d(278,344);

        glVertex2d(262,344);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(246,343);

        glVertex2d(260,343);

        glVertex2d(260,387);

        glVertex2d(246,387);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(225,392);

        glVertex2d(241,392);

        glVertex2d(241,411);

        glVertex2d(225,411);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(241,411);

        glVertex2d(259,411);

        glVertex2d(259,433);

        glVertex2d(241,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(207,414);

        glVertex2d(223,414);

        glVertex2d(223,433);

        glVertex2d(207,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(189,436);

        glVertex2d(203,436);

        glVertex2d(203,455);

        glVertex2d(189,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(169,458);

        glVertex2d(185,458);

        glVertex2d(185,477);

        glVertex2d(169,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(260,434);

        glVertex2d(278,434);

        glVertex2d(278,477);

        glVertex2d(260,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(373,300);

        glVertex2d(390,300);

        glVertex2d(390,411);

        glVertex2d(373,411);
        glEnd();

glBegin(GL_POLYGON);        // part of ru grey

        glVertex2d(356,413);

        glVertex2d(372,413);

        glVertex2d(372,455);

        glVertex2d(356,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(353,412);

        glVertex2d(357,412);

        glVertex2d(357,414);

        glVertex2d(353,414);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(337,457);

        glVertex2d(352,457);

        glVertex2d(352,477);

        glVertex2d(337,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(335,456);

        glVertex2d(339,456);

        glVertex2d(339,458);

        glVertex2d(335,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(409,300);

        glVertex2d(427,300);

        glVertex2d(427,458);

        glVertex2d(409,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(427,456);

        glVertex2d(429,456);

        glVertex2d(429,457);

        glVertex2d(427,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(465,412);

        glVertex2d(483,412);

        glVertex2d(483,433);

        glVertex2d(465,433);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(449,436);

        glVertex2d(464,436);

        glVertex2d(464,455);

        glVertex2d(449,455);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(429,458);

        glVertex2d(445,458);

        glVertex2d(445,477);

        glVertex2d(429,477);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,322);

        glVertex2d(650,322);

        glVertex2d(650,344);

        glVertex2d(540,344);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(634,344);

        glVertex2d(650,344);

        glVertex2d(650,474);

        glVertex2d(634,474);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,388);

        glVertex2d(615,388);

        glVertex2d(615,391);

        glVertex2d(540,391);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(540,456);

        glVertex2d(615,456);

        glVertex2d(615,459);

        glVertex2d(540,459);
        glEnd();

//su white

glBegin(GL_POLYGON);
        glColor3ub(wht,wht,wht);
        if (wht>0){
            if (glfwGetTime()>2){
        glColor3ub(wht,wht,wht);wht-=0.8;}}
        glVertex2d(151,302);

        glVertex2d(262,302);

        glVertex2d(262,323);

        glVertex2d(151,323);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(245,323);

        glVertex2d(262,323);

        glVertex2d(262,345);

        glVertex2d(245,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(227,346);

        glVertex2d(246,346);

        glVertex2d(246,392);

        glVertex2d(227,392);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(208,392);

        glVertex2d(225,392);

        glVertex2d(225,414);

        glVertex2d(208,414);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(190,414);

        glVertex2d(207,414);

        glVertex2d(207,436);

        glVertex2d(190,436);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(170,436);

        glVertex2d(189,436);

        glVertex2d(189,458);

        glVertex2d(170,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(150,458);

        glVertex2d(169,458);

        glVertex2d(169,480);

        glVertex2d(150,480);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(224,411);

        glVertex2d(244,411);

        glVertex2d(244,435);

        glVertex2d(224,435);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(245,433);

        glVertex2d(263,433);

        glVertex2d(263,480);

        glVertex2d(245,480);
        glEnd();

//ru white

glBegin(GL_POLYGON);

        glVertex2d(356,302);

        glVertex2d(373,302);

        glVertex2d(373,413);

        glVertex2d(356,413);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(338,414);

        glVertex2d(356,414);

        glVertex2d(356,457);

        glVertex2d(338,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(318,458);

        glVertex2d(337,458);

        glVertex2d(337,481);

        glVertex2d(318,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(393,302);

        glVertex2d(411,302);

        glVertex2d(411,457);

        glVertex2d(393,457);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(393,457);

        glVertex2d(411,457);

        glVertex2d(411,481);

        glVertex2d(393,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(411,458);

        glVertex2d(429,458);

        glVertex2d(429,481);

        glVertex2d(411,481);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(430,436);

        glVertex2d(449,436);

        glVertex2d(449,458);

        glVertex2d(430,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(449,414);

        glVertex2d(466,414);

        glVertex2d(466,436);

        glVertex2d(449,436);
        glEnd();

// yo white

glBegin(GL_POLYGON);

        glVertex2d(523,324);

        glVertex2d(633,324);

        glVertex2d(633,345);

        glVertex2d(523,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,324);

        glVertex2d(634,324);

        glVertex2d(634,345);

        glVertex2d(615,345);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,345);

        glVertex2d(634,345);

        glVertex2d(634,391);

        glVertex2d(615,391);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(523,391);

        glVertex2d(634,391);

        glVertex2d(634,413);

        glVertex2d(523,413);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(615,413);

        glVertex2d(634,413);

        glVertex2d(634,458);

        glVertex2d(615,458);
        glEnd();

glBegin(GL_POLYGON);

        glVertex2d(523,458);

        glVertex2d(634,458);

        glVertex2d(634,481);

        glVertex2d(523,481);
        glEnd();

        // END OF suryo KATAKANA //

// katakana ko

glBegin(GL_POLYGON);

    glVertex2d(316,598);

    glVertex2d(337,598);

    glVertex2d(337,601);

    glVertex2d(316,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(334,601);

    glVertex2d(337,601);

    glVertex2d(337,623);

    glVertex2d(334,623);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(316,620);

    glVertex2d(337,620);

    glVertex2d(337,623);

    glVertex2d(316,623);
    glEnd();

// katakana pi

glBegin(GL_POLYGON);

    glVertex2d(349,594);

    glVertex2d(352,594);

    glVertex2d(352,617);

    glVertex2d(349,617);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,598);

    glVertex2d(370,598);

    glVertex2d(370,601);

    glVertex2d(352,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,617);

    glVertex2d(356,617);

    glVertex2d(356,620);

    glVertex2d(352,620);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,620);

    glVertex2d(370,620);

    glVertex2d(370,623);

    glVertex2d(356,623);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(370,602);

    glVertex2d(374,602);

    glVertex2d(374,608);

    glVertex2d(370,608);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,598);

    glVertex2d(381,598);

    glVertex2d(381,601);

    glVertex2d(374,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(381,602);

    glVertex2d(385,602);

    glVertex2d(385,608);

    glVertex2d(381,608);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,609);

    glVertex2d(381,609);

    glVertex2d(381,612);

    glVertex2d(374,612);
    glEnd();

// katakana ra

glBegin(GL_POLYGON);

    glVertex2d(400,595);

    glVertex2d(418,595);

    glVertex2d(418,599);

    glVertex2d(400,599);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(396,602);

    glVertex2d(421,602);

    glVertex2d(421,606);

    glVertex2d(396,606);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(418,606);

    glVertex2d(421,606);

    glVertex2d(421,612);

    glVertex2d(418,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(414,613);

    glVertex2d(418,613);

    glVertex2d(418,616);

    glVertex2d(414,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(411,617);

    glVertex2d(415,617);

    glVertex2d(415,620);

    glVertex2d(411,620);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(403,620);

    glVertex2d(411,620);

    glVertex2d(411,623);

    glVertex2d(403,623);
    glEnd();

// katakana i

glBegin(GL_POLYGON);

    glVertex2d(450,595);

    glVertex2d(454,595);

    glVertex2d(454,601);

    glVertex2d(450,601);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(447,602);

    glVertex2d(450,602);

    glVertex2d(450,624);

    glVertex2d(447,624);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(444,606);

    glVertex2d(448,606);

    glVertex2d(448,609);

    glVertex2d(444,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(440,609);

    glVertex2d(444,609);

    glVertex2d(444,612);

    glVertex2d(440,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(434,613);

    glVertex2d(440,613);

    glVertex2d(440,616);

    glVertex2d(434,616);
    glEnd();

// katakana to

glBegin(GL_POLYGON);

    glVertex2d(466,595);

    glVertex2d(469,595);

    glVertex2d(469,624);

    glVertex2d(466,624);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(468,606);

    glVertex2d(476,606);

    glVertex2d(476,609);

    glVertex2d(468,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(476,609);

    glVertex2d(480,609);

    glVertex2d(480,612);

    glVertex2d(476,612);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(480,612);

    glVertex2d(484,612);

    glVertex2d(484,616);

    glVertex2d(480,616);
    glEnd();

// katakana little su

glBegin(GL_POLYGON);

    glVertex2d(348,653);

    glVertex2d(369,653);

    glVertex2d(369,656);

    glVertex2d(348,656);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(366,656);

    glVertex2d(369,656);

    glVertex2d(369,660);

    glVertex2d(366,660);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,660);

    glVertex2d(366,660);

    glVertex2d(366,666);

    glVertex2d(362,666);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(358,666);

    glVertex2d(362,666);

    glVertex2d(362,671);

    glVertex2d(358,671);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(355,670);

    glVertex2d(359,670);

    glVertex2d(359,674);

    glVertex2d(355,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(351,674);

    glVertex2d(355,674);

    glVertex2d(355,678);

    glVertex2d(351,678);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(348,677);

    glVertex2d(352,677);

    glVertex2d(352,681);

    glVertex2d(348,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,670);

    glVertex2d(366,670);

    glVertex2d(366,674);

    glVertex2d(362,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(366,674);

    glVertex2d(370,674);

    glVertex2d(370,681);

    glVertex2d(366,681);
    glEnd();

// little ru

glBegin(GL_POLYGON);

    glVertex2d(388,652);

    glVertex2d(391,652);

    glVertex2d(391,670);

    glVertex2d(388,670);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(385,671);

    glVertex2d(388,671);

    glVertex2d(388,677);

    glVertex2d(385,677);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(381,677);

    glVertex2d(384,677);

    glVertex2d(384,681);

    glVertex2d(381,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(395,652);

    glVertex2d(398,652);

    glVertex2d(398,681);

    glVertex2d(395,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(398,678);

    glVertex2d(402,678);

    glVertex2d(402,681);

    glVertex2d(398,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(402,675);

    glVertex2d(405,675);

    glVertex2d(405,678);

    glVertex2d(402,678);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(405,671);

    glVertex2d(408,671);

    glVertex2d(408,674);

    glVertex2d(405,674);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,656);

    glVertex2d(442,656);

    glVertex2d(442,659);

    glVertex2d(421,659);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(439,659);

    glVertex2d(442,659);

    glVertex2d(442,681);

    glVertex2d(439,681);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,667);

    glVertex2d(442,667);

    glVertex2d(442,670);

    glVertex2d(421,670);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,678);

    glVertex2d(442,678);

    glVertex2d(442,681);

    glVertex2d(421,681);
    glEnd();

// number 2

glBegin(GL_POLYGON);

    glVertex2d(342,711);

    glVertex2d(355,711);

    glVertex2d(355,714);

    glVertex2d(342,714);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(339,714);

    glVertex2d(342,714);

    glVertex2d(342,721);

    glVertex2d(339,721);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(355,714);

    glVertex2d(358,714);

    glVertex2d(358,724);

    glVertex2d(355,724);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(353,725);

    glVertex2d(356,725);

    glVertex2d(356,728);

    glVertex2d(353,728);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(350,729);

    glVertex2d(353,729);

    glVertex2d(353,732);

    glVertex2d(350,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(346,732);

    glVertex2d(349,732);

    glVertex2d(349,735);

    glVertex2d(346,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(339,736);

    glVertex2d(359,736);

    glVertex2d(359,739);

    glVertex2d(339,739);
    glEnd();

// number 0

glBegin(GL_POLYGON);

    glVertex2d(374,711);

    glVertex2d(389,711);

    glVertex2d(389,714);

    glVertex2d(374,714);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(371,714);

    glVertex2d(374,714);

    glVertex2d(374,735);

    glVertex2d(371,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(389,714);

    glVertex2d(392,714);

    glVertex2d(392,735);

    glVertex2d(389,735);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(374,736);

    glVertex2d(389,736);

    glVertex2d(389,739);

    glVertex2d(374,739);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,714);

    glVertex2d(414,714);

    glVertex2d(414,717);

    glVertex2d(404,717);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(411,710);

    glVertex2d(414,710);

    glVertex2d(414,739);

    glVertex2d(411,739);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,736);

    glVertex2d(418,736);

    glVertex2d(418,739);

    glVertex2d(404,739);
    glEnd();

// number 8

glBegin(GL_POLYGON);

    glVertex2d(433,711);

    glVertex2d(448,711);

    glVertex2d(448,714);

    glVertex2d(433,714);
    glEnd();

for(int em=430, en=714, eks=433, ye=724 ,i=0; i<2; i++, em+=18, eks+=18){
    glBegin(GL_POLYGON);

    glVertex2d(em,en);

    glVertex2d(eks,en);

    glVertex2d(eks,ye);

    glVertex2d(em,ye);
    glEnd();

}

for(int x1=430, y1=728, x2=433, y2=735 ,i=0; i<2; i++, x1+=18, x2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=433, y1=725, x2=448, y2=728 ,i=0; i<2; i++, y1+=11, y2+=11){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

}

// end of kana

// start of romaji
float gr2=0;
float bl2=0;
void romaji(){
    // gray s

glBegin(GL_POLYGON);
    glColor3ub(gr2,gr2,gr2);
    if (gr2<190){
            if (glfwGetTime()>1){
                    gr2+=0.45;}}
    glVertex2d(180,321);

    glVertex2d(208,321);

    glVertex2d(208,339);

    glVertex2d(180,339);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(208,338);

    glVertex2d(223,338);

    glVertex2d(223,354);

    glVertex2d(208,354);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(167,338);

    glVertex2d(179,338);

    glVertex2d(179,376);

    glVertex2d(167,376);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(179,372);

    glVertex2d(208,372);

    glVertex2d(208,391);

    glVertex2d(179,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(208,391);

    glVertex2d(223,391);

    glVertex2d(223,423);

    glVertex2d(208,423);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(180,424);

    glVertex2d(208,424);

    glVertex2d(208,442);

    glVertex2d(180,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(167,408);

    glVertex2d(180,408);

    glVertex2d(180,428);

    glVertex2d(167,428);
    glEnd();

// gray u

glBegin(GL_POLYGON);

    glVertex2d(267,355);

    glVertex2d(278,355);

    glVertex2d(278,428);

    glVertex2d(267,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(269,424);

    glVertex2d(321,424);

    glVertex2d(321,442);

    glVertex2d(269,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(309,355);

    glVertex2d(321,355);

    glVertex2d(321,442);

    glVertex2d(309,442);
    glEnd();

// gray r

glBegin(GL_POLYGON);

    glVertex2d(366,355);

    glVertex2d(380,355);

    glVertex2d(380,442);

    glVertex2d(366,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(380,372);

    glVertex2d(392,372);

    glVertex2d(392,390);

    glVertex2d(380,390);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(393,355);

    glVertex2d(421,355);

    glVertex2d(421,371);

    glVertex2d(393,371);
    glEnd();

// gray y

glBegin(GL_POLYGON);

    glVertex2d(464,355);

    glVertex2d(479,355);

    glVertex2d(479,409);

    glVertex2d(464,409);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(479,408);

    glVertex2d(493,408);

    glVertex2d(493,428);

    glVertex2d(479,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(493,424);

    glVertex2d(498,424);

    glVertex2d(498,428);

    glVertex2d(493,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(508,355);

    glVertex2d(522,355);

    glVertex2d(522,459);

    glVertex2d(508,459);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(464,443);

    glVertex2d(479,443);

    glVertex2d(479,462);

    glVertex2d(464,462);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(479,460);

    glVertex2d(507,460);

    glVertex2d(507,476);

    glVertex2d(479,476);
    glEnd();

// gray o

    glBegin(GL_POLYGON);

    glVertex2d(580,355);

    glVertex2d(608,355);

    glVertex2d(608,376);

    glVertex2d(580,376);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(565,372);

    glVertex2d(580,372);

    glVertex2d(580,428);

    glVertex2d(565,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(580,424);

    glVertex2d(608,424);

    glVertex2d(608,442);

    glVertex2d(580,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(608,372);

    glVertex2d(621,372);

    glVertex2d(621,423);

    glVertex2d(608,423);
    glEnd();


// white s

glBegin(GL_POLYGON);
    glColor3ub(bl2,bl2,bl2);
    if (bl2<255){
            if (glfwGetTime()>1){
    ;bl2+=0.8;}}
    glVertex2d(169,322);

    glVertex2d(197,322);

    glVertex2d(197,339);

    glVertex2d(169,339);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(156,340);

    glVertex2d(168,340);

    glVertex2d(168,375);

    glVertex2d(156,375);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(198,339);

    glVertex2d(213,339);

    glVertex2d(213,357);

    glVertex2d(198,357);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(169,376);

    glVertex2d(197,376);

    glVertex2d(197,391);

    glVertex2d(169,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(198,391);

    glVertex2d(213,391);

    glVertex2d(213,427);

    glVertex2d(198,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(156,409);

    glVertex2d(168,409);

    glVertex2d(168,427);

    glVertex2d(156,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(169,428);

    glVertex2d(197,428);

    glVertex2d(197,444);

    glVertex2d(169,444);
    glEnd();

// white u

glBegin(GL_POLYGON);

    glVertex2d(255,358);

    glVertex2d(268,358);

    glVertex2d(268,427);

    glVertex2d(255,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(269,428);

    glVertex2d(310,428);

    glVertex2d(310,444);

    glVertex2d(269,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(298,358);

    glVertex2d(311,358);

    glVertex2d(311,444);

    glVertex2d(298,444);
    glEnd();

// white r

glBegin(GL_POLYGON);

    glVertex2d(357,358);

    glVertex2d(369,358);

    glVertex2d(369,444);

    glVertex2d(357,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(368,376);

    glVertex2d(383,376);

    glVertex2d(383,391);

    glVertex2d(368,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(384,358);

    glVertex2d(410,358);

    glVertex2d(410,375);

    glVertex2d(384,375);
    glEnd();

// white y

glBegin(GL_POLYGON);

    glVertex2d(454,358);

    glVertex2d(469,358);

    glVertex2d(469,409);

    glVertex2d(454,409);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(470,409);

    glVertex2d(483,409);

    glVertex2d(483,428);

    glVertex2d(470,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(482,428);

    glVertex2d(510,428);

    glVertex2d(510,444);

    glVertex2d(482,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(498,358);

    glVertex2d(512,358);

    glVertex2d(512,461);

    glVertex2d(498,461);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(454,445);

    glVertex2d(469,445);

    glVertex2d(469,462);

    glVertex2d(454,462);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(470,462);

    glVertex2d(497,462);

    glVertex2d(497,478);

    glVertex2d(470,478);
    glEnd();

// white o

glBegin(GL_POLYGON);

    glVertex2d(569,358);

    glVertex2d(597,358);

    glVertex2d(597,375);

    glVertex2d(569,375);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(555,376);

    glVertex2d(569,376);

    glVertex2d(569,428);

    glVertex2d(555,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(569,428);

    glVertex2d(596,428);

    glVertex2d(596,444);

    glVertex2d(569,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(597,376);

    glVertex2d(611,376);

    glVertex2d(611,427);

    glVertex2d(597,427);
    glEnd();

// copyright c

for(int x1=304, y1=593, x2=311, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

    glBegin(GL_POLYGON);

    glVertex2d(301,597);

    glVertex2d(304,597);

    glVertex2d(304,609);

    glVertex2d(301,609);
    glEnd();

for(int x1=311, y1=598, x2=315, y2=601 ,i=0; i<2; i++, y1+=8, y2+=8){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// copyright o

for(int x1=330, y1=593, x2=336, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=327, y1=598, x2=330, y2=610 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// copyright p

for(int x1=351, y1=593, x2=361, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

    glBegin(GL_POLYGON);

    glVertex2d(351,593);

    glVertex2d(354,593);

    glVertex2d(354,622);

    glVertex2d(351,622);
    glEnd();

    glBegin(GL_POLYGON);

    glVertex2d(361,596);

    glVertex2d(364,596);

    glVertex2d(364,610);

    glVertex2d(361,610);
    glEnd();

// copyright y

glBegin(GL_POLYGON);

    glVertex2d(377,593);

    glVertex2d(380,593);

    glVertex2d(380,605);

    glVertex2d(377,605);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(385,595);

    glVertex2d(389,595);

    glVertex2d(389,617);

    glVertex2d(385,617);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(379,606);

    glVertex2d(382,606);

    glVertex2d(382,609);

    glVertex2d(379,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(384,611);

    glVertex2d(388,611);

    glVertex2d(388,616);

    glVertex2d(384,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(377,615);

    glVertex2d(380,615);

    glVertex2d(380,618);

    glVertex2d(377,618);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(380,618);

    glVertex2d(385,618);

    glVertex2d(385,621);

    glVertex2d(380,621);
    glEnd();

// copyright r

glBegin(GL_POLYGON);

    glVertex2d(401,596);

    glVertex2d(404,596);

    glVertex2d(404,615);

    glVertex2d(401,615);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,599);

    glVertex2d(407,599);

    glVertex2d(407,602);

    glVertex2d(404,602);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(407,595);

    glVertex2d(415,595);

    glVertex2d(415,599);

    glVertex2d(407,599);
    glEnd();

// copyright i

glBegin(GL_POLYGON);

    glVertex2d(425,591);

    glVertex2d(429,591);

    glVertex2d(429,595);

    glVertex2d(425,595);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(425,600);

    glVertex2d(429,600);

    glVertex2d(429,615);

    glVertex2d(425,615);
    glEnd();

// copyright g

for(int x1=444, y1=594, x2=450, y2=597 ,i=0; i<2; i++, y1+=17, y2+=17){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(441,598);

    glVertex2d(444,598);

    glVertex2d(444,611);

    glVertex2d(441,611);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(450,597);

    glVertex2d(454,597);

    glVertex2d(454,618);

    glVertex2d(450,618);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(443,619);

    glVertex2d(450,619);

    glVertex2d(450,622);

    glVertex2d(443,622);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(464,586);

    glVertex2d(467,586);

    glVertex2d(467,615);

    glVertex2d(464,615);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(466,597);

    glVertex2d(473,597);

    glVertex2d(473,600);

    glVertex2d(466,600);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(473,602);

    glVertex2d(476,602);

    glVertex2d(476,616);

    glVertex2d(473,616);
    glEnd();

// copyright t
glBegin(GL_POLYGON);

    glVertex2d(489,586);

    glVertex2d(492,586);

    glVertex2d(492,611);

    glVertex2d(489,611);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(486,594);

    glVertex2d(495,594);

    glVertex2d(495,596);

    glVertex2d(486,596);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(492,612);

    glVertex2d(495,612);

    glVertex2d(495,616);

    glVertex2d(492,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(496,610);

    glVertex2d(499,610);

    glVertex2d(499,613);

    glVertex2d(496,613);
    glEnd();

// lil s

for(int x1=346, y1=650, x2=352, y2=653 ,i=0; i<3; i++, y1+=10, y2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(343,653);

    glVertex2d(346,653);

    glVertex2d(346,659);

    glVertex2d(343,659);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,653);

    glVertex2d(355,653);

    glVertex2d(355,656);

    glVertex2d(352,656);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(343,666);

    glVertex2d(346,666);

    glVertex2d(346,669);

    glVertex2d(343,669);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,662);

    glVertex2d(355,662);

    glVertex2d(355,668);

    glVertex2d(352,668);
    glEnd();

// lil u

for(int x1=366, y1=656, x2=369, y2=669 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(369,669);

    glVertex2d(378,669);

    glVertex2d(378,672);

    glVertex2d(369,672);
    glEnd();

// lil r

glBegin(GL_POLYGON);

    glVertex2d(389,657);

    glVertex2d(392,657);

    glVertex2d(392,672);

    glVertex2d(389,672);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(392,660);

    glVertex2d(396,660);

    glVertex2d(396,662);

    glVertex2d(392,662);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(396,656);

    glVertex2d(401,656);

    glVertex2d(401,659);

    glVertex2d(396,659);
    glEnd();

// lil y

glBegin(GL_POLYGON);

    glVertex2d(412,656);

    glVertex2d(415,656);

    glVertex2d(415,665);

    glVertex2d(412,665);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(415,666);

    glVertex2d(418,666);

    glVertex2d(418,669);

    glVertex2d(415,669);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(418,669);

    glVertex2d(424,669);

    glVertex2d(424,672);

    glVertex2d(418,672);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,657);

    glVertex2d(424,657);

    glVertex2d(424,675);

    glVertex2d(421,675);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(412,673);

    glVertex2d(415,673);

    glVertex2d(415,676);

    glVertex2d(412,676);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(415,676);

    glVertex2d(421,676);

    glVertex2d(421,678);

    glVertex2d(415,678);
    glEnd();

// lil o

for(int x1=438, y1=656, x2=444, y2=659 ,i=0; i<2; i++, y1+=14, y2+=14){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=435, y1=660, x2=438, y2=670 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// nomer 2018

glBegin(GL_POLYGON);

    glVertex2d(359,706);

    glVertex2d(365,706);

    glVertex2d(365,709);

    glVertex2d(359,709);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,709);

    glVertex2d(359,709);

    glVertex2d(359,715);

    glVertex2d(356,715);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(365,709);

    glVertex2d(369,709);

    glVertex2d(369,719);

    glVertex2d(365,719);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,720);

    glVertex2d(365,720);

    glVertex2d(365,725);

    glVertex2d(362,725);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(359,726);

    glVertex2d(362,726);

    glVertex2d(362,732);

    glVertex2d(359,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,729);

    glVertex2d(369,729);

    glVertex2d(369,732);

    glVertex2d(356,732);
    glEnd();

for(int x1=378, y1=709, x2=382, y2=729 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=382, y1=706, x2=389, y2=710 ,i=0; i<2; i++, y1+=23, y2+=23){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(405,707);

    glVertex2d(409,707);

    glVertex2d(409,732);

    glVertex2d(405,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(401,710);

    glVertex2d(408,710);

    glVertex2d(408,712);

    glVertex2d(401,712);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(401,729);

    glVertex2d(412,729);

    glVertex2d(412,732);

    glVertex2d(401,732);
    glEnd();

// nomer 8

for(int x1=425, y1=706, x2=431, y2=710 ,i=0; i<2; i++, y1+=14, y2+=14){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=421, y1=710, x2=425, y2=719 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=421, y1=723, x2=425, y2=730 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(425,730);

    glVertex2d(432,730);

    glVertex2d(432,733);

    glVertex2d(425,733);

    glEnd();

    // end of romaji
}

// start of romaji2

void romaji2(){
    glBegin(GL_POLYGON);
    glColor3ub(gr3,gr3,gr3);
    if (gr3>0){
            if (glfwGetTime()>1){
                    gr3-=0.45;}}
    glVertex2d(180,321);

    glVertex2d(208,321);

    glVertex2d(208,339);

    glVertex2d(180,339);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(208,338);

    glVertex2d(223,338);

    glVertex2d(223,354);

    glVertex2d(208,354);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(167,338);

    glVertex2d(179,338);

    glVertex2d(179,376);

    glVertex2d(167,376);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(179,372);

    glVertex2d(208,372);

    glVertex2d(208,391);

    glVertex2d(179,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(208,391);

    glVertex2d(223,391);

    glVertex2d(223,423);

    glVertex2d(208,423);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(180,424);

    glVertex2d(208,424);

    glVertex2d(208,442);

    glVertex2d(180,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(167,408);

    glVertex2d(180,408);

    glVertex2d(180,428);

    glVertex2d(167,428);
    glEnd();

// gray u

glBegin(GL_POLYGON);

    glVertex2d(267,355);

    glVertex2d(278,355);

    glVertex2d(278,428);

    glVertex2d(267,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(269,424);

    glVertex2d(321,424);

    glVertex2d(321,442);

    glVertex2d(269,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(309,355);

    glVertex2d(321,355);

    glVertex2d(321,442);

    glVertex2d(309,442);
    glEnd();

// gray r

glBegin(GL_POLYGON);

    glVertex2d(366,355);

    glVertex2d(380,355);

    glVertex2d(380,442);

    glVertex2d(366,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(380,372);

    glVertex2d(392,372);

    glVertex2d(392,390);

    glVertex2d(380,390);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(393,355);

    glVertex2d(421,355);

    glVertex2d(421,371);

    glVertex2d(393,371);
    glEnd();

// gray y

glBegin(GL_POLYGON);

    glVertex2d(464,355);

    glVertex2d(479,355);

    glVertex2d(479,409);

    glVertex2d(464,409);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(479,408);

    glVertex2d(493,408);

    glVertex2d(493,428);

    glVertex2d(479,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(493,424);

    glVertex2d(498,424);

    glVertex2d(498,428);

    glVertex2d(493,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(508,355);

    glVertex2d(522,355);

    glVertex2d(522,459);

    glVertex2d(508,459);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(464,443);

    glVertex2d(479,443);

    glVertex2d(479,462);

    glVertex2d(464,462);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(479,460);

    glVertex2d(507,460);

    glVertex2d(507,476);

    glVertex2d(479,476);
    glEnd();

// gray o

    glBegin(GL_POLYGON);

    glVertex2d(580,355);

    glVertex2d(608,355);

    glVertex2d(608,376);

    glVertex2d(580,376);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(565,372);

    glVertex2d(580,372);

    glVertex2d(580,428);

    glVertex2d(565,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(580,424);

    glVertex2d(608,424);

    glVertex2d(608,442);

    glVertex2d(580,442);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(608,372);

    glVertex2d(621,372);

    glVertex2d(621,423);

    glVertex2d(608,423);
    glEnd();


// white s

glBegin(GL_POLYGON);
    glColor3ub(bl3,bl3,bl3);
    if (bl3>0){
            if (glfwGetTime()>1){
    ;bl3-=0.8;}}
    glVertex2d(169,322);

    glVertex2d(197,322);

    glVertex2d(197,339);

    glVertex2d(169,339);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(156,340);

    glVertex2d(168,340);

    glVertex2d(168,375);

    glVertex2d(156,375);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(198,339);

    glVertex2d(213,339);

    glVertex2d(213,357);

    glVertex2d(198,357);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(169,376);

    glVertex2d(197,376);

    glVertex2d(197,391);

    glVertex2d(169,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(198,391);

    glVertex2d(213,391);

    glVertex2d(213,427);

    glVertex2d(198,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(156,409);

    glVertex2d(168,409);

    glVertex2d(168,427);

    glVertex2d(156,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(169,428);

    glVertex2d(197,428);

    glVertex2d(197,444);

    glVertex2d(169,444);
    glEnd();

// white u

glBegin(GL_POLYGON);

    glVertex2d(255,358);

    glVertex2d(268,358);

    glVertex2d(268,427);

    glVertex2d(255,427);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(269,428);

    glVertex2d(310,428);

    glVertex2d(310,444);

    glVertex2d(269,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(298,358);

    glVertex2d(311,358);

    glVertex2d(311,444);

    glVertex2d(298,444);
    glEnd();

// white r

glBegin(GL_POLYGON);

    glVertex2d(357,358);

    glVertex2d(369,358);

    glVertex2d(369,444);

    glVertex2d(357,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(368,376);

    glVertex2d(383,376);

    glVertex2d(383,391);

    glVertex2d(368,391);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(384,358);

    glVertex2d(410,358);

    glVertex2d(410,375);

    glVertex2d(384,375);
    glEnd();

// white y

glBegin(GL_POLYGON);

    glVertex2d(454,358);

    glVertex2d(469,358);

    glVertex2d(469,409);

    glVertex2d(454,409);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(470,409);

    glVertex2d(483,409);

    glVertex2d(483,428);

    glVertex2d(470,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(482,428);

    glVertex2d(510,428);

    glVertex2d(510,444);

    glVertex2d(482,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(498,358);

    glVertex2d(512,358);

    glVertex2d(512,461);

    glVertex2d(498,461);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(454,445);

    glVertex2d(469,445);

    glVertex2d(469,462);

    glVertex2d(454,462);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(470,462);

    glVertex2d(497,462);

    glVertex2d(497,478);

    glVertex2d(470,478);
    glEnd();

// white o

glBegin(GL_POLYGON);

    glVertex2d(569,358);

    glVertex2d(597,358);

    glVertex2d(597,375);

    glVertex2d(569,375);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(555,376);

    glVertex2d(569,376);

    glVertex2d(569,428);

    glVertex2d(555,428);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(569,428);

    glVertex2d(596,428);

    glVertex2d(596,444);

    glVertex2d(569,444);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(597,376);

    glVertex2d(611,376);

    glVertex2d(611,427);

    glVertex2d(597,427);
    glEnd();

// copyright c

for(int x1=304, y1=593, x2=311, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

    glBegin(GL_POLYGON);

    glVertex2d(301,597);

    glVertex2d(304,597);

    glVertex2d(304,609);

    glVertex2d(301,609);
    glEnd();

for(int x1=311, y1=598, x2=315, y2=601 ,i=0; i<2; i++, y1+=8, y2+=8){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// copyright o

for(int x1=330, y1=593, x2=336, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=327, y1=598, x2=330, y2=610 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// copyright p

for(int x1=351, y1=593, x2=361, y2=596 ,i=0; i<2; i++, y1+=18, y2+=18){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

    glBegin(GL_POLYGON);

    glVertex2d(351,593);

    glVertex2d(354,593);

    glVertex2d(354,622);

    glVertex2d(351,622);
    glEnd();

    glBegin(GL_POLYGON);

    glVertex2d(361,596);

    glVertex2d(364,596);

    glVertex2d(364,610);

    glVertex2d(361,610);
    glEnd();

// copyright y

glBegin(GL_POLYGON);

    glVertex2d(377,593);

    glVertex2d(380,593);

    glVertex2d(380,605);

    glVertex2d(377,605);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(385,595);

    glVertex2d(389,595);

    glVertex2d(389,617);

    glVertex2d(385,617);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(379,606);

    glVertex2d(382,606);

    glVertex2d(382,609);

    glVertex2d(379,609);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(384,611);

    glVertex2d(388,611);

    glVertex2d(388,616);

    glVertex2d(384,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(377,615);

    glVertex2d(380,615);

    glVertex2d(380,618);

    glVertex2d(377,618);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(380,618);

    glVertex2d(385,618);

    glVertex2d(385,621);

    glVertex2d(380,621);
    glEnd();

// copyright r

glBegin(GL_POLYGON);

    glVertex2d(401,596);

    glVertex2d(404,596);

    glVertex2d(404,615);

    glVertex2d(401,615);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(404,599);

    glVertex2d(407,599);

    glVertex2d(407,602);

    glVertex2d(404,602);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(407,595);

    glVertex2d(415,595);

    glVertex2d(415,599);

    glVertex2d(407,599);
    glEnd();

// copyright i

glBegin(GL_POLYGON);

    glVertex2d(425,591);

    glVertex2d(429,591);

    glVertex2d(429,595);

    glVertex2d(425,595);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(425,600);

    glVertex2d(429,600);

    glVertex2d(429,615);

    glVertex2d(425,615);
    glEnd();

// copyright g

for(int x1=444, y1=594, x2=450, y2=597 ,i=0; i<2; i++, y1+=17, y2+=17){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(441,598);

    glVertex2d(444,598);

    glVertex2d(444,611);

    glVertex2d(441,611);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(450,597);

    glVertex2d(454,597);

    glVertex2d(454,618);

    glVertex2d(450,618);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(443,619);

    glVertex2d(450,619);

    glVertex2d(450,622);

    glVertex2d(443,622);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(464,586);

    glVertex2d(467,586);

    glVertex2d(467,615);

    glVertex2d(464,615);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(466,597);

    glVertex2d(473,597);

    glVertex2d(473,600);

    glVertex2d(466,600);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(473,602);

    glVertex2d(476,602);

    glVertex2d(476,616);

    glVertex2d(473,616);
    glEnd();

// copyright t
glBegin(GL_POLYGON);

    glVertex2d(489,586);

    glVertex2d(492,586);

    glVertex2d(492,611);

    glVertex2d(489,611);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(486,594);

    glVertex2d(495,594);

    glVertex2d(495,596);

    glVertex2d(486,596);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(492,612);

    glVertex2d(495,612);

    glVertex2d(495,616);

    glVertex2d(492,616);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(496,610);

    glVertex2d(499,610);

    glVertex2d(499,613);

    glVertex2d(496,613);
    glEnd();

// lil s

for(int x1=346, y1=650, x2=352, y2=653 ,i=0; i<3; i++, y1+=10, y2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(343,653);

    glVertex2d(346,653);

    glVertex2d(346,659);

    glVertex2d(343,659);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,653);

    glVertex2d(355,653);

    glVertex2d(355,656);

    glVertex2d(352,656);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(343,666);

    glVertex2d(346,666);

    glVertex2d(346,669);

    glVertex2d(343,669);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(352,662);

    glVertex2d(355,662);

    glVertex2d(355,668);

    glVertex2d(352,668);
    glEnd();

// lil u

for(int x1=366, y1=656, x2=369, y2=669 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(369,669);

    glVertex2d(378,669);

    glVertex2d(378,672);

    glVertex2d(369,672);
    glEnd();

// lil r

glBegin(GL_POLYGON);

    glVertex2d(389,657);

    glVertex2d(392,657);

    glVertex2d(392,672);

    glVertex2d(389,672);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(392,660);

    glVertex2d(396,660);

    glVertex2d(396,662);

    glVertex2d(392,662);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(396,656);

    glVertex2d(401,656);

    glVertex2d(401,659);

    glVertex2d(396,659);
    glEnd();

// lil y

glBegin(GL_POLYGON);

    glVertex2d(412,656);

    glVertex2d(415,656);

    glVertex2d(415,665);

    glVertex2d(412,665);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(415,666);

    glVertex2d(418,666);

    glVertex2d(418,669);

    glVertex2d(415,669);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(418,669);

    glVertex2d(424,669);

    glVertex2d(424,672);

    glVertex2d(418,672);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(421,657);

    glVertex2d(424,657);

    glVertex2d(424,675);

    glVertex2d(421,675);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(412,673);

    glVertex2d(415,673);

    glVertex2d(415,676);

    glVertex2d(412,676);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(415,676);

    glVertex2d(421,676);

    glVertex2d(421,678);

    glVertex2d(415,678);
    glEnd();

// lil o

for(int x1=438, y1=656, x2=444, y2=659 ,i=0; i<2; i++, y1+=14, y2+=14){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=435, y1=660, x2=438, y2=670 ,i=0; i<2; i++, x1+=9, x2+=9){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

// nomer 2018

glBegin(GL_POLYGON);

    glVertex2d(359,706);

    glVertex2d(365,706);

    glVertex2d(365,709);

    glVertex2d(359,709);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,709);

    glVertex2d(359,709);

    glVertex2d(359,715);

    glVertex2d(356,715);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(365,709);

    glVertex2d(369,709);

    glVertex2d(369,719);

    glVertex2d(365,719);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(362,720);

    glVertex2d(365,720);

    glVertex2d(365,725);

    glVertex2d(362,725);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(359,726);

    glVertex2d(362,726);

    glVertex2d(362,732);

    glVertex2d(359,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(356,729);

    glVertex2d(369,729);

    glVertex2d(369,732);

    glVertex2d(356,732);
    glEnd();

for(int x1=378, y1=709, x2=382, y2=729 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=382, y1=706, x2=389, y2=710 ,i=0; i<2; i++, y1+=23, y2+=23){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(405,707);

    glVertex2d(409,707);

    glVertex2d(409,732);

    glVertex2d(405,732);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(401,710);

    glVertex2d(408,710);

    glVertex2d(408,712);

    glVertex2d(401,712);
    glEnd();

glBegin(GL_POLYGON);

    glVertex2d(401,729);

    glVertex2d(412,729);

    glVertex2d(412,732);

    glVertex2d(401,732);
    glEnd();

// nomer 8

for(int x1=425, y1=706, x2=431, y2=710 ,i=0; i<2; i++, y1+=14, y2+=14){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=421, y1=710, x2=425, y2=719 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

for(int x1=421, y1=723, x2=425, y2=730 ,i=0; i<2; i++, x1+=10, x2+=10){
    glBegin(GL_POLYGON);

    glVertex2d(x1,y1);

    glVertex2d(x2,y1);

    glVertex2d(x2,y2);

    glVertex2d(x1,y2);
    glEnd();
}

glBegin(GL_POLYGON);

    glVertex2d(425,730);

    glVertex2d(432,730);

    glVertex2d(432,733);

    glVertex2d(425,733);

    glEnd();

    // end of romaji
}

void display1(){
    katakana1();

}

void display2(){
    katakana2();
}

void display3(){
    romaji();
}

void display4(){
    romaji2();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160095", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);


    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);


        display1();

        if(glfwGetTime()>3.5)
        display2();
        if(glfwGetTime()>4.75)
        display3();
        if(glfwGetTime()>6)
        display4();
        if(glfwGetTime()>6.9) {
            glfwSetTime(0);
            gry = 190;
            wht = 255;
            bl  =   0;
            gr  =   0;
            bl2 =   0;
            gr2 =   0;
            bl3 = 255;
            gr3 = 190;
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
