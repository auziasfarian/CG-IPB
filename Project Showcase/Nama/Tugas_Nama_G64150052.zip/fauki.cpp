#include <GLFW/glfw3.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 470

using namespace std;

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); //Close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting view ports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, SCREEN_WIDTH, SCREEN_HEIGHT, 0, 1.f, -1.f); // left, right, bottom, top, front, back

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void background()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,128);
    glVertex2d(0,0);
    glVertex2d(0,470);
    glVertex2d(800,470);
    glVertex2d(800,0);
    glEnd();
}

void nama()
{
    //Huruf F
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(128,153);
    glVertex2d(213,153);
    glVertex2d(213,170);
    glVertex2d(128,170);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(128,300);
    glVertex2d(148,300);
    glVertex2d(148,153);
    glVertex2d(128,153);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(128,230);
    glVertex2d(200,230);
    glVertex2d(200,210);
    glVertex2d(128,210);
    glEnd();
    
    
    //Huruf A
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(208,300);
    glVertex2d(228,300);
    glVertex2d(288,153);
    glVertex2d(268,153);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(325,300);
    glVertex2d(345,300);
    glVertex2d(288,153);
    glVertex2d(268,153);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(240,250);
    glVertex2d(315,250);
    glVertex2d(315,270);
    glVertex2d(240,270);
    glEnd();
    
    //huruf U
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(365,153);
    glVertex2d(385,153);
    glVertex2d(385,270);
    glVertex2d(365,285);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(385,270);
    glVertex2d(365,285);
    glVertex2d(420,300);
    glVertex2d(420,280);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(420,300);
    glVertex2d(420,280);
    glVertex2d(460,265);
    glVertex2d(480,280);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(460,300);
    glVertex2d(480,300);
    glVertex2d(480,153);
    glVertex2d(460,153);
    glEnd();
    
    //huruf k
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(517,300);
    glVertex2d(537,300);
    glVertex2d(537,153);
    glVertex2d(517,153);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(537,217);
    glVertex2d(603,153);
    glVertex2d(625,153);
    glVertex2d(537,239);
    glEnd();
    
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(542,213);
    glVertex2d(625,300);
    glVertex2d(603,300);
    glVertex2d(542,235);
    glEnd();
    
    //juruf I
    glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(650,300);
    glVertex2d(670,300);
    glVertex2d(670,153);
    glVertex2d(650,153);
    glEnd();

	//kotak kanan
	glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(690,330);
    glVertex2d(700,330);
    glVertex2d(700,123);
    glVertex2d(690,123);
    glEnd();
    
    //kotak kiri
	glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(108,330);
    glVertex2d(98,330);
    glVertex2d(98,123);
    glVertex2d(108,123);
    glEnd();
    
    //kotak atas
	glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(670,123);
    glVertex2d(128,123);
    glVertex2d(128,133);
    glVertex2d(670,133);
    glEnd();
    
    //kotak bawah
	glBegin(GL_POLYGON);
    glColor3ub(255,0,0);
    glVertex2d(670,320);
    glVertex2d(128,320);
    glVertex2d(128,330);
    glVertex2d(670,330);
    glEnd();
}


int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);

    // initialize the GLFW
    if (!glfwInit())
        exit(EXIT_FAILURE);

    // create a windowed mode and its OpenGL context
    window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Tugas Nama FAUKI", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    // make the window's context current
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    // loop until the user closes window
    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        background();
        nama();

        // swap front and back buffers
        glfwSwapBuffers(window);

        // poll for and process any events
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
