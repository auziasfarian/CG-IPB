#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#define maroon1 83, 71, 65
#define maroon2 99, 85, 79
#define maroon3 117, 100, 94
#define black 0+255*DETIK, 0+255*DETIK, 0+255*DETIK

float DETIK = 0.25;
float DETIK2 = 0.0;
float go =0.0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);

    // Background
    glColor3ub(226, 200, 181);
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(0, 800);
    glVertex2d(800, 800);
    glVertex2d(800, 0);
    glEnd();


 //Huruf t
    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(133.71,264);
    glVertex2d(114.61,274.97);
    glVertex2d(133.71,286.06);
    glVertex2d(152.82,275.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(114.61,274.97);
    glVertex2d(114.61,494.97);
    glVertex2d(133.71,505.97);
    glVertex2d(133.71,286.06);
    glEnd();

    glColor3ub(maroon3);
    glBegin(GL_POLYGON);
    glVertex2d(152.82,275.03);
    glVertex2d(133.71,286.06);
    glVertex2d(133.71,505.97);
    glVertex2d(152.82,494.97);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(152.82,275.03);
    glVertex2d(133.71,286.06);
    glVertex2d(133.71,505.97);
    glVertex2d(152.82,494.97);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(152.82,275.03);
    glVertex2d(133.71,286.06);
    glVertex2d(133.71,505.97);
    glVertex2d(152.82,494.97);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(152.82,275.03);
    glVertex2d(133.71,286.06);
    glVertex2d(133.71,505.97);
    glVertex2d(152.82,494.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(152.82,363.09);
    glVertex2d(133.71,374.06);
    glVertex2d(171.92,396.11);
    glVertex2d(191.02,385.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(133.71,374.06);
    glVertex2d(133.71,395.94);
    glVertex2d(171.92,417.94);
    glVertex2d(171.92,396.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(191.02,385.09);
    glVertex2d(171.92,396.11);
    glVertex2d(171.92,417.94);
    glVertex2d(191.02,406.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(152.82,473.11);
    glVertex2d(133.71,484.09);
    glVertex2d(210.12,528.45);
    glVertex2d(229.23,517.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(133.71,484.09);
    glVertex2d(133.71,505.97);
    glVertex2d(210.12,550.28);
    glVertex2d(210.12,528.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(229.23,517.43);
    glVertex2d(210.12,528.45);
    glVertex2d(210.12,550.28);
    glVertex2d(229.23,539.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(229.23,494.97);
    glVertex2d(210.12,506.40);
    glVertex2d(229.23,517.43);
    glVertex2d(248.33,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(248.33,506);
    glVertex2d(229.23,517.43);
    glVertex2d(229.23,539.26);
    glVertex2d(248.33,528.34);
    glEnd();

    //Huruf A

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(343.84,363.20);
    glVertex2d(248.33,308);
    glVertex2d(229.23,318.97);
    glVertex2d(324.74,374.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(248.33,330.00);
    glVertex2d(229.23,318.97);
    glVertex2d(229.23,495.48);
    glVertex2d(248.33,506.51);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(267.43,341.09);
    glVertex2d(248.33,352.00);
    glVertex2d(248.33,506.51);
    glVertex2d(267.43,495.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(267.43,408.73);
    glVertex2d(248.33,419.70);
    glVertex2d(305.63,453.07);
    glVertex2d(324.74,442.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(305.63,453.07);
    glVertex2d(248.33,419.70);
    glVertex2d(248.33,441.59);
    glVertex2d(305.63,474.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(305.63,363.14);
    glVertex2d(248.33,330.00);
    glVertex2d(248.33,352.00);
    glVertex2d(305.63,385.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(324.74,374.23);
    glVertex2d(305.63,363.14);
    glVertex2d(305.63,539.16);
    glVertex2d(324.74,550.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(382.04,494.89);
    glVertex2d(362.94,483.89);
    glVertex2d(324.74,505.83);
    glVertex2d(343.84,516.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(382.04,494.89);
    glVertex2d(343.84,516.89);
    glVertex2d(343.84,539.16);
    glVertex2d(382.04,517.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(343.84,363.20);
    glVertex2d(324.74,374.23);
    glVertex2d(324.74,550.18);
    glVertex2d(343.84,539.16);
    glEnd();

    //Huruf M
    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(401.14,352.23);
    glVertex2d(382.04,363.09);
    glVertex2d(382.04,494.89);
    glVertex2d(401.14,483.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(420.25,363.31);
    glVertex2d(382.04,341.20);
    glVertex2d(382.04,363.09);
    glVertex2d(420.25,385.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(382.04,341.20);
    glVertex2d(362.94,330.17);
    glVertex2d(362.94,483.89);
    glVertex2d(382.04,494.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(439.35,352.28);
    glVertex2d(382.04,319.20);
    glVertex2d(362.94,330.17);
    glVertex2d(420.25,363.31);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(439.35,352.28);
    glVertex2d(420.25,363.31);
    glVertex2d(420.25,385.03);
    glVertex2d(439.35,374.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(439.35,395.72);
    glVertex2d(420.25,385.03);
    glVertex2d(420.25,428.97);
    glVertex2d(439.35,440.00);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(458.45,384.80);
    glVertex2d(439.35,395.72);
    glVertex2d(439.35,440.00);
    glVertex2d(458.45,428.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(439.35,374.06);
    glVertex2d(420.25,385.03);
    glVertex2d(439.35,395.72);
    glVertex2d(458.45,384.80);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(458.45,362.86);
    glVertex2d(439.35,373.83);
    glVertex2d(496.66,407.00);
    glVertex2d(515.76,395.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(439.35,373.83);
    glVertex2d(439.35,395.72);
    glVertex2d(477.55,417.72);
    glVertex2d(477.55,395.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(496.66,407.00);
    glVertex2d(477.55,395.92);
    glVertex2d(477.55,542.54);
    glVertex2d(496.66,553.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(553.96,498.58);
    glVertex2d(534.86,487.55);
    glVertex2d(496.66,509.44);
    glVertex2d(515.76,520.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(553.96,498.58);
    glVertex2d(515.76,520.52);
    glVertex2d(515.76,542.35);
    glVertex2d(553.96,521.00);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(515.76,395.97);
    glVertex2d(496.66,407.00);
    glVertex2d(496.66,553.57);
    glVertex2d(515.76,542.54);
    glEnd();


    //Huruf A
    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(573.06,341.37);
    glVertex2d(553.96,352.40);
    glVertex2d(553.96,498.58);
    glVertex2d(573.06,487.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(573.06,341.37);
    glVertex2d(553.96,330.34);
    glVertex2d(534.86,341.31);
    glVertex2d(553.96,352.40);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(553.96,352.40);
    glVertex2d(534.86,341.31);
    glVertex2d(534.86,487.55);
    glVertex2d(553.96,498.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(630.37,462.06);
    glVertex2d(573.06,428.97);
    glVertex2d(553.96,439.95);
    glVertex2d(611.27,473.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(611.27,473.09);
    glVertex2d(553.96,439.95);
    glVertex2d(553.96,461.83);
    glVertex2d(611.27,494.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(553.96,330.34);
    glVertex2d(534.86,341.31);
    glVertex2d(611.27,385.37);
    glVertex2d(630.37,374.34);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(553.96,352.34);
    glVertex2d(553.96,374.23);
    glVertex2d(611.27,407.20);
    glVertex2d(611.27,385.37);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon1);
    glVertex2d(611.27,385.20);
    glVertex2d(630.37,396.29);
    glVertex2d(649.47,385.26);
    glVertex2d(630.37,374.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon2);
    glVertex2d(630.37,396.29);
    glVertex2d(611.27,385.20);
    glVertex2d(611.27,538.40);
    glVertex2d(630.37,549.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(maroon3);
    glVertex2d(649.47,385.26);
    glVertex2d(630.37,396.29);
    glVertex2d(630.37,549.43);
    glVertex2d(649.47,538.40);
    glEnd();

    //Titik
    glBegin(GL_POLYGON);
    glColor3ub(0+255*DETIK,0+255*DETIK,0+255*DETIK);
    glVertex2d(668.57,527.49);
    glVertex2d(649.47,538.46);
    glVertex2d(668.57,549.55);
    glVertex2d(687.68,538.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0+150*DETIK,0+150*DETIK,0+150*DETIK);
    glVertex2d(668.57,549.55);
    glVertex2d(649.47,538.46);
    glVertex2d(649.47,560.35);
    glVertex2d(668.57,571.38);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0+100*DETIK,0+100*DETIK,0+100*DETIK);
    glVertex2d(687.68,538.52);
    glVertex2d(668.57,549.55);
    glVertex2d(668.57,571.38);
    glVertex2d(687.68,560.35);
    glEnd();

    //Titik2
    glBegin(GL_POLYGON);
    glColor3ub(0+255*DETIK,0+255*DETIK,0+255*DETIK);
    glVertex2d(439.35,462.00);
    glVertex2d(420.25,472.97);
    glVertex2d(439.35,484.06);
    glVertex2d(458.45,473.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0+200*DETIK,0+200*DETIK,0+200*DETIK);
    glVertex2d(458.45,473.03);
    glVertex2d(439.35,484.06);
    glVertex2d(439.35,505.89);
    glVertex2d(458.45,494.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0+145*DETIK,0+145*DETIK,0+145*DETIK);
    glVertex2d(439.35,484.06);
    glVertex2d(420.25,472.97);
    glVertex2d(420.25,494.86);
    glVertex2d(439.35,505.89);
    glEnd();

    //Line
    glBegin(GL_POLYGON);
    glColor3ub(black);
    glVertex2d(229.23+go/10,289.59);
    glVertex2d(229.23+go/10,297.09);
    glVertex2d(706.78+go/10,297.09);
    glVertex2d(706.78+go/10,289.59);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(black);
    glVertex2d(596.94+go/10,565.63);
    glVertex2d(71.63+go/10,565.63);
    glVertex2d(71.63+go/10,573.13);
    glVertex2d(596.94+go/10,573.13);
    glEnd();

    glFlush();
    go++;
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160034_Ghalyatama Ikram Fauzi", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        DETIK = glfwGetTime();
        DETIK2 = sin(DETIK);

        setup_viewport(window);

        display();
        if (go<255) go+=0.5;
        else go=2;


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
