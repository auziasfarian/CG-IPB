#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
    // your code here, maybe
}

void A()
{
    //garis A kiri
    glBegin(GL_POLYGON);
    glColor3ub(224,234,208);

    glVertex2d(121.02,259.01);
    glVertex2d(134.82,259.01);
    glVertex2d(134.82,355.31);
    glVertex2d(75.12,484.01);
    glVertex2d(16.02,484.01);

    glEnd();

    //garis A kanan
    glBegin(GL_POLYGON);
    glColor3ub(224,234,208);

    glVertex2d(134.82,259.01);
    glVertex2d(147.72,259.01);
    glVertex2d(253.62,484.01);
    glVertex2d(194.52,484.01);
    glVertex2d(157.62,404.81);
    glVertex2d(134.82,355.31);

    glEnd();

    //garis A tengah
    glBegin(GL_POLYGON);
    glColor3ub(224,234,208);

    glVertex2d(111.72,404.81);
    glVertex2d(157.62,404.81);
    glVertex2d(180.72,454.61);
    glVertex2d(88.62,454.61);

    glEnd();

}

void BG()
{
    glBegin(GL_POLYGON);
    glColor3ub(250,250,250);

    glVertex2d(0,0);
    glVertex2d(800,0);
   // glColor4ub(172,187,211,1);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();
}

void N()
{
    //N kiri
    glBegin(GL_POLYGON);
    glColor3ub(213,233,195);

    glVertex2d(283.62,227.01);
    glVertex2d(307.62,227.01);
    glVertex2d(342.72,262.01);
    glVertex2d(342.72,452.01);
    glVertex2d(283.62,452.01);

    glEnd();

    //N tengah
    glBegin(GL_POLYGON);
    glColor3ub(213,233,195);

    glVertex2d(342.72,262.01);
    glVertex2d(414.12,333.21);
    glVertex2d(414.12,417.12);
    glVertex2d(342.72,345.51);

    glEnd();

    //N kanan
    glBegin(GL_POLYGON);
    glColor3ub(213,233,195);

    glVertex2d(414.12,227.01);
    glVertex2d(473.22,227.01);
    glVertex2d(473.22,452.01);
    glVertex2d(448.92,452.01);
    glVertex2d(414.12,417.12);

    glEnd();
}

void I()
{
    //N kiri
    glBegin(GL_POLYGON);
    glColor3ub(188,222,174);

    glVertex2d(518.21,248.01);
    glVertex2d(577.32,248.01);
    glVertex2d(577.32,473.01);
    glVertex2d(518.21,473.01);

    glEnd();
}

void S()
{
    //atas
    glBegin(GL_POLYGON);
    glColor3ub(120,150,112);

    glVertex2d(719.45,201.53);
    glVertex2d(683.63,303.52);
    glVertex2d(611.59,293.02);

    glEnd();

    //tengah
    glBegin(GL_POLYGON);
    glColor3ub(120,150,112);

    glVertex2d(683.63,303.52);
    glVertex2d(763.63,407.02);
    glVertex2d(705.58,391.94);
    glVertex2d(611.59,293.02);

    glEnd();

    //bawah
    glBegin(GL_POLYGON);
    glColor3ub(120,150,112);

    glVertex2d(763.63,407.02);
    glVertex2d(622.63,452.02);
    glVertex2d(705.58,391.94);

    glEnd();

}

void newS()
{
    //s atas
    glBegin(GL_POLYGON);
    glColor3ub(120,150,112);

    for (int i=-270; i <=-40 ; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(686.46+cos(rad)*69.3,249.61+sin(rad)*69.3);
        }
        glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250,250,250);

        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(686.46+cos(rad)*20,249.61+sin(rad)*20);
        }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250,250,250);

    glVertex2d(676.01,267.57);
    glVertex2d(693.48,230.3);
    glVertex2d(721.51,253.3);
    glVertex2d(704.04,283);

    glEnd();

    //s bawah
    glBegin(GL_POLYGON);
    glColor3ub(120,150,112);

    for (int i=-80; i <=180 ; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(687.14+cos(rad)*69.3,350.4+sin(rad)*69.3);
        }
        glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250,250,250);

        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(687.14+cos(rad)*20,350.4+sin(rad)*20);
        }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(250,250,250);

    glVertex2d(648.35,308.3);
    glVertex2d(694.32,332);
    glVertex2d(670.5,362);
    glVertex2d(640.67,320);

    glEnd();
}

void Pohon()
{
    //Batang 1
    glBegin(GL_POLYGON);
    glColor3ub(66,66,105);

    glVertex2d(105.71,677.18);
    glVertex2d(112.93,677.18);
    glVertex2d(112.93,721.01);
    glVertex2d(105.71,721.01);

    glEnd();
    //Pohon 1
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);

    glVertex2d(110.35,622.48);
    glVertex2d(127.37,652.87);
    glVertex2d(119.4,652.87);
    glVertex2d(128.43,669);
    glVertex2d(120.42,669);
    glVertex2d(132.02,689.71);
    glVertex2d(88.18,689.71);
    glVertex2d(100.13,669);
    glVertex2d(91.77,669);
    glVertex2d(101.07,652.87);
    glVertex2d(92.82,652.87);

    glEnd();

     //Batang 2
    glBegin(GL_POLYGON);
    glColor3ub(66,66,105);

    glVertex2d(338.9,661.57);
    glVertex2d(344.31,661.57);
    glVertex2d(344.31,694.42);
    glVertex2d(338.9,694.42);

    glEnd();
    //Pohon 2
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);

    glVertex2d(342.38,620.58);
    glVertex2d(355.13,643.35);
    glVertex2d(349.16,643.35);
    glVertex2d(355.92,655.43);
    glVertex2d(349.92,655.43);
    glVertex2d(358.61,670.95);
    glVertex2d(325.76,670.95);
    glVertex2d(334.72,655.43);
    glVertex2d(328.45,655.43);
    glVertex2d(335.42,643.35);
    glVertex2d(329.24,643.35);

    glEnd();

    //Batang 3
    glBegin(GL_POLYGON);
    glColor3ub(66,66,105);

    glVertex2d(459.09,632.39);
    glVertex2d(462.67,632.39);
    glVertex2d(462.67,654.13);
    glVertex2d(459.09,654.13);

    glEnd();

    //Pohon 3
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);

    glVertex2d(461.39,605.26);
    glVertex2d(469.83,620.33);
    glVertex2d(465.88,620.33);
    glVertex2d(470.36,628.33);
    glVertex2d(466.38,628.33);
    glVertex2d(472.14,638.6);
    glVertex2d(450.39,638.6);
    glVertex2d(456.32,628.33);
    glVertex2d(452.17,628.33);
    glVertex2d(456.79,620.33);
    glVertex2d(452.7,620.33);


    glEnd();

    //Batang 4
    glBegin(GL_POLYGON);
    glColor3ub(66,66,105);

    glVertex2d(763.95,649.05);
    glVertex2d(767.68,649.05);
    glVertex2d(767.68,663.5);
    glVertex2d(763.95,663.5);

    glEnd();

    //Pohon 4
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);

    glVertex2d(766.35,620.82);
    glVertex2d(775.14,636.51);
    glVertex2d(771.01,636.51);
    glVertex2d(775.67,644.83);
    glVertex2d(771.54,644.83);
    glVertex2d(777.52,655.52);
    glVertex2d(754.9,655.52);
    glVertex2d(761.07,644.83);
    glVertex2d(756.75,644.83);
    glVertex2d(761.55,636.51);
    glVertex2d(757.3,636.51);


    glEnd();
}


void Gunung()
{
    //Gunung 1
    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    //ungu
    glVertex2d(0,591.44);
    glVertex2d(110.1,708.42);
    glVertex2d(0,800);

    glEnd();
    //Gunung 2
    glBegin(GL_POLYGON);
    glColor3ub(243,216,232);
    //pink
    glVertex2d(0,800);
    glVertex2d(250.74,591.44);
    glVertex2d(291.84,800);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    //ungu
    glVertex2d(250.74,591.44);
    glVertex2d(471.29,800);
    glVertex2d(291.84,800);

    glEnd();

    //Gunung 3
    glBegin(GL_POLYGON);
    glColor3ub(243,216,232);
    //pink
    glVertex2d(531.56,543.49);
    glVertex2d(675.52,800);
    glVertex2d(353.48,800);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    //ungu
    glVertex2d(531.56,543.49);
    glVertex2d(800,677.74);
    glVertex2d(800,800);
    glVertex2d(675.52,800);

    glEnd();
}

void BungaA()
{
    // glRotatef((float) glfwGetTime() * 100.f, 300.f, 600.f, 0.f);
    //kiri bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(235.33+cos(rad)*14.23,483.33+sin(rad)*14.23);
        }
    glEnd();

    //kiri atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(225.92+cos(rad)*14.23,465.35+sin(rad)*14.23);
        }
    glEnd();

    //kanan atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(243.34+cos(rad)*14.23,457.29+sin(rad)*14.23);
        }
    glEnd();

    //kanan bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(253.2+cos(rad)*14.23,474.83+sin(rad)*14.23);
        }
    glEnd();

    //kuning
    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(239.41+cos(rad)*9.67,470.05+sin(rad)*9.67);
        }
    glEnd();

}

void BungaN()
{
    // glRotatef((float) glfwGetTime() * 100.f, 300.f, 600.f, 0.f);
    //kiri bawah
    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(306.99+cos(rad)*14.23,253.7+sin(rad)*14.23);
        }
    glEnd();

    //kiri atas
    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(295.37+cos(rad)*14.23,231.5+sin(rad)*14.23);
        }
    glEnd();

    //kanan atas
    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(316.88+cos(rad)*14.23,221.54+sin(rad)*14.23);
        }
    glEnd();

    //kanan bawah
    glBegin(GL_POLYGON);
    glColor3ub(205,178,191);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(329.06+cos(rad)*14.23,243.2+sin(rad)*14.23);
        }
    glEnd();

    //kuning
    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(312.03+cos(rad)*9.67,237.3+sin(rad)*9.67);
        }
    glEnd();

}

void BungaI()
{
    // glRotatef((float) glfwGetTime() * 100.f, 300.f, 600.f, 0.f);
    //kiri bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(536.31+cos(rad)*12,221.99+sin(rad)*12);
        }
    glEnd();

    //kiri atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(541.67+cos(rad)*12,206.92+sin(rad)*12);
        }
    glEnd();

    //kanan atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(557.31+cos(rad)*12,211.81+sin(rad)*12);
        }
    glEnd();

    //kanan bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(551.97+cos(rad)*12,226.37+sin(rad)*12);
        }
    glEnd();

    //kuning
    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(546.92+cos(rad)*7.8,216.84+sin(rad)*7.8);
        }
    glEnd();

}
void BungaS()
{
    // glRotatef((float) glfwGetTime() * 100.f, 300.f, 600.f, 0.f);
    //kiri bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(618.02+cos(rad)*12.6,351.84+sin(rad)*12.6);
        }
    glEnd();

    //kiri atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(609.33+cos(rad)*12.6,335.25+sin(rad)*12.6);
        }
    glEnd();

    //kanan atas
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(625.41+cos(rad)*12.6,327.8+sin(rad)*12.6);
        }
    glEnd();

    //kanan bawah
    glBegin(GL_POLYGON);
    glColor3ub(164,186,197);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(634.51+cos(rad)*12.6,343.99+sin(rad)*12.6);
        }
    glEnd();

    //kuning
    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
    for (int i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(621.78+cos(rad)*9,339.58+sin(rad)*9);
        }
    glEnd();

}

void KotakA()
{
    int colorf[3][3]={{224,234,208},{213,233,195},{188,222,174}};
    //Warna A
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    glVertex2d(0,0);
    glVertex2d(253.62,0);
    glVertex2d(253.62,98.61);
    glVertex2d(0,98.61);

    glEnd();
}

void KotakN()
{
    int colorf[3][3]={{213,233,195},{188,222,174},{120,150,112}};
    //Warna N
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);


    glVertex2d(253.62,0);
    glVertex2d(439.09,0);
    glVertex2d(439.09,98.61);
    glVertex2d(253.62,98.61);

    glEnd();
}

void KotakI()
{
    int colorf[3][3]={{188,222,174},{120,150,112},{224,234,208}};
    //Warna I
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    glVertex2d(439.09,0);
    glVertex2d(577.32,0);
    glVertex2d(577.32,98.61);
    glVertex2d(439.09,98.61);

    glEnd();
}

void KotakS()
{
    int colorf[3][3]={{120,150,112},{224,234,208},{213,233,195}};
    //Warna S
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    glVertex2d(577.32,0);
    glVertex2d(800,0);
    glVertex2d(800,98.61);
    glVertex2d(577.32,98.61);

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Nisrina Sudrajat - <G64160050>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        setup_viewport(window);

        display();

        //panggil fungsi
        BG();
        A();
        N();
        I();
        newS();
        Pohon();
        Gunung();
        BungaA();
        BungaN();
        BungaI();
        BungaS();
        KotakA();
        KotakN();
        KotakI();
        KotakS();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
