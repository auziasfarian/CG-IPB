#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    //glOrtho(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your drawing code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
void latar() // ini untuk buat r
{

    glBegin(GL_POLYGON);

    glColor3ub(255,255,255);

    glVertex2d(10,550);
    glVertex2d(10,16);
    glVertex2d(789,16);
    glVertex2d(789,550);


    glEnd();

}

void wadah(){

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

    glVertex2d(26,400);
    glVertex2d(773,400);
    glVertex2d(586,537);
    glVertex2d(213,537);


    glEnd();

}

void R()
{

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(653,252);
    glVertex2d(653,378);
    glVertex2d(682,378);
    glVertex2d(682,284);


    glEnd();

}
void R2()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

    glVertex2d(653,252);
    glVertex2d(740,252);
    glVertex2d(755,268);
    glVertex2d(726,284);
    glVertex2d(682,284);




    glEnd();

}
void R3()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

    glVertex2d(755,268);
    glVertex2d(755,315);
    glVertex2d(740,331);
    glVertex2d(733,331);
    glVertex2d(726,300);
    glVertex2d(726,284);
    glVertex2d(682,284);

    glEnd();

}

void R4()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(726,300);
    glVertex2d(697,300);
    glVertex2d(697,315);
    glVertex2d(726,378);
    glVertex2d(755,378);
    glVertex2d(733,331);

    glEnd();

}

void F()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(37,379);
    glVertex2d(37,253);
    glVertex2d(66,284);
    glVertex2d(66,379);

    glEnd();

}
void F2()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(37,253);
    glVertex2d(139,253);
    glVertex2d(124,284);
    glVertex2d(66,284);

    glEnd();

}
void F3()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(66,299);
    glVertex2d(124,299);
    glVertex2d(124,331);
    glVertex2d(66,331);

    glEnd();

}
void A()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(139,378);
    glVertex2d(197,252);
    glVertex2d(211,300);
    glVertex2d(175,378);

    glEnd();

}
void A2()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(197,252);
    glVertex2d(226,252);
    glVertex2d(284,378);
    glVertex2d(247,378);
    glVertex2d(211,300);
    glEnd();

}
void A3()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(226,331);
    glVertex2d(204,331);
    glVertex2d(189,363);
    glVertex2d(240,363);
    glEnd();

}

void T()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(305,378);
    glVertex2d(305,284);
    glVertex2d(334,284);
    glVertex2d(334,378);
    glEnd();

}

void T2()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(305,284);
    glVertex2d(268,284);
    glVertex2d(268,252);
    glVertex2d(384,252);
    glVertex2d(355,284);
    glVertex2d(334,284);

    glEnd();

}
void H()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(399,378);
    glVertex2d(399,252);
    glVertex2d(428,252);
    glVertex2d(428,378);

    glEnd();

}
void H2()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(428,331);
    glVertex2d(428,300);
    glVertex2d(472,300);
    glVertex2d(472,331);

    glEnd();

}
void H3()
{

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);
    glVertex2d(472,378);
    glVertex2d(472,252);
    glVertex2d(501,252);
    glVertex2d(501,378);

    glEnd();

}

void U()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(523,252);
    glVertex2d(552,252);
    glVertex2d(552,347);
    glVertex2d(537,378);
    glVertex2d(523,363);
    glEnd();

}
void U2()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(552,347);
    glVertex2d(595,347);
    glVertex2d(610,378);
    glVertex2d(537,378);
    glEnd();

}
void U3()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(595,347);
    glVertex2d(595,252);
    glVertex2d(624,252);
    glVertex2d(624,347);
    glVertex2d(610,378);
    glEnd();

}
void kulit()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(20,174);
    glVertex2d(188,7);
    glVertex2d(190,74);
    glVertex2d(52,236);
    glEnd();

}
void kulit2()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(594,9);
    glVertex2d(762,176);
    glVertex2d(730,238);
    glVertex2d(593,76);
    glEnd();

}
void mata()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(166,108);
    glVertex2d(386,197);
    glVertex2d(324,224);
    glVertex2d(122,161);
    glEnd();

}
void alis()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(190,82);
    glVertex2d(236,31);
    glVertex2d(452,130);
    glVertex2d(389,154);
    glEnd();

}

void alis2()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(546,33);
    glVertex2d(592,84);
    glVertex2d(393,156);
    glVertex2d(330,132);
    glEnd();

}
void mata2()
{

    glBegin(GL_POLYGON);

    glColor3ub(225,0,0);
    glVertex2d(660,163);
    glVertex2d(617,110);
    glVertex2d(396,199);
    glVertex2d(458,226);
    glEnd();

}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "HELO BOX", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        latar();
        wadah();
        R();
        R2();
        R3();
        R4();
        F();
        F2();
        F3();
        A();
        A2();
        A3();
        T();
        T2();
        H();
        H2();
        H3();
        U();
        U2();
        U3();
        kulit();
        kulit2();
        alis();
        mata();
        alis2();
        mata2();

        /* O(); */



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
