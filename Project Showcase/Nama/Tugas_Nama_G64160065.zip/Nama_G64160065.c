#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, -1.f, 1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glBegin(GL_POLYGON);
    glColor3ub(166,255,164);
    glVertex3f(0,0,0);
    glVertex3f(0,800,0);
    glVertex3f(800,800,0);
    glVertex3f(800,0,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,255,0);
    glVertex3f(73.23,33.78,0);
    glVertex3f(98.57,33.78,0);
    glVertex3f(85.13,71.15,0);
    glEnd();


    // spinning shit
    glPushMatrix();
    glTranslated(591.5,199.5,0); //ini kodingannya keren banget sumpah
    glRotatef((float)glfwGetTime()*50.0f,0.0f,0.0f,1.0f);//yang ini juga
    glTranslated(-591.5,-199.5,0);//apalagi yang ini

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(562.85,155.98,0);
    glVertex3f(542.26,191.65,0);
    glVertex3f(431.58,168.36,0);
    glVertex3f(485.82,74.39,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(537.0,45.5,0);
    glVertex3f(645.5,45.5,0);
    glVertex3f(613.35,153.0,0);
    glVertex3f(572.16,153,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(695.92,71.2,0);
    glVertex3f(751.13,164.6,0);
    glVertex3f(642.23,191.63,0);
    glVertex3f(621.27,156.17,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(640.94,208.1,0);
    glVertex3f(751.78,230.63,0);
    glVertex3f(698.19,324.97,0);
    glVertex3f(620.6,243.92,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(536.58,352.57,0);
    glVertex3f(645.07,353.47,0);
    glVertex3f(610.76,245.65,0);
    glVertex3f(569.57,245.33,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(487.73,325.34,0);
    glVertex3f(432.34,232.04,0);
    glVertex3f(541.18,204.8,0);
    glVertex3f(562.21,240.22,0);
    glEnd();
    glPopMatrix();


    //huruf w
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(15.78,33.78,0);
    glVertex3f(39.38,98.76,0);
    glVertex3f(91.32,98.76,0);
    glVertex3f(114.92,33.78,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166,255,164);
    glVertex3f(32.12,33.78,0);
    glVertex3f(57.46,33.78,0);
    glVertex3f(45.47,71.15,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166,255,164);
    glVertex3f(73.23,33.78,0);
    glVertex3f(98.57,33.78,0);
    glVertex3f(85.13,71.15,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166,255,164);
    glVertex3f(80.1,98.76,0);
    glVertex3f(50.6,98.76,0);
    glVertex3f(65.3,53.58,0);
    glEnd();

    //huruf i
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(164.71,145.32,0);
    glVertex3f(179.8,145.32,0);
    glVertex3f(179.8,210.3,0);
    glVertex3f(164.71,210.3,0);
    glEnd();

    //huruf l
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(266.77,256.86,0);
    glVertex3f(281.86,256.86,0);
    glVertex3f(281.86,321.84,0);
    glVertex3f(266.77,321.84,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(310.68,308.92,0);
    glVertex3f(310.68,321.84,0);
    glVertex3f(266.77,321.84,0);
    glVertex3f(266.77,308.92,0);
    glEnd();

    // l kedua
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(368.83,368.41,0);
    glVertex3f(383.92,368.41,0);
    glVertex3f(383.92,433.38,0);
    glVertex3f(368.83,433.38,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(412.74,420.46,0);
    glVertex3f(412.74,433.38,0);
    glVertex3f(368.83,433.38,0);
    glVertex3f(368.83,420.46,0);
    glEnd();

    //huruf y
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(484.91,544.92,0);
    glVertex3f(500,544.92,0);
    glVertex3f(500,504.11,0);
    glVertex3f(484.91,504.11,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(461.51,479.95,0);
    glVertex3f(477.85,479.95,0);
    glVertex3f(492.46,504.11,0);
    glVertex3f(484.91,519.26,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(523.41,479.95,0);
    glVertex3f(507.06,479.95,0);
    glVertex3f(492.46,504.11,0);
    glVertex3f(500,519.26,0);
    glEnd();

    // huruf a
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(593.35,591.49,0);
    glVertex3f(607.96,591.49,0);
    glVertex3f(580.2,656.46,0);
    glVertex3f(564.15,656.46,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(593.35,591.49,0);
    glVertex3f(607.96,591.49,0);
    glVertex3f(637.17,656.46,0);
    glVertex3f(621.11,656.46,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(590,629.69,0);
    glVertex3f(610,629.69,0);
    glVertex3f(616,642.42,0);
    glVertex3f(580,642.42,0);
    glEnd();

    //huruf m
    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(702.82,768,0);
    glVertex3f(687.74,768,0);
    glVertex3f(687.74,703.03,0);
    glVertex3f(702.82,703.03,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(687.74,703.03,0);
    glVertex3f(708.14,703.03,0);
    glVertex3f(730,762.61,0);
    glVertex3f(721.01,762.61,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(743.06,703.03,0);
    glVertex3f(763.37,703.03,0);
    glVertex3f(730,762.61,0);
    glVertex3f(721.01,762.61,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(0,0,0);
    glVertex3f(748.28,768,0);
    glVertex3f(763.37,768,0);
    glVertex3f(763.37,703.03,0);
    glVertex3f(748.28,703.03,0);
    glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160065", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
