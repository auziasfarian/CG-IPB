#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#define a 20.366
#define b 29.775
#define t +0.5

using namespace std;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 75, 50, 0, 0.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
//half circle sebelah kanan
void halfcircle(float posisiX,float posisiY,float jari2){
    float X, Y;
	glBegin(GL_POLYGON);
		for(int i=0; i<=500; i++){
			X=sin(i*2*3.14/1000)*jari2+posisiX;
			Y=cos(i*2*3.14/1000)*jari2+posisiY;
			glVertex2f(X, Y);
		}
	glEnd();
}
//halfcircle sebelah kiri
void revhalfcircle(float posisiX,float posisiY,float jari2){
    float X, Y;
	glBegin(GL_POLYGON);
		for(int i=0; i<=500; i++){
			X=-sin(i*2*3.14/1000)*jari2+posisiX;
			Y=-cos(i*2*3.14/1000)*jari2+posisiY;
			glVertex2f(X, Y);
		}
	glEnd();
}

void kotak(float x1,float y1,float x2,float y2,float x3,float y3,float x4,float y4){
    glBegin(GL_QUADS);
        glVertex2f(x1,y1); //kiri atas
        glVertex2f(x2,y2);   //kiri bawah
        glVertex2f(x3,y3);    //kanan bawah
        glVertex2f(x4,y4);  //kanan atas
    glEnd();
}

void kotaklurus(float x1,float y1, float x2, float y2){
    glBegin(GL_QUADS);
        glVertex2f(x1,y1);
        glVertex2f(x2,y1);
        glVertex2f(x2,y2);
        glVertex2f(x1,y2);
    glEnd();
}

//nyoba warna
vector<vector<int> > va;
vector<vector<int> > vb;
void pva(int e, int d, int c) {
    vector<int> tmp;
    tmp.push_back(e);
    tmp.push_back(d);
    tmp.push_back(c);
    va.push_back(tmp);
}

void pvb(int e, int d, int c) {
    vector<int> tmp;
    tmp.push_back(e);
    tmp.push_back(d);
    tmp.push_back(c);
    vb.push_back(tmp);
}

void fc() {
    pva(44,44,44); pvb(0,1,1);
    pva(240,240,230); pvb(0,1,1);
    pva(255,191,23); pvb(0,1,1);
    pva(222,6,7); pvb(5,1,6);
    pva(24,24,24); pvb(1,1,5);
}



void display()
{
    //Background Hitam
    glColor3d(0,0,0);
    kotaklurus(0,0,500,750);

    //bata
    glColor3d(0.4706,0.2353,0);
    for(int i=0; i<20; i++)
        for(int j=0; j<12; j++)
        {
            if(i%2==0) kotaklurus(j*7.25,0+i*3.25,7+j*7.25,3+i*3.25);
            else kotaklurus(j*7.25-3,0+i*3.25,7+j*7.25-3,3+i*3.25);
        }

    //alas
    int c = 0;
    float cc;
    cc = cc + 0.1;
    c = (int)cc % va.size();
    glColor3ub(va[c][0],va[c][1],va[c][2]);
    kotaklurus(8.8,18.5,67.3,32.5);

    //huruf Gt
    glColor3f(0,0,0);
    revhalfcircle(20.157 t,25.066 t,9.4/2);
    glColor3ub(va[c][0],va[c][1],va[c][2]);
    revhalfcircle(21.706 t, 25.066 t, 5.7/2);
    glColor3f(0,0,0);
    kotak(19.609 t, a t, 19.609 t, 22.356 t, 23.156 t , 23.566 t, 23.156 t, a t);
    kotaklurus(19.609 t, 27.066 t, 23.156 t, b t);
    kotak(20.506 t,24.566 t, 21.506 t,27.066 t, 23.156 t,27.066 t, 23.156 t,24.566 t);

    //huruf G
    glColor3f(0,0,1);
    revhalfcircle(20.157,25.066,9.4/2);
    glColor3ub(va[c][0],va[c][1],va[c][2]);
    revhalfcircle(21.706, 25.066, 5.7/2);
    glColor3f(0,0,1);
    kotak(19.609, a, 19.609, 22.356, 23.156 , 23.566, 23.156, a);
    kotaklurus(19.609, 27.066, 23.156, b);
    kotak(20.506,24.566, 21.506,27.066, 23.156,27.066, 23.156,24.566 );

    //huruf It
    glColor3d(0,0,0);
    kotak(24.8 t,a t, 24.4 t,b t, 28.5 t,b t, 28.346 t,a t);
    kotaklurus(24 t,a t, 28.35 t,21.2 t);

    //huruf I
    glColor3d(0,0,1);
    kotak(24.8,a, 24.4,b, 28.5,b, 28.346,a);
    kotaklurus(24,a, 28.35,21.2);

    //huruf Lt
    glColor3d(0,0,0);
    kotak(29.06 t,a t, 29.6 t,b t, 32.88 t,b t, 33.15 t,a t);
    kotak(31.1 t,28.41 t, 31.1 t,b t, 34.5 t,b t, 34.5 t, 27.92 t);

    //huruf L
    glColor3d(0,0,1);
    kotak(29.06,a, 29.6,b, 32.88,b, 33.15,a);
    kotak(31.1,28.41, 31.1,b, 34.5,b, 34.5, 27.92);

    //huruf At
    glColor3d(0,0,0);
    kotak(37 t,a t, 35.2 t,b t, 36.9 t,b t, 39.4 t, a t);
    kotak(37.2 t,a t, 40 t,b t, 43.12 t,b t, 41.02 t,a t);
    kotak(36.6 t,27.3 t, 38 t,29.7 t, 40.9 t,27.3 t, 40.7 t,27.3 t);

    //huruf A
    glColor3d(0,0,1);
    kotak(37,a, 35.2,b, 36.9,b, 39.4, a);
    kotak(37.2,a, 40,b, 43.12,b, 41.02,a);
    kotak(36.6,27.3, 38,29.7, 40.9,27.3, 40.7,27.3);

    //huruf N
    glColor3d(0,0,0);
    kotak(43.22 t,a t, 43.82 t,b t, 45.7 t,b t, 45.9 t,a t);
    kotak(45.6 t,a t, 45.6 t,26.47 t, 50.3 t,b t, 50.3 t,24 t);
    kotaklurus(48.4 t,a t,50.3 t,26.87 t);

    //huruf N
    glColor3d(0,0,1);
    kotak(43.22,a, 43.82,b, 45.7,b, 45.9,a);
    kotak(45.6,a, 45.6,26.47, 50.3,b, 50.3,24);
    kotaklurus(48.4,a,50.3,26.87);

    //huruf G
    glColor3f(0,0,0);
    revhalfcircle(55.757 t,25.066 t,9.4/2);
    glColor3ub(va[c][0],va[c][1],va[c][2]);
    revhalfcircle(57.306 t, 25.066 t, 5.7/2);
    glColor3f(0,0,0);
    kotak(55.21 t,a t, 55.21 t,22.356 t, 58.76 t,23.566 t, 58.76 t,a t);
    kotaklurus(55.21 t,27.066 t, 58.61 t,b t);
    kotak(56.11 t,24.566 t, 56.61 t,27.066 t, 58.61 t,27.066 t, 58.61 t,24.566 t);

    //huruf G
    glColor3f(0,0,1);
    revhalfcircle(55.757,25.066,9.4/2);
    glColor3ub(va[c][0],va[c][1],va[c][2]);
    revhalfcircle(57.306, 25.066, 5.7/2);
    glColor3f(0,0,1);
    kotak(55.21,a, 55.21,22.356, 58.76,23.566, 58.76,a);
    kotaklurus(55.21,27.066, 58.61,b);
    kotak(56.11,24.566, 56.61,27.066, 58.61,27.066, 58.61,24.566);
}

int main(void)
{
    fc();
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(750, 500, "Gilang Gunawan G64160060", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
