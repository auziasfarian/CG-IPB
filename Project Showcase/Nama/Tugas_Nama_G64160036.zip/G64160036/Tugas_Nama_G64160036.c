#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

int clindex=0,buff=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

double titik, sizze;
    double cons; //keliling
    double px, py;
    double posx, posy; //titik koordinatnya
    int i; //radius

void display()

{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void A(){

    glBegin(GL_POLYGON);

glColor3ub(242,119,169);
   glVertex2d(533.58,597.13);
    glVertex2d(533.58,583.99);
    glVertex2d(576.64,583.99);
     glVertex2d(576.64,703.1);
    glVertex2d(533.58,703.1);
    glVertex2d(533.58,690.51);
    glEnd();
glBegin(GL_POLYGON);
    glColor3ub(242,119,169);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(510+cos(rad)*60,643.54+sin(rad)*60);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,0,183);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(510+cos(rad)*30,643.54+sin(rad)*30);
        }
        glEnd();

    }

void L(){

    glBegin(GL_POLYGON);



    glColor3ub(255,0,183);glVertex2d(649.96,231.43);
    glVertex2d(706.3,231.43);
    glColor3ub(242,119,169);glVertex2d(706.3,703.1);
    glVertex2d(649.96,703.1);
    glEnd();
}

void S(){

       glBegin(GL_POLYGON);
        glColor3ub(255,0,183);
        for (int i=125; i <=325; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(233.5+cos(rad)*143.14,288.1+sin(rad)*143.14);
        }
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(242,119,169);
        for (int i=-50; i <=150; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(233.5+cos(rad)*143.14,566.57+sin(rad)*143.14);
        }
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(233.5+cos(rad)*53.39,288.1+sin(rad)*53.39);
        }
        glEnd();

             glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(233.5+cos(rad)*53.39,566.57+sin(rad)*53.39);
        }
        glEnd();
//1
    int colorf[3][3]={{255,74,204},{255,74,151},{255,74,156}};
    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    glVertex2d(152.62,422.62);
    glVertex2d(237.12,338.12);
    glVertex2d(263.31,366.31);
    glVertex2d(180.81,450.81);
    glEnd();

//2
    int colorff[3][3]={{255,151,151},{255,74,156},{255,74,204}};
    glBegin(GL_POLYGON);

    glColor3ub(colorff[(clindex+1)%3][0],colorff[(clindex+1)%3][1],colorff[(clindex+1)%3][2]);

    glVertex2d(184.62,454.62);
    glVertex2d(269.12,370.12);
    glVertex2d(297.31,398.31);
    glVertex2d(212.81,482.81);
    glEnd();

//3
    int colorfff[3][3]={{255,74,156},{255,74,204},{255,151,151}};
    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorfff[(clindex+1)%3][1],colorfff[(clindex+1)%3][2]);

    glVertex2d(217.08,485.19);
    glVertex2d(306.61,406.04);
    glVertex2d(333.01,435.9);
    glVertex2d(243.48,515.05);
    glEnd();

  }

void garis(){
//deket L
    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-5,0,0,1);
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);
    glVertex2d(589.65,145.1);
    glVertex2d(722.06,145.1);
    glVertex2d(713.57,158.6);
    glVertex2d(601.65,158.6);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-10,0,0,1);
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

    glVertex2d(722.06,145.1);
    glVertex2d(722.06,556.71);
    glVertex2d(713.57,530.58);
    glVertex2d(713.57,158.6);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-15,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(713.57,530.58);
    glVertex2d(722.06,556.71);
    glVertex2d(589.65,556.71);
    glVertex2d(601.65,530.53);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-20,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(589.65,145.1);
    glVertex2d(601.65,158.6);
    glVertex2d(601.65,530.58);
    glVertex2d(589.65,556.71);
    glEnd();
    glPopMatrix();
//2
    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-25,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(627.67,307.92);
    glVertex2d(760.07,307.92);
    glVertex2d(749.83,327.73);
    glVertex2d(637.91,327.73);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-30,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(760.07,307.92);
    glVertex2d(760.07,719.53);
    glVertex2d(749.83,699.71);
    glVertex2d(749.83,327.73);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-35,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(749.83,699.71);
    glVertex2d(760.07,719.53);
    glVertex2d(627.67,719.53);
    glVertex2d(637.91,699.71);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *-40,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(627.67,307.92);
    glVertex2d(637.91,327.73);
    glVertex2d(637.91,699.71);
    glVertex2d(627.67,719.53);
    glEnd();
    glPopMatrix();
    //deket S
        glPushMatrix();
    glTranslated(-0.5,0,0);
    glRotated((float) glfwGetTime() *5,0,0,1);
    glBegin(GL_POLYGON);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(40.65,145.1);
    glVertex2d(219,145.1);
    glVertex2d(213.5,153.55);
    glVertex2d(46.15,153.55);
    glEnd(); glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *10,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(219,145.1);
    glVertex2d(219,643.83);
    glVertex2d(213.5,635.38);
    glVertex2d(213.5,153.55);
    glEnd();
    glPopMatrix();

        glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *15,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(213.5,635.38);
    glVertex2d(219,643.83);
    glVertex2d(40.65,643.83);
    glVertex2d(46.15,635.38);
    glEnd();
glPopMatrix();

    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *20,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(40.65,145.1);
    glVertex2d(46.15,153.55);
    glVertex2d(46.15,635.38);
    glVertex2d(40.65,643.83);
    glEnd();
    glPopMatrix();

//2
    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *25,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(147.3,288.1);
    glVertex2d(356.59,288.1);
    glVertex2d(329.59,302.6);
    glVertex2d(168.27,302.6);
    glEnd();
glPopMatrix();

    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *30,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(356.59,288.1);
    glVertex2d(356.59,721.07);
    glVertex2d(329.50,706.21);
    glVertex2d(329.59,302.6);
    glEnd();
glPopMatrix();

    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *35,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(329.50,706.21);
    glVertex2d(356.59,721.07);
    glVertex2d(147.3,721.07);
    glVertex2d(168.27,706.21);
    glEnd();
glPopMatrix();

    glPushMatrix();
    glTranslated(0.5,0,0);
    glRotated((float) glfwGetTime() *40,0,0,1);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(147.3,288.1);
    glVertex2d(168.27,302.6);
    glVertex2d(168.27,706.21);
    glVertex2d(147.3,721.07);
    glEnd();
    glPopMatrix();
}

void segitiga(){

    glBegin(GL_POLYGON);
    glColor3ub(193,16,188);
    glVertex2d(409.76,399.94);
    glVertex2d(469.08,399.94);
    glVertex2d(469.09,534.58);
    glVertex2d(409.76,534.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,174,222);
    glVertex2d(477.61,356.59);
    glVertex2d(536.94,356.59);
    glVertex2d(536.94,534.58);
    glVertex2d(477.61,534.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224,141,222);
    glVertex2d(546.98,310.09);
    glVertex2d(606.3,310.09);
    glVertex2d(606.3,534.58);
    glVertex2d(546.98,534.58);
    glEnd();


}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas_Nama_<G64160036>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

   while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++; buff=buff%100;
         float ratio;
        int width, height;

        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);


        glClearColor (1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glShadeModel(GL_SMOOTH);

        glEnable(GL_LINE_SMOOTH);
        glEnable(GL_TEXTURE_BINDING_1D);
        glEnable(GL_TEXTURE_1D);
        glEnable(GL_TEXTURE_BINDING_2D);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_COLOR_MATERIAL);
        glEnable(GL_LIGHT0);
        glDisable(GL_CULL_FACE);


        glOrtho(-50, 50, -30, 30, 50, -50); //koordinat
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();


        //lingkaran();
        display();
 //       glfwSwapBuffers(window);
//        glfwPollEvents();
        setup_viewport(window);

        //display();

        garis();
        A();
        L();
        S();
        //segitiga();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
