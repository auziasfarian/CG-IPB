#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <unistd.h>

using namespace std;

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE&& action == GLFW_PRESS)
    glfwSetWindowShouldClose(window, GL_TRUE);
}

void generatePixel(){
    glBegin(GL_POLYGON);
    glVertex2f(0.0,0.0);
    glVertex2f(1.0,0.0);
    glVertex2f(1.0,-1.0);
    glVertex2f(0.0,-1.0);
    glEnd();
}

void createLine(float x, float y, int n, string task, int color){
    int i;
    for(i=0;i<n;i++){
        glPushMatrix();
        glColor3ub(color,color,color);
        glTranslatef(x, y, 0.0);
        generatePixel();
        glPopMatrix();
        if(task=="vertical|down"){
            y -= 1.0;
        }else if (task == "vertical|up"){
            y +=1.0;
        } else if (task == "nvertical|left"){
            x -= 1.0;
        } else if (task == "nvertical|right"){
            x += 1.0;
        } else{
            break;
        }
    }
}

void hurufd(){
    float x, y;
    glPushMatrix();
    glTranslatef(-20.0,0.0,0.0);

    //shadow
    x = 0.3; y = 0.0;
    createLine(x,y,10,"vertical|down",128);

    //shadow line 4
    x = 0.0; y = -9.7;
    createLine(x,y,7,"nvertical|right",128);
    //

    x = 0.0; y = 0.0;
    createLine(x,y,10,"vertical|down",0);
    //

    //shadow
    x = 2.0; y = -0.6;
    createLine(x,y,5,"nvertical|right",128);

    x = 2.0; y = -1.0;
    createLine(x,y,5,"nvertical|right",0);
    //

    //shadow
    x = 7.0; y = -1.7;
    createLine(x,y,7,"vertical|down",128);

    x = 7.5; y = -1.7;
    createLine(x,y,7,"vertical|down",0);
    //

    //line 4
    x = 0.0; y= -10.0;
    createLine(x,y,7,"nvertical|right",0);
    //

    glPopMatrix();
}

void hurufi(){
    float x, y;
    glPushMatrix();
    glTranslatef(-10.0,0.0,0.0);

    //shadow
    x = 0.3; y = 0.0;
    createLine(x,y,1,"vertical|down",128);

        //shadow line 2
    x = 0.0; y = -0.7;
    createLine(x,y,5,"nvertical|right",128);
    //

    x = 0.0; y=0.0;
    createLine(x,y,1,"vertical|down",0);
    //

    //line 2
    x = 0.0; y = -1.0;
    createLine(x,y,4,"nvertical|right",0);
    //

    //shadow
    x = 4.5; y = -1.0;
    createLine(x,y,8,"vertical|down",128);

    x = 4.0; y = -1.0;
    createLine(x,y,8,"vertical|down",0);
    //

    //shadow
    x = 0.3; y = -8.0;
    createLine(x,y,3,"vertical|down",128);

    //shadow line 4
    x = 0.0; y = -9.6;
    createLine(x,y,5,"nvertical|right",128);
    //

    x = 0.0; y=-8.0;
    createLine(x,y,3,"vertical|down",0);
    //

    //line 4
    x = 0.0; y=-10.0;
    createLine(x,y,5,"nvertical|right",0);
    //

    //shadow
    x = 6.0; y = -0.6;
    createLine(x,y,2,"nvertical|right",128);

    x = 6.0; y = -1.0;
    createLine(x,y,2,"nvertical|right",0);
    //

    //shadow
    x = 6.0; y = -9.6;
    createLine(x,y,2,"nvertical|right",128);

    x = 6.0; y = -10.0;
    createLine(x,y,2,"nvertical|right",0);
    //

    glPopMatrix();

}

void hurufk(){
    int i;
    float x, y;
    glPushMatrix();
    glTranslatef(0.0,0.0,0.0);

    //shadow
    x = 0.3; y = 0.0;
    createLine(x,y,10,"vertical|down",128);

    //shadow line 2
    x = 0.0; y = -9.7;
    createLine(x,y,2,"nvertical|right",128);
    //

    x = 0.0; y = 0.0;
    createLine(x,y,10,"vertical|down",0);
    //

    //line 2
    x = 0.0; y= -10.0;
    createLine(x,y,2,"nvertical|right",0);
    //

    //shadow
    x = 2.2; y = -5.2;
    createLine(x,y,1,"vertical|down",128);

    x = 2.0; y = -5.0;
    createLine(x,y,1,"vertical|down",0);
    //

    //shadow
    x = 4.0; y = -3.0;
    for(i=0;i<4;i++){
            if(i%2==0){
                createLine(x+0.15,y+0.15,1,"vertical|down",128);
            }else{
                createLine(x-0.15,y-0.15,1,"vertical|down",128);
            }
        x += 1.0;
        y += 1.0;
    }
    x = 4.0; y = -3.0;
    for(i=0;i<4;i++){
        createLine(x,y,1,"vertical|down",0);
        x += 1.0;
        y += 1.0;
    }

    //shadow
    x = 4.0; y = -6.0;
    for(i=0;i<4;i++){
        if(i<=1){
            createLine(x+0.15,y,1,"vertical|down",128);
        }else{
            createLine(x-0.15,y,1,"vertical|down",128);
        }
        y -= 1.0;
        if(i==1){
            x += 1.0;
        }
    }

    x = 4.0; y = -6.0;
    for(i=0;i<4;i++){
        createLine(x,y,1,"vertical|down",0);
        y -= 1.0;
        if(i==1){
            x += 1.0;
        }
    }

    //shadow
    x = 6.0; y = -9.6;
    createLine(x,y,2,"nvertical|right",128);

    x = 6.0; y = -10.0;
    createLine(x,y,2,"nvertical|right",0);
    //


    glPopMatrix();
}

void hurufm(){
    int i;
    float x,y, x2;
    glPushMatrix();
    glTranslatef(10.0,0.0,0.0);

    //shadow
    x = 0.3; y = 0.0;
    createLine(x,y,10,"vertical|down",128);

    //shadow line 2
    x = 0.0; y = -9.7;
    createLine(x,y,2,"nvertical|right",128);
    //

    x = 0.0; y = 0.0;
    createLine(x,y,10,"vertical|down",0);
    //

    //line 2
    x = 0.0; y= -10.0;
    createLine(x,y,2,"nvertical|right",0);
    //

    //shadow
    x = 2.0; y = -2.3; x2 = 8.0;
    for(i=0;i<8;i++){
        createLine(x,y,1,"vertical|down",128);
        if(i<6){
            createLine(x+x2,y,1,"vertical|down",128);
        }
        if(i<=1){
            x += 1.0;
            y -= 1.0;
            x2 -= 2.0;
        } else{
            if(i%2!=0){
                x += 1.0;
                x2 -= 2.0;
            }
            y -= 1.0;
        }
    }

    x = 2.0; y = -2.0; x2 = 8.0;
    for(i=0;i<8;i++){
        createLine(x,y,1,"vertical|down",0);
        if(i<6){
            createLine(x+x2,y,1,"vertical|down",0);
        }
        if(i<=1){
            x += 1.0;
            y -= 1.0;
            x2 -= 2.0;
        } else{
            if(i%2!=0){
                x += 1.0;
                x2 -= 2.0;
            }
            y -= 1.0;
        }
    }

        //shadow
    x = 11.3; y = 0.0;
    createLine(x,y,10,"vertical|down",128);

    //shadow line 2
    x = 11.0; y = -9.7;
    createLine(x,y,2,"nvertical|right",128);
    //

    x = 11.0; y = 0.0;
    createLine(x,y,10,"vertical|down",0);
    //

    //line 2
    x = 11.0; y= -10.0;
    createLine(x,y,2,"nvertical|right",0);
    //

    glPopMatrix();
}

void hurufa(){
    int i;
    float x,y;

    glPushMatrix();
    glTranslatef(25.0,0.0,0.0);

    //shadow
    x = 0.3; y = -10.0;
    for(i=0;i<11;i++){
        if(i%2==0){
           createLine(x,y,1,"vertical|up",128);
           y += 1.0;
        } else{
           createLine(x,y,1,"vertical|up",128);
           x += 1.0;
           y += 1.0;
        }
    }
    x += 1.0; y -= 2.0;
    for(i=0;i<5;i++){
        if(i%2==0){
           createLine(x,y,1,"vertical|up",128);
           y -= 1.0;
        } else{
           createLine(x,y,1,"vertical|up",128);
           x += 1.0;
           y -= 1.0;
        }

    }

    y -= 1.0; x-= 1.0;
    createLine(x,y,3,"nvertical|left",128);
    y -= 1.0;
    createLine(x,y,1,"vertical|down",128);
    x += 1.0; y -= 1.0;
    createLine(x,y,1,"vertical|down",128);
    x = 0.3; y = -9.7;
    createLine(x,y,4,"nvertical|right",128);

    //
    x = 0.0; y = -10.0;
    createLine(x,y,4,"nvertical|right",0);
    for(i=0;i<11;i++){
        if(i%2==0){
           createLine(x,y,1,"vertical|up",0);
           y += 1.0;
        } else{
           createLine(x,y,1,"vertical|up",0);
           x += 1.0;
           y += 1.0;
        }
    }
    x += 1.0; y -= 2.0;
    for(i=0;i<5;i++){
        if(i%2==0){
           createLine(x,y,1,"vertical|up",0);
           y -= 1.0;
        } else{
           createLine(x,y,1,"vertical|up",0);
           x += 1.0;
           y -= 1.0;
        }

    }
    y -= 1.0; x-= 1.0;
    createLine(x,y,3,"nvertical|left",0);
    y -= 1.0;
    createLine(x,y,1,"vertical|down",0);
    x += 1.0; y -= 1.0;
    createLine(x,y,1,"vertical|down",0);
    y -= 1.0;
    createLine(x,y,1,"vertical|down",0);
    createLine(x,y,2,"nvertical|right",0);

    glPopMatrix();

}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
    exit(EXIT_FAILURE);
window = glfwCreateWindow(640, 640, "Nama", NULL, NULL);
if (!window)
{
    glfwTerminate();
    exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);
    glClearColor(255, 255, 255, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-50.f, 50.f, -50.f, 50.f, 50.f, -50.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glScalef(1.1,1.1,1.1);
    glTranslatef(-7.0,7.0,0.0);
    hurufd();
    hurufi();
    hurufk();
    hurufm();
    hurufa();

    glfwSwapBuffers(window);
    glfwPollEvents();
}
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
