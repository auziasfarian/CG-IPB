#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void nama(){

    srand(time(NULL));
    for(int j = 0; j < 5; j++){
        int x_offset = j * 60 - 15;
        int y_offset = j * (50+122) - 15;
        int xxx=rand()%255,yyy=rand()%255,zzz=rand()%255;
        int r=xxx/3,g=yyy/3,b=zzz/3;

        // I
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(42.87+x_offset, 21.62+y_offset);
        glVertex2f(50.56+x_offset, 21.62+y_offset);
        glVertex2f(50.56+x_offset, 143.19+y_offset);
        glVertex2f(42.87+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(52.87+x_offset, 21.62+y_offset);
        glVertex2f(68.56+x_offset, 21.62+y_offset);
        glVertex2f(68.56+x_offset, 143.19+y_offset);
        glVertex2f(52.87+x_offset, 143.19+y_offset);
        glEnd();

        // D

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);

        glVertex2d(95.98+x_offset, 21.62+y_offset);
        glVertex2d(111.56+x_offset, 21.62+y_offset);
        glVertex2d(111.56+x_offset, 143.19+y_offset);
        glVertex2d(95.98+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            double x_base = 115+cos(rad)*61;
            double x_bonus = 0.11 * (1-(abs(i)/90)) * x_base;
            glVertex2f(x_base+x_bonus+x_offset,82.5+sin(rad)*61+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(115+cos(rad)*51+x_offset,91+sin(rad)*51+y_offset);
        }
        glEnd();

        // Z
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(213.58+x_offset, 21.62+y_offset);
        glVertex2d(295.65+x_offset, 21.62+y_offset);
        glVertex2d(295.65+x_offset, 31.18+y_offset);
        glVertex2d(275.26+x_offset, 35.33+y_offset);
        glVertex2d(213.58+x_offset, 34.79+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(275.26+x_offset, 35.33+y_offset);
        glVertex2d(295.65+x_offset, 31.18+y_offset);
        glVertex2d(228.55+x_offset, 130.03+y_offset);
        glVertex2d(207.8+x_offset, 133.99+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(207.8+x_offset, 133.99+y_offset);
        glVertex2d(228.55+x_offset, 130.03+y_offset);
        glVertex2d(296.55+x_offset, 130.03+y_offset);
        glVertex2d(296.55+x_offset, 143.19+y_offset);
        glVertex2d(207.8+x_offset, 143.19+y_offset);
        glEnd();

        // H

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(315.85+x_offset, 21.62+y_offset);
        glVertex2f(331.54+x_offset, 21.62+y_offset);
        glVertex2f(331.54+x_offset, 143.19+y_offset);
        glVertex2f(315.85+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(331.54+x_offset, 70.49+y_offset);
        glVertex2f(390.34+x_offset, 70.49+y_offset);
        glVertex2f(390.34+x_offset, 88.2+y_offset);
        glVertex2f(331.54+x_offset, 88.2+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(315.85+x_offset+74.49, 21.62+y_offset);
        glVertex2f(331.54+x_offset+74.49, 21.62+y_offset);
        glVertex2f(331.54+x_offset+74.49, 143.19+y_offset);
        glVertex2f(315.85+x_offset+74.49, 143.19+y_offset);
        glEnd();

        // A
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(465.55+x_offset, 21.62+y_offset);
        glVertex2f(484.49+x_offset, 21.62+y_offset);
        glVertex2f(440.48+x_offset, 143.19+y_offset);
        glVertex2f(424.25+x_offset, 143.19+y_offset);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(465.55+x_offset, 21.62+y_offset);
        glVertex2f(484.49+x_offset, 21.62+y_offset);
        glVertex2f(525.98+x_offset, 143.19+y_offset);
        glVertex2f(509.21+x_offset, 143.19+y_offset);
        glEnd();

        // R

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(534.83+x_offset, 21.62+y_offset);
        glVertex2f(540.53+x_offset, 21.62+y_offset);
        glVertex2f(540.53+x_offset, 143.19+y_offset);
        glVertex2f(534.83+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(543.83+x_offset, 21.62+y_offset);
        glVertex2f(559.53+x_offset, 21.62+y_offset);
        glVertex2f(559.53+x_offset, 143.19+y_offset);
        glVertex2f(543.83+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            double x_base = 563+cos(rad)*61+x_offset;
            double x_bonus = 0.02 * (1-(abs(i)/90)) * x_base;
            glVertex2f(x_base+x_bonus,59+sin(rad)*37+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(563+cos(rad)*51+x_offset,63+sin(rad)*37+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(563.53+x_offset, 95.52+y_offset);
        glVertex2f(653.02+x_offset, 143.19+y_offset);
        glVertex2f(606.79+x_offset, 143.19+y_offset);
        glEnd();

        x_offset = j * 60;
        y_offset = j * (50+122);
        r=xxx,g=yyy,b=zzz;
        // I
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(42.87+x_offset, 21.62+y_offset);
        glVertex2f(50.56+x_offset, 21.62+y_offset);
        glVertex2f(50.56+x_offset, 143.19+y_offset);
        glVertex2f(42.87+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(52.87+x_offset, 21.62+y_offset);
        glVertex2f(68.56+x_offset, 21.62+y_offset);
        glVertex2f(68.56+x_offset, 143.19+y_offset);
        glVertex2f(52.87+x_offset, 143.19+y_offset);
        glEnd();

        // D

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);

        glVertex2d(95.98+x_offset, 21.62+y_offset);
        glVertex2d(111.56+x_offset, 21.62+y_offset);
        glVertex2d(111.56+x_offset, 143.19+y_offset);
        glVertex2d(95.98+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            double x_base = 115+cos(rad)*61;
            double x_bonus = 0.11 * (1-(abs(i)/90)) * x_base;
            glVertex2f(x_base+x_bonus+x_offset,82.5+sin(rad)*61+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(115+cos(rad)*51+x_offset,91+sin(rad)*51+y_offset);
        }
        glEnd();

        // Z
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(213.58+x_offset, 21.62+y_offset);
        glVertex2d(295.65+x_offset, 21.62+y_offset);
        glVertex2d(295.65+x_offset, 31.18+y_offset);
        glVertex2d(275.26+x_offset, 35.33+y_offset);
        glVertex2d(213.58+x_offset, 34.79+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(275.26+x_offset, 35.33+y_offset);
        glVertex2d(295.65+x_offset, 31.18+y_offset);
        glVertex2d(228.55+x_offset, 130.03+y_offset);
        glVertex2d(207.8+x_offset, 133.99+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2d(207.8+x_offset, 133.99+y_offset);
        glVertex2d(228.55+x_offset, 130.03+y_offset);
        glVertex2d(296.55+x_offset, 130.03+y_offset);
        glVertex2d(296.55+x_offset, 143.19+y_offset);
        glVertex2d(207.8+x_offset, 143.19+y_offset);
        glEnd();

        // H

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(315.85+x_offset, 21.62+y_offset);
        glVertex2f(331.54+x_offset, 21.62+y_offset);
        glVertex2f(331.54+x_offset, 143.19+y_offset);
        glVertex2f(315.85+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(331.54+x_offset, 70.49+y_offset);
        glVertex2f(390.34+x_offset, 70.49+y_offset);
        glVertex2f(390.34+x_offset, 88.2+y_offset);
        glVertex2f(331.54+x_offset, 88.2+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(315.85+x_offset+74.49, 21.62+y_offset);
        glVertex2f(331.54+x_offset+74.49, 21.62+y_offset);
        glVertex2f(331.54+x_offset+74.49, 143.19+y_offset);
        glVertex2f(315.85+x_offset+74.49, 143.19+y_offset);
        glEnd();

        // A
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(465.55+x_offset, 21.62+y_offset);
        glVertex2f(484.49+x_offset, 21.62+y_offset);
        glVertex2f(440.48+x_offset, 143.19+y_offset);
        glVertex2f(424.25+x_offset, 143.19+y_offset);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(465.55+x_offset, 21.62+y_offset);
        glVertex2f(484.49+x_offset, 21.62+y_offset);
        glVertex2f(525.98+x_offset, 143.19+y_offset);
        glVertex2f(509.21+x_offset, 143.19+y_offset);
        glEnd();

        // R

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(534.83+x_offset, 21.62+y_offset);
        glVertex2f(540.53+x_offset, 21.62+y_offset);
        glVertex2f(540.53+x_offset, 143.19+y_offset);
        glVertex2f(534.83+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(543.83+x_offset, 21.62+y_offset);
        glVertex2f(559.53+x_offset, 21.62+y_offset);
        glVertex2f(559.53+x_offset, 143.19+y_offset);
        glVertex2f(543.83+x_offset, 143.19+y_offset);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            double x_base = 563+cos(rad)*61+x_offset;
            double x_bonus = 0.02 * (1-(abs(i)/90)) * x_base;
            glVertex2f(x_base+x_bonus,59+sin(rad)*37+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=-90; i <= 90; i++)
        {
            float rad = i*3.14159/180;
            glVertex2f(563+cos(rad)*51+x_offset,63+sin(rad)*37+y_offset);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(r,g,b);
        glVertex2f(563.53+x_offset, 95.52+y_offset);
        glVertex2f(653.02+x_offset, 143.19+y_offset);
        glVertex2f(606.79+x_offset, 143.19+y_offset);
        glEnd();
    }

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160052", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        nama();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
