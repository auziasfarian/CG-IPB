#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void kotak1()
{
    glBegin(GL_POLYGON);

    glColor3ub(255, 0, 0);

    glVertex2d(0, 0);
    glVertex2d(400, 0);
    glVertex2d(400, 400);
    glVertex2d(0, 400);

    glEnd();
}

void kotak2()
{
    glBegin(GL_POLYGON);

    glColor3ub(255, 255, 0);

    glVertex2d(400, 0);
    glVertex2d(800, 0);
    glVertex2d(800, 400);
    glVertex2d(400, 400);

    glEnd();
}

void kotak3()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 255, 0);

    glVertex2d(0, 400);
    glVertex2d(400, 400);
    glVertex2d(400, 800);
    glVertex2d(0, 800);

    glEnd();
}

void kotak4()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 255);

    glVertex2d(400, 400);
    glVertex2d(800, 400);
    glVertex2d(800, 800);
    glVertex2d(400, 800);

    glEnd();
}

void kotak5()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 255);

    glVertex2d(0, 300);
    glVertex2d(200, 300);
    glVertex2d(200, 500);
    glVertex2d(0, 500);

    glEnd();
}

void kotak6()
{
    glBegin(GL_POLYGON);

    glColor3ub(255, 255, 0);

    glVertex2d(200, 300);
    glVertex2d(400, 300);
    glVertex2d(400, 500);
    glVertex2d(200, 500);

    glEnd();
}

void kotak7()
{
    glBegin(GL_POLYGON);

    glColor3ub(255, 0, 0);

    glVertex2d(400, 300);
    glVertex2d(600, 300);
    glVertex2d(600, 500);
    glVertex2d(400, 500);

    glEnd();
}

void kotak8()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 255, 0);

    glVertex2d(600, 300);
    glVertex2d(800, 300);
    glVertex2d(800, 500);
    glVertex2d(600, 500);

    glEnd();
}

void L()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(51, 334);
    glVertex2d(95, 334);
    glVertex2d(95, 438);
    glVertex2d(51, 472);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(95, 438);
    glVertex2d(152, 438);
    glVertex2d(152, 472);
    glVertex2d(51, 472);

    glEnd();
}

void E()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(245, 334);
    glVertex2d(289, 366);
    glVertex2d(289, 439);
    glVertex2d(245, 472);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(245, 334);
    glVertex2d(354, 334);
    glVertex2d(354, 366);
    glVertex2d(289, 366);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(289, 386);
    glVertex2d(341, 386);
    glVertex2d(341, 417);
    glVertex2d(289, 417);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(289, 439);
    glVertex2d(354, 439);
    glVertex2d(354, 472);
    glVertex2d(245, 472);

    glEnd();
}

void N()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(439, 334);
    glVertex2d(471, 383);
    glVertex2d(471, 472);
    glVertex2d(439, 472);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(439, 334);
    glVertex2d(480, 334);
    glVertex2d(562, 472);
    glVertex2d(526, 472);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(523, 334);
    glVertex2d(562, 334);
    glVertex2d(562, 472);
    glVertex2d(523, 411);

    glEnd();
}

void I()
{
    glBegin(GL_POLYGON);

    glColor3ub(0, 0, 0);

    glVertex2d(674, 334);
    glVertex2d(718, 334);
    glVertex2d(718, 472);
    glVertex2d(674, 472);

    glEnd();
}

int main(void)
{

    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Grid", NULL, NULL);
    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    int c = 0;
    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        display();
        //kotak();

        c++;

        if(c>350) kotak1();
        if(c>700) kotak2();
        if(c>1050) kotak3();
        if(c>1400) kotak4();

        if(c>1750){ kotak5(); L();}
        if(c>2100){ kotak6(); E();}
        if(c>2450){ kotak7(); N();}
        if(c>2800){ kotak8(); I();}

        if(c>3150) c=1450;

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
