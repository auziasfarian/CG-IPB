#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160066", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    // here lies ur variables
    double nol = 0, resetx=60, resety=-18, geser=0, puter=0, naik=0;
    int trigger = 0, i, status = 0, yok=0;


    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800, 0, 0, 1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        //background atas
        glBegin(GL_POLYGON);
        glColor3ub(0,0,nol);
        glVertex2f(0,0);
        glColor3ub(0,nol,0);
        glVertex2f(800,0);
        glColor3ub(nol,0,0);
        glVertex2f(800,400);
        glColor3ub(0,nol,nol);
        glVertex2f(0,400);
        glColor3ub(nol,nol,nol);
        glEnd();
        //background bawah
        glBegin(GL_POLYGON);
        glColor3ub(nol,nol,nol);
        glVertex2d(0,400);
        glVertex2d(800,400);
        glVertex2d(800,800);
        glVertex2d(0,800);
        glEnd();

        // I
        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(161.58+nol-resetx,158+nol-resety);
        glVertex2d(175.94+nol-resetx,158+nol-resety);
        glVertex2d(175.94+nol-resetx,301.66+nol-resety);
        glVertex2d(161.58+nol-resetx,301.66+nol-resety);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(nol,255,nol);
        glVertex2d(162.58+nol-resetx,158+nol-resety);
        glColor3ub(nol,nol,255);
        glVertex2d(176.94+nol-resetx,158+nol-resety);
        glColor3ub(255,nol,nol);
        glVertex2d(176.94+nol-resetx,301.66+nol-resety);
        glColor3ub(255,nol,0);
        glVertex2d(162.58+nol-resetx,301.66+nol-resety);
        glEnd();

        // V
        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(197.54+nol-resetx,195.41+nol-resety);
        glVertex2d(212.09+nol-resetx,195.41+nol-resety);
        glVertex2d(247.76+nol-resetx,272.86+nol-resety);
        glVertex2d(249.01+nol-resetx,301.66+nol-resety);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex2d(282.99+nol-resetx,195.41+nol-resety);
        glVertex2d(297.64+nol-resetx,195.41+nol-resety);
        glVertex2d(249.01+nol-resetx,301.66+nol-resety);
        glVertex2d(247.76+nol-resetx,272.86+nol-resety);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(255,nol,nol);
        glVertex2d(282.99+nol-resetx,195.41+nol-resety);
        glColor3ub(nol,255,nol);
        glVertex2d(297.64+nol-resetx,195.41+nol-resety);
        glColor3ub(nol,nol,255);
        glVertex2d(249.01+nol-resetx,301.66+nol-resety);
        glColor3ub(255,255,nol);
        glVertex2d(197.54+nol-resetx,195.41+nol-resety);
        glColor3ub(nol,255,255);
        glVertex2d(212.09+nol-resetx,195.41+nol-resety);
        glColor3ub(255,nol,255);
        glVertex2d(247.76+nol-resetx,272.86+nol-resety);

        glEnd();


        // A
        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(368.98+cos(rad)*54.5+nol-resetx,248.53+sin(rad)*54.5+nol-resety);
           }
        glEnd();

        glBegin(GL_LINE_LOOP);
                for (i=0; i <= 360; i++) {
            glColor3ub(i+nol,i*2+nol,i*3+nol);
              float rad = i*3.14159/180;
              glVertex2f(368.98+cos(rad)*54.5+nol-resetx,248.53+sin(rad)*54.5+nol-resety);
           }
        glColor3ub(123+nol,0,0);
        glVertex2d(410.82+nol-resetx, 195.41+nol-resety);
        glColor3ub(0,244+nol,0);
        glVertex2d(424.3+nol-resetx, 195.41+nol-resety);
        glColor3ub(0,0,nol*3+201);
        glVertex2d(424.3+nol-resetx, 301.66+nol-resety);
        glColor3ub(-nol,0,0);
        glVertex2d(410.82+nol-resetx, 301.66+nol-resety);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(nol,nol,nol);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(368.98+cos(rad)*39.85+nol-resetx,248.53+sin(rad)*39.85+nol-resety);
           }
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(255,nol,nol);
                for (i=0; i <= 360; i++) {
            glColor3ub(123+nol,i,i+nol*2);
              float rad = i*3.14159/180;
              glVertex2f(368.98+cos(rad)*39.85+nol-resetx,248.53+sin(rad)*39.85+nol-resety);
           }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(410.82+nol-resetx, 195.41+nol-resety);
        glVertex2d(424.3+nol-resetx, 195.41+nol-resety);
        glVertex2d(424.3+nol-resetx, 301.66+nol-resety);
        glVertex2d(410.82+nol-resetx, 301.66+nol-resety);
        glEnd();


        // N
        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(455.06+nol-resetx,195.41+nol-resety);
        glVertex2d(455.06+nol-resetx,301.66+nol-resety);
        glVertex2d(468.73+nol-resetx,301.66+nol-resety);
        glVertex2d(468.73+nol-resetx,195.41+nol-resety);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(468.73+nol-resetx,226.46+nol-resety);
        glVertex2d(468.73+nol-resetx,212.45+nol-resety);
        glVertex2d(524.43+nol-resetx,205.27+nol-resety);
        glVertex2d(524.43+nol-resetx,221.27+nol-resety);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex2d(524.43+nol-resetx,204.45+nol-resety);
        glVertex2d(524.43+nol-resetx,301.66+nol-resety);
        glVertex2d(536.74+nol-resetx,301.66+nol-resety);
        glVertex2d(536.74+nol-resetx,214.45+nol-resety);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(255,0,0);
        glVertex2d(455.06+nol-resetx,195.41+nol-resety);
        glColor3ub(0,nol+244,nol*32);
        glVertex2d(455.06+nol-resetx,301.66+nol-resety);
        glColor3ub(nol,231,nol*2);
        glVertex2d(468.73+nol-resetx,301.66+nol-resety);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(468.73+nol-resetx,195.41+nol-resety);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(120+nol,123,0);
        glVertex2d(524.43+nol-resetx,204.45+nol-resety);
        glColor3ub(glfwGetTime()*50,50,50);
        glVertex2d(524.43+nol-resetx,301.66+nol-resety);
        glColor3ub(125,23,245);
        glVertex2d(536.74+nol-resetx,301.66+nol-resety);
        glColor3ub(255,0,0);
        glVertex2d(536.74+nol-resetx,214.45+nol-resety);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(-nol,-nol,-nol);
        glVertex2d(524.43+nol-resetx,204.45+nol-resety);
        glColor3ub(245,185,123);
        glVertex2d(524.43+nol-resetx,301.66+nol-resety);
        glColor3ub(nol,255,nol*3);
        glVertex2d(536.74+nol-resetx,301.66+nol-resety);
        glColor3ub(255,nol*2,255);
        glVertex2d(536.74+nol-resetx,214.45+nol-resety);
        glEnd();


        // colour control

        if (yok == 1){
            if(trigger%2==0){
                nol+=0.25;}
            else{
                nol-=0.25;
            }
            if(nol==255 || nol == 0){
            trigger++;
            }
        }

        // pintu
        glBegin(GL_POLYGON);
        glColor3ub(255/2,255/2,255/2);
        glVertex2d(0-geser,0);
        glVertex2d(400-geser,0);
        glVertex2d(400-geser,800);
        glVertex2d(0-geser,800);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255/1.2,255/1.2,255/1.2);
        glVertex2d(400+geser,0);
        glVertex2d(800+geser,0);
        glVertex2d(800+geser,800);
        glVertex2d(400+geser,800);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255/1.25,255/1.25,255/1.25);
        glVertex2d(0-geser,0);
        glVertex2d(400-geser,0);
        glVertex2d(400-geser,800);
        glVertex2d(0-geser,800);
        glEnd();

        glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(400+geser,0);
        glVertex2d(800+geser,0);
        glVertex2d(800+geser,800);
        glVertex2d(400+geser,800);
        glEnd();

        if (status == 1)  geser+=0.25;
        if (geser >= 400) yok = 1;

        //ganggang

        puter = glfwGetTime()*50;

        glPushMatrix();
        glTranslated(405,400,0);
        if (puter <=90) glRotated(puter,0,0,1);
        glTranslated(-400,-400,0);
        glBegin(GL_POLYGON);
        if(puter <= 90){
        glColor3ub(255/2,255/2,255/2);
                for (i=180; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(400+cos(rad)*50,400+sin(rad)*50);
           }
        }
        else {
        glColor3ub(255/2,255/2,255/2);
                for (i=180+90; i <= 360+90; i++) {
              float rad = i*3.14159/180;
              glVertex2f(400+cos(rad)*50+geser,400+sin(rad)*50);
           }
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslated(395,400,0);
        if (puter <=90) glRotated(puter,0,0,1);
        glTranslated(-400,-400,0);
        glBegin(GL_POLYGON);

        if (puter <=90) {
        glColor3ub(255/2,255/2,255/2);
                for (i=0; i <= 180; i++) {
              float rad = i*3.14159/180;
              glVertex2f(400+cos(rad)*50,400+sin(rad)*50);
           }
        }

        else {
        glColor3ub(255/2,255/2,255/2);
                for (i=0+90; i <= 180+90; i++) {
              float rad = i*3.14159/180;
              glVertex2f(400+cos(rad)*50-geser,400+sin(rad)*50);
           }
        }

        if (puter>=90) status=1;

        glEnd();
        glPopMatrix();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
