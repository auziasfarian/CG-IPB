#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//ini buat menerima input dari user dan apa yang harus dilakukan
// esc -> exit
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

// ini tempat set view, perhitungan segala macem
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f); // kiri, kanan, bottom, top, depan, belakang
    //glOrtho(0, 800, 800, 0, 1.f, -1.f); // kiri, kanan, bottom, top, depan, belakang -> ala ala editor

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}



void display()  {
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void lingkaran (double x, double y, double a, double b, double n){
    double cons=2*3.14/1000;
	double pX, pY;
	double posX=0, posY=0;
	double sizee=n;

	glEnable(GL_BLEND);
    glEnable(GL_POLYGON_SMOOTH);
	glBegin(GL_POLYGON);
		for(int i=0; i<1000; i++){
			pX=sin(i*cons)*sizee+x;
			pY=cos(i*cons)*sizee+y;
			glVertex2f(a*pX, b*pY);
		}
	glEnd();
}

//////////////////////////////FUNGSI BUAT SENDIRI

void K()
{
    /* BACKGROUND */
    glBegin(GL_POLYGON);
    glColor3f(0.898, 0.784, 0.619);
    glVertex2f(800, 800);
    glVertex2f(800, -800);
    glVertex2f(-800, -800);
    glVertex2f(-800, 800);
    glEnd();


    int naik=100;
    //Huruf A
    glBegin(GL_POLYGON);
    glColor3ub(0,37,97);   //
    glVertex2d(49,457-naik);    // 146 681 // +97 +224
    glVertex2d(127,270-naik);   // 225 493 // +98 +223
    glVertex2d(145,319-naik);   // 243 542 // +98 +223
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,138,190);
    glVertex2d(145,319-naik);
    glVertex2d(49,457-naik);
    glVertex2d(90,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,138,190);
    glVertex2d(127,270-naik);
    glVertex2d(164,270-naik);
    glVertex2d(145,319-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(164,270-naik);
    glVertex2d(145,319-naik);
    glVertex2d(243,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,37,97);
    glVertex2d(145,319-naik);
    glVertex2d(184,416-naik);
    glVertex2d(243,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,84,138);
    glVertex2d(184,416-naik);
    glVertex2d(201,457-naik);
    glVertex2d(243,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(121,379-naik);
    glVertex2d(169,379-naik);
    glVertex2d(106,416-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,84,138);
    glVertex2d(184,416-naik);
    glVertex2d(169,379-naik);
    glVertex2d(106,416-naik);
    glEnd();


    //R
    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(312,270-naik);
    glVertex2d(312,457-naik);
    glVertex2d(352,307-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(31,44,95);
    glVertex2d(312,270-naik);
    glVertex2d(396,270-naik);
    glVertex2d(352,307-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,139,192);
    glVertex2d(453,293-naik);
    glVertex2d(396,270-naik);
    glVertex2d(352,307-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(2,85,137);
    glVertex2d(453,293-naik);
    glVertex2d(352,307-naik);
    glVertex2d(423,325-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,169,195);
    glVertex2d(453,293-naik);
    glVertex2d(423,325-naik);
    glVertex2d(463,348-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(31,44,95);
    glVertex2d(393,361-naik);
    glVertex2d(423,325-naik);
    glVertex2d(463,348-naik);
    glVertex2d(459,361-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(2,85,137);
    glVertex2d(393,361-naik);
    glVertex2d(426,390-naik);
    glVertex2d(459,361-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,139,192);
    glVertex2d(393,361-naik);
    glVertex2d(426,390-naik);
    glVertex2d(384,397-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(31,44,95);
    glVertex2d(393,361-naik);
    glVertex2d(352,397-naik);
    glVertex2d(384,397-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(2,85,137);
    glVertex2d(352,457-naik);
    glVertex2d(352,307-naik);
    glVertex2d(312,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(423,457-naik);
    glVertex2d(426,390-naik);
    glVertex2d(384,397-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(2,85,137);
    glVertex2d(423,457-naik);
    glVertex2d(426,390-naik);
    glVertex2d(470,457-naik);
    glEnd();

    //D
    glBegin(GL_POLYGON);
    glColor3ub(31,44,95);
    glVertex2d(559,270-naik);
    glVertex2d(600,307-naik);
    glVertex2d(559,383-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,77,135);
    glVertex2d(600,420-naik);
    glVertex2d(600,307-naik);
    glVertex2d(559,383-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,165,195);
    glVertex2d(600,420-naik);
    glVertex2d(559,457-naik);
    glVertex2d(559,383-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(600,420-naik);
    glVertex2d(559,457-naik);
    glVertex2d(631,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,77,135);
    glVertex2d(600,420-naik);
    glVertex2d(679,446-naik);
    glVertex2d(631,457-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(13,39,95);
    glVertex2d(600,420-naik);
    glVertex2d(679,446-naik);
    glVertex2d(710,420-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,165,196);
    glVertex2d(682,386-naik);
    glVertex2d(631,420-naik);
    glVertex2d(710,420-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(682,386-naik);
    glVertex2d(710,420-naik);
    glVertex2d(727,352-naik);
    glVertex2d(685,355-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,165,196);
    glVertex2d(682,340-naik);
    glVertex2d(716,316-naik);
    glVertex2d(727,352-naik);
    glVertex2d(685,355-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,37,97);
    glVertex2d(682,340-naik);
    glVertex2d(716,316-naik);
    glVertex2d(727,352-naik);
    glVertex2d(685,355-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,77,135);
    glVertex2d(682,340-naik);
    glVertex2d(716,316-naik);
    glVertex2d(710,307-naik);
    glVertex2d(631,307-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,165,196);
    glVertex2d(600,307-naik);
    glVertex2d(673,278-naik);
    glVertex2d(710,307-naik);
    glVertex2d(631,307-naik);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(600,307-naik);
    glVertex2d(673,278-naik);
    glVertex2d(559,270-naik);
    glEnd();

    int uppp=70;
    //A
    int x=97, y=223;
    //Huruf A
    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(49+x,457+y-uppp);    // 146 681 // +97 +224
    glVertex2d(127+x,270+y-uppp);   // 225 493 // +98 +223
    glVertex2d(145+x,319+y-uppp);   // 243 542 // +98 +223
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,84,138);
    glVertex2d(145+x,319+y-uppp);
    glVertex2d(49+x,457+y-uppp);
    glVertex2d(90+x,457+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(13,39,95);
    glVertex2d(127+x,270+y-uppp);
    glVertex2d(164+x,270+y-uppp);
    glVertex2d(145+x,319+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,170,196);
    glVertex2d(164+x,270+y-uppp);
    glVertex2d(145+x,319+y-uppp);
    glVertex2d(243+x,457+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(38,100,217);
    glVertex2d(145+x,319+y-uppp);
    glVertex2d(184+x,416+y-uppp);
    glVertex2d(243+x,457+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(184+x,416+y-uppp);
    glVertex2d(201+x,457+y-uppp);
    glVertex2d(243+x,457+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(13,39,95);
    glVertex2d(121+x,379+y-uppp);
    glVertex2d(169+x,379+y-uppp);
    glVertex2d(106+x,416+y-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(184+x,416+y-uppp);
    glVertex2d(169+x,379+y-uppp);
    glVertex2d(106+x,416+y-uppp);
    glEnd();

    //N
    glBegin(GL_POLYGON);
    glColor3ub(0,165,196);
    glVertex2d(401,680-uppp);
    glVertex2d(441,562-uppp);
    glVertex2d(441,680-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(401,680-uppp);
    glVertex2d(441,562-uppp);
    glVertex2d(401,494-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(13,39,95);
    glVertex2d(438,494-uppp);
    glVertex2d(441,562-uppp);
    glVertex2d(401,494-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(438,494-uppp);
    glVertex2d(441,562-uppp);
    glVertex2d(529,680-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(13,39,95);
    glVertex2d(438,494-uppp);
    glVertex2d(524,609-uppp);
    glVertex2d(529,680-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,165,196);
    glVertex2d(564,680-uppp);
    glVertex2d(524,609-uppp);
    glVertex2d(529,680-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,134,193);
    glVertex2d(564,680-uppp);
    glVertex2d(524,609-uppp);
    glVertex2d(564,494-uppp);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,77,135);
    glVertex2d(524,494-uppp);
    glVertex2d(524,609-uppp);
    glVertex2d(564,494-uppp);
    glEnd();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 2, 0,0);
    for(int i=0, j=-100; i<100; i++, j+=15){
        lingkaran(-400+j,140,1,1, 0.7);
        lingkaran(-400+j,395,1,1, 0.7);
        lingkaran(-400+j,640,1,1, 0.7);
    }
    glPopMatrix();
}


/////////////////////////////////////////////////


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - G64150010", NULL, NULL); // ini buat ukuran window nya ,, terus namanya

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))//kecepatan FPS dari while ini tergantung komputer masing masing
    {
        setup_viewport(window);

        display();

        ////////////////////////////////////////////////////////////

        //panggil fungsi K
        K();




        ////////////////////////////////////////////////////////////

        glfwSwapBuffers(window);
        glfwPollEvents();



        //y
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
