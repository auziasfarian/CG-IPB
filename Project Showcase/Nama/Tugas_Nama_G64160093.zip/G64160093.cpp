#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clrindex=0,buffer=0;
int colf[3][3]={{255, 165, 0},{20,97,99},{0,242,219}};
double x=glfwGetTime();

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
  glClear( GL_COLOR_BUFFER_BIT );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    glOrtho( 0, 800, 800, 0,-1, 1);

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    glBegin(GL_POLYGON);
    glColor3ub(colf[(clrindex+1)%3][0],colf[(clrindex+1)%3][1],colf[(clrindex+1)%3][2]);
    glVertex2f(79,502);
    glVertex2f(56,502);
    glVertex2f(56,300);
    glVertex2f(79,300);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(252,444);
    glVertex2f(233,444);
    glVertex2f(233,344);
    glVertex2f(252,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(252,385);
    glVertex2f(304,385);
    glVertex2f(304,400);
    glVertex2f(252,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(322,444);
    glVertex2f(304,444);
    glVertex2f(304,344);
    glVertex2f(322,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(350,444);
    glVertex2f(368,444);
    glVertex2f(368,344);
    glVertex2f(350,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(396,444);
    glVertex2f(414,444);
    glVertex2f(414,344);
    glVertex2f(396,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(396,444);
    glVertex2f(414,444);
    glVertex2f(414,344);
    glVertex2f(396,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(462,405);
    glVertex2f(414,405);
    glVertex2f(414,390);
    glVertex2f(462,390);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(469,358);
    glVertex2f(414,358);
    glVertex2f(414,344);
    glVertex2f(469,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(488,444);
    glVertex2f(469,444);
    glVertex2f(514,344);
    glVertex2f(523,344);
    glVertex2f(523,361);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(578,444);
    glVertex2f(558,444);
    glVertex2f(523,361);
    glVertex2f(523,344);
    glVertex2f(532,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(495,406);
    glVertex2f(549,406);
    glVertex2f(549,421);
    glVertex2f(495,421);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(695,344);
    glVertex2f(714,344);
    glVertex2f(714,444);
    glVertex2f(695,444);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(10+x,5+x,15+x);
       for (int i=0; i <= 360; i++)
       {
          float rad = i*3.14159/180;
          glVertex2f(746+cos(rad)*9,432+sin(rad)*9);
       }
       glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(10+x,5+x,15+x);
       for (int i=30; i <= 330; i++)
       {
          float rad = i*3.14159/180;
          glVertex2f(168+cos(rad)*55,392+sin(rad)*55);
       }
       glEnd();
    glBegin(GL_POLYGON);
     glColor3ub(0,0,0);
       for (int i=30; i <= 330; i++)
       {
          float rad = i*3.14159/180;
          glVertex2f(168+cos(rad)*39,392+sin(rad)*39);
       }
       glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2f(196,391);
    glVertex2f(220,391);
    glVertex2f(220,366);
    glVertex2f(195,374);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(182,391);
    glVertex2f(182,405);
    glVertex2f(204,405);
    glVertex2f(204,391);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(609,444);
    glVertex2f(590,444);
    glVertex2f(590,344);
    glVertex2f(609,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(609,444);
    glVertex2f(590,444);
    glVertex2f(590,344);
    glVertex2f(609,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(630,344);
    glVertex2f(630,358);
    glVertex2f(609,358);
    glVertex2f(609,344);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(630,399);
    glVertex2f(630,414);
    glVertex2f(609,414);
    glVertex2f(609,399);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(10+x,5+x,15+x);
       for (int i=-90; i <= 90; i++)
       {
          float rad = i*3.14159/180;
          glVertex2f(630+cos(rad)*35,379+sin(rad)*35);
       }
       glEnd();
    glBegin(GL_POLYGON);
     glColor3ub(0,0,0);
       for (int i=-90; i <=90; i++)
       {
          float rad = i*3.14159/180;
          glVertex2f(630+cos(rad)*20,379+sin(rad)*20);
       }
       glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(10+x,5+x,15+x);
    glVertex2f(673,444);
    glVertex2f(653,444);
    glVertex2f(629,407);
    glVertex2f(648,407);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160093", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buffer==0){
            clrindex++;
        }
        buffer++;
        buffer=buffer%100;
        setup_viewport(window);
        x=x+0.2;

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
