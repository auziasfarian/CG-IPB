#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

#define tgreen 65,255,0
#define red 255,65,0

static void error_callback(int error, const char* description) {
    fputs(description, stderr);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void) {
    int b, t = 0;
    int ch = 0;
    int geser = 0;
    int h[5] = {0};
    int v[5] = {0};

    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Alif Hilmi Akbar - G64160074", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window)) {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800, 0, -1.f, 1.f);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        b = b % 500; b++; t++;

        //A
        if(t > 599) {
            for(int i = 0; i < 5; i++) {
                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(126 + (i*10), 416 - (i*25));
                glVertex2f(145 + (i*10), 416 - (i*25));
                glVertex2f(145 + (i*10), 441 - (i*25));
                glVertex2f(126 + (i*10), 441 - (i*25));
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(202 - (i*10), 416 - (i*25));
                glVertex2f(221 - (i*10), 416 - (i*25));
                glVertex2f(221 - (i*10), 441 - (i*25));
                glVertex2f(202 - (i*10), 441 - (i*25));
                glEnd();
            }

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(136, 400);
            glVertex2f(211, 400);
            glVertex2f(211, 416);
            glVertex2f(136, 416);
            glEnd();

            if(t < 601) geser += 131;
        }

        //L
        if(t > 799) {
            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(257, 314);
            glVertex2f(274, 314);
            glVertex2f(274, 441);
            glVertex2f(257, 441);
            glEnd();

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(257, 424);
            glVertex2f(335, 424);
            glVertex2f(335, 441);
            glVertex2f(257, 441);
            glEnd();

            if(t < 801) geser += 114;
        }

        //I
        if(t > 999) {
            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(371, 314);
            glVertex2f(428, 314);
            glVertex2f(428, 331);
            glVertex2f(371, 331);
            glEnd();

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(390, 314);
            glVertex2f(409, 314);
            glVertex2f(409, 441);
            glVertex2f(390, 441);
            glEnd();

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(371, 424);
            glVertex2f(428, 424);
            glVertex2f(428, 441);
            glVertex2f(371, 441);
            glEnd();

            if(t < 1001) geser += 93;
        }

        //F
        if(t > 1199) {
            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(464, 314);
            glVertex2f(481, 314);
            glVertex2f(481, 441);
            glVertex2f(464, 441);
            glEnd();

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(464, 314);
            glVertex2f(558, 314);
            glVertex2f(558, 331);
            glVertex2f(464, 331);
            glEnd();

            glBegin(GL_POLYGON);
            glColor3ub(tgreen);
            glVertex2f(464, 370);
            glVertex2f(540, 370);
            glVertex2f(540, 387);
            glVertex2f(464, 387);
            glEnd();

            if(t < 1201) geser += 130;
        }

        //kedip-kedip
        glBegin(GL_POLYGON);
        if(t < 598 || t > 1500) {
            if(b > 250) glColor3ub(tgreen);
            else glColor3ub(0, 0, 0);
        }
        else glColor3ub(tgreen);
        glVertex2f(126 + geser, 441);
        glVertex2f(228 + geser, 441);
        glVertex2f(228 + geser, 457);
        glVertex2f(126 + geser, 457);
        glEnd();

        if(t > 1500) {
            for(int i = 0; i < 5; i++) {
                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(40 + h[i], 40 + v[i]);
                glVertex2f(60 + h[i], 40 + v[i]);
                glVertex2f(60 + h[i], 60 + v[i]);
                glVertex2f(40 + h[i], 60 + v[i]);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(740 - v[i], 40 + h[i]);
                glVertex2f(760 - v[i], 40 + h[i]);
                glVertex2f(760 - v[i], 60 + h[i]);
                glVertex2f(740 - v[i], 60 + h[i]);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(740 - h[i], 760 - v[i]);
                glVertex2f(760 - h[i], 760 - v[i]);
                glVertex2f(760 - h[i], 740 - v[i]);
                glVertex2f(740 - h[i], 740 - v[i]);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(40 + v[i], 740 - h[i]);
                glVertex2f(60 + v[i], 740 - h[i]);
                glVertex2f(60 + v[i], 760 - h[i]);
                glVertex2f(40 + v[i], 760 - h[i]);
                glEnd();
            }

            if(v[0] == 0 && h[0] < 700 && t % 30 == 0) h[0] += 20;
            else if(h[1] == 700 && v[0] < 700 && t % 30 == 0) v[0] += 20;
            else if(v[1] == 700 && h[0] > 0 && t % 30 == 0) h[0] -= 20;
            else if(h[1] == 0 && v[0] > 0 && t % 30 == 0) v[0] -= 20;

            if(v[1] == 0 && h[0] > 20 && h[1] < 700 && t % 30 == 0) h[1] += 20;
            else if(h[0] == 700 && v[0] > 20 && v[1] < 700 && t % 30 == 0) v[1] += 20;
            else if(h[0] < 680 && h[1] > 0 && t % 30 == 0) h[1] -= 20;
            else if(v[0] < 680 && v[1] > 0 && t % 30 == 0) v[1] -= 20;

            if(v[2] == 0 && h[1] > 20 && h[2] < 700 && t % 30 == 0) h[2] += 20;
            else if(h[1] == 700 && v[1] > 20 && v[2] < 700 && t % 30 == 0) v[2] += 20;
            else if(h[1] < 680 && h[2] > 0 && t % 30 == 0) h[2] -= 20;
            else if(v[1] < 680 && v[2] > 0 && t % 30 == 0) v[2] -= 20;

            if(v[3] == 0 && h[2] > 20 && h[3] < 700 && t % 30 == 0) h[3] += 20;
            else if(h[2] == 700 && v[2] > 20 && v[3] < 700 && t % 30 == 0) v[3] += 20;
            else if(h[2] < 680 && h[3] > 0 && t % 30 == 0) h[3] -= 20;
            else if(v[2] < 680 && v[3] > 0 && t % 30 == 0) v[3] -= 20;

            if(v[4] == 0 && h[3] > 20 && h[4] < 700 && t % 30 == 0) h[4] += 20;
            else if(h[3] == 700 && v[3] > 20 && v[4] < 700 && t % 30 == 0) v[4] += 20;
            else if(h[3] < 680 && h[4] > 0 && t % 30 == 0) h[4] -= 20;
            else if(v[3] < 680 && v[4] > 0 && t % 30 == 0) v[4] -= 20;

            if((h[0] < 640 || v[4] > 60) && (v[0] < 640 || h[4] < 640) && (h[0] > 60 || v[4] < 640) && (v[0] > 60 || h[4] > 60)) {
                //ULcorner1
                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(40, 40);
                glVertex2f(100, 40);
                glVertex2f(100, 60);
                glVertex2f(40, 60);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(40, 40);
                glVertex2f(60, 40);
                glVertex2f(60, 100);
                glVertex2f(40, 100);
                glEnd();

                //URcorner1
                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(700, 40);
                glVertex2f(760, 40);
                glVertex2f(760, 60);
                glVertex2f(700, 60);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(740, 40);
                glVertex2f(760, 40);
                glVertex2f(760, 100);
                glVertex2f(740, 100);
                glEnd();

                //LRcorner1
                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(700, 760);
                glVertex2f(760, 760);
                glVertex2f(760, 740);
                glVertex2f(700, 740);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(740, 760);
                glVertex2f(760, 760);
                glVertex2f(760, 700);
                glVertex2f(740, 700);
                glEnd();

                //LLcorner1
                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(40, 760);
                glVertex2f(100, 760);
                glVertex2f(100, 740);
                glVertex2f(40, 740);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(tgreen);
                glVertex2f(40, 760);
                glVertex2f(60, 760);
                glVertex2f(60, 700);
                glVertex2f(40, 700);
                glEnd();
            }

            else {
                //ULcorner2
                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(20, 20);
                glVertex2f(100, 20);
                glVertex2f(100, 40);
                glVertex2f(20, 40);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(20, 40);
                glVertex2f(40, 40);
                glVertex2f(40, 100);
                glVertex2f(20, 100);
                glEnd();

                //URcorner2
                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(700, 20);
                glVertex2f(780, 20);
                glVertex2f(780, 40);
                glVertex2f(700, 40);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(760, 20);
                glVertex2f(780, 20);
                glVertex2f(780, 100);
                glVertex2f(760, 100);
                glEnd();

                //LRcorner2
                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(700, 780);
                glVertex2f(780, 780);
                glVertex2f(780, 760);
                glVertex2f(700, 760);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(760, 760);
                glVertex2f(780, 760);
                glVertex2f(780, 700);
                glVertex2f(760, 700);
                glEnd();

                //LLcorner3
                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(20, 780);
                glVertex2f(100, 780);
                glVertex2f(100, 760);
                glVertex2f(20, 760);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(20, 760);
                glVertex2f(40, 760);
                glVertex2f(40, 700);
                glVertex2f(20, 700);
                glEnd();

                //solid heart
                for(int i = 5; i > 0; i--) {
                    for(int j = i; j > 0; j--) {
                        glBegin(GL_POLYGON);
                        glColor3ub(red);
                        glVertex2f(344 + (i * 10), 170 + (j * 10));
                        glVertex2f(344 + ((i + 1) * 10), 170 + (j * 10));
                        glVertex2f(344 + ((i + 1) * 10), 170 + ((j + 1) * 10));
                        glVertex2f(344 + (i * 10), 170 + ((j + 1) * 10));
                        glEnd();
                    }
                }

                for(int i = 5; i > 0; i--) {
                    for(int j = 1; j <= i; j++) {
                        glBegin(GL_POLYGON);
                        glColor3ub(red);
                        glVertex2f(454 - (i * 10), 170 + (j * 10));
                        glVertex2f(454 - ((i + 1) * 10), 170 + (j * 10));
                        glVertex2f(454 - ((i + 1) * 10), 170 + ((j + 1) * 10));
                        glVertex2f(454 - (i * 10), 170 + ((j + 1) * 10));
                        glEnd();
                    }
                }

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(354, 170);
                glVertex2f(444, 170);
                glVertex2f(444, 180);
                glVertex2f(354, 180);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(364, 160);
                glVertex2f(394, 160);
                glVertex2f(394, 170);
                glVertex2f(364, 170);
                glEnd();

                glBegin(GL_POLYGON);
                glColor3ub(red);
                glVertex2f(404, 160);
                glVertex2f(434, 160);
                glVertex2f(434, 170);
                glVertex2f(404, 170);
                glEnd();
            }
        }

//            //!
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(390, 650);
//            glVertex2f(410, 650);
//            glVertex2f(410, 660);
//            glVertex2f(390, 660);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(390, 620);
//            glVertex2f(410, 620);
//            glVertex2f(410, 630);
//            glVertex2f(390, 630);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(380, 630);
//            glVertex2f(390, 630);
//            glVertex2f(390, 650);
//            glVertex2f(380, 650);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(380, 600);
//            glVertex2f(390, 600);
//            glVertex2f(390, 620);
//            glVertex2f(380, 620);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(410, 630);
//            glVertex2f(420, 630);
//            glVertex2f(420, 650);
//            glVertex2f(410, 650);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(410, 600);
//            glVertex2f(420, 600);
//            glVertex2f(420, 620);
//            glVertex2f(410, 620);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(370, 570);
//            glVertex2f(380, 570);
//            glVertex2f(380, 600);
//            glVertex2f(370, 600);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(420, 570);
//            glVertex2f(430, 570);
//            glVertex2f(430, 600);
//            glVertex2f(420, 600);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(410, 560);
//            glVertex2f(420, 560);
//            glVertex2f(420, 570);
//            glVertex2f(410, 570);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(380, 560);
//            glVertex2f(390, 560);
//            glVertex2f(390, 570);
//            glVertex2f(380, 570);
//            glEnd();
//
//            glBegin(GL_POLYGON);
//            glColor3ub(red);
//            glVertex2f(390, 550);
//            glVertex2f(410, 550);
//            glVertex2f(410, 560);
//            glVertex2f(390, 560);
//            glEnd();

//        //hollow heart
//        for(int i = 1; i <= 5; i++) {
//            glBegin(GL_POLYGON);
//            glColor3ub(tgreen);
//            glVertex2f(i * 10, 100 + (i * 10));
//            glVertex2f((i + 1) * 10, 100 + (i * 10));
//            glVertex2f((i + 1) * 10, 100 + ((i + 1) * 10));
//            glVertex2f(i * 10, 100 + ((i + 1) * 10));
//            glEnd();
//        }
//
//        for(int i = 1; i <= 5; i++) {
//            glBegin(GL_POLYGON);
//            glColor3ub(tgreen);
//            glVertex2f(110 - (i * 10), 100 + (i * 10));
//            glVertex2f(110 - ((i + 1) * 10), 100 + (i * 10));
//            glVertex2f(110 - ((i + 1) * 10), 100 + ((i + 1) * 10));
//            glVertex2f(110 - (i * 10), 100 + ((i + 1) * 10));
//            glEnd();
//        }
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(10, 100);
//        glVertex2f(20, 100);
//        glVertex2f(20, 110);
//        glVertex2f(10, 110);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(50, 100);
//        glVertex2f(60, 100);
//        glVertex2f(60, 110);
//        glVertex2f(50, 110);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(90, 100);
//        glVertex2f(100, 100);
//        glVertex2f(100, 110);
//        glVertex2f(90, 110);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(20, 90);
//        glVertex2f(50, 90);
//        glVertex2f(50, 100);
//        glVertex2f(20, 100);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(60, 90);
//        glVertex2f(90, 90);
//        glVertex2f(90, 100);
//        glVertex2f(60, 100);
//        glEnd();

//        //solid heart
//        for(int i = 5; i > 0; i--) {
//            for(int j = i; j > 0; j--) {
//                glBegin(GL_POLYGON);
//                glColor3ub(tgreen);
//                glVertex2f(i * 10, 100 + (j * 10));
//                glVertex2f((i + 1) * 10, 100 + (j * 10));
//                glVertex2f((i + 1) * 10, 100 + ((j + 1) * 10));
//                glVertex2f(i * 10, 100 + ((j + 1) * 10));
//                glEnd();
//            }
//        }
//
//        for(int i = 5; i > 0; i--) {
//            for(int j = 1; j <= i; j++) {
//                glBegin(GL_POLYGON);
//                glColor3ub(tgreen);
//                glVertex2f(110 - (i * 10), 100 + (j * 10));
//                glVertex2f(110 - ((i + 1) * 10), 100 + (j * 10));
//                glVertex2f(110 - ((i + 1) * 10), 100 + ((j + 1) * 10));
//                glVertex2f(110 - (i * 10), 100 + ((j + 1) * 10));
//                glEnd();
//            }
//        }
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(10, 100);
//        glVertex2f(100, 100);
//        glVertex2f(100, 110);
//        glVertex2f(10, 110);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(20, 90);
//        glVertex2f(50, 90);
//        glVertex2f(50, 100);
//        glVertex2f(20, 100);
//        glEnd();
//
//        glBegin(GL_POLYGON);
//        glColor3ub(tgreen);
//        glVertex2f(60, 90);
//        glVertex2f(90, 90);
//        glVertex2f(90, 100);
//        glVertex2f(60, 100);
//        glEnd();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
