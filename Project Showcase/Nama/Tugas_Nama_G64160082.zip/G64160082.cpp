#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, height, 0, 10.f, -10.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void iBesar(int tmpx, int tmpy){

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(tmpx, tmpy, -1);
    glVertex3i(tmpx, tmpy+96, -1);
    glVertex3i(tmpx+32, tmpy+96, -1);
    glVertex3i(tmpx+32, tmpy, -1);
    glEnd();
    glPopMatrix();
}

void barTengah(int tmpx, int tmpy, int lebar, int tinggi, int warna){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(warna,warna,warna);
    glVertex3i(tmpx, tmpy, -1);
    glVertex3i(tmpx, tmpy+tinggi, -1);
    glVertex3i(tmpx+lebar, tmpy+tinggi, -1);
    glVertex3i(tmpx+lebar, tmpy, -1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(warna,warna,warna);
    glVertex3i(tmpx, tmpy, -1);
    glVertex3i(tmpx, tmpy+tinggi, -1);
    glVertex3i(tmpx-lebar, tmpy+tinggi, -1);
    glVertex3i(tmpx-lebar, tmpy, -1);
    glEnd();
    glPopMatrix();
}

void iBesarSamping(int tmpx, int tmpy){

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(tmpx, tmpy, -1);
    glVertex3i(tmpx+79, tmpy, -1);
    glVertex3i(tmpx+79, tmpy+28, -1);
    glVertex3i(tmpx, tmpy+28, -1);
    glEnd();
    glPopMatrix();
}

void clip10(int tmpx, int tmpy){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex3i(tmpx, tmpy, 1);
    glVertex3i(tmpx+10, tmpy, 1);
    glVertex3i(tmpx+10, tmpy+10, 1);
    glVertex3i(tmpx, tmpy+10, 1);
    glEnd();
    glPopMatrix();
}

void clipBox(int tmpx, int tmpy){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(tmpx, tmpy, 1);
    glVertex3i(tmpx+25, tmpy, 1);
    glVertex3i(tmpx+25, tmpy+21, 1);
    glVertex3i(tmpx, tmpy+21, 1);
    glEnd();
    glPopMatrix();
}

void bar(int tmpx, int tmpy){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(tmpx, tmpy, 1);
    glVertex3i(tmpx, tmpy+8, 1);
    glVertex3i(tmpx+47, tmpy+8, 1);
    glVertex3i(tmpx+47, tmpy, 1);
    glEnd();
    glPopMatrix();
}

void whisker(){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex3i(320+5, 93, 2);
    glVertex3i(320, 96, 1);
    glVertex3i(320-5, 93, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex3i(320, 96, 2);
    glVertex3i(320, 123, 1);
    glVertex3i(320-45, 133, 1);
    glVertex3i(320-80, 120, 1);
    glVertex3i(320-75, 114, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex3i(320, 123, 1);
    glVertex3i(320+45, 133, 1);
    glVertex3i(320+80, 120, 1);
    glVertex3i(320+75, 114, 1);
    glEnd();
    glPopMatrix();
}

void eyes(){
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex3i(320-40, 59, 1);
    glVertex3i(320-90, 59+10, 1);
    glVertex3i(320-80, 59+13, 1);
    glVertex3i(320-30, 59+10, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex3i(320+40, 59, 1);
    glVertex3i(320+90, 59+10, 1);
    glVertex3i(320+80, 59+13, 1);
    glVertex3i(320+30, 59+10, 1);
    glEnd();
    glPopMatrix();
}

void display()
{
    iBesar(60, 239);            //Buat H
    iBesar(113, 239);

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(91, 280, 0);
    glVertex3i(91, 307, 0);
    glVertex3i(114, 307, 0);
    glVertex3i(114, 280, 0);
    glEnd();
    glPopMatrix();


    iBesar(159, 239);           //Buat A
    iBesar(205, 239);

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(187, 315, 0);
    glVertex3i(205, 315, 0);
    glVertex3i(206, 239, 0);
    glVertex3i(187, 239, 0);
    glEnd();
    glPopMatrix();
    //dekor A
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex3i(191, 256, 1);
    glVertex3i(179, 258, 1);
    glVertex3i(180, 263, 1);
    glVertex3i(191, 260, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(213, 243, 1);
    glVertex3i(226, 226, 1);
    glVertex3i(229, 243, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(184, 243, 1);
    glVertex3i(171, 226, 1);
    glVertex3i(168, 243, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex3i(205, 256, 1);
    glVertex3i(205, 260, 1);
    glVertex3i(215, 263, 1);
    glVertex3i(216, 258, 1);
    glEnd();
    glPopMatrix();

    glLineWidth(3.0);
    glPushMatrix();
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex3i(196, 274, 2);
    glVertex3i(196, 281, 2);
    glVertex3i(189, 285, 2);
    glVertex3i(183, 274, 2);
    glEnd();
    glPopMatrix();

    glLineWidth(3.0);
    glPushMatrix();
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex3i(198, 274, 2);
    glVertex3i(198, 281, 2);
    glVertex3i(205, 285, 2);
    glVertex3i(211, 274, 2);
    glEnd();
    glPopMatrix();

    iBesar(251,239);                //buat F
    iBesarSamping(251, 239);
    iBesarSamping(251, 279);

    iBesar(342,239);                //buat I

    iBesar(387,239);                //buat D
    iBesar(438,239);
    iBesarSamping(387,239);
    iBesarSamping(387,239+68);
    clip10(461,239);
    clip10(461,325);

    iBesarSamping(486,239);         //buat Z
    iBesarSamping(486,239+68);
    bar(510,280);
    bar(510-13,280+8);
    bar(486,280+16);
    bar(486,280+23);
    clipBox(540,239+28);

    /** Buat Cat (^・ω・^ ) **/

    barTengah(320,59,150,70,0);
    barTengah(320,59+70,125,10,0);
    barTengah(320,59+80,100,10,0);
    barTengah(320,59+90,75,10,0);
    barTengah(320,59-10,125,10,0);
    barTengah(320,59-20,100,10,0);
    barTengah(320,59-30,75,10,0);

    eyes();
    whisker();

    glPushMatrix();
    glRotatef((float) glfwGetTime() * 100.f, 1.f, 0.f, 0.f);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(320-30, 59-1, 2);
    glVertex3i(320-100, 59+5, 2);
    glVertex3i(320-100, 59+25, 2);
    glVertex3i(320-20, 59+20, 2);
    glEnd();

    glPushMatrix();
    //glRotatef((float) glfwGetTime() * 100.f, 1.f, 0.f, 0.f);
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(320+30, 59-1, 2);
    glVertex3i(320+100, 59+5, 2);
    glVertex3i(320+100, 59+25, 2);
    glVertex3i(320+20, 59+20, 2);
    glEnd();

    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(320+50, 59-20, 1);
    glVertex3i(320+150, 59-40, 1);
    glVertex3i(320+125, 59, 1);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex3i(320-50, 59-20, 1);
    glVertex3i(320-150, 59-40, 1);
    glVertex3i(320-125, 59, 1);
    glEnd();
    glPopMatrix();


}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(640, 480, "G64160082", NULL, NULL);
    //grid(10,10);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    glClearColor(255, 255, 0, 1);


    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
