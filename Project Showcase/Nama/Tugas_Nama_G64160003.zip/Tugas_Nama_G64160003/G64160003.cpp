#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;
int in=0,tr=0;
int colorf[3][3]={{242,237,81},{244,243,295},{242,239,143}};
int color[2][3]={{47,242,247},{255,255,255}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();

}
void bg(){ //MEMBUAT BACKGROUND LANGIT
    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);glVertex2f(0,0);
    //glColor3ub(0,0,0);glVertex2d(800,0);
    glColor3ub(38,47,144);glVertex2f(0,800);
    glColor3ub(25,25,86); glVertex2d(800,800);

    glColor3ub(0,0,0);glVertex2f(0,0);
    glColor3ub(0,0,0);glVertex2d(800,0);
    //glColor3ub(0,0,130);glVertex2f(0,678);
    glColor3ub(25,25,86); glVertex2d(800,800);

    glEnd();
}
void Lingkaran(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<360;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}
void bingkai(){ int i;int j;

   glBegin(GL_LINES);
      glLineWidth(100);
      glColor3ub(255,255,255);  glColor3ub(color[in%3][0],color[(in)%3][1],color[(in)%3][2]);
      glVertex2f(58, 35); glVertex2f(738, 35);
   glEnd();


    glBegin(GL_LINES);
      glLineWidth(100);
      glColor3ub(255,255,255);  glColor3ub(color[in+1%3][0],color[(in+1)%3][1],color[(in+1)%3][2]);
      glVertex2f(58, 764); glVertex2f(738, 764);
   glEnd();

    glBegin(GL_LINES);
      glLineWidth(100);
      glColor3ub(255,255,255);  glColor3ub(color[in+1%3][0],color[(in+1)%3][1],color[(in+1)%3][2]);
      glVertex2f(35, 65); glVertex2f(35, 730);
   glEnd();

    glBegin(GL_LINES);
      glLineWidth(100);
      glColor3ub(255,255,255); glColor3ub(color[in%3][0],color[(in)%3][1],color[(in)%3][2]);
      glVertex2f(760, 65); glVertex2f(760, 730);
   glEnd();
}
void hiasan(){
    glColor3f(1.0, 1.0, 1.0);
         glPushMatrix();
    glRotatef((float) glfwGetTime() * 50, 0, 0, 0);
    glBegin(GL_POINTS); //BINTIK KECIL
    glVertex2f(101, 145); glVertex2f(335, 125); glVertex2f(689, 127);glVertex2f(691, 343);glVertex2f(667, 505);
    glVertex2f(603, 667); glVertex2f(479, 667); glVertex2f(497, 94); glVertex2f(228, 576);
    glEnd();
    glPopMatrix();
    glBegin(GL_POLYGON);
    glColor4ub(41,171,226,200);
    glVertex2d(35,431);
    glVertex2d(352,764);
    glVertex2d(213,764);
    glVertex2d(35,569);
    glEnd();
    glColor3ub(239,247,84);
    glBegin(GL_TRIANGLES);
    glVertex2f(35,569);
    glVertex2f(35,764);
    glVertex2f(213,764);
    glEnd();
    glColor3ub(255,255,255);
        glPushMatrix();
    glRotatef((float) glfwGetTime() * 40, 77, 546, 0);
    Lingkaran(77,546,18);
    glPopMatrix();

    glColor3ub(255,255,255);
            glPushMatrix();
    glRotatef((float) glfwGetTime() * 60, 158, 630, 0);
    Lingkaran(158,630,18); glPopMatrix();
    glColor3ub(255,255,255);
    glPushMatrix();
    glRotatef((float) glfwGetTime() * 70, 228, 705, 0);
    Lingkaran(228,705,18);glPopMatrix();

    glBegin(GL_LINES);
      glLineWidth(100);glColor3ub(255,255,255);
      glVertex2f(460, 578); glVertex2f(497, 597); glVertex2f(497, 597); glVertex2f(517, 576);
      glVertex2f(517, 576);glVertex2f(540, 588);glVertex2f(540, 588);glVertex2f(537, 563);
      glVertex2f(537, 563);glVertex2f(568, 584);
   glEnd();
   glBegin(GL_LINES);
      glLineWidth(100);glColor3ub(255,255,255);
      glVertex2f(228, 495); glVertex2f(273, 519); glVertex2f(273, 519); glVertex2f(289, 501);
      glVertex2f(289, 501);glVertex2f(318, 522);glVertex2f(318, 522);glVertex2f(330, 505);
      glVertex2f(330, 505);glVertex2f(360, 517);glVertex2f(360, 517); glVertex2f(391, 507);
   glEnd();
}
void bulat(){//BULAT-BULAT DI BINGKAI

    glColor3ub(255,255,255);
    Lingkaran(35,42,18);

    glColor3ub(255,255,255);
    Lingkaran(759,42,18);

    glColor3ub(255,255,255);
    Lingkaran(759,753,18);

    glColor3ub(255,255,255);
    Lingkaran(35,753,18);
}

void A()
{
    glBegin(GL_POLYGON);

    glColor3ub(41,171,226);

    glVertex2d(131,224);
    glVertex2d(164,224);
    glColor3ub(161,188,226);glVertex2d(88,400);
    glVertex2d(60,400);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(43,207,224);
    glVertex2d(131,224);
    glVertex2d(164,224);
    glColor3ub(112,131,160); glVertex2d(236,400);
    glVertex2d(207,400);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(92,178,198);
    glVertex2d(116,323);
    //glVertex2d(110,344);
    glVertex2d(180,323);
    glVertex2d(185,344);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(92,178,198);
    glVertex2d(116,323);
    glVertex2d(110,344);
    //glVertex2d(180,323);
    glVertex2d(185,344);
    glEnd();
}
void AA()
{
    glBegin(GL_POLYGON);

    glColor3ub(15,183,127);

    glVertex2d(332,224);
    glVertex2d(365,224);
    glColor3ub(152,152,152);
    glVertex2d(289,400);
    glVertex2d(260,400);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(159,237,165);
    glVertex2d(332,224);
    glVertex2d(365,224);
    glColor3ub(11,221,101);glVertex2d(437,400);
    glVertex2d(408,400);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(159,237,165);

    glVertex2d(316,327);
    //glVertex2d(310,344);
    glVertex2d(380,327);
    glVertex2d(385,344);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(159,237,165);

    glVertex2d(316,327);
    glVertex2d(310,344);
    //glVertex2d(380,327);
    glVertex2d(385,344);

    glEnd();
}
void LingkaranR(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<101;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}
void R(){

    glBegin(GL_POLYGON);

    glColor3ub(237,98,174);

    glVertex2d(466,227);
    glVertex2d(490,227);
    glColor3ub(239,177,224); glVertex2d(490,401);
    glVertex2d(466,401);

    glEnd();

    glColor3ub(242,95,172);
    LingkaranR(511,275.5,48.55); // Lingkaran Luar Atas
    glColor3ub(25,25,86);glColor3ub(8,8,45);
    LingkaranR(511,275.5,31.5); // Lingkaran Dalam Atas

    glBegin(GL_POLYGON);
    glColor3ub(242,95,172);
     glVertex2d(490,242);
     glVertex2d(512,242);
     glVertex2d(512,227);
     glVertex2d(490,227);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,95,172);
     glVertex2d(490,324);
     glVertex2d(512,324);
     glVertex2d(512,307);
     glVertex2d(490,307);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(226,207,222);
     glVertex2d(545,401);
     glVertex2d(574,401);
      glColor3ub(242,145,198);glVertex2d(525,322);
     glVertex2d(500,324);
    glEnd();
}
void star(){

glColor3f(1,1,1);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(582,179);
glColor3ub(239,247,84);glVertex2f(581,143);
glVertex2f(610,164);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(633,186);
glColor3ub(239,247,84);glVertex2f(643,152);
glVertex2f(610,164);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(633,186);
glColor3ub(239,247,84);glVertex2f(655,214);
glVertex2f(619,214);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(588,210);
glColor3ub(239,247,84);glVertex2f(599,244);
glVertex2f(619,214);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(588,210);
glColor3ub(239,247,84);glVertex2f(554,200);
glVertex2f(582,179);
glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(239,247,84);glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
     glVertex2d(582,179);
     glVertex2d(610,164);
     glVertex2d(633,186);
     glVertex2d(619,214);
     glVertex2d(588,210);
    glEnd();

glColor3f(1,1,1);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(606,275);
glColor3ub(239,247,84);glVertex2f(596,257);
glVertex2f(617,260);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(617,260);
glColor3ub(239,247,84);glVertex2f(632,244);
glVertex2f(635,265);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(635,265);
glColor3ub(239,247,84);glVertex2f(655,274);
glVertex2f(636,284);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(636,284);
glColor3ub(239,247,84);glVertex2f(633,306);
glVertex2f(618,291);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(618,291);
glColor3ub(239,247,84);glVertex2f(597,295);
glVertex2f(606,275);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,247,84);glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
     glVertex2f(606,275);
     glVertex2f(617,260);
     glVertex2f(635,265);
     glVertex2f(636,284);
     glVertex2f(618,291);
    glEnd();

glColor3f(1,1,1);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(668,224);
glColor3ub(239,247,84);glVertex2f(658,205);
glVertex2f(679,208);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(679,208);
glColor3ub(239,247,84);glVertex2f(694,192);
glVertex2f(697,213);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(697,213);
glColor3ub(239,247,84);glVertex2f(717,222);
glVertex2f(698,232);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(698,232);
glColor3ub(239,247,84);glVertex2f(696,254);
glVertex2f(680,239);
glEnd();
glColor3f(1,1,1);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
glBegin(GL_TRIANGLES);
glVertex2f(680,239);
glColor3ub(239,247,84);glVertex2f(659,243);
glVertex2f(668,224);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,247,84);glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
     glVertex2f(668,224);
     glVertex2f(679,208);
     glVertex2f(697,213);
     glVertex2f(698,232);
     glVertex2f(680,239);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160003>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        if(tr==0){
            in++;
        }
        tr++;
        tr=tr%100;

        setup_viewport(window);

        display();
        //panggil fungsi
bg(); hiasan(); bingkai();
        A();
       AA();
        R();
        star(); bulat();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
