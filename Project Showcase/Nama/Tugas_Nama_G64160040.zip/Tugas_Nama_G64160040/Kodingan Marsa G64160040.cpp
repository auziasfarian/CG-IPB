
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


int clindex=0,buff=0;
int colorf[3][3]={{255,215,0},{255,219,67},{225,229,118}};
int colorg[3][3]={{56,50,50},{30,28,28},{0,0,0}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT) ;

    glFlush();
}
void BG()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(colorg[clindex%3][0],colorg[(clindex)%3][1],colorg[(clindex)%3][2]);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(0,0,0);
    glVertex2d(800,120);
    glVertex2d(0,120);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(0,680);
    glVertex2d(800,680);
    glColor3ub(colorg[clindex%3][0],colorg[(clindex)%3][1],colorg[(clindex)%3][2]);
    glVertex2d(800,800);
    glVertex2d(0,800);
    glEnd();

}

void kotak()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,215,0);
    glVertex2d(145,281);
    glVertex2d(256,281);
    glVertex2d(256,448);
    glVertex2d(145,448);

    glEnd();
   glBegin(GL_POLYGON);
    glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(145,281);
    glVertex2d(256,281);
    glVertex2d(256,448);
    glVertex2d(145,448);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(159,294);
    glVertex2d(242,294);
    glVertex2d(242,434);
    glVertex2d(159,434);

    glEnd();
}

void M()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(284,359);
    glVertex2d(284,303);
    glVertex2d(293,303);
    glVertex2d(293,359);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(293,303);
    glVertex2d(310,340);
    glVertex2d(310,354);
    glVertex2d(293,324);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(310,340);
    glVertex2d(326,303);
    glVertex2d(326,324);
    glVertex2d(310,354);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(326,303);
    glVertex2d(335,303);
    glVertex2d(335,359);
    glVertex2d(326,359);

    glEnd();

}

void A()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(347,359);
    glVertex2d(365,303);
    glVertex2d(374,303);
    glVertex2d(392,359);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(356,359);
    glVertex2d(359,347);
    glVertex2d(379,347);
    glVertex2d(383,359);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(360,342);
    glVertex2d(369,312);
    glVertex2d(378,342);

    glEnd();

}
void R()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(404,359);
    glVertex2d(404,303);
    glVertex2d(413,307);
    glVertex2d(413,359);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(404,303);
    glVertex2d(438,303);
    glVertex2d(443,304);
    glVertex2d(445,307);

    glVertex2d(445,328);
    glVertex2d(436,332);
     glVertex2d(433,332);
    glVertex2d(430,332);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(430,332);
    glVertex2d(447,359);
    glVertex2d(438,359);
    glVertex2d(419,329);

    glVertex2d(420,328);
    glVertex2d(436,328);

    glEnd();

      glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(420,328);
    glVertex2d(436,328);
    glVertex2d(436,307);
    glVertex2d(413,307);

    glEnd();
}
void S()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(461,307);
    glVertex2d(463,304);
    glVertex2d(468,303);
    glVertex2d(494,303);
    glVertex2d(492,307);
    glVertex2d(470,307);
    glVertex2d(470,319);
    glVertex2d(464,323);
    glVertex2d(461,318);



    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(494,303);
    glVertex2d(499,304);
    glVertex2d(501,307);
    glVertex2d(501,320);
    glVertex2d(492,320);
    glVertex2d(492,307);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(461,318);
    glVertex2d(464,323);
    glVertex2d(492,341);
    glVertex2d(501,342);

    glVertex2d(498,338);
    glVertex2d(470,319);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(501,342);
    glVertex2d(501,355);
    glVertex2d(499,358);
    glVertex2d(494,359);

    glVertex2d(492,355);
    glVertex2d(492,341);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(494,359);
    glVertex2d(468,359);
    glVertex2d(463,358);
    glVertex2d(461,355);

    glVertex2d(470,355);
    glVertex2d(492,355);

    glEnd();

      glBegin(GL_POLYGON);
      glColor3ub(255,255,255);
    glVertex2d(461,355);
    glVertex2d(461,341);
    glVertex2d(470,341);
    glVertex2d(470,355);

    glEnd();
}

void A2()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(513,359);
    glVertex2d(531,303);
    glVertex2d(540,303);
    glVertex2d(558,359);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(521,359);
    glVertex2d(525,347);
    glVertex2d(545,347);
    glVertex2d(549,359);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(526,342);
    glVertex2d(535,312);
    glVertex2d(544,342);

    glEnd();

}

void M2()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(281,427);
    glVertex2d(281,377);
    glVertex2d(286,377);
    glVertex2d(286,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(286,377);
    glVertex2d(297,411);
    glVertex2d(297,422);
    glVertex2d(286,395);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(297,411);
    glVertex2d(307,377);
    glVertex2d(307,395);
    glVertex2d(297,422);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(307,377);
    glVertex2d(312,377);
    glVertex2d(312,427);
    glVertex2d(307,427);

    glEnd();

}


void U()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(322,377);
    glVertex2d(322,423);
    glVertex2d(323,426);
    glVertex2d(326,427);

    glVertex2d(327,423);
    glVertex2d(327,377);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(327,423);
    glVertex2d(342,423);
    glVertex2d(343,427);
    glVertex2d(326,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(342,423);
    glVertex2d(342,377);
    glVertex2d(348,377);
    glVertex2d(348,423);


    glVertex2d(346,426);
    glVertex2d(343,427);

    glEnd();

}

void H()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(358,427);
    glVertex2d(358,377);
    glVertex2d(363,377);
    glVertex2d(363,427);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(363,399);
    glVertex2d(378,399);
    glVertex2d(378,403);
    glVertex2d(363,403);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(378,377);
    glVertex2d(384,377);
    glVertex2d(384,427);
    glVertex2d(378,427);

    glEnd();

}

void A3()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(391,427);
    glVertex2d(402,377);
    glVertex2d(408,377);
    glVertex2d(419,427);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(396,427);
    glVertex2d(398,416);
    glVertex2d(411,416);
    glVertex2d(413,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(399,412);
    glVertex2d(405,385);
    glVertex2d(410,412);

    glEnd();

}

void M3()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(426,427);
    glVertex2d(426,377);
    glVertex2d(431,377);
    glVertex2d(431,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(431,377);
    glVertex2d(441,411);
    glVertex2d(442,422);
    glVertex2d(431,395);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(441,411);
    glVertex2d(452,377);
    glVertex2d(452,395);
    glVertex2d(442,422);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(452,377);
    glVertex2d(457,377);
    glVertex2d(457,427);
    glVertex2d(452,427);

    glEnd();

}

void A4()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(464,427);
    glVertex2d(475,377);
    glVertex2d(481,377);
    glVertex2d(492,427);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(469,427);
    glVertex2d(472,416);
    glVertex2d(484,416);
    glVertex2d(486,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(472,412);
    glVertex2d(478,385);
    glVertex2d(483,412);

    glEnd();

}
void D()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(499,427);
    glVertex2d(499,377);
    glVertex2d(513,377);
    glVertex2d(522,380);
     glVertex2d(525,386);
    glVertex2d(525,418);
    glVertex2d(522,424);
    glVertex2d(513,427);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(505,423);
    glVertex2d(505,381);
    glVertex2d(512,381);
    glVertex2d(517,383);

    glVertex2d(519,387);
    glVertex2d(519,417);
    glVertex2d(517,421);
    glVertex2d(512,423);

    glEnd();

}
void A5()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(532,427);
    glVertex2d(543,377);
    glVertex2d(549,377);
    glVertex2d(560,427);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(537,427);
    glVertex2d(540,416);
    glVertex2d(552,416);
    glVertex2d(554,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(540,412);
    glVertex2d(546,385);
    glVertex2d(551,412);

    glEnd();

}
void F()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(567,427);
    glVertex2d(567,377);

    glVertex2d(573,381);
    glVertex2d(573,427);


    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(567,377);
    glVertex2d(587,377);
    glVertex2d(587,381);
    glVertex2d(573,381);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(573,400);
    glVertex2d(586,400);
    glVertex2d(586,404);
    glVertex2d(573,404);

    glEnd();

}
void F2()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(595,427);
    glVertex2d(595,377);

    glVertex2d(600,381);
    glVertex2d(600,427);


    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(595,377);
    glVertex2d(615,377);
    glVertex2d(615,381);
    glVertex2d(600,381);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(600,400);
    glVertex2d(614,400);
    glVertex2d(614,404);
    glVertex2d(600,404);

    glEnd();

}
void A6()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(620,427);
    glVertex2d(631,377);
    glVertex2d(636,377);
    glVertex2d(647,427);


    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(625,427);
    glVertex2d(627,416);
    glVertex2d(640,416);
    glVertex2d(642,427);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(628,412);
    glVertex2d(634,385);
    glVertex2d(639,412);

    glEnd();

}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Grid", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();

        //panggil fungsi m
        BG();
        kotak();
        M();
        A();
        R();
        //S();
        A2();
        M2();
        U();
        H();
        S();
        A3();
        M3();
        A4();
        D();
        A5();
        F();
        F2();
        A6();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
