#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

    int clindex=0,buff=0;
    int colorf[2][3]={{255,255,255},{126,1,0}};
    int color[2][3]={{126,1,0},{255,255,255}};
    int hideung[2][3]={{126,1,0},{0,0,0}};
    int bodas[2][3]={{126,1,0},{255,255,255}};
    int krem[2][3]={{126,1,0},{255,187,128}};
    int beureum[2][3]={{126,1,0},{255,0,0}};
    int abu[2][3]={{126,1,0},{187,187,187}};




void LengkungU(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0;i<101;i++)
        {
            py = sin(i*cons)*radius1+posX;
            px = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            py = sin(i*cons)*radius2+posX;
            px = cos(i*cons)*radius2+posY;

            glVertex2d(px,py);
        }
    glEnd();
}

void segienamHorizontal(double x1, double x2, double x3, double x4, double y1, double y2, double y3)
{
    glBegin(GL_POLYGON);
        glVertex2d(x1,y2);
        glVertex2d(x2,y1);
        glVertex2d(x3,y1);
        glVertex2d(x4,y2);
        glVertex2d(x3,y3);
        glVertex2d(x2,y3);
    glEnd();
}

void segienamVertikal(double x1, double x2, double x3, double y1, double y2, double y3, double y4)
{
    glBegin(GL_POLYGON);
        glVertex2d(x1,y2);
        glVertex2d(x2,y1);
        glVertex2d(x3,y2);
        glVertex2d(x3,y3);
        glVertex2d(x2,y4);
        glVertex2d(x1,y3);
    glEnd();
}

void botak(double x1, double y1, double x2, double y2)
{
    glBegin(GL_POLYGON);
    glVertex2d(x1,y1);
    glVertex2d(x1,y2);
    glVertex2d(x2,y2);
    glVertex2d(x2,y1);
    glEnd();
}

void Background ()
{
        glBegin(GL_POLYGON);
        glColor3ub(126,1,0);
        glVertex2d(0,0);
        glVertex2d(800,0);
        glVertex2d(800,800);
        glVertex2d(0,800);
        glEnd();
}

void kotak_luar()
{
    // your drawing code here, maybe
    glBegin(GL_POLYGON);
    glColor3f(1,1,1);
    glVertex2d(116,531);
    glVertex2d(684,531);
    glVertex2d(684,268);
    glVertex2d(116,268);
    glEnd();
}

void kotak_dalam()
{
    //dalam kotak
    glBegin(GL_POLYGON);
    glColor3ub(126,1,0);
    glVertex2d(127,521);
    glVertex2d(672,521);
    glVertex2d(672,279);
    glVertex2d(127,279);
    glEnd();
}

void A ()
{
    glBegin(GL_POLYGON);
    glColor3f(1,1,1);
    glVertex2d(183,457);
    glVertex2d(199,457);
    glVertex2d(211,420);
    glVertex2d(252,420);
    glVertex2d(264,457);
    glVertex2d(281,457);
    glVertex2d(241,340);
    glVertex2d(223,340);
    glEnd();

    glBegin(GL_POLYGON); //A_atas
    glColor3ub(126,1,0);
    glVertex2d(214,408);
    glVertex2d(249,408);
    glVertex2d(231,354);
    glEnd();

    glBegin(GL_POLYGON); //A_bawah
    glColor3ub(126,1,0);
    glVertex2d(199,457);
    glVertex2d(211,420);
    glVertex2d(252,420);
    glVertex2d(264,457);
    glEnd();
}

void U ()
{
    glColor3f(1,1,1);
    LengkungU(420,335,43);
    glColor3ub(126,1,0);
    LengkungU(420,335,27);

    glBegin(GL_POLYGON); //left
    glColor3f(1,1,1);
    glVertex2d(292,340);
    glVertex2d(292,424);
    glVertex2d(308,424);
    glVertex2d(308,340);
    glEnd();

    glBegin(GL_POLYGON); //right
    glColor3f(1,1,1);
    glVertex2d(363,340);
    glVertex2d(363,424);
    glVertex2d(378,424);
    glVertex2d(378,340);
    glEnd();
}

void L ()
{
    glBegin(GL_POLYGON);
    glColor3f(1,1,1);
    glVertex2d(405,457);
    glVertex2d(469,457);
    glVertex2d(469,444);
    glVertex2d(420,444);
    glVertex2d(420,340);
    glVertex2d(405,340);
    glEnd();
}

void I ()
{
    glBegin(GL_POLYGON);
    glColor3f(1,1,1);
    glVertex2d(486,457);
    glVertex2d(501,457);
    glVertex2d(501,340);
    glVertex2d(486,340);
    glEnd();
}

void A_2 ()
{
    glBegin(GL_POLYGON);
    glColor3f(1,1,1);
    glVertex2d(534,457);
    glVertex2d(546,420);
    glVertex2d(587,420);
    glVertex2d(600,457);
    glVertex2d(616,457);
    glVertex2d(576,340);
    glVertex2d(558,340);
    glVertex2d(518,457);
    glEnd();

    glBegin(GL_POLYGON); //A_2_atas
    glColor3ub(126,1,0);
    glVertex2d(549,408);
    glVertex2d(584,408);
    glVertex2d(566,354);
    glEnd();

    glBegin(GL_POLYGON); //A_2_bawah
    glColor3ub(126,1,0);
    glVertex2d(534,457);
    glVertex2d(546,420);
    glVertex2d(587,420);
    glVertex2d(600,457);
    glEnd();
}


void t ()
{
    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(223,646);
    glVertex2d(225,644);
    glVertex2d(225,629);
    glVertex2d(223,627);
    glVertex2d(221,629);
    glVertex2d(221,644);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(223,625);
    glVertex2d(225,623);
    glVertex2d(225,608);
    glVertex2d(223,606);
    glVertex2d(221,608);
    glVertex2d(221,623);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(210,605);
    glVertex2d(212,607);
    glVertex2d(221,607);
    glVertex2d(223,605);
    glVertex2d(221,603);
    glVertex2d(212,603);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(224,605);
    glVertex2d(226,607);
    glVertex2d(235,607);
    glVertex2d(237,605);
    glVertex2d(235,603);
    glVertex2d(226,603);
    glEnd();
}

void i ()
{
    glBegin(GL_POLYGON);
   glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(262,646);
    glVertex2d(264,644);
    glVertex2d(264,629);
    glVertex2d(262,627);
    glVertex2d(260,629);
    glVertex2d(260,644);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(262,625);
    glVertex2d(264,623);
    glVertex2d(264,608);
    glVertex2d(262,606);
    glVertex2d(260,608);
    glVertex2d(260,623);
    glEnd();
}

void c ()
{
    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(286,646);
    glVertex2d(288,644);
    glVertex2d(288,629);
    glVertex2d(286,627);
    glVertex2d(284,629);
    glVertex2d(284,644);
    glEnd();

    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    segienamVertikal(284,286,288,606,608,623,625);
    segienamHorizontal(286,288,297,299,603,605,607);
    segienamHorizontal(286,288,297,299,645,647,649);
    segienamHorizontal(301,303,312,314,603,605,607);
    segienamHorizontal(301,303,312,314,645,647,649);
}

void k ()
{
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    segienamVertikal(322,324,326,606,608,623,625);
    segienamVertikal(322,324,326,627,629,644,646);
    segienamHorizontal(325,327,336,338,624,626,628);

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(341,623);
    glVertex2d(343,623);
    glVertex2d(350,613);
    glVertex2d(350,608);
    glVertex2d(349,608);
    glVertex2d(341,619);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%2][0],color[clindex%2][1],color[clindex%2][2]);
    glVertex2d(341,629);
    glVertex2d(343,629);
    glVertex2d(350,639);
    glVertex2d(350,644);
    glVertex2d(349,644);
    glVertex2d(341,633);
    glEnd();
}

void t_2 ()
{
    glColor3ub(colorf[clindex%2][0],colorf[clindex%2][1],colorf[clindex%2][2]);
    segienamHorizontal(448,450,459,461,603,605,607);
    segienamHorizontal(462,464,473,475,603,605,607);
    segienamVertikal(459,461,463,606,608,623,625);
    segienamVertikal(459,461,463,627,629,644,646);
}

void o ()
{
    segienamHorizontal(486,488,497,499,603,605,607);
    segienamHorizontal(500,503,511,514,603,605,607);
    segienamHorizontal(486,488,497,499,645,647,649);
    segienamHorizontal(500,503,511,514,645,647,649);
    segienamVertikal(483,485,487,606,608,623,625);
    segienamVertikal(512,514,516,606,608,623,625);
    segienamVertikal(483,485,487,627,629,644,646);
    segienamVertikal(512,514,516,627,629,644,646);
}

void c_2 ()
{
    segienamVertikal(522,524,526,606,608,623,625);
    segienamVertikal(522,524,526,627,629,644,646);
    segienamHorizontal(524,526,535,537,603,605,607);
    segienamHorizontal(539,541,550,552,603,605,607);
    segienamHorizontal(524,526,535,537,645,647,649);
    segienamHorizontal(539,541,550,552,645,647,649);
}


void k_2 ()
{
    segienamVertikal(560,562,564,606,608,623,625);
    segienamVertikal(560,562,564,627,629,644,646);
    segienamHorizontal(563,565,574,576,624,626,628);

    glBegin(GL_POLYGON);
    glColor3ub(colorf[clindex%2][0],colorf[clindex%2][1],colorf[clindex%2][2]);
    glVertex2d(579,623);
    glVertex2d(581,623);
    glVertex2d(588,613);
    glVertex2d(588,608);
    glVertex2d(587,608);
    glVertex2d(579,619);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colorf[clindex%2][0],colorf[clindex%2][1],colorf[clindex%2][2]);
    glVertex2d(579,629);
    glVertex2d(581,629);
    glVertex2d(588,639);
    glVertex2d(588,644);
    glVertex2d(587,644);
    glVertex2d(579,633);
    glEnd();
}

void botak_keren()
{
    glColor3ub(hideung[clindex%2][0],hideung[clindex%2][1],hideung[clindex%2][2]);
    botak(391,124,418,121);
    botak(386,129,389,125);
    botak(419,129,422,125);
    botak(381,138,385,130);
    botak(424,134,428,130);
    botak(424,148,428,144);
    botak(428,157,432,135);
    botak(427,181,451,158);
    botak(447,158,451,154);
    botak(452,181,460,177);
    botak(461,176,465,168);
    botak(466,166,479,163);
    botak(480,162,484,158);
    botak(480,157,498,151);
    botak(452,152,479,149);
    botak(419,181,427,168);
    botak(424,167,427,163);
    botak(419,171,423,168);
    botak(414,195,427,181);
    botak(427,195,436,192);
    botak(409,200,441,195);
    botak(381,215,446,200);
    botak(424,228,452,214);
    botak(433,233,451,228);
    botak(381,233,403,214);
    botak(385,252,409,228);
    botak(391,256,404,252);
    botak(381,200,394,196);
    botak(381,196,399,177);
    botak(395,176,419,173);
    botak(390,172,394,169);
    botak(385,167,389,163);
    botak(381,162,384,154);
    botak(376,152,380,140);
    botak(353,181,381,158);
    botak(380,185,384,154);
    botak(376,185,394,168);
    botak(343,181,353,177);
    botak(353,158,356,154);
    botak(339,176,342,168);
    botak(325,166,337,163);
    botak(325,152,352,149);
    botak(320,162,323,151);
    botak(305,157,324,151);
    botak(400,167,417,163);
    botak(419,157,422,149);
    botak(405,157,413,148);
    botak(400,149,408,144);
    botak(424,167,436,162);
    botak(419,172,429,167);
    botak(428,181,460,177);
    botak(362,169,389,163);
    botak(392,184,399,173);
    botak(428,162,432,153);

    glColor3ub(bodas[clindex%2][0],bodas[clindex%2][1],bodas[clindex%2][2]);
    botak(399,157,405,148);
    botak(423,157,427,149);
    botak(395,200,399,196);
    botak(404,200,408,196);
    botak(400,195,404,176);
    botak(409,195,413,176);
    botak(413,181,419,176);

    glColor3ub(beureum[clindex%2][0],beureum[clindex%2][1],beureum[clindex%2][2]);
    botak(404,195,409,177);
    botak(400,200,404,196);

    glColor3ub(abu[clindex%2][0],abu[clindex%2][1],abu[clindex%2][2]);
    botak(324,163,353,152);
    botak(451,163,479,152);
    botak(404,157,404,149);
    botak(423,157,423,149);

    glColor3ub(krem[clindex%2][0],krem[clindex%2][1],krem[clindex%2][2]);
    botak(389,129,419,124);
    botak(384,138,423,129);
    botak(423,144,428,134);
    botak(408,148,423,143);
    botak(381,144,427,138);
    botak(380,153,399,139);
    botak(385,162,399,153);
    botak(413,157,419,148);
    botak(385,162,427,157);
    botak(417,166,423,162);
    botak(389,167,399,162);
    botak(395,172,418,166);
    botak(451,178,460,163);
    botak(460,167,465,163);
    botak(343,176,353,163);
    botak(338,167,343,163);

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Aulia", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        if(buff == 0) {
            clindex++;
        }
        buff++;
        buff = buff%1000;

        setup_viewport(window);


        Background();
        kotak_luar();
        kotak_dalam();
        A();
        U();
        L();
        I();
        A_2();



        t();
        i();
        c();
        k();

        t_2();
        o();
        c_2();
        k_2();

        botak_keren();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
