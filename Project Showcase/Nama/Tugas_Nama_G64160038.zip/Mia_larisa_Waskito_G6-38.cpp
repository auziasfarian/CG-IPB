#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define pink 248, 222, 189
#define ungu 159, 97, 100
#define oren 255, 174, 93
#define ping 255, 113, 130

float DETIK = 0.0;
float DETIK2 = 0.0;

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void mia(){
    glClear(GL_COLOR_BUFFER_BIT);

    // Background
    glColor3ub(pink);
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(0, 1000);
    glVertex2d(1200, 1000);
    glVertex2d(1200, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ungu);
    glVertex2f(195.6,518.14);
    glVertex2f(195.6,244.71);
    glVertex2f(226.3,245.68);
    glVertex2f(279.13,342.56);
    glVertex2f(332.9,244.71);
    glVertex2f(363.04,244.71);
    glVertex2f(363.04,518.14);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2f(325.83,518.14);
    glVertex2f(325.83,336.11);
    glVertex2f(279.51,420.49);
    glVertex2f(232.81,336.11);
    glVertex2f(232.81,518.14);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(ungu);
    glVertex2f(567.68,518.14);
    glVertex2f(567.68,342.36);
    glVertex2f(604.88,342.36);
    glVertex2f(604.88,518.14);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(ungu);
    glVertex2f(381.64,283.77);
    glVertex2f(381.64,244.71);
    glVertex2f(418.85,244.71);
    glVertex2f(418.85,283.77);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(ungu);
    glVertex2f(381.64,518.14);
    glVertex2f(381.64,342.36);
    glVertex2f(418.85,342.36);
    glVertex2f(418.85,518.14);
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(ungu);
        float x=i*3.14159/180;
        glVertex2f(521+cos(x)*83.55,430+sin(x)*83.55);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(pink);
        float x=i*3.14159/180;
        glVertex2f(521+cos(x)*46.34,430+sin(x)*46.34);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(1255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(59+cos(x)*30,740.5+sin(x)*30);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(89.5+cos(x)*32.5,580+sin(x)*32.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(178.5+cos(x)*34.5,693.5+sin(x)*34.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(320.5+cos(x)*35.5,602.5+sin(x)*35.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(360+cos(x)*28,718+sin(x)*28);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(523.5+cos(x)*30.5,706.5+sin(x)*30.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(662+cos(x)*24.5,626+sin(x)*24.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(723.5+cos(x)*32.5,740.5+sin(x)*32.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(771.5+cos(x)*20,585.5+sin(x)*20);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(59+cos(x)*26,54.5+sin(x)*26);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(166.5+cos(x)*33,119.5+sin(x)*33);}
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(295+cos(x)*24.5,69+sin(x)*24.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(295+cos(x)*34,69+sin(x)*34);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(391+cos(x)*25,153+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(474.5+cos(x)*30,93.5+sin(x)*30);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(586+cos(x)*27,192+sin(x)*28);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(59+cos(x)*30,740.5+sin(x)*30);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(692.5+cos(x)*31.5,156+sin(x)*31.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255, 174, 38+255*DETIK);
        float x=i*3.14159/180;
        glVertex2f(648.5+cos(x)*33.5,54.5+sin(x)*33.5);
    }
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(ping);
    glVertex2f(151.5,552.5);
    glVertex2f(151.5,244.5);
    glVertex2f(166.5,244.5);
    glVertex2f(166.5,552.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ping);
    glVertex2f(166.5,552.5);
    glVertex2f(166.5,538.5);
    glVertex2f(648.5,538.5);
    glVertex2f(648.5,552.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ping);
    glVertex2f(648.5,552.5);
    glVertex2f(648.5,244.5);
    glVertex2f(661.5,244.5);
    glVertex2f(661.5,552.5);
    glEnd();

    //glLineWidth(5);
    //glColor3ub(100+255*DETIK, 31+255*DETIK, 38+255*DETIK);
    //glBegin(GL_LINE_LOOP);
    //glVertex2f(648.5,552.5);
    //glVertex2f(648.5,244.5);
    //glVertex2f(661.5,244.5);
    //glVertex2f(661.5,552.5);
    //glEnd();

    //glLineWidth(5);
    //glColor3ub(100+255*DETIK, 31+255*DETIK, 38+255*DETIK);
    //glBegin(GL_LINE_LOOP);
    //glVertex2f(166.5,552.5);
    //glVertex2f(166.5,538.5);
    //glVertex2f(648.5,538.5);
    //glVertex2f(648.5,552.5);
    //glEnd();

    //glLineWidth(5);
    //glColor3ub(100+255*DETIK, 31+255*DETIK, 38+255*DETIK);
    //glBegin(GL_LINE_LOOP);
    //glVertex2f(151.5,552.5);
    //glVertex2f(151.5,244.5);
    //glVertex2f(166.5,244.5);
    //glVertex2f(166.5,552.5);
    //glEnd();

    //glLineWidth(5);
    //glColor3ub(100+255*DETIK, 31+255*DETIK, 38+255*DETIK);
    //glBegin(GL_LINE_LOOP);
    //glVertex2f(151.5,552.5);
    //glVertex2f(151.5,244.5);
    //glVertex2f(166.5,244.5);
    //glVertex2f(166.5,552.5);
    //glEnd();

}
int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "Mia G64160038", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width*10 / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
        DETIK = glfwGetTime();
        DETIK2 = sin(DETIK);
mia();

glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
