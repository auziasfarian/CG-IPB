#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void A()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(33.64,406.73);
    glVertex2d(80.58,263.53);
    glVertex2d(104.18,263.53);
    glVertex2d(58.82,406.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(80.58,263.53);
    glVertex2d(104.18,263.53);
    glVertex2d(157.16,407.73);
    glVertex2d(129.83,407.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(119.63,375.79);
    glVertex2d(68.54,375.79);
    glVertex2d(74.64,353.2);
    glVertex2d(113.22,353.2);
    glEnd();
}

void B(){
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(175.45,406.61);
    glVertex2d(175.45,263.53);
    glVertex2d(203.2,263.53);
    glVertex2d(203.2,406.61);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(175.45,406.61);
    glVertex2d(175.45,380.52);
    glVertex2d(247.83,380.52);
    glVertex2d(247.83,406.61);
    glEnd();
}

void C()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(266.48,406.61);
    glVertex2d(266.48,263.53);
    glVertex2d(294.24,263.53);
    glVertex2d(294.24,406.61);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(266.48,263.53);
    glVertex2d(342.54,263.53);
    glVertex2d(342.54,288.09);
    glVertex2d(266.48,288.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(266.48,327.02);
    glVertex2d(342.54,327.02);
    glVertex2d(342.54,350.62);
    glVertex2d(266.48,350.62);
    glEnd();
}

void D()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(365.3,406.61);
    glVertex2d(365.3,263.53);
    glVertex2d(393.5,263.53);
    glVertex2d(393.5,406.61);
    glEnd();
}
void E()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(449.92,406.06);
    glVertex2d(449.92,327.02);
    glVertex2d(477.67,327.02);
    glVertex2d(477.67,406.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(410.76,263.53);
    glVertex2d(440.56,263.53);
    glVertex2d(477.67,353.87);
    glVertex2d(449.92,353.87);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(487.77,263.53);
    glVertex2d(517.41,263.53);
    glVertex2d(477.67,353.87);
    glVertex2d(449.92,353.87);
    glEnd();
}
void F()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(504.64,406.73);
    glVertex2d(551.73,263.53);
    glVertex2d(580,263.53);
    glVertex2d(533.08,406.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(599.93,406.73);
    glVertex2d(551.73,263.53);
    glVertex2d(580,263.53);
    glVertex2d(629.15,406.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(539.7,375.79);
    glVertex2d(593.78,375.79);
    glVertex2d(584.37,353.2);
    glVertex2d(545.79,353.2);
    glEnd();
}
void G()
{
    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(646.6,406.73);
    glVertex2d(646.6,263.53);
    glVertex2d(671.52,263.53);
    glVertex2d(671.52,406.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(733.58,406.73);
    glVertex2d(733.58,263.53);
    glVertex2d(758.77,263.53);
    glVertex2d(758.77,406.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,41,71);
    glVertex2d(671.52,263.53);
    glVertex2d(646.6,263.53);
    glVertex2d(733.58,406.73);
    glVertex2d(758.77,406.73);
    glEnd();
}

void H()
{
    glBegin(GL_POLYGON);
    glColor3ub(63,107,216);
    glVertex2d(0,0);
    glVertex2d(400,0);
    glVertex2d(400,800);
    glVertex2d(0,800);
    glEnd();
}

void I()
{
    glBegin(GL_POLYGON);
    glColor3ub(208,216,63);
    glVertex2d(400,0);
    glVertex2d(800,0);
    glColor3ub(159,182,191);
    glVertex2d(800,800);
    glColor3ub(159,182,191);
    glVertex2d(400,800);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Dwika Ayu N- <G64160116>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        H();
        I();
        A();
        B();
        C();
        D();
        E();
        F();
        G();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
