#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
using namespace std;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

vector<vector<int> > va;
void pva(int a, int b, int c) {
    vector<int> tmp;
    tmp.push_back(a);
    tmp.push_back(b);
    tmp.push_back(c);
    va.push_back(tmp);
}

void fc() {
    pva(128, 218, 252); pva(86, 175, 241); pva(36, 98, 197);
    pva(103, 205, 253); pva(124, 223, 255); pva(65, 150, 215);
    pva(112, 205, 246); pva(125, 219, 244); pva(59, 151, 214);
    pva(97, 200, 241); pva(87, 182, 236); pva(141, 236, 255);
    pva(136, 223, 251); pva(176, 249, 255); pva(53, 126, 195);
    pva(97, 185, 235); pva(84, 170, 243); pva(71, 149, 231);
    pva(138, 230, 255); pva(69, 149, 234); pva(50, 120, 206);
    pva(1, 67, 177); pva(38, 102, 200); pva(88, 193, 200);
    pva(116, 208, 255); pva(52, 132, 217); pva(95, 183, 247);
    pva(155, 243, 255); pva(129, 223, 255); pva(105, 211, 253);
    pva(63, 161, 234); pva(12, 69, 182); pva(66, 178, 242);
    pva(47, 131, 243); pva(70, 148, 220); pva(113, 212, 253);
    pva(157, 244, 255); pva(91, 196, 241); pva(72, 165, 234);
    pva(103, 201, 246); pva(68, 120, 196); pva(69, 155, 242);
    pva(146, 238, 253); pva(104, 209, 254); pva(59, 128, 221);
    pva(96, 179, 245); pva(144, 245, 255); pva(105, 207, 247);
    pva(139, 232, 250); pva(98, 194, 252); pva(129, 223, 251);
}

int random (int m){
        return rand()%m;
    }

void display()
{
    // your code here, maybe
    glPointSize(7.0);
    glBegin(GL_POINTS);
    for(int i=0;i<10;i++)
        glVertex2i(random(800), random(500));
    glEnd();
    glFlush();

    glBegin(GL_POLYGON);
    glColor3ub(104, 128, 162);
    glVertex2d(283, 424);
    glVertex2d(313, 468);
    glVertex2d(290, 527);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(109, 176, 221);
    glVertex2d(290, 527);
    glVertex2d(335, 406);
    glVertex2d(455, 519);
    glVertex2d(387, 561);
    glVertex2d(335, 501);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92, 100, 136);
    glVertex2d(335, 501);
    glVertex2d(294, 576);
    glVertex2d(290, 527);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92, 100, 136);
    glVertex2d(283, 424);
    glVertex2d(294, 576);
    glVertex2d(228, 520);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92, 100, 136);
    glVertex2d(228, 520);
    glVertex2d(294, 576);
    glVertex2d(141, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104, 128, 162);
    glVertex2d(294, 576);
    glVertex2d(335, 501);
    glVertex2d(400, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(143, 207, 255);
    glVertex2d(335, 406);
    glVertex2d(403, 406);
    glVertex2d(471, 507);
    glVertex2d(455, 519);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(109, 176, 219);
    glVertex2d(471, 507);
    glVertex2d(444, 467);
    glVertex2d(453, 452);
    glVertex2d(606, 576);
    glVertex2d(571, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92, 100, 136);
    glVertex2d(387, 561);
    glVertex2d(480, 501);
    glVertex2d(440, 576);
    glVertex2d(400, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(103, 129, 164);
    glVertex2d(440, 576);
    glVertex2d(480, 501);
    glVertex2d(571, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(143, 207, 255);
    glVertex2d(453, 452);
    glVertex2d(501, 422);
    glVertex2d(606, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186, 225, 254);
    glVertex2d(606, 576);
    glVertex2d(578, 535);
    glVertex2d(585, 476);
    glVertex2d(641, 576);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167, 213, 247);
    glVertex2d(578, 535);
    glVertex2d(551, 496);
    glVertex2d(585, 476);
    glEnd();
}

int c, b;
float cc = 50, o = 0.002;
void huruf_R()
{
    int ar = va.size();
    cc += o;
    c = (int)cc;

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-50)%ar][0],va[(c-50)%ar][1],va[(c-50)%ar][2]);
    glVertex2d(50, 494);
    glVertex2d(18, 479);
    glVertex2d(18, 392);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-49)%ar][0],va[(c-49)%ar][1],va[(c-49)%ar][2]);
    glVertex2d(50, 494);
    glVertex2d(59, 449);
    glVertex2d(18, 392);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-48)%ar][0],va[(c-48)%ar][1],va[(c-48)%ar][2]);
    glVertex2d(50, 494);
    glVertex2d(59, 449);
    glVertex2d(79, 479);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-47)%ar][0],va[(c-47)%ar][1],va[(c-47)%ar][2]);
    glVertex2d(79, 479);
    glVertex2d(59, 449);
    glVertex2d(79, 348);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-46)%ar][0],va[(c-46)%ar][1],va[(c-46)%ar][2]);
    glVertex2d(59, 449);
    glVertex2d(79, 348);
    glVertex2d(18, 392);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-45)%ar][0],va[(c-45)%ar][1],va[(c-45)%ar][2]);
    glVertex2d(79, 348);
    glVertex2d(59, 328);
    glVertex2d(18, 392);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-44)%ar][0],va[(c-44)%ar][1],va[(c-44)%ar][2]);
    glVertex2d(59, 328);
    glVertex2d(18, 288);
    glVertex2d(18, 392);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-43)%ar][0],va[(c-43)%ar][1],va[(c-43)%ar][2]);
    glVertex2d(79, 303);
    glVertex2d(79, 348);
    glVertex2d(18, 288);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-42)%ar][0],va[(c-42)%ar][1],va[(c-42)%ar][2]);
    glVertex2d(79, 303);
    glVertex2d(79, 288);
    glVertex2d(49, 273);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-41)%ar][0],va[(c-41)%ar][1],va[(c-41)%ar][2]);
    glVertex2d(49, 273);
    glVertex2d(79, 303);
    glVertex2d(18, 288);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-40)%ar][0],va[(c-40)%ar][1],va[(c-40)%ar][2]);
    glVertex2d(79, 348);
    glVertex2d(79, 288);
    glVertex2d(106, 336);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-39)%ar][0],va[(c-39)%ar][1],va[(c-39)%ar][2]);
    glVertex2d(79, 288);
    glVertex2d(103, 273);
    glVertex2d(93, 312);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-38)%ar][0],va[(c-38)%ar][1],va[(c-38)%ar][2]);
    glVertex2d(103, 273);
    glVertex2d(98, 291);
    glVertex2d(165, 303);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-37)%ar][0],va[(c-37)%ar][1],va[(c-37)%ar][2]);
    glVertex2d(98, 291);
    glVertex2d(165, 303);
    glVertex2d(106, 336);
    glVertex2d(93, 312);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-36)%ar][0],va[(c-36)%ar][1],va[(c-36)%ar][2]);
    glVertex2d(106, 336);
    glVertex2d(165, 303);
    glVertex2d(191, 318);
    glVertex2d(130, 348);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-35)%ar][0],va[(c-35)%ar][1],va[(c-35)%ar][2]);
    glVertex2d(130, 348);
    glVertex2d(191, 318);
    glVertex2d(131, 376);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-34)%ar][0],va[(c-34)%ar][1],va[(c-34)%ar][2]);
    glVertex2d(191, 318);
    glVertex2d(131, 376);
    glVertex2d(191, 407);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-33)%ar][0],va[(c-33)%ar][1],va[(c-33)%ar][2]);
    glVertex2d(191, 407);
    glVertex2d(106, 449);
    glVertex2d(174, 398);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-32)%ar][0],va[(c-32)%ar][1],va[(c-32)%ar][2]);
    glVertex2d(174, 398);
    glVertex2d(131, 376);
    glVertex2d(106, 449);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-31)%ar][0],va[(c-31)%ar][1],va[(c-31)%ar][2]);
    glVertex2d(105, 388);
    glVertex2d(131, 376);
    glVertex2d(106, 449);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-30)%ar][0],va[(c-30)%ar][1],va[(c-30)%ar][2]);
    glVertex2d(79, 376);
    glVertex2d(105, 388);
    glVertex2d(106, 449);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-29)%ar][0],va[(c-29)%ar][1],va[(c-29)%ar][2]);
    glVertex2d(106, 449);
    glVertex2d(79, 376);
    glVertex2d(79, 438);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-28)%ar][0],va[(c-28)%ar][1],va[(c-28)%ar][2]);
    glVertex2d(168, 418);
    glVertex2d(191, 431);
    glVertex2d(106, 449);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-27)%ar][0],va[(c-27)%ar][1],va[(c-27)%ar][2]);
    glVertex2d(106, 449);
    glVertex2d(191, 431);
    glVertex2d(130, 462);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-26)%ar][0],va[(c-26)%ar][1],va[(c-26)%ar][2]);
    glVertex2d(130, 462);
    glVertex2d(191, 431);
    glVertex2d(130, 479);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-25)%ar][0],va[(c-25)%ar][1],va[(c-25)%ar][2]);
    glVertex2d(148, 464);
    glVertex2d(191, 479);
    glVertex2d(191, 431);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-24)%ar][0],va[(c-24)%ar][1],va[(c-24)%ar][2]);
    glVertex2d(148, 464);
    glVertex2d(191, 479);
    glVertex2d(160, 494);
    glVertex2d(130, 479);
    glEnd();
}

void huruf_E()
{
    int ar = va.size();
    cc += o;
    c = (int)cc;

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-23)%ar][0],va[(c-23)%ar][1],va[(c-23)%ar][2]);
    glVertex2d(335, 369);
    glVertex2d(342, 348);
    glVertex2d(264, 379);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-22)%ar][0],va[(c-22)%ar][1],va[(c-22)%ar][2]);
    glVertex2d(325, 332);
    glVertex2d(342, 348);
    glVertex2d(264, 379);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-21)%ar][0],va[(c-21)%ar][1],va[(c-21)%ar][2]);
    glVertex2d(325, 332);
    glVertex2d(276, 340);
    glVertex2d(264, 379);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-20)%ar][0],va[(c-20)%ar][1],va[(c-20)%ar][2]);
    glVertex2d(264, 336);
    glVertex2d(276, 340);
    glVertex2d(264, 379);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-19)%ar][0],va[(c-19)%ar][1],va[(c-19)%ar][2]);
    glVertex2d(212, 330);
    glVertex2d(264, 334);
    glVertex2d(264, 379);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-18)%ar][0],va[(c-18)%ar][1],va[(c-18)%ar][2]);
    glVertex2d(212, 330);
    glVertex2d(276, 340);
    glVertex2d(260, 322);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-17)%ar][0],va[(c-17)%ar][1],va[(c-17)%ar][2]);
    glVertex2d(212, 330);
    glVertex2d(276, 277);
    glVertex2d(260, 322);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-16)%ar][0],va[(c-16)%ar][1],va[(c-16)%ar][2]);
    glVertex2d(227, 277);
    glVertex2d(276, 277);
    glVertex2d(212, 330);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-15)%ar][0],va[(c-15)%ar][1],va[(c-15)%ar][2]);
    glVertex2d(227, 277);
    glVertex2d(276, 277);
    glVertex2d(238, 242);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-14)%ar][0],va[(c-14)%ar][1],va[(c-14)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(276, 277);
    glVertex2d(238, 242);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-13)%ar][0],va[(c-13)%ar][1],va[(c-13)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(276, 238);
    glVertex2d(238, 242);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-12)%ar][0],va[(c-12)%ar][1],va[(c-12)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(276, 238);
    glVertex2d(306, 234);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-11)%ar][0],va[(c-11)%ar][1],va[(c-11)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(346, 267);
    glVertex2d(306, 234);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-10)%ar][0],va[(c-10)%ar][1],va[(c-10)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(346, 267);
    glVertex2d(361, 282);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-9)%ar][0],va[(c-9)%ar][1],va[(c-9)%ar][2]);
    glVertex2d(294, 274);
    glVertex2d(361, 282);
    glVertex2d(342, 311);
    glVertex2d(317, 296);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-8)%ar][0],va[(c-8)%ar][1],va[(c-8)%ar][2]);
    glVertex2d(352, 310);
    glVertex2d(361, 282);
    glVertex2d(342, 311);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-7)%ar][0],va[(c-7)%ar][1],va[(c-7)%ar][2]);
    glVertex2d(260, 322);
    glVertex2d(342, 311);
    glVertex2d(317, 296);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-6)%ar][0],va[(c-6)%ar][1],va[(c-6)%ar][2]);
    glVertex2d(260, 322);
    glVertex2d(267, 303);
    glVertex2d(317, 296);
    glEnd();
}

void huruf_S()
{
    int ar = va.size();
    cc += o;
    c = (int)cc;

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-5)%ar][0],va[(c-5)%ar][1],va[(c-5)%ar][2]);
    glVertex2d(442, 199);
    glVertex2d(391, 249);
    glVertex2d(425, 242);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-4)%ar][0],va[(c-4)%ar][1],va[(c-4)%ar][2]);
    glVertex2d(442, 199);
    glVertex2d(465, 242);
    glVertex2d(425, 242);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-3)%ar][0],va[(c-3)%ar][1],va[(c-3)%ar][2]);
    glVertex2d(442, 199);
    glVertex2d(465, 242);
    glVertex2d(506, 226);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-2)%ar][0],va[(c-2)%ar][1],va[(c-2)%ar][2]);
    glVertex2d(391, 249);
    glVertex2d(400, 303);
    glVertex2d(425, 242);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-1)%ar][0],va[(c-1)%ar][1],va[(c-1)%ar][2]);
    glVertex2d(425, 242);
    glVertex2d(450, 250);
    glVertex2d(400, 303);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c)%ar][0],va[(c)%ar][1],va[(c)%ar][2]);
    glVertex2d(425, 242);
    glVertex2d(450, 250);
    glVertex2d(506, 226);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-1)%ar][0],va[(c-1)%ar][1],va[(c-1)%ar][2]);
    glVertex2d(450, 250);
    glVertex2d(494, 273);
    glVertex2d(506, 226);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-2)%ar][0],va[(c-2)%ar][1],va[(c-2)%ar][2]);
    glVertex2d(494, 273);
    glVertex2d(512, 254);
    glVertex2d(506, 226);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-3)%ar][0],va[(c-3)%ar][1],va[(c-3)%ar][2]);
    glVertex2d(445, 322);
    glVertex2d(455, 284);
    glVertex2d(434, 275);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-4)%ar][0],va[(c-4)%ar][1],va[(c-4)%ar][2]);
    glVertex2d(400, 303);
    glVertex2d(438, 290);
    glVertex2d(435, 265);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-5)%ar][0],va[(c-5)%ar][1],va[(c-5)%ar][2]);
    glVertex2d(400, 303);
    glVertex2d(445, 322);
    glVertex2d(438, 290);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-6)%ar][0],va[(c-6)%ar][1],va[(c-6)%ar][2]);
    glVertex2d(445, 322);
    glVertex2d(455, 284);
    glVertex2d(464, 309);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-7)%ar][0],va[(c-7)%ar][1],va[(c-7)%ar][2]);
    glVertex2d(464, 309);
    glVertex2d(455, 284);
    glVertex2d(474, 273);
    glVertex2d(480, 316);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-8)%ar][0],va[(c-8)%ar][1],va[(c-8)%ar][2]);
    glVertex2d(480, 325);
    glVertex2d(498, 309);
    glVertex2d(474, 273);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-9)%ar][0],va[(c-9)%ar][1],va[(c-9)%ar][2]);
    glVertex2d(474, 273);
    glVertex2d(518, 292);
    glVertex2d(498, 309);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-10)%ar][0],va[(c-10)%ar][1],va[(c-10)%ar][2]);
    glVertex2d(518, 292);
    glVertex2d(529, 340);
    glVertex2d(498, 309);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-11)%ar][0],va[(c-11)%ar][1],va[(c-11)%ar][2]);
    glVertex2d(498, 309);
    glVertex2d(529, 340);
    glVertex2d(494, 376);
    glVertex2d(480, 325);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-12)%ar][0],va[(c-12)%ar][1],va[(c-12)%ar][2]);
    glVertex2d(480, 325);
    glVertex2d(488, 352);
    glVertex2d(465, 340);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-13)%ar][0],va[(c-13)%ar][1],va[(c-13)%ar][2]);
    glVertex2d(494, 376);
    glVertex2d(474, 391);
    glVertex2d(488, 352);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-14)%ar][0],va[(c-14)%ar][1],va[(c-14)%ar][2]);
    glVertex2d(474, 391);
    glVertex2d(488, 352);
    glVertex2d(471, 354);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-15)%ar][0],va[(c-15)%ar][1],va[(c-15)%ar][2]);
    glVertex2d(474, 391);
    glVertex2d(455, 384);
    glVertex2d(464, 355);
    glVertex2d(471, 354);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-16)%ar][0],va[(c-16)%ar][1],va[(c-16)%ar][2]);
    glVertex2d(455, 384);
    glVertex2d(464, 355);
    glVertex2d(455, 357);
    glVertex2d(434, 376);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-17)%ar][0],va[(c-17)%ar][1],va[(c-17)%ar][2]);
    glVertex2d(455, 357);
    glVertex2d(434, 376);
    glVertex2d(410, 364);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-18)%ar][0],va[(c-18)%ar][1],va[(c-18)%ar][2]);
    glVertex2d(410, 364);
    glVertex2d(488, 352);
    glVertex2d(465, 340);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-19)%ar][0],va[(c-19)%ar][1],va[(c-19)%ar][2]);
    glVertex2d(465, 340);
    glVertex2d(410, 364);
    glVertex2d(403, 336);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-20)%ar][0],va[(c-20)%ar][1],va[(c-20)%ar][2]);
    glVertex2d(465, 340);
    glVertex2d(403, 336);
    glVertex2d(426, 322);
    glEnd();
}

void huruf_T()
{
    int ar = va.size();
    cc += o;
    c = (int)cc;

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-21)%ar][0],va[(c-21)%ar][1],va[(c-21)%ar][2]);
    glVertex2d(563, 260);
    glVertex2d(559, 282);
    glVertex2d(596, 316);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-21)%ar][0],va[(c-21)%ar][1],va[(c-21)%ar][2]);
    glVertex2d(596, 316);
    glVertex2d(602, 288);
    glVertex2d(563, 260);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-22)%ar][0],va[(c-22)%ar][1],va[(c-22)%ar][2]);
    glVertex2d(591, 282);
    glVertex2d(584, 249);
    glVertex2d(563, 260);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-23)%ar][0],va[(c-23)%ar][1],va[(c-23)%ar][2]);
    glVertex2d(591, 282);
    glVertex2d(601, 291);
    glVertex2d(606, 265);
    glVertex2d(584, 249);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-24)%ar][0],va[(c-24)%ar][1],va[(c-24)%ar][2]);
    glVertex2d(683, 282);
    glVertex2d(668, 265);
    glVertex2d(678, 303);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-25)%ar][0],va[(c-25)%ar][1],va[(c-25)%ar][2]);
    glVertex2d(668, 265);
    glVertex2d(678, 303);
    glVertex2d(645, 273);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-26)%ar][0],va[(c-26)%ar][1],va[(c-26)%ar][2]);
    glVertex2d(678, 303);
    glVertex2d(645, 273);
    glVertex2d(638, 311);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-27)%ar][0],va[(c-27)%ar][1],va[(c-27)%ar][2]);
    glVertex2d(638, 311);
    glVertex2d(678, 303);
    glVertex2d(636, 322);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-28)%ar][0],va[(c-28)%ar][1],va[(c-28)%ar][2]);
    glVertex2d(645, 273);
    glVertex2d(636, 322);
    glVertex2d(606, 298);
    glVertex2d(627, 260);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-29)%ar][0],va[(c-29)%ar][1],va[(c-29)%ar][2]);
    glVertex2d(636, 322);
    glVertex2d(616, 322);
    glVertex2d(596, 316);
    glVertex2d(606, 298);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-30)%ar][0],va[(c-30)%ar][1],va[(c-30)%ar][2]);
    glVertex2d(596, 316);
    glVertex2d(606, 265);
    glVertex2d(627, 260);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-31)%ar][0],va[(c-31)%ar][1],va[(c-31)%ar][2]);
    glVertex2d(636, 322);
    glVertex2d(627, 373);
    glVertex2d(616, 322);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-32)%ar][0],va[(c-32)%ar][1],va[(c-32)%ar][2]);
    glVertex2d(615, 424);
    glVertex2d(595, 431);
    glVertex2d(576, 418);
    glVertex2d(616, 384);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-33)%ar][0],va[(c-33)%ar][1],va[(c-33)%ar][2]);
    glVertex2d(616, 384);
    glVertex2d(616, 322);
    glVertex2d(576, 418);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-34)%ar][0],va[(c-34)%ar][1],va[(c-34)%ar][2]);
    glVertex2d(627, 373);
    glVertex2d(616, 319);
    glVertex2d(615, 424);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(va[(c-35)%ar][0],va[(c-35)%ar][1],va[(c-35)%ar][2]);
    glVertex2d(576, 418);
    glVertex2d(596, 316);
    glVertex2d(616, 322);
    glEnd();
}

void huruf_U()
{
    int ar = va.size();
    cc += o;
    c = (int)cc;

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-36)%ar][0],va[(c-36)%ar][1],va[(c-36)%ar][2]);
    glVertex2d(661, 501);
    glVertex2d(663, 484);
    glVertex2d(716, 531);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-37)%ar][0],va[(c-37)%ar][1],va[(c-37)%ar][2]);
    glVertex2d(663, 484);
    glVertex2d(700, 488);
    glVertex2d(716, 531);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-38)%ar][0],va[(c-38)%ar][1],va[(c-38)%ar][2]);
    glVertex2d(663, 484);
    glVertex2d(683, 447);
    glVertex2d(700, 488);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-39)%ar][0],va[(c-39)%ar][1],va[(c-39)%ar][2]);
    glVertex2d(663, 484);
    glVertex2d(683, 447);
    glVertex2d(668, 401);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-40)%ar][0],va[(c-40)%ar][1],va[(c-40)%ar][2]);
    glVertex2d(705, 405);
    glVertex2d(683, 447);
    glVertex2d(668, 401);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-41)%ar][0],va[(c-41)%ar][1],va[(c-41)%ar][2]);
    glVertex2d(705, 405);
    glVertex2d(688, 390);
    glVertex2d(668, 401);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-42)%ar][0],va[(c-42)%ar][1],va[(c-42)%ar][2]);
    glVertex2d(705, 405);
    glVertex2d(683, 447);
    glVertex2d(700, 488);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-43)%ar][0],va[(c-43)%ar][1],va[(c-43)%ar][2]);
    glVertex2d(700, 488);
    glVertex2d(715, 496);
    glVertex2d(716, 531);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-44)%ar][0],va[(c-44)%ar][1],va[(c-44)%ar][2]);
    glVertex2d(715, 496);
    glVertex2d(716, 531);
    glVertex2d(734, 484);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-45)%ar][0],va[(c-45)%ar][1],va[(c-45)%ar][2]);
    glVertex2d(716, 531);
    glVertex2d(732, 522);
    glVertex2d(734, 484);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-46)%ar][0],va[(c-46)%ar][1],va[(c-46)%ar][2]);
    glVertex2d(732, 522);
    glVertex2d(749, 535);
    glVertex2d(734, 484);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-47)%ar][0],va[(c-47)%ar][1],va[(c-47)%ar][2]);
    glVertex2d(749, 535);
    glVertex2d(734, 484);
    glVertex2d(769, 507);
    glVertex2d(768, 524);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-48)%ar][0],va[(c-48)%ar][1],va[(c-48)%ar][2]);
    glVertex2d(734, 484);
    glVertex2d(752, 450);
    glVertex2d(771, 497);
    glVertex2d(769, 507);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-49)%ar][0],va[(c-49)%ar][1],va[(c-49)%ar][2]);
    glVertex2d(734, 484);
    glVertex2d(752, 450);
    glVertex2d(737, 405);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-50)%ar][0],va[(c-50)%ar][1],va[(c-50)%ar][2]);
    glVertex2d(752, 450);
    glVertex2d(771, 497);
    glVertex2d(775, 409);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-49)%ar][0],va[(c-49)%ar][1],va[(c-49)%ar][2]);
    glVertex2d(737, 405);
    glVertex2d(752, 450);
    glVertex2d(760, 437);
    glVertex2d(758, 396);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(va[(c-48)%ar][0],va[(c-48)%ar][1],va[(c-48)%ar][2]);
    glVertex2d(758, 396);
    glVertex2d(760, 437);
    glVertex2d(775, 409);
    glEnd();
}

int main(void)
{
    fc();
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160056", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        huruf_R();
        huruf_E();
        huruf_S();
        huruf_T();
        huruf_U();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
