#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
using namespace std;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-400, 400, 400, -400, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

vector<vector<int> > va;
vector<vector<int> > vb;
vector<vector<int> > vc;
void pva(int a, int b, int c) {
    vector<int> tmp;
    tmp.push_back(a);
    tmp.push_back(b);
    tmp.push_back(c);
    va.push_back(tmp);
}

void pvb(int a, int b, int c) {
    vector<int> tmp;
    tmp.push_back(a);
    tmp.push_back(b);
    tmp.push_back(c);
    vb.push_back(tmp);
}

void pvc(int a, int b, int c) {
    vector<int> tmp;
    tmp.push_back(a);
    tmp.push_back(b);
    tmp.push_back(c);
    vc.push_back(tmp);
}

void fc() {
    pva(239,83,80); pvb(182,24,39); pvc(255,235,238); //red
    pva(236,64,122); pvb(180,0,78); pvc(252,228,236); //pink
    pva(171,71,188); pvb(121,14,139); pvc(243,229,245); //purple
    pva(126,87,194); pvb(77,44,145); pvc(237,231,246); //deep purple
    pva(92,107,192); pvb(38,65,143); pvc(232,234,246); //indigo
    pva(66,165,245); pvb(0,119,194); pvc(227,242,253); //blue
    pva(41,182,246); pvb(0,134,195); pvc(225,245,254); //light blue
    pva(38,198,218); pvb(0,149,168); pvc(224,247,250); //cyan
    pva(38,166,154); pvb(0,118,108); pvc(224,242,241); //teal
    pva(102,187,106); pvb(51,138,62); pvc(232,245,233); //green
    pva(156,204,101); pvb(107,155,55); pvc(241,248,233); //light green
    pva(212,225,87); pvb(160,175,34); pvc(249,251,231); //lime
    pva(255,238,88); pvb(201,188,31); pvc(255,253,231); //yellow
    pva(255,202,40); pvb(199,154,0); pvc(255,248,225); //amber
    pva(255,167,38); pvb(199,120,0); pvc(255,243,224); //orange
    pva(255,112,67); pvb(198,63,23); pvc(251,233,231); //deep orange
    //pva(141,110,99); pvb(95,67,57); //brown
    //pva(189,189,189); pvb(141,141,141); //grey
    //pva(120,144,156); pvb(75,99,110); //blue grey
}

int c, b;
float cc = 4, o = 0.125;
void yoshi1() {
    int ar = va.size();
    glPushMatrix();
    glTranslatef(-400,-400,0);
    cc += o;
    c = (int)cc;

    //y
    glBegin(GL_POLYGON);
    glColor3ub(vc[(c-4)%ar][0],vc[(c-4)%ar][1],vc[(c-4)%ar][2]);
    glVertex2f(260,369);
    glVertex2f(289,369);
    //glColor3ub(vb[(c-4)%ar][0],vb[(c-4)%ar][1],vb[(c-4)%ar][2]);
    glVertex2f(291,374);
    glVertex2f(277,399);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(277,399);
    //glColor3ub(va[(c-4)%ar][0],va[(c-4)%ar][1],va[(c-4)%ar][2]);
    glVertex2f(293,369);
    glVertex2f(322,369);
    //glColor3ub(vb[(c-4)%ar][0],vb[(c-4)%ar][1],vb[(c-4)%ar][2]);
    glVertex2f(305,399);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3ub(vb[(c-4)%ar][0],vb[(c-4)%ar][1],vb[(c-4)%ar][2]);
    glVertex2f(277,399);
    glVertex2f(305,399);
    //glColor3ub(va[(c-4)%ar][0],va[(c-4)%ar][1],va[(c-4)%ar][2]);
    glVertex2f(305,430);
    glVertex2f(277,430);
    glEnd();

    //o
    glColor3ub(vc[(c-3)%ar][0],vc[(c-3)%ar][1],vc[(c-3)%ar][2]);
    glBegin(GL_TRIANGLE_STRIP);
    float x, y, i;
    int k, r1 = 31, r2 = 4;
    for(k = 0, i = 0; i <= 6.28; i += 0.001, k++) {
        if(k%2) {
            x = 344 + r1*cos(i);
            y = 400 + r1*sin(i);
        }
        else {
            x = 344 + r2*cos(i);
            y = 400 + r2*sin(i);
        }
        glVertex2f(x,y);
    }
    glEnd();

    //s
    glBegin(GL_POLYGON);
    glColor3ub(vc[(c-2)%ar][0],vc[(c-2)%ar][1],vc[(c-2)%ar][2]);
    glVertex2f(441,369);
    glVertex2f(441,391);
    glVertex2f(424,391);
    glVertex2f(391,382);
    glVertex2f(388,369);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(441,391);
    //glColor3ub(vb[(c-2)%ar][0],vb[(c-2)%ar][1],vb[(c-2)%ar][2]);
    glVertex2f(441,399);
    glVertex2f(431,399);
    //glColor3ub(va[(c-2)%ar][0],va[(c-2)%ar][1],va[(c-2)%ar][2]);
    glVertex2f(424,391);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(391,382);
    for(i = 4.71; i >= 1.83; i = i - 0.001) {
        float x = 391 + 13*cos(i);
        float y = 382 + 13*sin(i);
        glVertex2f(x,y);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(391,382);
    glVertex2f(391 + 13*cos(2.7),382 + 13*sin(2.7));
    glVertex2f(396,411);
    glVertex2f(429,418);
    glVertex2f(428 + 13*cos(5.76),417 + 13*sin(5.76));
    glVertex2f(424,391);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(428,417);
    for(i = 1.57; i >= -0.52; i = i - 0.001) {
        float x = 428 + 13*cos(i);
        float y = 417 + 13*sin(i);
        glVertex2f(x,y);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(396,411);
    glVertex2f(379,411);
    //glColor3ub(vb[(c-2)%ar][0],vb[(c-2)%ar][1],vb[(c-2)%ar][2]);
    glVertex2f(379,401);
    glVertex2f(388,401);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3ub(va[(c-2)%ar][0],va[(c-2)%ar][1],va[(c-2)%ar][2]);
    glVertex2f(379,411);
    glVertex2f(396,411);
    glVertex2f(428,417);
    glVertex2f(430,430);
    glVertex2f(379,430);
    glEnd();

    //h
    glBegin(GL_POLYGON);
    glColor3ub(vc[(c-1)%ar][0],vc[(c-1)%ar][1],vc[(c-1)%ar][2]);
    glVertex2f(445,369);
    glVertex2f(471,369);
    glVertex2f(471,430);
    glVertex2f(445,430);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(471,388);
    //glColor3ub(vb[(c-1)%ar][0],vb[(c-1)%ar][1],vb[(c-1)%ar][2]);
    glVertex2f(471,413);
    glVertex2f(480,413);
    //glColor3ub(va[(c-1)%ar][0],va[(c-1)%ar][1],va[(c-1)%ar][2]);
    glVertex2f(480,388);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(480,369);
    glVertex2f(506,369);
    glVertex2f(506,430);
    glVertex2f(480,430);
    glEnd();

    //i
    glBegin(GL_POLYGON);
    glColor3ub(vc[c%ar][0],vc[c%ar][1],vc[c%ar][2]);
    glVertex2f(511,369);
    glVertex2f(537,369);
    glVertex2f(537,430);
    glVertex2f(511,430);
    glEnd();
    glPopMatrix();
    //glColor3ub(vb[c%ar][0],vb[c%ar][1],vb[c%ar][2]);
}

void yoshi() {
    int ar = va.size();
    glPushMatrix();
    glTranslatef(-400,-400,0);
    cc += o;
    if(cc == ar*100000+4) cc = 4;
    c = (int)cc;

    //y
    glBegin(GL_LINE_LOOP);
    glColor3ub(vb[(c-4)%ar][0],vb[(c-4)%ar][1],vb[(c-4)%ar][2]);
    glVertex2f(260,369);
    glVertex2f(289,369);
    glVertex2f(291,374);
    glVertex2f(293,369);
    glVertex2f(322,369);
    glVertex2f(305,399);
    glVertex2f(305,430);
    glVertex2f(277,430);
    glVertex2f(277,399);

    glEnd();

    //o
    float x, y, i;
    int r1 = 31, r2 = 4;
    glColor3ub(vb[(c-3)%ar][0],vb[(c-3)%ar][1],vb[(c-3)%ar][2]);
    glBegin(GL_LINE_LOOP);
    for(i = 0; i <= 6.279; i += 0.001) {
        x = 344 + r1*cos(i);
        y = 400 + r1*sin(i);
        glVertex2f(x,y);
    }
    glEnd();

    glBegin(GL_LINE_LOOP);
    for(i = 0; i <= 6.279; i += 0.001) {
        x = 344 + r2*cos(i);
        y = 400 + r2*sin(i);
        glVertex2f(x,y);
    }
    glEnd();

    //s
    glColor3ub(vb[(c-2)%ar][0],vb[(c-2)%ar][1],vb[(c-2)%ar][2]);
    glBegin(GL_LINE_LOOP);
    glVertex2f(441,369);
    glVertex2f(441,399);
    glVertex2f(431,399);
    glVertex2f(424,391);
    glVertex2f(428 + 13*cos(5.76),417 + 13*sin(5.76));
    for(i = -0.52; i <= 1.57; i += 0.001) {
        float x = 428 + 13*cos(i);
        float y = 417 + 13*sin(i);
        glVertex2f(x,y);
    }
    glVertex2f(379,430);
    glVertex2f(379,401);
    glVertex2f(388,401);
    glVertex2f(396,411);
    for(i = 2.37; i <= 4.71; i += 0.001) {
        float x = 391 + 13*cos(i);
        float y = 382 + 13*sin(i);
        glVertex2f(x,y);
    }
    glEnd();

    //h
    glColor3ub(vb[(c-1)%ar][0],vb[(c-1)%ar][1],vb[(c-1)%ar][2]);
    glBegin(GL_LINE_LOOP);
    glVertex2f(445,369);
    glVertex2f(471,369);
    glVertex2f(471,388);
    glVertex2f(480,388);
    glVertex2f(480,369);
    glVertex2f(506,369);
    glVertex2f(506,430);
    glVertex2f(480,430);
    glVertex2f(480,413);
    glVertex2f(471,413);
    glVertex2f(471,430);
    glVertex2f(445,430);
    glEnd();

    //i
    glColor3ub(vb[c%ar][0],vb[c%ar][1],vb[c%ar][2]);
    glBegin(GL_LINE_LOOP);
    glVertex2f(511,369);
    glVertex2f(537,369);
    glVertex2f(537,430);
    glVertex2f(511,430);
    glEnd();
    glPopMatrix();
    glColor3ub(va[(c+1)%ar][0],va[(c+1)%ar][1],va[(c+1)%ar][2]);
}
float k = 1;
void glow() {
    if((int)k == va.size()) k = 0;
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST );
    glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST );
    int r, z = 0;
    float i, s;
    //560
    for(r = 200, s = 1; r <= 580; r += s, /*s += 0.22,*/ z++) {
        glPushAttrib(1);
        float r1, g, b, j = r-200, u = 1900;
        r1 = (255-va[k][0])/u;
        g = (255-va[k][1])/u;
        b = (255-va[k][2])/u;
        glColor3ub(255-r1*j,255-g*j,255-b*j);
        glPushMatrix();
        glLineWidth(1);
        glBegin(GL_LINE_LOOP);
        for(i = 0; i <= 6.278; i = i + 0.1) {
            float x = r*cos(i);
            float y = r*sin(i);
            glVertex2f(x,y);
        }
        glEnd();
        glPopMatrix();
        glPopAttrib();
    }
    for(r = 200, s = 0; r <= 230; r += s, s += 0.22, z++) {
        glPushAttrib(1);
        float h = 255*(r - 200)/30.0;
        glColor3ub(h,h,h);
        glPushMatrix();
        if(z%2) glRotatef(0.573,0,0,1);
        glLineWidth(1);
        glBegin(GL_POINTS);
        for(i = 0; i <= 6.278; i = i + 0.02) {
            float x = r*cos(i);
            float y = r*sin(i);
            glVertex2f(x,y);
        }
        glEnd();
        glPopMatrix();
        glPopAttrib();
    }
    k += 0.25;
}

void lingkaran(float r) {
    glBegin(GL_LINE_LOOP);
    for(float i = 0; i <= 6.28; i += 0.01) {
        float x = r*cos(i);
        float y = r*sin(i);
        glVertex2f(x,y);
    }
    glEnd();
}

void lingkaranq(int x1, int y1, float r) {
    glBegin(GL_LINE_LOOP);
    for(float i = 0; i <= 6.28; i += 0.01) {
        float x = x1 + r*cos(i);
        float y = y1 + r*sin(i);
        glVertex2f(x,y);
    }
    glEnd();
}

void lingkaranp(int x1, int y1, float r) {
    glPushAttrib(1);
    glColor3ub(255,255,255);
    glBegin(GL_POLYGON);
    for(float i = 0; i <= 6.28; i += 0.01) {
        float x = x1 + r*cos(i);
        float y = y1 + r*sin(i);
        glVertex2f(x,y);
    }
    glEnd();
    glPopAttrib();
}

void hexagon(float r) {
    int i;
    float s = 1.0/3*3.14;
    //hexagon
    glBegin(GL_LINE_LOOP);
    for(i = 0; i < 6; i++)
        glVertex2f(r*cos(3.14/6+i*s),r*sin(3.14/6+i*s));
    glEnd();
    //garis
    for(i = 0; i < 3; i++) {
        glBegin(GL_LINE_STRIP);
        glVertex2f(r*cos(3.14/6+i*s),r*sin(3.14/6+i*s));
        glVertex2f(r*cos(3.14/6+i*s + 3.14),r*sin(3.14/6+i*s + 3.14));
        glEnd();
    }
}

void super(float x1, float y1, float rad, float r, int width) {
    glLineWidth(width);
    glBegin(GL_LINE_STRIP);
    float z = rad + 2.0/3*3.14;
    for(float i = rad; i <= z; i += 0.01) {
        float x = x1 + r*cos(i);
        float y = y1 + r*sin(i);
        glVertex2f(x,y);
    }
    glEnd();
}

void super2(float x1, float y1, float rad, float r1, float r2) {
    glPushAttrib(1);
    glColor3ub(255,255,255);
    glBegin(GL_TRIANGLE_STRIP);
    glVertex2f(x1,y1);
    float z = rad + 2.0/3*3.14 - 0.1, x, y, i;
    int k;
    for(k = 0, i = rad + 0.1; i <= z; i += 0.01, k++) {
        if(k%2) {
            x = x1 + r1*cos(i);
            y = y1 + r1*sin(i);
        }
        else {
            x = x1 + r2*cos(i);
            y = y1 + r2*sin(i);
        }
        glVertex2f(x,y);
    }
    glEnd();
    glPopAttrib();
}

void segitiga(float r) {
    //1/3 lingkaran
    float z = -3.14/6;
    for(int i = 0; i < 3; i++) {
        float x = r*cos(z + 2.0/3*3.14*i);
        float y = r*sin(z + 2.0/3*3.14*i);
        super2(x,y,1.57 + 2.0/3*3.14*i,80,60);
        super(x,y,1.57 + 2.0/3*3.14*i,80,1);
        super(x,y,1.57 + 2.0/3*3.14*i,65,2);
        super(x,y,1.57 + 2.0/3*3.14*i,60,1);
    }
    //segitiga
    glLineWidth(2);
    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < 3; i++)
        glVertex2f(r*cos(1.57 + 2.0/3*3.14*i),r*sin(1.57 + 2.0/3*3.14*i));
    glEnd();
    //lingkaran kecil
    for(int i = 0; i < 3; i++) {
        lingkaranp(r*(cos(1.57 + 2.0/3*3.14*i) + cos(1.57 + 2.0/3*3.14*((i+1)%3)))/2,r*(sin(1.57 + 2.0/3*3.14*i) + sin(1.57 + 2.0/3*3.14*((i+1)%3)))/2,20);
        lingkaranq(r*(cos(1.57 + 2.0/3*3.14*i) + cos(1.57 + 2.0/3*3.14*((i+1)%3)))/2,r*(sin(1.57 + 2.0/3*3.14*i) + sin(1.57 + 2.0/3*3.14*((i+1)%3)))/2,20);
    }
}

float rt = 0;
float z = 0;
void summon() {
    z += 0.225;
    glPushMatrix();
    glRotatef(z,0,0,1);
    glLineWidth(2);
    lingkaran(200);
    lingkaran(192);
    lingkaran(160);
    lingkaran(50);
    lingkaran(40);
    glLineWidth(1);
    hexagon(160);
    lingkaran(130);
    segitiga(160);
    glPopMatrix();
}

void display()
{
    glClearColor(1,1,1,0);
    glow();
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_POLYGON_SMOOTH);
    summon();
    yoshi1();
    glLineWidth(2);
    yoshi();
}

int main(void)
{
    fc();
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160055>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        glfwWindowHint(GLFW_SAMPLES, 4);
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
