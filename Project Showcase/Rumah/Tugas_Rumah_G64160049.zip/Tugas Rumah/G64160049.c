#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void bg()
{
    glBegin(GL_POLYGON);
        glColor3ub(112,214,237);
        glVertex2d(0,0);
        glVertex2d(800,0);
        glVertex2d(800,800);
        glVertex2d(0,800);
    glEnd();
}

void tanah()
{
    glBegin(GL_POLYGON);
        glColor3ub(253,234,201);
        glVertex2d(34,459);
        glVertex2d(376,261);
        glVertex2d(766,486);
        glVertex2d(423,684);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(250,204,171);
        glVertex2d(423,684);
        glVertex2d(766,486);
        glVertex2d(766,497);
        glVertex2d(423,694);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(246,217,183);
        glVertex2d(34,459);
        glVertex2d(423,684);
        glVertex2d(423,694);
        glVertex2d(34,470);
    glEnd();
}

void jalan()
{
    glBegin(GL_POLYGON);
        glColor3ub(176,184,187);
        glVertex2d(89,490);
        glVertex2d(241,402);
        glVertex2d(290,430);
        glVertex2d(137,518);
    glEnd();
}

void rumput()
{
    glBegin(GL_POLYGON);
        glColor3ub(120,160,108);
        glVertex2d(379,609);
        glVertex2d(658,447);
        glVertex2d(726,487);
        glVertex2d(447,648);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(248,196,139);
        glVertex2d(379,609);
        glVertex2d(658,447);
        glVertex2d(658,452);
        glVertex2d(383,611);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189,123,91);
        glVertex2d(658,447);
        glVertex2d(726,487);
        glVertex2d(722,489);
        glVertex2d(658,452);
    glEnd();
}

void pagar()
{
    glBegin(GL_POLYGON);
        glColor3ub(171,182,103);
        glVertex2d(181,498);
        glVertex2d(431,643);
        glVertex2d(417,651);
        glVertex2d(166,507);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(144,166,102);
        glVertex2d(166,507);
        glVertex2d(417,651);
        glVertex2d(417,663);
        glVertex2d(166,518);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(117,167,104);
        glVertex2d(417,651);
        glVertex2d(431,643);
        glVertex2d(431,655);
        glVertex2d(417,663);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(120,158,85);
        glVertex2d(166,518);
        glVertex2d(417,663);
        glVertex2d(417,667);
        glVertex2d(166,522);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(120,158,85);
        glVertex2d(417,663);
        glVertex2d(431,655);
        glVertex2d(431,659);
        glVertex2d(417,667);
    glEnd();
}

void tembok_kiri()
{
    glBegin(GL_POLYGON);
        glColor3ub(57,75,85);
        glVertex2d(205,216);
        glVertex2d(420,92);
        glVertex2d(420,295);
        glVertex2d(205,419);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(80,103,117);
        glVertex2d(191,208);
        glVertex2d(406,84);
        glVertex2d(420,92);
        glVertex2d(205,216);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(100,124,136);
        glVertex2d(191,208);
        glVertex2d(205,216);
        glVertex2d(205,419);
        glVertex2d(191,411);
    glEnd();
}

void gedung_putih()
{
    glBegin(GL_POLYGON);
        glColor3ub(241,241,243);
        glVertex2d(238,221);
        glVertex2d(420,116);
        glVertex2d(466,143);
        glVertex2d(284,248);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(224,224,222);
        glVertex2d(238,221);
        glVertex2d(379,304);
        glVertex2d(379,482);
        glVertex2d(238,400);
    glEnd();
}

void kaca_gedung_putih()
{
    // Kaca kiri
    glBegin(GL_POLYGON);
        glColor3ub(196,203,209);
        glVertex2d(241,240);
        glVertex2d(243,241);
        glVertex2d(243,309);
        glVertex2d(241,311);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(196,203,209);
        glVertex2d(243,309);
        glVertex2d(249,313);
        glVertex2d(249,315);
        glVertex2d(241,311);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(80,188,226);
        glVertex2d(249,245);
        glVertex2d(249,313);
        glVertex2d(243,309);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(112,214,237);
        glVertex2d(243,241);
        glVertex2d(249,245);
        glVertex2d(243,309);
    glEnd();

    // Kaca Kanan
    glBegin(GL_POLYGON);
        glColor3ub(196,203,209);
        glVertex2d(259,250);
        glVertex2d(261,251);
        glVertex2d(261,319);
        glVertex2d(259,320);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(196,203,209);
        glVertex2d(261,319);
        glVertex2d(267,323);
        glVertex2d(267,325);
        glVertex2d(259,320);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(80,188,226);
        glVertex2d(267,255);
        glVertex2d(267,323);
        glVertex2d(261,319);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(112,214,237);
        glVertex2d(261,251);
        glVertex2d(267,255);
        glVertex2d(261,319);
    glEnd();
}

void pintu()
{
    // Kaca
    glBegin(GL_POLYGON);
        glColor3ub(82,185,226);
        glVertex2d(241,331);
        glVertex2d(296,363);
        glVertex2d(296,434);
        glVertex2d(241,402);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(196,204,207);
        glVertex2d(241,331);
        glVertex2d(244,333);
        glVertex2d(244,400);
        glVertex2d(241,402);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(245,334);
        glVertex2d(247,335);
        glVertex2d(247,402);
        glVertex2d(245,403);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(243,332);
        glVertex2d(296,363);
        glVertex2d(296,366);
        glVertex2d(243,335);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(243,332);
        glVertex2d(245,334);
        glVertex2d(245,403);
        glVertex2d(243,401);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(247,343);
        glVertex2d(294,370);
        glVertex2d(294,372);
        glVertex2d(245,344);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(243,342);
        glVertex2d(296,373);
        glVertex2d(296,376);
        glVertex2d(243,345);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(247,399);
        glVertex2d(294,426);
        glVertex2d(294,428);
        glVertex2d(245,400);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(266,357);
        glVertex2d(268,358);
        glVertex2d(268,415);
        glVertex2d(266,414);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(268,358);
        glVertex2d(269,359);
        glVertex2d(269,414);
        glVertex2d(268,415);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(268,358);
        glVertex2d(271,359);
        glVertex2d(271,417);
        glVertex2d(268,415);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(271,359);
        glVertex2d(272,360);
        glVertex2d(272,416);
        glVertex2d(271,417);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(69,73,74);
        glVertex2d(244,400);
        glVertex2d(296,430);
        glVertex2d(296,434);
        glVertex2d(241,402);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(243,399);
        glVertex2d(296,429);
        glVertex2d(296,432);
        glVertex2d(243,402);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,92,95);
        glVertex2d(294,365);
        glVertex2d(296,366);
        glVertex2d(296,432);
        glVertex2d(294,431);
    glEnd();
}

void rumah_coklat()
{
    // tembok depan
    glBegin(GL_POLYGON);
        glColor3ub(168,114,76);
        glVertex2d(276,257);
        glVertex2d(418,340);
        glVertex2d(418,559);
        glVertex2d(276,477);
    glEnd();

    // atas
    glBegin(GL_POLYGON);
        glColor3ub(135,57,37);
        glVertex2d(513,121);
        glVertex2d(655,203);
        glVertex2d(418,340);
        glVertex2d(276,258);
    glEnd();

    // samping
    glBegin(GL_POLYGON);
        glColor3ub(156,95,67);
        glVertex2d(418,340);
        glVertex2d(655,203);
        glVertex2d(655,422);
        glVertex2d(418,559);
    glEnd();
}

void alas_lantai()
{
    glBegin(GL_POLYGON);
        glColor3ub(80,103,117);
        glVertex2d(276,354);
        glVertex2d(418,435);
        glVertex2d(459,494);
        glVertex2d(246,371);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(80,103,117);
        glVertex2d(418,435);
        glVertex2d(655,299);
        glVertex2d(726,340);
        glVertex2d(459,494);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(100,124,134);
        glVertex2d(246,371);
        glVertex2d(459,494);
        glVertex2d(459,502);
        glVertex2d(246,379);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(58,76,86);
        glVertex2d(459,494);
        glVertex2d(726,340);
        glVertex2d(726,348);
        glVertex2d(459,502);
    glEnd();
}

void atap()
{
    glBegin(GL_POLYGON);
        glColor3ub(80,103,117);
        glVertex2d(513,106);
        glVertex2d(655,188);
        glVertex2d(418,325);
        glVertex2d(276,243);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(100,124,134);
        glVertex2d(276,243);
        glVertex2d(418,325);
        glVertex2d(418,333);
        glVertex2d(276,251);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(57,75,85);
        glVertex2d(418,325);
        glVertex2d(655,188);
        glVertex2d(655,196);
        glVertex2d(418,333);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(57,75,85);
        glVertex2d(418,325);
        glVertex2d(655,188);
        glVertex2d(655,196);
        glVertex2d(418,333);
    glEnd();
}

void jendela1()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(454,330);
        glVertex2d(455,329);
        glVertex2d(455,403);
        glVertex2d(454,402);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(439,408);
        glVertex2d(454,400);
        glVertex2d(455,400);
        glVertex2d(439,409);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(439,409);
        glVertex2d(455,400);
        glVertex2d(459,402);
        glVertex2d(439,414);
    glEnd();

     glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(455,329);
        glVertex2d(459,327);
        glVertex2d(459,402);
        glVertex2d(455,400);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(439,338);
        glVertex2d(457,328);
        glVertex2d(457,330);
        glVertex2d(439,341);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(439,338);
        glVertex2d(441,337);
        glVertex2d(441,410);
        glVertex2d(439,412);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(439,409);
        glVertex2d(457,399);
        glVertex2d(457,401);
        glVertex2d(439,412);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(455,329);
        glVertex2d(457,328);
        glVertex2d(457,401);
        glVertex2d(455,403);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(80,188,227);
        glVertex2d(441,339);
        glVertex2d(454,400);
        glVertex2d(441,408);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(112,214,237);
        glVertex2d(454,400);
        glVertex2d(454,332);
        glVertex2d(441,339);
    glEnd();
}

void jendela2()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(480,315);
        glVertex2d(481,314);
        glVertex2d(481,388);
        glVertex2d(480,387);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(465,393);
        glVertex2d(480,385);
        glVertex2d(481,385);
        glVertex2d(465,394);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(466,394);
        glVertex2d(481,385);
        glVertex2d(485,387);
        glVertex2d(465,399);
    glEnd();

    glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(481,314);
        glVertex2d(485,312);
        glVertex2d(485,387);
        glVertex2d(481,385);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(465,323);
        glVertex2d(483,313);
        glVertex2d(483,316);
        glVertex2d(465,326);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(465,323);
        glVertex2d(467,322);
        glVertex2d(467,395);
        glVertex2d(465,397);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(465,394);
        glVertex2d(483,384);
        glVertex2d(483,386);
        glVertex2d(465,397);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(481,314);
        glVertex2d(483,313);
        glVertex2d(483,386);
        glVertex2d(481,388);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(80,188,227);
        glVertex2d(467,325);
        glVertex2d(480,385);
        glVertex2d(467,393);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(112,214,237);
        glVertex2d(480,385);
        glVertex2d(480,317);
        glVertex2d(467,325);
    glEnd();
}

void jendela3()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(506,300);
        glVertex2d(507,300);
        glVertex2d(507,373);
        glVertex2d(506,372);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(492,378);
        glVertex2d(506,370);
        glVertex2d(507,370);
        glVertex2d(492,380);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(492,380);
        glVertex2d(508,371);
        glVertex2d(511,373);
        glVertex2d(492,384);
    glEnd();

    glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(508,299);
        glVertex2d(511,297);
        glVertex2d(511,373);
        glVertex2d(508,371);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(492,309);
        glVertex2d(509,298);
        glVertex2d(509,301);
        glVertex2d(492,311);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(492,309);
        glVertex2d(494,308);
        glVertex2d(494,381);
        glVertex2d(492,382);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(492,379);
        glVertex2d(509,369);
        glVertex2d(509,372);
        glVertex2d(492,382);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(507,300);
        glVertex2d(509,298);
        glVertex2d(509,372);
        glVertex2d(507,373);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(80,188,227);
        glVertex2d(494,310);
        glVertex2d(506,370);
        glVertex2d(494,377);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(112,214,237);
        glVertex2d(506,370);
        glVertex2d(506,303);
        glVertex2d(494,310);
    glEnd();
}

void jendela4()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(582,255);
        glVertex2d(583,255);
        glVertex2d(583,328);
        glVertex2d(582,327);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(567,333);
        glVertex2d(582,325);
        glVertex2d(583,326);
        glVertex2d(567,334);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(567,335);
        glVertex2d(583,326);
        glVertex2d(587,328);
        glVertex2d(567,339);
    glEnd();

    glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(583,254);
        glVertex2d(587,252);
        glVertex2d(587,328);
        glVertex2d(583,326);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(567,264);
        glVertex2d(585,253);
        glVertex2d(585,256);
        glVertex2d(567,267);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(567,264);
        glVertex2d(569,263);
        glVertex2d(569,336);
        glVertex2d(567,337);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(567,334);
        glVertex2d(585,324);
        glVertex2d(585,327);
        glVertex2d(567,337);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(583,255);
        glVertex2d(585,253);
        glVertex2d(585,327);
        glVertex2d(583,328);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(80,188,227);
        glVertex2d(569,265);
        glVertex2d(582,325);
        glVertex2d(569,332);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(112,214,237);
        glVertex2d(582,325);
        glVertex2d(582,258);
        glVertex2d(569,265);
    glEnd();
}

void jendela5()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(609,240);
        glVertex2d(610,239);
        glVertex2d(610,314);
        glVertex2d(609,313);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(594,319);
        glVertex2d(609,310);
        glVertex2d(610,311);
        glVertex2d(594,320);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(594,320);
        glVertex2d(610,311);
        glVertex2d(613,313);
        glVertex2d(594,324);
    glEnd();

    glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(610,240);
        glVertex2d(613,237);
        glVertex2d(613,313);
        glVertex2d(610,311);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(594,249);
        glVertex2d(612,239);
        glVertex2d(612,241);
        glVertex2d(594,251);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(594,249);
        glVertex2d(596,248);
        glVertex2d(596,321);
        glVertex2d(594,322);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(594,319);
        glVertex2d(612,309);
        glVertex2d(612,312);
        glVertex2d(594,322);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(609,240);
        glVertex2d(612,239);
        glVertex2d(612,312);
        glVertex2d(609,313);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(80,188,227);
        glVertex2d(596,250);
        glVertex2d(609,310);
        glVertex2d(596,318);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(112,214,237);
        glVertex2d(609,310);
        glVertex2d(609,243);
        glVertex2d(596,250);
    glEnd();
}

void jendela6()
{
    glBegin(GL_POLYGON); // shadow dalam kanan
        glColor3ub(70,72,72);
        glVertex2d(635,226);
        glVertex2d(636,225);
        glVertex2d(636,299);
        glVertex2d(635,298);
    glEnd();

    glBegin(GL_POLYGON); // shadow dalam bawah
        glColor3ub(70,72,72);
        glVertex2d(620,304);
        glVertex2d(635,296);
        glVertex2d(636,296);
        glVertex2d(620,305);
    glEnd();

    glBegin(GL_POLYGON); // shadow bawah
        glColor3ub(168,114,76);
        glVertex2d(620,305);
        glVertex2d(636,296);
        glVertex2d(640,298);
        glVertex2d(620,310);
    glEnd();

    glBegin(GL_POLYGON); // shadow kanan
        glColor3ub(168,114,76);
        glVertex2d(636,225);
        glVertex2d(640,223);
        glVertex2d(640,298);
        glVertex2d(636,296);
    glEnd();

    glBegin(GL_POLYGON); //atas
        glColor3ub(94,94,94);
        glVertex2d(620,234);
        glVertex2d(638,224);
        glVertex2d(638,226);
        glVertex2d(620,237);
    glEnd();

    glBegin(GL_POLYGON); //kiri
        glColor3ub(94,94,94);
        glVertex2d(620,234);
        glVertex2d(622,233);
        glVertex2d(622,306);
        glVertex2d(620,307);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(94,94,94); //bawah
        glVertex2d(620,305);
        glVertex2d(638,295);
        glVertex2d(638,297);
        glVertex2d(620,307);
    glEnd();

    glBegin(GL_POLYGON); //kanan
        glColor3ub(94,94,94);
        glVertex2d(636,225);
        glVertex2d(638,224);
        glVertex2d(638,297);
        glVertex2d(636,296);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(80,188,227);
        glVertex2d(622,235);
        glVertex2d(635,296);
        glVertex2d(622,304);
    glEnd();

    glBegin(GL_POLYGON); //kaca kanan
        glColor3ub(112,214,237);
        glVertex2d(635,296);
        glVertex2d(635,228);
        glVertex2d(622,235);
    glEnd();
}

void jendela_kiri_atas()
{
    glBegin(GL_POLYGON); //kaca biru gelap
        glColor3ub(80,188,227);
        glVertex2d(292,278);
        glVertex2d(401,341);
        glVertex2d(401,414);
        glVertex2d(292,352);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(112,214,237);
        glVertex2d(366,320);
        glVertex2d(399,413);
        glVertex2d(366,393);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
        glColor3ub(112,214,237);
        glVertex2d(293,279);
        glVertex2d(327,371);
        glVertex2d(293,351);
    glEnd();

    glBegin(GL_POLYGON); //kayu kiri
        glColor3ub(156,95,67);
        glVertex2d(292,278);
        glVertex2d(293,279);
        glVertex2d(293,353);
        glVertex2d(292,352);
    glEnd();

    glBegin(GL_POLYGON); //kayu bawah
        glColor3ub(156,95,67);
        glVertex2d(293,351);
        glVertex2d(401,414);
        glVertex2d(401,416);
        glVertex2d(291,352);
    glEnd();

    glBegin(GL_POLYGON); //jendela tengah
        glColor3ub(80,103,117);
        glVertex2d(331,300);
        glVertex2d(362,318);
        glVertex2d(362,391);
        glVertex2d(331,374);
    glEnd();

    glBegin(GL_POLYGON); //jendela tengah kiri
        glColor3ub(100,124,134);
        glVertex2d(327,298);
        glVertex2d(329,299);
        glVertex2d(329,374);
        glVertex2d(327,372);
    glEnd();

    glBegin(GL_POLYGON); //jendela tengah kanan
        glColor3ub(100,124,136);
        glVertex2d(362,318);
        glVertex2d(364,320);
        glVertex2d(364,394);
        glVertex2d(362,393);
    glEnd();

    glBegin(GL_POLYGON); //shadow jendela tengah kiri
        glColor3ub(58,76,86);
        glVertex2d(329,299);
        glVertex2d(331,300);
        glVertex2d(331,373);
        glVertex2d(329,374);
    glEnd();

    glBegin(GL_POLYGON); //shadow jendela tengah kanan
        glColor3ub(58,76,86);
        glVertex2d(364,321);
        glVertex2d(366,320);
        glVertex2d(366,393);
        glVertex2d(364,394);
    glEnd();

    glBegin(GL_POLYGON); //strip 1
        glColor3ub(56,76,87);
        glVertex2d(331,305);
        glVertex2d(362,324);
        glVertex2d(362,327);
        glVertex2d(331,308);
    glEnd();

    glBegin(GL_POLYGON); //strip 2
        glColor3ub(56,76,87);
        glVertex2d(331,313);
        glVertex2d(362,331);
        glVertex2d(362,334);
        glVertex2d(331,316);
    glEnd();

    glBegin(GL_POLYGON); //strip 3
        glColor3ub(56,76,87);
        glVertex2d(331,320);
        glVertex2d(362,338);
        glVertex2d(362,341);
        glVertex2d(331,323);
    glEnd();

    glBegin(GL_POLYGON); //strip 4
        glColor3ub(56,76,87);
        glVertex2d(331,328);
        glVertex2d(362,346);
        glVertex2d(362,349);
        glVertex2d(331,331);
    glEnd();

    glBegin(GL_POLYGON); //strip 5
        glColor3ub(56,76,87);
        glVertex2d(331,335);
        glVertex2d(362,353);
        glVertex2d(362,356);
        glVertex2d(331,338);
    glEnd();

    glBegin(GL_POLYGON); //strip 6
        glColor3ub(56,76,87);
        glVertex2d(331,343);
        glVertex2d(362,361);
        glVertex2d(362,364);
        glVertex2d(331,346);
    glEnd();

    glBegin(GL_POLYGON); //strip 7
        glColor3ub(56,76,87);
        glVertex2d(331,350);
        glVertex2d(362,368);
        glVertex2d(362,371);
        glVertex2d(331,353);
    glEnd();

    glBegin(GL_POLYGON); //strip 8
        glColor3ub(56,76,87);
        glVertex2d(331,357);
        glVertex2d(362,376);
        glVertex2d(362,379);
        glVertex2d(331,360);
    glEnd();

    glBegin(GL_POLYGON); //strip 9
        glColor3ub(56,76,87);
        glVertex2d(331,365);
        glVertex2d(362,383);
        glVertex2d(362,386);
        glVertex2d(331,368);
    glEnd();

    glBegin(GL_POLYGON); //strip 9
        glColor3ub(56,76,87);
        glVertex2d(331,365);
        glVertex2d(362,383);
        glVertex2d(362,386);
        glVertex2d(331,368);
    glEnd();
}

void jendela_kiri_bawah()
{
    glBegin(GL_POLYGON); //biru tua
        glColor3ub(80,188,227);
        glVertex2d(293,417);
        glVertex2d(401,479);
        glVertex2d(401,547);
        glVertex2d(293,485);
    glEnd();

    glBegin(GL_POLYGON); //segitiga kiri
        glColor3ub(112,214,237);
        glVertex2d(295,420);
        glVertex2d(316,432);
        glVertex2d(295,484);
    glEnd();

    glBegin(GL_POLYGON); //segitiga kanan
        glColor3ub(112,214,237);
        glVertex2d(320,434);
        glVertex2d(340,446);
        glVertex2d(320,498);
    glEnd();

        glBegin(GL_POLYGON); //kayu kiri dalam
        glColor3ub(70,72,71);
        glVertex2d(294,417);
        glVertex2d(295,418);
        glVertex2d(295,486);
        glVertex2d(294,487);
    glEnd();

    glBegin(GL_POLYGON); //kayu bawah dalam
        glColor3ub(70,72,71);
        glVertex2d(295,484);
        glVertex2d(401,545);
        glVertex2d(401,547);
        glVertex2d(294,485);
    glEnd();

    glBegin(GL_POLYGON); //kayu tengah dalam
        glColor3ub(70,72,71);
        glVertex2d(318,431);
        glVertex2d(320,432);
        glVertex2d(320,500);
        glVertex2d(318,501);
    glEnd();

    glBegin(GL_POLYGON); //kayu atas
        glColor3ub(93,93,93);
        glVertex2d(293,417);
        glVertex2d(401,479);
        glVertex2d(401,482);
        glVertex2d(292,419);
    glEnd();

    glBegin(GL_POLYGON); //kayu kiri
        glColor3ub(93,93,93);
        glVertex2d(292,416);
        glVertex2d(294,417);
        glVertex2d(294,487);
        glVertex2d(292,486);
    glEnd();

    glBegin(GL_POLYGON); //kayu tengah
        glColor3ub(93,93,93);
        glVertex2d(316,430);
        glVertex2d(318,431);
        glVertex2d(318,501);
        glVertex2d(316,500);
    glEnd();

    glBegin(GL_POLYGON); //kayu bawah
        glColor3ub(93,93,93);
        glVertex2d(294,485);
        glVertex2d(401,547);
        glVertex2d(401,549);
        glVertex2d(294,487);
    glEnd();
}

void jendela_kanan()
{
    glBegin(GL_POLYGON); //biru tua
        glColor3ub(80,188,227);
        glVertex2d(441,454);
        glVertex2d(636,341);
        glVertex2d(636,429);
        glVertex2d(441,541);
    glEnd();

    glBegin(GL_POLYGON); //segitiga 1
        glColor3ub(112,214,237);
        glVertex2d(465,459);
        glVertex2d(496,441);
        glVertex2d(496,507);
    glEnd();

    glBegin(GL_POLYGON); //segitiga 2
        glColor3ub(112,214,237);
        glVertex2d(499,439);
        glVertex2d(530,421);
        glVertex2d(530,487);
    glEnd();

    glBegin(GL_POLYGON); //segitiga 3
        glColor3ub(112,214,237);
        glVertex2d(534,419);
        glVertex2d(564,401);
        glVertex2d(564,467);
    glEnd();

    glBegin(GL_POLYGON); //segitiga 4
        glColor3ub(112,214,237);
        glVertex2d(568,399);
        glVertex2d(599,381);
        glVertex2d(599,447);
    glEnd();

    glBegin(GL_POLYGON); //segitiga 4
        glColor3ub(112,214,237);
        glVertex2d(603,379);
        glVertex2d(633,362);
        glVertex2d(633,427);
    glEnd();

    glBegin(GL_POLYGON); //shadow
        glColor3ub(219,193,176);
        glVertex2d(441,541);
        glVertex2d(636,429);
        glVertex2d(639,432);
        glVertex2d(441,546);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam bawah
        glColor3ub(57,77,88);
        glVertex2d(441,538);
        glVertex2d(635,426);
        glVertex2d(637,427);
        glVertex2d(441,540);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam tegak 1
        glColor3ub(57,77,88);
        glVertex2d(496,423);
        glVertex2d(497,422);
        glVertex2d(497,511);
        glVertex2d(496,510);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam tegak 2
        glColor3ub(57,77,88);
        glVertex2d(530,403);
        glVertex2d(531,402);
        glVertex2d(531,491);
        glVertex2d(530,490);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam tegak 3
        glColor3ub(57,77,88);
        glVertex2d(564,383);
        glVertex2d(566,382);
        glVertex2d(566,471);
        glVertex2d(564,470);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam tegak 4
        glColor3ub(57,77,88);
        glVertex2d(599,363);
        glVertex2d(600,362);
        glVertex2d(600,451);
        glVertex2d(599,450);
    glEnd();

    glBegin(GL_POLYGON); //kayu dalam tegak 5
        glColor3ub(57,77,88);
        glVertex2d(633,343);
        glVertex2d(635,342);
        glVertex2d(635,431);
        glVertex2d(633,431);
    glEnd();

    glBegin(GL_POLYGON); //kayu bawah
        glColor3ub(80,103,117);
        glVertex2d(441,540);
        glVertex2d(637,427);
        glVertex2d(637,430);
        glVertex2d(441,543);
    glEnd();

    glBegin(GL_POLYGON); //kayu tegak 1
        glColor3ub(80,103,117);
        glVertex2d(497,422);
        glVertex2d(499,421);
        glVertex2d(499,509);
        glVertex2d(497,511);
    glEnd();

    glBegin(GL_POLYGON); //kayu tegak 2
        glColor3ub(80,103,117);
        glVertex2d(531,402);
        glVertex2d(534,401);
        glVertex2d(534,489);
        glVertex2d(531,491);
    glEnd();

    glBegin(GL_POLYGON); //kayu tegak 3
        glColor3ub(80,103,117);
        glVertex2d(566,382);
        glVertex2d(568,381);
        glVertex2d(568,470);
        glVertex2d(566,471);
    glEnd();

    glBegin(GL_POLYGON); //kayu tegak 4
        glColor3ub(80,103,117);
        glVertex2d(600,362);
        glVertex2d(603,361);
        glVertex2d(603,450);
        glVertex2d(600,451);
    glEnd();

    glBegin(GL_POLYGON); //kayu tegak 5
        glColor3ub(80,103,117);
        glVertex2d(635,343);
        glVertex2d(637,341);
        glVertex2d(637,430);
        glVertex2d(635,431);
    glEnd();
}

void Lingkaran(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<101;i++)
        {
            px = cos(i*cons)*radius1+posX;
            py = sin(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = cos(i*cons)*radius2+posX;
            py = sin(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void Lingkaran2(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<202;i++)
        {
            px = cos(i*cons)*radius1+posX;
            py = sin(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = cos(i*cons)*radius2+posX;
            py = sin(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void pohon_kotak()
{
    glColor3ub(109,141,94);
    Lingkaran2(468,598,15); //shadow
    glBegin(GL_POLYGON); //Batang
        glColor3ub(125,79,67);
        glVertex2d(465,555);
        glVertex2d(473,555);
        glVertex2d(473,595);
        glVertex2d(465,595);
    glEnd();
    Lingkaran(469,595,4); //bawah batang

    glBegin(GL_POLYGON); // daun kiri 1
        glColor3ub(149,176,67);
        glVertex2d(445,552);
        glVertex2d(468,565);
        glVertex2d(468,587);
        glVertex2d(445,573);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 2
        glColor3ub(169,193,96);
        glVertex2d(445,552);
        glVertex2d(469,538);
        glVertex2d(491,552);
        glVertex2d(468,565);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 3
        glColor3ub(149,176,67);
        glVertex2d(451,531);
        glVertex2d(468,541);
        glVertex2d(468,561);
        glVertex2d(451,551);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 4
        glColor3ub(169,193,96);
        glVertex2d(451,531);
        glVertex2d(469,520);
        glVertex2d(486,531);
        glVertex2d(468,541);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 5
        glColor3ub(149,176,67);
        glVertex2d(456,515);
        glVertex2d(468,523);
        glVertex2d(468,537);
        glVertex2d(456,530);
    glEnd();

    glBegin(GL_POLYGON); // daun tengah
        glColor3ub(169,193,96);
        glVertex2d(456,515);
        glVertex2d(468,508);
        glVertex2d(481,515);
        glVertex2d(468,523);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 1
        glColor3ub(119,143,45);
        glVertex2d(468,565);
        glVertex2d(491,552);
        glVertex2d(491,573);
        glVertex2d(468,587);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 2
        glColor3ub(119,143,45);
        glVertex2d(468,541);
        glVertex2d(486,531);
        glVertex2d(486,551);
        glVertex2d(468,561);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 3
        glColor3ub(119,143,45);
        glVertex2d(468,523);
        glVertex2d(481,515);
        glVertex2d(481,530);
        glVertex2d(468,537);
    glEnd();
}

void pohon_kotak2()
{
    glColor3ub(109,141,94);
    Lingkaran2(561,547,15); //shadow
    glBegin(GL_POLYGON); //Batang
        glColor3ub(125,79,67);
        glVertex2d(557,500);
        glVertex2d(566,500);
        glVertex2d(566,545);
        glVertex2d(557,545);
    glEnd();
    Lingkaran(562,545,4); //bawah batang

    glBegin(GL_POLYGON); // daun kiri dalam
        glColor3ub(149,176,67);
        glVertex2d(535,473);
        glVertex2d(561,488);
        glVertex2d(561,534);
        glVertex2d(535,520);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan dalam
        glColor3ub(119,143,45);
        glVertex2d(561,488);
        glVertex2d(586,473);
        glVertex2d(586,520);
        glVertex2d(561,534);
    glEnd();

    glBegin(GL_POLYGON); // daun tengah dalam
        glColor3ub(169,193,96);
        glVertex2d(535,473);
        glVertex2d(561,458);
        glVertex2d(586,473);
        glVertex2d(561,488);
    glEnd();

    glBegin(GL_POLYGON); // daun atas 1
        glColor3ub(169,193,96);
        glVertex2d(541,466);
        glVertex2d(561,455);
        glVertex2d(580,466);
        glVertex2d(561,477);
    glEnd();

    glBegin(GL_POLYGON); // daun atas 2
        glColor3ub(149,176,67);
        glVertex2d(541,466);
        glVertex2d(561,477);
        glVertex2d(561,483);
        glVertex2d(541,472);
    glEnd();

    glBegin(GL_POLYGON); // daun atas 3
        glColor3ub(119,143,45);
        glVertex2d(561,477);
        glVertex2d(580,466);
        glVertex2d(580,472);
        glVertex2d(561,483);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 1
        glColor3ub(149,176,67);
        glVertex2d(533,483);
        glVertex2d(551,493);
        glVertex2d(551,533);
        glVertex2d(533,522);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 2
        glColor3ub(119,143,45);
        glVertex2d(537,480);
        glVertex2d(555,490);
        glVertex2d(551,493);
        glVertex2d(533,483);
    glEnd();

    glBegin(GL_POLYGON); // daun kiri 3
        glColor3ub(106,130,33);
        glVertex2d(551,493);
        glVertex2d(555,490);
        glVertex2d(555,530);
        glVertex2d(551,533);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 1
        glColor3ub(119,143,45);
        glVertex2d(570,493);
        glVertex2d(588,483);
        glVertex2d(588,522);
        glVertex2d(570,533);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 2
        glColor3ub(106,130,33);
        glVertex2d(566,490);
        glVertex2d(583,480);
        glVertex2d(588,483);
        glVertex2d(570,493);
    glEnd();

    glBegin(GL_POLYGON); // daun kanan 2
        glColor3ub(86,105,33);
        glVertex2d(566,490);
        glVertex2d(570,493);
        glVertex2d(570,533);
        glVertex2d(566,530);
    glEnd();
}

void pohon_segitiga()
{
    glColor3ub(109,141,94);
    Lingkaran2(643,500,15); //shadow
    glBegin(GL_POLYGON); //Batang
        glColor3ub(125,79,67);
        glVertex2d(639,452);
        glVertex2d(649,452);
        glVertex2d(649,499);
        glVertex2d(639,499);
    glEnd();
    Lingkaran(644,499,4); // bawah batang

    glBegin(GL_POLYGON); // segitiga kiri
        glColor3ub(169,193,96);
        glVertex2d(644,403);
        glVertex2d(644,489);
        glVertex2d(613,472);
    glEnd();

    glBegin(GL_POLYGON); // segitiga kanan
        glColor3ub(137,163,57);
        glVertex2d(644,403);
        glVertex2d(644,489);
        glVertex2d(675,472);
    glEnd();
}

void SolarPanel1 ()
{

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(328,238);
        glVertex2d(373,212);
        glVertex2d(462,264);
        glVertex2d(417,289);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(328,238);
        glVertex2d(417,289);
        glVertex2d(417,292);
        glVertex2d(328,241);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(230,231,232);
        glVertex2d(417,289);
        glVertex2d(462,264);
        glVertex2d(462,267);
        glVertex2d(417,292);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 1
        glColor3ub(98,94,112);
        glVertex2d(331,238);
        glVertex2d(373,214);
        glVertex2d(417,288);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 2
        glColor3ub(128,123,146);
        glVertex2d(373,214);
        glVertex2d(459,264);
        glVertex2d(417,288);
    glEnd();

    int i, c=0;
    int a[6] = {220,227,234,241,248,255};
    int b[3] = {232,225,219};

    for(i=373;i<459;i++){
        if(i==385 || i==397 || i==410 || i==422 || i==434 || i==446){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,a[c]);
                glVertex2d(i+1,a[c]+1);
                glVertex2d(i-44,a[c]+27);
                glVertex2d(i-42,a[c]+25);
            glEnd();
            c++;
        }
    }
    c =0;
    for(i=331;i<459;i++){
        if(i==340 || i==351 || i==362){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,b[c]);
                glVertex2d(i+1,b[c]-1);
                glVertex2d(i+88,b[c]+52);
                glVertex2d(i+86,b[c]+53);
            glEnd();
            c++;
        }
    }
}

void SolarPanel2 ()
{

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(400,196);
        glVertex2d(445,171);
        glVertex2d(534,222);
        glVertex2d(490,248);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(400,196);
        glVertex2d(490,248);
        glVertex2d(490,251);
        glVertex2d(400,199);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(230,231,232);
        glVertex2d(490,248);
        glVertex2d(534,222);
        glVertex2d(534,225);
        glVertex2d(490,251);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 1
        glColor3ub(98,94,112);
        glVertex2d(445,172);
        glVertex2d(490,246);
        glVertex2d(403,196);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 2
        glColor3ub(128,123,146);
        glVertex2d(445,172);
        glVertex2d(531,222);
        glVertex2d(490,246);
    glEnd();

    int i, c=0;
    int a[6] = {178,185,192,199,206,213};
    int b[3] = {190,183,178};

    for(i=445;i<531;i++){
        if(i==457 || i==470 || i==482 || i==494 || i==506 || i==518){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,a[c]);
                glVertex2d(i+1,a[c]+1);
                glVertex2d(i-44,a[c]+27);
                glVertex2d(i-42,a[c]+25);
            glEnd();
            c++;
        }
    }
    c =0;
    for(i=403;i<445;i++){
        if(i==412 || i==424 || i==434){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,b[c]);
                glVertex2d(i+1,b[c]-1);
                glVertex2d(i+88,b[c]+52);
                glVertex2d(i+86,b[c]+53);
            glEnd();
            c++;
        }
    }
}

void SolarPanel3 ()
{

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(467,157);
        glVertex2d(512,132);
        glVertex2d(601,183);
        glVertex2d(556,209);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(241,241,242);
        glVertex2d(467,157);
        glVertex2d(556,209);
        glVertex2d(556,212);
        glVertex2d(467,160);
    glEnd();

    glBegin(GL_POLYGON); // backroundnya
        glColor3ub(230,231,232);
        glVertex2d(556,209);
        glVertex2d(601,183);
        glVertex2d(601,186);
        glVertex2d(556,212);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 1
        glColor3ub(98,94,112);
        glVertex2d(512,133);
        glVertex2d(556,207);
        glVertex2d(470,157);
    glEnd();

    glBegin(GL_POLYGON); // segitiga 2
        glColor3ub(128,123,146);
        glVertex2d(512,133);
        glVertex2d(598,183);
        glVertex2d(556,207);
    glEnd();

    int i, c=0;
    int a[6] = {139,146,153,160,167,174};
    int b[3] = {151,144,139};

    for(i=512;i<598;i++){
        if(i==524 || i==537 || i==549 || i==561 || i==573 || i==585){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,a[c]);
                glVertex2d(i+1,a[c]+1);
                glVertex2d(i-44,a[c]+27);
                glVertex2d(i-42,a[c]+25);
            glEnd();
            c++;
        }
    }
    c =0;
    for(i=470;i<512;i++){
        if(i==479 || i==490|| i==501){
            glBegin(GL_POLYGON);
                glColor3ub(241,241,242);
                glVertex2d(i,b[c]);
                glVertex2d(i+1,b[c]-1);
                glVertex2d(i+88,b[c]+52);
                glVertex2d(i+86,b[c]+53);
            glEnd();
            c++;
        }
    }
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Rumah - G64160049", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        bg();
        tanah();
        jalan();
        rumput();
        pagar();
        tembok_kiri();
        gedung_putih();
        kaca_gedung_putih();
        pintu();
        rumah_coklat();
        jendela_kanan();
        alas_lantai();
        atap();
        jendela1();
        jendela2();
        jendela3();
        jendela4();
        jendela5();
        jendela6();
        jendela_kiri_atas();
        jendela_kiri_bawah();
        pohon_kotak();
        pohon_kotak2();
        pohon_segitiga();
        SolarPanel1();
        SolarPanel2();
        SolarPanel3();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
