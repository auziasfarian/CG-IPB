#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClearColor(1,1,1,1);
}

void display()
{


}

void lampu(){
     glBegin(GL_POLYGON);
glColor3ub(71, 71, 68);

glVertex2d(328.33,368.73);
glVertex2d(330.33,368.72);
glVertex2d(330.33,381.07);
glVertex2d(328,381.07);
glEnd();
//batang kanan
    glBegin(GL_POLYGON);
glColor3ub(71, 71, 68);

glVertex2d(595.67,368.73);
glVertex2d(598,368.73);
glVertex2d(598,381.07);
glVertex2d(595.67,381.07);
glEnd();
    //
glBegin(GL_POLYGON);
  srand(time(NULL));
 int a=rand()%255,b=rand()%255,c=rand()%255;
 glColor3ub(a,b,c);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(329+cos(rad)*11,359+sin(rad)*11);
   }
   glEnd();

   //

   glBegin(GL_POLYGON);
  srand(time(NULL));
 int x=rand()%255,y=rand()%255,z=rand()%255;
 glColor3ub(x,y,z);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(597+cos(rad)*11,360+sin(rad)*11);
   }
   glEnd();

}




void tanaman(){

glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(272.61,381.07);
glVertex2d(304.36,365.82);
glVertex2d(304.36,376.57);
glVertex2d(272.61,392.32);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(265.67,379.07);
glVertex2d(298.67,362.48);
glVertex2d(304.36,365.82);
glVertex2d(272.61,381.07);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(265.67,379.07);
glVertex2d(272.61,381.07);
glVertex2d(272.61,392.32);
glVertex2d(265.67,389.43);
glEnd();
//TANAMAN TENGAH
glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(231.921,402);
glVertex2d(263.67,386.75);
glVertex2d(263.67,397.5);
glVertex2d(231.92,413.25);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(224.98,400.98);
glVertex2d(257.98,383.55);
glVertex2d(263.67,386.89);
glVertex2d(231.92,402.14);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(224.98,400);
glVertex2d(231.92,402);
glVertex2d(231.92,413.25);
glVertex2d(224.98,410.37);
glEnd();
//tanaman kiri
glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(189.58,423.88);
glVertex2d(221.33,408.63);
glVertex2d(221.33,419.38);
glVertex2d(189.58,435.13);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(182.64,422.32);
glVertex2d(215.64,405.73);
glVertex2d(221.33,409.07);
glVertex2d(189.58,424.32);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(182.64,421.88);
glVertex2d(189.58,423.88);
glVertex2d(189.58,435.13);
glVertex2d(182.64,432.25);
glEnd();
// 3 terbaru di kiri

glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(146.08,446.95);
glVertex2d(177.83,431.7);
glVertex2d(177.83,442.13);
glVertex2d(146.08,457.51);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(139.14,444.95);
glVertex2d(172.14,428.36);
glVertex2d(177.83,431.7);
glVertex2d(146.08,446.95);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(139.14,444.95);
glVertex2d(146.08,446.95);
glVertex2d(146.08,457.51);
glVertex2d(139.14,454.62);
glEnd();
// tanaman terkiri
glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(104.08,466.11);
glVertex2d(135.83,450.86);
glVertex2d(135.83,461.61);
glVertex2d(104.08,477.36);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(97.14,464.8);
glVertex2d(130.14,448.21);
glVertex2d(135.83,451.55);
glVertex2d(104.08,466.8);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(97.14,464.8);
glVertex2d(104.08,466.8);
glVertex2d(104.08,477.28);
glVertex2d(97.14,474.4);
glEnd();


}


void tanaman2(){

glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(623.41,351.64);
glVertex2d(655.16,366.89);
glVertex2d(655.16,378.14);
glVertex2d(623.41,362.39);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(629.1,347.98);
glVertex2d(662.1,364.57);
glVertex2d(655.16,366.57);
glVertex2d(623.41,351.32);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(655.16,366.38);
glVertex2d(662.1,364.38);
glVertex2d(662.1,374.74);
glVertex2d(655.16,377.63);
glEnd();
//ditengah
glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(662.1,371);
glVertex2d(693.85,386.25);
glVertex2d(693.85,397.5);
glVertex2d(662.1,381.75);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(667.79,368.33);
glVertex2d(700.79,384.92);
glVertex2d(693.85,386.92);
glVertex2d(662.1,371.67);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(693.85,386.25);
glVertex2d(700.79,384.25);
glVertex2d(700.79,394.62);
glVertex2d(693.85,397.5);
glEnd();
// akhir
glBegin(GL_POLYGON);
glColor3ub(57, 132, 58);

glVertex2d(702.65,392.13);
glVertex2d(734.4,406.79);
glVertex2d(734.4,418.63);
glVertex2d(702.65,402.88);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(69, 201, 102);

glVertex2d(708.34,388.21);
glVertex2d(741.34,404.79);
glVertex2d(734.4,406.79);
glVertex2d(702.65,391.54);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(11, 111, 46);

glVertex2d(734.4,407.38);
glVertex2d(741.34,405.38);
glVertex2d(741.34,415.74);
glVertex2d(734.4,418.63);
glEnd();

}

void rumah(){
    //item atas
glBegin(GL_POLYGON);
glColor3ub(33, 27, 27);

glVertex2d(362,327.93);
glVertex2d(475,272.13);
glVertex2d(564.04,314.42);
glVertex2d(452.5,371.13);

glEnd();
//coklat atap
glBegin(GL_POLYGON);
glColor3ub(155, 122, 86);

glVertex2d(385.75,328.33);
glVertex2d(477.54,283);
glVertex2d(538.75,313.27);
glVertex2d(452.16,360.16);

glEnd();

//cokalt muda samping kiri
glBegin(GL_POLYGON);
glColor3ub(117, 90, 57);

glVertex2d(362,327.93);
glVertex2d(388.21,340.44);
glVertex2d(388.21,396.88);
glVertex2d(361.67,381.99);

glEnd();

//item bawah kiri
glBegin(GL_POLYGON);
glColor3ub(33, 27, 27);

glVertex2d(361.67,381.99);
glVertex2d(382.91,393.9);
glVertex2d(376.97,396.88);
glVertex2d(362.18,388.82);

glEnd();
//coklat bayangan tua kiri
glBegin(GL_POLYGON);
glColor3ub(104, 80, 54);

glVertex2d(388.21,353.13);
glVertex2d(402.99,360.16);
glVertex2d(402.25,384.78);
glVertex2d(388.21,391.38);

glEnd();
//garis coklat atas kanan
glBegin(GL_POLYGON);
glColor3ub(117, 90, 57);

glVertex2d(452.5,371.05);
glVertex2d(557.1,317.22);
glVertex2d(558,328.75);
glVertex2d(452.5,384.59);

glEnd();
//garis coklat atas kiri
glBegin(GL_POLYGON);
glColor3ub(117, 90, 57);

glVertex2d(388.21,340.37);
glVertex2d(452.5,371.05);
glVertex2d(452.5,384.59);
glVertex2d(388.21,353.13);

glEnd();
//tiang kanan coklat
glBegin(GL_POLYGON);
glColor3ub(117, 90, 57);

glVertex2d(555.94,318);
glVertex2d(564.04,314.42);
glVertex2d(565.77,365.82);
glVertex2d(557.44,370.25);

glEnd();
//bayangan kanan coklat tua
glBegin(GL_POLYGON);
glColor3ub(104, 80, 54);

glVertex2d(532.54,342.3);
glVertex2d(556.5,329.45);
glVertex2d(557.44,370.25);
glVertex2d(534.33,365.82);

glEnd();
//kaca kanan
glBegin(GL_POLYGON);
glColor3ub(129, 179, 172);

glVertex2d(452.5,384.59);
glVertex2d(532.54,342.3);
glVertex2d(534.33,365.82);
glVertex2d(453.27,407.5);

glEnd();

//kaca kiri
glBegin(GL_POLYGON);
glColor3ub(129, 179, 172);

glVertex2d(402.99,360.16);
glVertex2d(452.9,384.59);
glVertex2d(453.67,407.5);
glVertex2d(402.25,384.78);

glEnd();

//ubin putih kanan
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(453.67,407.5);
glVertex2d(534.33,365.82);
glVertex2d(557.44,370.25);
glVertex2d(473.02,415.03);

glEnd();

//ubin kiri
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(402.43,383.83);
glVertex2d(473.02,415.03);
glVertex2d(434,435.2);
glVertex2d(365.54,402.33);

glEnd();

//sekat bawah kiri
glBegin(GL_POLYGON);
glColor3ub(212, 182, 157);

glVertex2d(365.54,402.33);
glVertex2d(434,435.2);
glVertex2d(434,441.43);
glVertex2d(365.54,409.37);

glEnd();
//sekat kanan bawah
glBegin(GL_POLYGON);
glColor3ub(175, 152, 135);

glVertex2d(434,435.32);
glVertex2d(565.77,365.82);
glVertex2d(565.77,372.55);
glVertex2d(434,441.43);

glEnd();

//pijakan kiri atas
glBegin(GL_POLYGON);
glColor3ub(82, 76, 78);

glVertex2d(362.18,388.82);
glVertex2d(365.54,390.65);
glVertex2d(365.54,396.88);
glVertex2d(362.18,396.88);

glEnd();
//pijakan kiri bawah
glBegin(GL_POLYGON);
glColor3ub(82, 76, 78);

glVertex2d(365.54,409.37);
glVertex2d(369.97,411.13);
glVertex2d(369.67,416.63);
glVertex2d(365.54,416.63);

glEnd();

//pijakan kanan bawah
glBegin(GL_POLYGON);
glColor3ub(82, 76, 78);

glVertex2d(429,439.09);
glVertex2d(434,441.43);
glVertex2d(434,447);
glVertex2d(429,447);

glEnd();
//pijakan kanan atas
glBegin(GL_POLYGON);
glColor3ub(82, 76, 78);

glVertex2d(560.85,374.83);
glVertex2d(565.77,372.25);
glVertex2d(565.77,381);
glVertex2d(560.85,381);

glEnd();


//kolam renag
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(379.27,480.7);
glVertex2d(505.36,413.46);
glVertex2d(586.83,452.38);
glVertex2d(454.83,521.04);

glEnd();

//
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(406.38,482.33);
glVertex2d(506.13,431.65);
glVertex2d(559.71,457.56);
glVertex2d(459.51,509.66);

glEnd();

//
glBegin(GL_POLYGON);
glColor3ub(99, 175, 224);

glVertex2d(412.04,482.66);
glVertex2d(506.05,434.64);
glVertex2d(554.05,458.66);
glVertex2d(459.39,506.66);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(131, 206, 242);

glVertex2d(506.05,434.66);
glVertex2d(554.05,458.66);
glVertex2d(551.21,460.09);
glVertex2d(506.05,437.74);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(84, 143, 163);

glVertex2d(412.04,482.66);
glVertex2d(506.05,434.66);
glVertex2d(506.05,437.74);
glVertex2d(415.67,484.49);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(154, 123, 89);

glVertex2d(379.27,480.7);
glVertex2d(454.83,520.81);
glVertex2d(454.83,526.77);
glVertex2d(379.27,486.78);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(206, 178, 160);

glVertex2d(454.83,520.81);
glVertex2d(586.83,452.15);
glVertex2d(587.67,458.44);
glVertex2d(454.83,526.77);

glEnd();
//tangga kecil
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(441.04,437.74);
glVertex2d(471.24,421.88);
glVertex2d(476.67,425);
glVertex2d(447,441.43);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(216, 216, 216);

glVertex2d(447,441.43);
glVertex2d(476.67,425);
glVertex2d(476.67,429.83);
glVertex2d(447,445.67);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(154, 155, 154);

glVertex2d(441.04,437.74);
glVertex2d(447,441.43);
glVertex2d(447,445.67);
glVertex2d(441.04,441.7);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(209, 209, 208);

glVertex2d(447.83,433);
glVertex2d(469.5,421.88);
glVertex2d(469.5,425);
glVertex2d(447,436.83);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(216, 216, 216);

glVertex2d(444.83,431.66);
glVertex2d(466.67,420.67);
glVertex2d(469.5,421.88);
glVertex2d(447.83,433);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(154, 155, 154);

glVertex2d(444.83,431.66);
glVertex2d(447.83,433);
glVertex2d(447.83,436.83);
glVertex2d(444.83,435.75);

glEnd();
//kaca jendela tmbahan
glBegin(GL_POLYGON);
glColor3ub(73, 96, 92);

glVertex2d(367.42,338.8);
glVertex2d(377.16,343.46);
glVertex2d(377.16,385.49);
glVertex2d(367.42,381.34);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(129, 179, 172);

glVertex2d(369.67,342.3);
glVertex2d(374.94,345);
glVertex2d(374.94,381.99);
glVertex2d(369.67,379.07);

glEnd();
//bayangan atap
glBegin(GL_POLYGON);
glColor3ub(86, 69, 54);

glVertex2d(385.75,328.33);
glVertex2d(477.54,283);
glVertex2d(477.67,286.67);
glVertex2d(389.44,330.1);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(196, 152, 108);

glVertex2d(477.54,283);
glVertex2d(538.75,313.27);
glVertex2d(534.33,315.67);
glVertex2d(477.67,286.67);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(196, 152, 108);

glVertex2d(477.54,283);
glVertex2d(538.75,313.27);
glVertex2d(534.33,315.67);
glVertex2d(477.67,286.67);

glEnd();
//pintu
glBegin(GL_POLYGON);
glColor3ub(73, 96, 92);

glVertex2d(454.83,383.02);
glVertex2d(471.87,373.99);
glVertex2d(472.34,398);
glVertex2d(455.21,406.85);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(193, 177, 97);

glVertex2d(458.09,389.66);
glVertex2d(460.01,389.66);
glVertex2d(460.01,396.03);
glVertex2d(458.09,396.03);
glEnd();
//atap rumah baru
glBegin(GL_POLYGON);
glColor3ub(33, 27, 27);

glVertex2d(491.7,284.25);
glVertex2d(538.75,261.67);
glVertex2d(538.75,313.27);
glVertex2d(491.7,338.75);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(33, 27, 27);

glVertex2d(432.3,258.25);
glVertex2d(479.67,233.92);
glVertex2d(538.75,261.67);
glVertex2d(493.4,285.71);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(33, 27, 27);

glVertex2d(432.3,258.25);
glVertex2d(493.4,285.71);
glVertex2d(491.7,338.75);
glVertex2d(432.3,309);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(107, 85, 63);

glVertex2d(446.03,257.58);
glVertex2d(478.69,240.25);
glVertex2d(524.53,261);
glVertex2d(490.73,276.25);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(86, 69, 54);

glVertex2d(445.92,257.58);
glVertex2d(478.69,240.25);
glVertex2d(478.58,246.08);
glVertex2d(451.42,259.88);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(132, 118, 82);

glVertex2d(478.58,240.25);
glVertex2d(524.42,261);
glVertex2d(518.7,263.58);
glVertex2d(478.58,246.08);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(68, 59, 35);

glVertex2d(433.77,263.17);
glVertex2d(458.28,273.83);
glVertex2d(458.28,302.83);
glVertex2d(433.77,289.92);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(127, 85, 43);

glVertex2d(456.87,291.06);
glVertex2d(481.37,301.73);
glVertex2d(481.37,330.72);
glVertex2d(456.87,317.87);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(122, 100, 54);

glVertex2d(439.35,278.94);
glVertex2d(456.87,286.56);
glVertex2d(456.87,309);
glVertex2d(439.35,300.44);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(61, 55, 44);

glVertex2d(465.41,285.71);
glVertex2d(482.93,293.34);
glVertex2d(482.93,315.78);
glVertex2d(465.41,307.21);
glEnd();

}

void tanah(){
glBegin(GL_POLYGON);
glColor3ub(108, 176, 99);

glVertex2d(479.67,265.58);
glVertex2d(779.67,416.83);
glVertex2d(347.67,640.58);
glVertex2d(46.67,486.78);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(72, 145, 61);

glVertex2d(46.67,486.78);
glVertex2d(347.67,640.58);
glVertex2d(347.67,661.33);
glVertex2d(46.67,507.33);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(28, 89, 17);

glVertex2d(347.67,640.58);
glVertex2d(779.67,416.83);
glVertex2d(779.67,435.2);
glVertex2d(347.67,661.33);

glEnd();
//bayangan

//
glBegin(GL_POLYGON);
glColor3ub(82, 124, 76);

glVertex2d(292.35,384.84);
glVertex2d(447.71,305.45);
glVertex2d(575.2,370.17);
glVertex2d(427.51,450.83);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(67, 99, 62);
glVertex2d(293.29,384.17);
glVertex2d(380.83,339.44);
glVertex2d(384.96,356.26);
glVertex2d(321.68,386.47);
glEnd();
}

void jalan(){
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(395.79,436.86);
glVertex2d(410.79,444.98);
glVertex2d(403.04,449.23);
glVertex2d(388.54,441.11);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(379.03,449.23);
glVertex2d(394.03,457.36);
glVertex2d(386.28,461.61);
glVertex2d(371.78,453.48);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(363.55,461.06);
glVertex2d(378.55,469.19);
glVertex2d(370.8,473.44);
glVertex2d(356.3,465.31);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(343.79,470.69);
glVertex2d(358.79,478.82);
glVertex2d(351.04,483.07);
glVertex2d(336.54,474.94);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(324.13,483.27);
glVertex2d(339.13,491.4);
glVertex2d(331.38,495.65);
glVertex2d(316.88,487.52);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(345.46,499.49);
glVertex2d(359.12,491.49);
glVertex2d(366.87,495.74);
glVertex2d(351.71,503.74);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(360.58,511.53);
glVertex2d(376.25,503.53);
glVertex2d(384,507.78);
glVertex2d(368.83,515.78);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(378.55,522.92);
glVertex2d(394.21,514.92);
glVertex2d(401.96,519.17);
glVertex2d(386.8,527.17);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(400.33,531.28);
glVertex2d(416,523.28);
glVertex2d(423.75,527.53);
glVertex2d(408.58,535.53);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(419.35,546.06);
glVertex2d(435.61,538.06);
glVertex2d(443.65,542.31);
glVertex2d(427.91,550.31);

glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(211, 209, 186);

glVertex2d(446.96,558.72);
glVertex2d(462.63,550.72);
glVertex2d(470.38,554.97);
glVertex2d(455.21,562.97);

glEnd();
// putih2 di kiri
glBegin(GL_POLYGON);
glColor3ub(171, 161, 151);

glVertex2d(192.17,508.55);
glVertex2d(231.92,484.55);
glVertex2d(271.67,505.75);
glVertex2d(229.67,528.76);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(229, 229, 229);

glVertex2d(266.21,462.97);
glVertex2d(270.36,460.47);
glVertex2d(270.36,505.68);
glVertex2d(266.64,508.63);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(229, 229, 229);

glVertex2d(230.61,483.95);
glVertex2d(235.11,481.95);
glVertex2d(235.11,527.45);
glVertex2d(230.61,529.54);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(229, 229, 229);

glVertex2d(192.17,462.99);
glVertex2d(196.67,464.99);
glVertex2d(196.67,510.58);
glVertex2d(192.17,508.49);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(201, 202, 199);

glVertex2d(190.86,462.99);
glVertex2d(231.86,441.49);
glVertex2d(270.36,460.49);
glVertex2d(230.61,484.49);
glEnd();


}

void rambat(){
glBegin(GL_POLYGON);
glColor3ub(34, 76, 28);

glVertex2d(233.65,477.24);
glVertex2d(238.06,477.24);
glVertex2d(238.06,481.26);
glVertex2d(233.65,481.26);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(34, 76, 28);

glVertex2d(231.92,480.7);
glVertex2d(236.25,480.7);
glVertex2d(236.25,484.49);
glVertex2d(231.92,484.49);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(34, 76, 28);

glVertex2d(228.45,479.25);
glVertex2d(232.86,479.25);
glVertex2d(232.86,483.27);
glVertex2d(228.45,483.27);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(73, 122, 66);

glVertex2d(224.74,479.25);
glVertex2d(229.05,475.6);
glVertex2d(232.14,479.25);
glVertex2d(227.83,482.9);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(17, 61, 7);

glVertex2d(230.65,482.9);
glVertex2d(232.82,482.9);
glVertex2d(232.82,508.63);
glVertex2d(230.65,508.63);
glEnd();
//bayangan
glBegin(GL_POLYGON);
glColor3ub(147, 147, 140);

glVertex2d(365.54,402.33);
glVertex2d(402.43,383.83);
glVertex2d(415.1,389.43);
glVertex2d(380.5,409.51);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(147, 147, 140);

glVertex2d(379.27,396.03);
glVertex2d(404.43,383.83);
glVertex2d(433.36,397.5);
glVertex2d(387.16,403.62);
glEnd();
}

void langit(){
glBegin(GL_POLYGON);
glColor3ub(17, 20, 71);

glVertex2d(46.67,253);
glVertex2d(477.67,51);
glVertex2d(479.67,265.58);
glVertex2d(46.67,486.78);
glEnd();
//
glBegin(GL_POLYGON);
glColor3ub(17, 20, 71);

glVertex2d(477.67,51);
glVertex2d(779.67,172);
glVertex2d(779.67,416.83);
glVertex2d(479.67,265.58);
glEnd();
//
glBegin(GL_POLYGON);
  srand(time(NULL));
 glColor3ub(247,247,62);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(500+cos(rad)*25,110+sin(rad)*25);
   }
   glEnd();

   //awan
   glBegin(GL_POLYGON);
  srand(time(NULL));
 glColor3ub(156,158,173);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(430+cos(rad)*22,120+sin(rad)*22);
   }
   glEnd();
//
 glBegin(GL_POLYGON);
  srand(time(NULL));
 glColor3ub(156,158,173);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(450+cos(rad)*45,130+sin(rad)*20);
   }
   glEnd();
   //
   glBegin(GL_POLYGON);
  srand(time(NULL));
 glColor3ub(156,158,173);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
    glVertex2f(465+cos(rad)*15,115+sin(rad)*15);
   }
   glEnd();
}

int main(void){
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Maya Maharani-<G64160021>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        tanah();
        langit();
        tanaman();
        tanaman2();
        rumah();
        lampu();
        jalan();
        rambat();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
