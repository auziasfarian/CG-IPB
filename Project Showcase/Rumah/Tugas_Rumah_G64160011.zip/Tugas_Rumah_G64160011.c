#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define xmin 0
#define xmax 1000
#define ymin 1000
#define ymax 0

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}
void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width * 10 / (float) height;
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(xmin, xmax, ymin, ymax, 1, -1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void circle(float size)
{
    int i, N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}
void langit ()
{
    glBegin(GL_POLYGON);
        glColor3ub(69,49,143);
        glVertex2d( 0 , 0 );
        glVertex2d( 1000 , 0 );
        glColor3ub(37,101,163);
        glVertex2d( 1000 , 1000 );
        glVertex2d( 0 , 1000 );
    glEnd();
}
void bulan() {

    glTranslated(348*2,177*2,0);
    glColor3ub(42,16,72);
    circle(70);
    glTranslated(-348*2,-177*2,0);
}
void bintang(){

        glPointSize(2.f);
        glColor3ub(255,255,255);
        glBegin(GL_POINTS);
        //glScalef((float)glfwGetTime()*0.1,(float)glfwGetTime()*0.1,0);
        glVertex2f(rand()%1000,rand()%500);
        glEnd();
}
void awan ()
{
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 746 , 538 );
        glVertex2d( 514 , 574 );
        glVertex2d( 524 , 546 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 514 , 574 );
        glVertex2d( 524 , 546 );
        glVertex2d( 480 , 536 );
        glVertex2d( 320 , 540 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 480 , 536 );
        glVertex2d( 320 , 540 );
        glVertex2d( 382 , 512 );
        glVertex2d( 600 , 510 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 320 , 540 );
        glVertex2d( 382 , 512 );
        glVertex2d( 292 , 500 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 382 , 512 );
        glVertex2d( 292 , 500 );
        glVertex2d( 416 , 500 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(84,79,157);
        glVertex2d( 292 , 500 );
        glVertex2d( 416 , 500 );
        glVertex2d( 514 , 488 );
        glVertex2d( 514 , 488 );
    glEnd();
}
void awan2 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 644 , 408 );
		glVertex2d( 390 , 426 );
		glVertex2d( 400 , 408 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 390 , 426 );
		glVertex2d( 400 , 408 );
		glVertex2d( 272 , 408 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 400 , 408 );
		glVertex2d( 272 , 408 );
		glVertex2d( 234 , 382 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 272 , 408 );
		glVertex2d( 234 , 382 );
		glVertex2d( 190 , 424 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 234 , 382 );
		glVertex2d( 190 , 424 );
		glVertex2d( 0 , 424 );
		glVertex2d( 0 , 406 );
	glEnd();
}
void awan3 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 1000 , 218 );
		glVertex2d( 1000 , 252 );
		glVertex2d( 796 , 240 );
		glVertex2d( 808 , 208 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 796 , 240 );
		glVertex2d( 808 , 208 );
		glVertex2d( 588 , 276 );
		glVertex2d( 592 , 292 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(84,79,157);
		glVertex2d( 588 , 276 );
		glVertex2d( 592 , 292 );
		glVertex2d( 480 , 282 );
	glEnd();
}
void gunung ()
{
	glBegin(GL_POLYGON);
		glColor3ub(54,52,132);
		glVertex2d( 482 , 720 );
		glVertex2d( 332 , 806 );
		glVertex2d( 250 , 584 );
		glVertex2d( 306 , 468 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(54,52,132);
		glVertex2d( 332 , 806 );
		glVertex2d( 250 , 584 );
		glVertex2d( 112 , 340 );
		glVertex2d( 0 , 520 );
		glVertex2d( 0 , 740 );
	glEnd();
}
void gunung2 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(59,34,127);
		glVertex2d( 1000 , 532 );
		glVertex2d( 1000 , 810 );
		glVertex2d( 966 , 940 );
		glVertex2d( 640 , 626 );
		glVertex2d( 876 , 376 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(59,34,127);
		glVertex2d( 966 , 940 );
		glVertex2d( 640 , 626 );
		glVertex2d( 506 , 526 );
		glVertex2d( 202 , 756 );
		glVertex2d( 108 , 988 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(59,34,127);
		glVertex2d( 202 , 756 );
		glVertex2d( 108 , 988 );
		glVertex2d( 0 , 938 );
		glVertex2d( 0 , 500 );
	glEnd();
}
void gunung3 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 0 , 500 );
		glVertex2d( 0 , 620 );
		glVertex2d( 18 , 608 );
		glVertex2d( 48 , 562 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 18 , 608 );
		glVertex2d( 48 , 562 );
		glVertex2d( 118 , 650 );
		glVertex2d( 48 , 716 );
		glVertex2d( 0 , 734 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 118 , 650 );
		glVertex2d( 48 , 716 );
		glVertex2d( 36 , 846 );
		glVertex2d( 164 , 818 );
		glVertex2d( 202 , 756 );
	glEnd();
}
void gunung4 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(45,45,112);
		glVertex2d( 250 , 584 );
		glVertex2d( 202 , 616 );
		glVertex2d( 178 , 558 );
		glVertex2d( 142 , 478 );
		glVertex2d( 112 , 340 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(45,45,112);
		glVertex2d( 178 , 558 );
		glVertex2d( 142 , 478 );
		glVertex2d( 142 , 574 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(45,45,112);
		glVertex2d( 142 , 478 );
		glVertex2d( 112 , 340 );
		glVertex2d( 122 , 482 );
	glEnd();
}
void gunung5 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 1000 , 540 );
		glVertex2d( 1000 , 940 );
		glVertex2d( 808 , 860 );
		glVertex2d( 826 , 818 );
		glVertex2d( 856 , 660 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 1000 , 540 );
		glVertex2d( 856 , 660 );
		glVertex2d( 840 , 644 );
		glVertex2d( 886 , 526 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 1000 , 540 );
		glVertex2d( 886 , 526 );
		glVertex2d( 856 , 484 );
		glVertex2d( 876 , 376 );
	glEnd();
}
void gunung6 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 640 , 626 );
		glVertex2d( 550 , 856 );
		glVertex2d( 472 , 852 );
		glVertex2d( 528 , 620 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 640 , 626 );
		glVertex2d( 528 , 620 );
		glVertex2d( 506 , 526 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(52,28,109);
		glVertex2d( 528 , 620 );
		glVertex2d( 506 , 526 );
		glVertex2d( 482 , 626 );
	glEnd();
}
void gunung7 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(45,45,112);
		glVertex2d( 404 , 602 );
		glVertex2d( 346 , 654 );
		glVertex2d( 346 , 574 );
		glVertex2d( 362 , 544 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(45,45,112);
		glVertex2d( 346 , 574 );
		glVertex2d( 362 , 544 );
		glVertex2d( 310 , 474 );
		glVertex2d( 324 , 582 );
	glEnd();
}
void gunung8 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 1000 , 782 );
		glVertex2d( 1000 , 864 );
		glVertex2d( 416 , 916 );
		glVertex2d( 396 , 810 );
		glVertex2d( 640 , 680 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 416 , 916 );
		glVertex2d( 396 , 810 );
		glVertex2d( 184 , 656 );
		glVertex2d( 0 , 818 );
		glVertex2d( 0 , 954 );
	glEnd();
}
void gunung9 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 640 , 680 );
		glVertex2d( 726 , 810 );
		glVertex2d( 650 , 884 );
		glVertex2d( 376 , 888 );
		glVertex2d( 396 , 810 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 376 , 888 );
		glVertex2d( 396 , 810 );
		glVertex2d( 184 , 656 );
		glVertex2d( 218 , 806 );
	glEnd();
}
void tanah ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 1000 , 842 );
		glVertex2d( 458 , 854 );
		glVertex2d( 250 , 896 );
		glVertex2d( 0 , 1000 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 250 , 896 );
		glVertex2d( 0 , 1000 );
		glVertex2d( 0 , 858 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 1000 , 842 );
		glVertex2d( 1000 , 1000 );
		glVertex2d( 0 , 1000 );
	glEnd();
}
void rumah ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 584 , 744 );
		glVertex2d( 718 , 794 );
		glVertex2d( 464 , 858 );
		glVertex2d( 332 , 808 );
	glEnd();
}
void rumah1 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 528 , 902 );
		glVertex2d( 714 , 852 );
		glVertex2d( 714 , 856 );
		glVertex2d( 526 , 926 );
	glEnd();
}
void rumah2 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 312 , 802 );
		glVertex2d( 360 , 820 );
		glVertex2d( 356 , 894 );
		glVertex2d( 346 , 888 );
		glVertex2d( 318 , 878 );
		glVertex2d( 306 , 876 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 318 , 878 );
		glVertex2d( 306 , 876 );
		glVertex2d( 304 , 896 );
		glVertex2d( 316 , 900 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 356 , 894 );
		glVertex2d( 346 , 888 );
		glVertex2d( 346 , 910 );
		glVertex2d( 356 , 914 );
	glEnd();
}
void rumah3 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 320 , 800 );
		glVertex2d( 368 , 818 );
		glVertex2d( 360 , 820 );
		glVertex2d( 312 , 802 );
	glEnd();
}
void rumah4 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 360 , 820 );
		glVertex2d( 368 , 818 );
		glVertex2d( 364 , 882 );
		glVertex2d( 362 , 918 );
		glVertex2d( 356 , 920 );
		glVertex2d( 356 , 914 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 356 , 920 );
		glVertex2d( 356 , 914 );
		glVertex2d( 304 , 928 );
		glVertex2d( 304 , 932 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 364 , 882 );
		glVertex2d( 362 , 918 );
		glVertex2d( 376 , 914 );
		glVertex2d( 378 , 884 );
	glEnd();
}
void rumah5 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 352 , 914 );
		glVertex2d( 356 , 914 );
		glVertex2d( 304 , 928 );
		glVertex2d( 302 , 926 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 304 , 928 );
		glVertex2d( 302 , 926 );
		glVertex2d( 304 , 932 );
		glVertex2d( 302 , 932 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 306 , 896 );
		glVertex2d( 308 , 898 );
		glVertex2d( 258 , 910 );
		glVertex2d( 256 , 908 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 258 , 910 );
		glVertex2d( 256 , 908 );
		glVertex2d( 256 , 914 );
		glVertex2d( 258 , 914 );
	glEnd();
}
void rumah6 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 258 , 910 );
		glVertex2d( 258 , 914 );
		glVertex2d( 308 , 898 );
	glEnd();
}
void rumah7 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(28,12,51);
		glVertex2d( 258 , 914 );
		glVertex2d( 308 , 898 );
		glVertex2d( 316 , 900 );
		glVertex2d( 346 , 910 );
		glVertex2d( 352 , 914 );
		glVertex2d( 302 , 926 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(28,12,51);
		glVertex2d( 258 , 914 );
		glVertex2d( 302 , 926 );
		glVertex2d( 302 , 930 );
	glEnd();
}
void rumah8 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 318 , 878 );
		glVertex2d( 320 , 878 );
		glVertex2d( 318 , 900 );
		glVertex2d( 316 , 900 );
	glEnd();
}
void rumah9 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 320 , 880 );
		glVertex2d( 346 , 888 );
		glVertex2d( 346 , 910 );
		glVertex2d( 320 , 900 );
	glEnd();
}
void rumah10 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 366 , 824 );
		glVertex2d( 368 , 822 );
		glVertex2d( 464 , 858 );
		glVertex2d( 464 , 860 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 464 , 858 );
		glVertex2d( 464 , 860 );
		glVertex2d( 630 , 816 );
		glVertex2d( 634 , 818 );
	glEnd();
}
void rumah11 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,21,84);
		glVertex2d( 378 , 886 );
		glVertex2d( 460 , 916 );
		glVertex2d( 460 , 940 );
		glVertex2d( 376 , 910 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(42,21,84);
		glVertex2d( 460 , 916 );
		glVertex2d( 460 , 940 );
		glVertex2d( 494 , 932 );
		glVertex2d( 494 , 910 );
	glEnd();
}
void rumah12 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(64,29,119);
		glVertex2d( 366 , 824 );
		glVertex2d( 464 , 860 );
		glVertex2d( 460 , 920 );
		glVertex2d( 362 , 882 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(64,29,119);
		glVertex2d( 464 , 860 );
		glVertex2d( 460 , 920 );
		glVertex2d( 630 , 876 );
		glVertex2d( 634 , 818 );
	glEnd();
}
void rumah13 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 638 , 814 );
		glVertex2d( 740 , 788 );
		glVertex2d( 736 , 852 );
		glVertex2d( 634 , 878 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 328 , 802 );
		glVertex2d( 334 , 804 );
		glVertex2d( 492 , 764 );
		glVertex2d( 492 , 762 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 492 , 756 );
		glVertex2d( 516 , 770 );
		glVertex2d( 516 , 790 );
		glVertex2d( 492 , 782 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 492 , 756 );
		glVertex2d( 516 , 770 );
		glVertex2d( 562 , 782 );
		glVertex2d( 562 , 788 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 562 , 782 );
		glVertex2d( 562 , 788 );
		glVertex2d( 648 , 766 );
		glVertex2d( 656 , 758 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 648 , 766 );
		glVertex2d( 656 , 758 );
		glVertex2d( 654 , 784 );
		glVertex2d( 648 , 786 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 498 , 756 );
		glVertex2d( 500 , 756 );
		glVertex2d( 584 , 736 );
		glVertex2d( 584 , 734 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 584 , 736 );
		glVertex2d( 584 , 734 );
		glVertex2d( 650 , 758 );
		glVertex2d( 648 , 758 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(50,22,91);
		glVertex2d( 656 , 764 );
		glVertex2d( 654 , 766 );
		glVertex2d( 716 , 790 );
		glVertex2d( 720 , 788 );
	glEnd();
}
void rumah14 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(24,11,45);
		glVertex2d( 630 , 810 );
		glVertex2d( 638 , 814 );
		glVertex2d( 634 , 878 );
		glVertex2d( 626 , 874 );
	glEnd();
}
void rumah15 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(42,16,72);
		glVertex2d( 630 , 810 );
		glVertex2d( 638 , 814 );
		glVertex2d( 732 , 784 );
		glVertex2d( 740 , 788 );
	glEnd();
}
void rumah16 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(0,0,0);
		glVertex2d( 494 , 910 );
		glVertex2d( 528 , 902 );
		glVertex2d( 526 , 926 );
		glVertex2d( 494 , 922 );
	glEnd();
}
void rumah17 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 460 , 940 );
		glVertex2d( 484 , 950 );
		glVertex2d( 502 , 946 );
		glVertex2d( 490 , 942 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 490 , 942 );
		glVertex2d( 460 , 940 );
		glVertex2d( 494 , 932 );
		glVertex2d( 500 , 940 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 490 , 942 );
		glVertex2d( 494 , 922 );
		glVertex2d( 526 , 926 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 490 , 942 );
		glVertex2d( 500 , 940 );
		glVertex2d( 628 , 908 );
		glVertex2d( 622 , 900 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 628 , 908 );
		glVertex2d( 622 , 900 );
		glVertex2d( 714 , 876 );
		glVertex2d( 760 , 896 );
		glVertex2d( 662 , 920 );
	glEnd();
}
void rumah18 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(28,12,51);
		glVertex2d( 376 , 910 );
		glVertex2d( 376 , 914 );
		glVertex2d( 484 , 954 );
		glVertex2d( 484 , 950 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(28,12,51);
		glVertex2d( 484 , 954 );
		glVertex2d( 484 , 950 );
		glVertex2d( 502 , 946 );
		glVertex2d( 502 , 950 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(28,12,51);
		glVertex2d( 628 , 908 );
		glVertex2d( 662 , 920 );
		glVertex2d( 662 , 924 );
		glVertex2d( 628 , 910 );
	glEnd();
}
void rumah19 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 490 , 942 );
		glVertex2d( 496 , 944 );
		glVertex2d( 628 , 910 );
		glVertex2d( 628 , 908 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(32,14,58);
		glVertex2d( 662 , 920 );
		glVertex2d( 760 , 896 );
		glVertex2d( 760 , 898 );
		glVertex2d( 662 , 924 );
	glEnd();
}
void rumah20 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 334 , 804 );
		glVertex2d( 340 , 806 );
		glVertex2d( 492 , 768 );
		glVertex2d( 492 , 764 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 492 , 756 );
		glVertex2d( 498 , 756 );
		glVertex2d( 562 , 780 );
		glVertex2d( 562 , 782 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 562 , 780 );
		glVertex2d( 562 , 782 );
		glVertex2d( 650 , 758 );
		glVertex2d( 656 , 758 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 492 , 756 );
		glVertex2d( 498 , 756 );
		glVertex2d( 584 , 732 );
		glVertex2d( 584 , 734 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 584 , 732 );
		glVertex2d( 584 , 734 );
		glVertex2d( 650 , 758 );
		glVertex2d( 656 , 758 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(61,28,114);
		glVertex2d( 654 , 766 );
		glVertex2d( 716 , 790 );
		glVertex2d( 710 , 790 );
		glVertex2d( 654 , 770 );
	glEnd();
}
void rumah21 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(29,17,48);
		glVertex2d( 634 , 770 );
		glVertex2d( 648 , 766 );
		glVertex2d( 648 , 786 );
		glVertex2d( 634 , 782 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(29,17,48);
		glVertex2d( 516 , 770 );
		glVertex2d( 530 , 776 );
		glVertex2d( 530 , 788 );
		glVertex2d( 516 , 790 );
	glEnd();
}
void rumah22 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(64,29,119);
		glVertex2d( 530 , 776 );
		glVertex2d( 530 , 788 );
		glVertex2d( 562 , 800 );
		glVertex2d( 562 , 788 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(64,29,119);
		glVertex2d( 562 , 800 );
		glVertex2d( 562 , 788 );
		glVertex2d( 634 , 770 );
		glVertex2d( 634 , 782 );
	glEnd();
}
void rumah23 ()
{
	glBegin(GL_POLYGON);
		glColor3ub(36,17,66);
		glVertex2d( 500 , 756 );
		glVertex2d( 562 , 780 );
		glVertex2d( 648 , 758 );
		glVertex2d( 584 , 736 );
	glEnd();
}
void display()
{
langit();
bintang();
bulan();
awan();
awan2();
awan3();
gunung();
gunung2();
gunung3();
gunung4();
gunung5();
gunung6();
gunung7();
gunung8();
gunung9();
tanah();
rumah();
rumah1();
rumah2();
rumah3();
rumah4();
rumah5();
rumah6();
rumah7();
rumah8();
rumah9();
rumah10();
rumah11();
rumah12();
rumah13();
rumah14();
rumah15();
rumah16();
rumah17();
rumah18();
rumah19();
rumah20();
rumah21();
rumah22();
rumah23();


}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(750 , 800, "Rendi Yuda Perkasa - G64160011", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);


        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
