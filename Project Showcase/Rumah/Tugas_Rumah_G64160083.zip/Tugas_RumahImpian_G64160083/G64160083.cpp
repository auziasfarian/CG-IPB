#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define putih 255,255,255
#define birumuda 111,214,233
#define birutua 54,75,161
#define pink 237,34,144
#define coklat 128,64,0
#define marun 128,0,0
#define merah 238,37,36
#define hijau 27,159,73


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods){
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window){
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);

    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, -1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display(){
    // your drawing code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);

    //background
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(0, 0);
    glColor3ub(putih);
    glVertex2d(0,600);
    glColor3ub(putih);
    glVertex2d(600, 600);
    glColor3ub(birumuda);
    glVertex2d(600, 0);
    glEnd();

    glFlush();
}

void tembokPersegi(){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,193);
    glVertex2d(147, 210);
    glVertex2d(262, 117);
    glVertex2d(261, 124);
    glVertex2d(149, 213);
    glEnd();
}

void atasGenteng(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(265, 117);
    glVertex2d(383, 114);
    glVertex2d(380, 119);
    glVertex2d(261, 124);
    glEnd();
}

void genteng(){
    glBegin(GL_POLYGON);
    glColor3ub(60,55,51);
    glVertex2d(261, 124);
    glVertex2d(380, 119);
    glVertex2d(270, 225);
    glVertex2d(149, 213);
    glEnd();
}
void genteng1(){
    glBegin(GL_POLYGON);
    glColor3ub(60,55,51);
    glVertex2d(338, 166);
    glVertex2d(249, 252);
    glVertex2d(392, 271);
    glVertex2d(474, 168);
    glEnd();
}
void palang1(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(153, 214);
    glVertex2d(270, 225);
    glVertex2d(273, 229);
    glVertex2d(153, 218);
    glEnd();
}
void palang2(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(271, 225);
    glVertex2d(384, 116);
    glVertex2d(384, 122);
    glVertex2d(274, 228);
    glEnd();
}

void palang3(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(384, 116);
    glVertex2d(429, 167);
    glVertex2d(424, 167);
    glVertex2d(384, 122);
    glEnd();
}

void palang4(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(384, 122);
    glVertex2d(424, 167);
    glVertex2d(415, 167);
    glVertex2d(379, 127);
    glEnd();
}

void palang5(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(253, 252);
    glVertex2d(391, 271);
    glVertex2d(391, 275);
    glVertex2d(253, 257);
    glEnd();
}

void tembokAtas(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(393, 268);
    glVertex2d(398, 268);
    glVertex2d(480, 166);
    glVertex2d(475, 167);
    glEnd();
}

void tembokDepan(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(393, 268);
    glVertex2d(398, 268);
    glVertex2d(398, 472);
    glVertex2d(393, 472);
    glEnd();
}

void tembokSam(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(398, 268);
    glVertex2d(540, 235);
    glVertex2d(540, 408);
    glVertex2d(398, 572);
    glEnd();
}

void tembokDepan1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(276, 273);
    glVertex2d(304, 277);
    glVertex2d(309, 467);
    glVertex2d(280, 457);
    glEnd();
}

void tembokDepan2(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(253, 256);
    glVertex2d(324, 266);
    glVertex2d(324, 290);
    glVertex2d(254, 278);
    glEnd();
}

void tembokDepan3(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(253, 570);
    glVertex2d(253, 565);
    glVertex2d(398, 472);
    glVertex2d(393, 472);
    glEnd();
}

void tembokSam1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(398, 472);
    glVertex2d(398, 572);
    glVertex2d(253, 600);
    glVertex2d(253, 565);
    glEnd();
}

void balkon1(){
    glBegin(GL_POLYGON);
    glColor3ub(marun);
    glVertex2d(321, 284);
    glVertex2d(352, 291);
    glVertex2d(352, 377);
    glVertex2d(321, 369);
    glEnd();
}

void balkon(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(317, 278);
    glVertex2d(356, 284);
    glVertex2d(356, 384);
    glVertex2d(317, 374);
    glEnd();
}

void balkon2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(317, 278);
    glVertex2d(356, 284);
    glVertex2d(369, 281);
    glVertex2d(336, 276);
    glEnd();
}

void balkonKiri(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(181, 220);
    glVertex2d(236, 225);
    glVertex2d(240, 331);
    glVertex2d(186, 318);
    glEnd();
}

void balkonKiri1(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(187, 221);
    glVertex2d(192, 221);
    glVertex2d(197, 303);
    glVertex2d(192, 303);
    glEnd();
}

void balkonKiri2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(187, 221);
    glVertex2d(219, 223);
    glVertex2d(223, 316);
    glVertex2d(192, 309);
    glEnd();
}

void balkonKiri3(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(191, 221);
    glVertex2d(219, 223);
    glVertex2d(219, 248);
    glVertex2d(191, 245);
    glEnd();
}

void balkonKiri4(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(223, 291);
    glVertex2d(222, 311);
    glVertex2d(206, 314);
    glVertex2d(204, 294);
    glEnd();
}

void balkonKiri5(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(174, 287);
    glVertex2d(204, 294);
    glVertex2d(206, 314);
    glVertex2d(175, 308);
    glEnd();
}

void balkonKiri6(){
    glBegin(GL_TRIANGLES);
    glColor3ub(pink);
    glVertex2d(175, 287);
    glVertex2d(190,284);
    glVertex2d(190, 290);
    glEnd();
}

void balkonKiri7(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(144, 319);
    glVertex2d(176, 314);
    glVertex2d(294, 344);
    glVertex2d(277, 356);
    glEnd();
}

void balkonKiri8(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(174, 308);
    glVertex2d(206, 315);
    glVertex2d(206, 320);
    glVertex2d(174, 311);
    glEnd();
}

void balkonKiri9(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(206, 314);
    glVertex2d(223, 311);
    glVertex2d(223, 316);
    glVertex2d(206, 321);
    glEnd();
}

void balkonKanan(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(355, 284);
    glVertex2d(372, 280);
    glVertex2d(372, 376);
    glVertex2d(355, 383);
    glEnd();
}

void balkonKanan1(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(320, 284);
    glVertex2d(334, 286);
    glVertex2d(334, 359);
    glVertex2d(320, 364);
    glEnd();
}

void balkonKanan2(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(342, 349);
    glVertex2d(351, 346);
    glVertex2d(351, 372);
    glVertex2d(342, 375);
    glEnd();
}

void balkonKanan3(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(312, 341);
    glVertex2d(343, 349);
    glVertex2d(343, 375);
    glVertex2d(312, 367);
    glEnd();
}

void balkonKanan4(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(372, 297);
    glVertex2d(390, 300);
    glVertex2d(390, 366);
    glVertex2d(372, 362);
    glEnd();
}

void balkonKanan5(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(369, 364);
    glVertex2d(389, 369);
    glVertex2d(389, 392);
    glVertex2d(369, 386);
    glEnd();
}

void balkonKanan6(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(355, 383);
    glVertex2d(369, 377);
    glVertex2d(369, 387);
    glEnd();
}

void balkonKanan7(){
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(312, 342);
    glVertex2d(320, 338);
    glVertex2d(320, 344);
    glEnd();
}

void balkonKanan8(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(319, 374);
    glVertex2d(409, 397);
    glVertex2d(369, 418);
    glVertex2d(282, 390);
    glEnd();
}

void balkonKanan9(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(297, 376);
    glVertex2d(309, 380);
    glVertex2d(301, 386);
    glVertex2d(288, 381);
    glEnd();
}

void balkonKanan10(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(342, 375);
    glVertex2d(351, 371);
    glVertex2d(351, 377);
    glVertex2d(342, 381);
    glEnd();
}

void balkonKanan11(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(312, 367);
    glVertex2d(342, 375);
    glVertex2d(342, 381);
    glVertex2d(310, 373);
    glEnd();
}

void tembokDepan4(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(236, 225);
    glVertex2d(265, 228);
    glVertex2d(265, 336);
    glVertex2d(240, 330);
    glEnd();
}

void tembokDepan5(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(254, 279);
    glVertex2d(276, 282);
    glVertex2d(278, 350);
    glVertex2d(256, 344);
    glEnd();
}

void kaca(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(213, 256);
    glVertex2d(220, 256);
    glVertex2d(223, 305);
    glVertex2d(215, 304);
    glEnd();
}

void kaca1(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(198, 253);
    glVertex2d(208, 254);
    glVertex2d(210, 302);
    glVertex2d(200, 301);
    glEnd();
}

void kaca2(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(263, 283);
    glVertex2d(276, 283);
    glVertex2d(278, 343);
    glVertex2d(264, 340);
    glEnd();
}

void tembokBawah(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(148, 327);
    glVertex2d(254, 355);
    glVertex2d(257, 448);
    glVertex2d(153, 441);
    glEnd();
}

void tembokBawah1(){
    glBegin(GL_POLYGON);
    glColor3ub(coklat);
    glVertex2d(259, 357);
    glVertex2d(277, 362);
    glVertex2d(278, 386);
    glVertex2d(259, 379);
    glEnd();
}

void AtasKaca(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(157, 339);
    glVertex2d(246, 366);
    glVertex2d(239, 368);
    glVertex2d(147, 341);
    glEnd();
}

void KacaBawah(){
    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2d(160, 348);
    glVertex2d(246, 371);
    glVertex2d(248, 425);
    glVertex2d(163, 392);
    glEnd();
}

void KacaBawah1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(162, 348);
    glVertex2d(169, 351);
    glVertex2d(171, 393);
    glVertex2d(165, 391);
    glEnd();
}

void KacaBawah2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(172, 351);
    glVertex2d(180, 353);
    glVertex2d(182, 398);
    glVertex2d(175, 395);
    glEnd();
}

void KacaBawah3(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(183, 355);
    glVertex2d(191, 357);
    glVertex2d(193, 402);
    glVertex2d(189, 399);
    glEnd();
}

void KacaBawah4(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(193, 358);
    glVertex2d(201, 360);
    glVertex2d(203, 405);
    glVertex2d(196, 402);
    glEnd();
}

void KacaBawah5(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(205, 361);
    glVertex2d(212, 364);
    glVertex2d(214, 409);
    glVertex2d(207, 406);
    glEnd();
}

void KacaBawah6(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(217, 364);
    glVertex2d(224, 367);
    glVertex2d(226, 414);
    glVertex2d(219, 411);
    glEnd();
}

void KacaBawah7(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(229, 368);
    glVertex2d(236, 371);
    glVertex2d(238, 418);
    glVertex2d(231, 415);
    glEnd();
}

void KacaBawah8(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(241, 372);
    glVertex2d(246, 370);
    glVertex2d(248, 421);
    glVertex2d(242, 420);
    glEnd();
}

void KacaBawah9(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(263, 381);
    glVertex2d(278, 386);
    glVertex2d(279, 443);
    glVertex2d(264, 437);
    glEnd();
}

void KacaBawah10(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(265, 382);
    glVertex2d(278, 386);
    glVertex2d(279, 443);
    glVertex2d(266, 435);
    glEnd();
}

void BawahKaca(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(163, 393);
    glVertex2d(248, 424);
    glVertex2d(248, 428);
    glVertex2d(160, 394);
    glEnd();
}

void BawahKaca1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(264, 437);
    glVertex2d(279, 443);
    glVertex2d(279, 450);
    glVertex2d(264, 444);
    glEnd();
}

void BawahKaca2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(264, 444);
    glVertex2d(279, 450);
    glVertex2d(279, 456);
    glVertex2d(258, 447);
    glEnd();
}

void TembokDuduk(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(249, 427);
    glVertex2d(254, 430);
    glVertex2d(136, 482);
    glVertex2d(131, 480);
    glEnd();
}

void TembokDuduk1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(254, 430);
    glVertex2d(255, 446);
    glVertex2d(137, 505);
    glVertex2d(136, 482);
    glEnd();
}

void lantai(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(334, 456);
    glVertex2d(387, 474);
    glVertex2d(351, 497);
    glVertex2d(299, 477);
    glEnd();
}

void lantai1(){
    glBegin(GL_POLYGON);
    glColor3ub(hijau);
    glVertex2d(160, 395);
    glVertex2d(249, 428);
    glVertex2d(133, 500);
    glVertex2d(45, 446);
    glEnd();
}

void lantai2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(160, 395);
    glVertex2d(45, 446);
    glVertex2d(45, 435);
    glEnd();
}

void lantai3(){
    glBegin(GL_POLYGON);
    glColor3ub(hijau);
    glVertex2d(153, 393);
    glVertex2d(160, 395);
    glVertex2d(44, 435);
    glVertex2d(40, 432);
    glEnd();
}

void lantai4(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(40, 441);
    glVertex2d(44, 445);
    glVertex2d(44, 435);
    glVertex2d(40, 432);
    glEnd();
}

void lantai5(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(132, 481);
    glVertex2d(137, 483);
    glVertex2d(137, 505);
    glVertex2d(132, 501);
    glEnd();
}

void lantai6(){
    glBegin(GL_POLYGON);
    glColor3ub(hijau);
    glVertex2d(255, 446);
    glVertex2d(312, 469);
    glVertex2d(186, 542);
    glVertex2d(137, 505);
    glEnd();
}

//void lantai7(){
  //  glBegin(GL_POLYGON);
    //glColor3ub(hijau);
    //glVertex2d(255, 446);
    //glVertex2d(312, 469);
    //glVertex2d(186, 542);
    //glVertex2d(137, 501);
    //glEnd();
//}

void palang6(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(292, 393);
    glVertex2d(369, 416);
    glVertex2d(371, 424);
    glVertex2d(292, 400);
    glEnd();
}

void palang7(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(371, 418);
    glVertex2d(389, 408);
    glVertex2d(389, 417);
    glVertex2d(372, 426);
    glEnd();
}

void KacaBawah11(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(312, 405);
    glVertex2d(322, 408);
    glVertex2d(322, 460);
    glVertex2d(312, 456);
    glEnd();
}

void tiang(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(301, 402);
    glVertex2d(306, 404);
    glVertex2d(308, 476);
    glVertex2d(303, 476);
    glEnd();
}

void tiang1(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(335, 413);
    glVertex2d(341, 415);
    glVertex2d(342, 489);
    glVertex2d(335, 489);
    glEnd();
}

void tiang2(){
    glBegin(GL_POLYGON);
    glColor3ub(pink);
    glVertex2d(372, 423);
    glVertex2d(378, 423);
    glVertex2d(378, 478);
    glVertex2d(372, 483);
    glEnd();
}

void segitiga(){
    glBegin(GL_TRIANGLES);
    glColor3ub(pink);
    glVertex2d(398, 268);
    glVertex2d(480,166);
    glVertex2d(535, 238);
    glEnd();
}

void segitiga1(){
    glBegin(GL_TRIANGLES);
    glColor3ub(pink);
    glVertex2d(350, 600);
    glVertex2d(253, 600);
    glVertex2d(400, 550);
    glEnd();
}

void lingkaran(double poX, double poY, double rad){
    double cons=(3.14/100)*2;
    double px, py;
    double posX=poX, posY=poY;
    double radius1=0;
    double radius2=rad;
    glColor3ub(merah);
    glBegin(GL_TRIANGLE_STRIP);
        for (int i=0; i<=100; i++){
            px=sin(1*cons)*radius1+posX;
            px=cos(1*cons)*radius1+posY;
            glVertex2f(px*10,py*10);
            px=sin(1*cons)*radius2+posX;
            px=cos(1*cons)*radius2+posY;
            glVertex2f(px*10,py*10);
        }
    glEnd();
}


int main(void){
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(600, 600, "Tugas Rumah", NULL, NULL);

    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    while (!glfwWindowShouldClose(window)){
        setup_viewport(window);

        display();
        //atap
        tembokPersegi();
        atasGenteng();
        genteng();
        palang1();
        palang2();
        palang3();
        palang4();
        palang5();
        tembokAtas();
        segitiga();
        segitiga1();

        //rumah tengah
        balkonKanan8();
        tembokDepan();
        tembokSam();
        tembokSam1();
        tembokDepan2();
        tembokDepan1();
        tembokDepan3();
        balkon();
        balkon1();
        balkon2();

        //balkon Kiri
        balkonKiri();
        balkonKiri2();
        balkonKiri1();
        balkonKiri3();
        kaca();
        kaca1();
        kaca2();
        balkonKiri4();
        balkonKiri5();
        balkonKiri6();
        balkonKiri8();
        balkonKiri7();
        balkonKiri9();
        tembokDepan4();
        tembokDepan5();

        //balkon kanan
        balkonKanan();
        balkonKanan1();
        balkonKanan2();
        balkonKanan3();
        balkonKanan4();
        balkonKanan5();
        balkonKanan6();
        balkonKanan7();
        balkonKanan9();
        balkonKanan10();
        balkonKanan11();

        genteng1();
        palang6();
        lantai6();
        lantai();
        tiang();
        tiang1();
        tiang2();
        palang7();
        KacaBawah11();

        //lantai bawah
        tembokBawah();
        AtasKaca();
        KacaBawah();
        KacaBawah1();
        KacaBawah2();
        KacaBawah3();
        KacaBawah4();
        KacaBawah5();
        KacaBawah6();
        KacaBawah7();
        KacaBawah8();
        KacaBawah9();
        KacaBawah10();
        BawahKaca();
        BawahKaca1();
        BawahKaca2();
        lantai1();
        lantai2();
        lantai3();
        lantai4();
        lantai5();
        TembokDuduk();
        TembokDuduk1();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
