#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "Tugas_Rumah_G64160016", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);

int hehe=0,buff=0;

while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();


glBegin(GL_POLYGON);
 glColor3ub(255, 153, 153);
   for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
      glVertex2f(204+cos(rad)*11,360+sin(rad)*11);
   }
   glEnd();

//background
glBegin(GL_POLYGON);
glColor3ub(153, 217, 234);
glVertex2f(0,0);
glColor3ub(153, 217, 234);
glVertex2f(0,800);
glColor3ub(153, 217, 234);
glVertex2f(800,800);
glColor3ub(153, 217, 234);
glVertex2f(800,0);
glEnd();

//Tanahbawah
glBegin(GL_POLYGON);
glColor3ub(120, 161, 48);
glVertex2f(18.9 ,457.177 );
glColor3ub(120, 161, 48);
glVertex2f(18.9,435.937 );
glColor3ub(120, 161, 48);
glVertex2f(290.554 ,294.92 );
glColor3ub(120, 161, 48);
glVertex2f(785.702,553.336);
glColor3ub(120, 161, 48);
glVertex2f(785.702,574.576 );
glColor3ub(120, 161, 48);
glVertex2f(514.048 ,715.593 );
glEnd();

//Tanahatas
glBegin(GL_POLYGON);
glColor3ub(154, 196, 82);
glVertex2f(18.9 ,435.937 );
glColor3ub(154, 196, 82);
glVertex2f(290.554,294.92  );
glColor3ub(154, 196, 82);
glVertex2f(785.702 ,553.336  );
glColor3ub(154, 196, 82);
glVertex2f(514.048,694.352);
glEnd();

//Tanahatas2
glBegin(GL_POLYGON);
glColor3ub(181, 232, 97);
glVertex2f(53.888  ,435.937 );
glColor3ub(181, 232, 97);
glVertex2f(290.553 ,313.083 );
glColor3ub(181, 232, 97);
glVertex2f(750.713 ,553.336  );
glColor3ub(181, 232, 97);
glVertex2f(514.048,676.19);
glEnd();

//Rumah1
//Dinding
glBegin(GL_POLYGON);
glColor3ub(255, 228, 192);
glVertex2f(137.4 ,434.006 );
glColor3ub(255, 228, 192);
glVertex2f(137.4,257.046);
glColor3ub(255, 228, 192);
glVertex2f(219.17,225.57 );
glColor3ub(255, 228, 192);
glVertex2f(299.764,341.94);
glColor3ub(255, 228, 192);
glVertex2f(299.764,518.9 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(214, 176, 133);
glVertex2f(299.764,341.94);
glColor3ub(214, 176, 133);
glVertex2f(441.667 ,267.645 );
glColor3ub(214, 176, 133);
glVertex2f(441.667,444.714);
glColor3ub(214, 176, 133);
glVertex2f(299.764,518.9 );
glEnd();

//atasatap
glBegin(GL_POLYGON);
glColor3ub(196, 53, 11);
glVertex2f(130.679 ,251.891);
glColor3ub(196, 53, 11);
glVertex2f(271.968 ,178.528 );
glColor3ub(196, 53, 11);
glVertex2f(358.078,146.136 );
glColor3ub(196, 53, 11);
glVertex2f(216.987,225.57 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(144, 37, 5);
glVertex2f(358.078,146.136 );
glColor3ub(144, 37, 5);
glVertex2f(216.987,225.57 );
glColor3ub(144, 37, 5);
glVertex2f(304.906,347.757);
glColor3ub(144, 37, 5);
glVertex2f(447.805,273.559);
glEnd();

//atap
glBegin(GL_POLYGON);
glColor3ub(122, 30, 3);
glVertex2f(134.292 ,260.864 );
glColor3ub(122, 30, 3);
glVertex2f(130.679,251.891);
glColor3ub(122, 30, 3);
glVertex2f(215.18,220.333);
glColor3ub(122, 30, 3);
glVertex2f(216.986,229.36);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(122, 30, 3);
glVertex2f(303.294,341.496 );
glColor3ub(122, 30, 3);
glVertex2f(299.682,346.718);
glColor3ub(122, 30, 3);
glVertex2f(216.986,229.36);
glColor3ub(122, 30, 3);
glVertex2f(215.18,220.333);
glEnd();

//rumah2
//Dinding
glBegin(GL_POLYGON);
glColor3ub(247, 197, 129);
glVertex2f(307.213,519.356);
glColor3ub(247, 197, 129);
glVertex2f(307.213,431.444 );
glColor3ub(247, 197, 129);
glVertex2f(379.207,405.379);
glColor3ub(247, 197, 129);
glVertex2f(446.919 ,501.743 );
glColor3ub(247, 197, 129);
glVertex2f(446.919 ,589.656 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(226, 172, 98);
glVertex2f(446.919 ,501.743 );
glColor3ub(226, 172, 98);
glVertex2f(446.919 ,589.656 );
glColor3ub(226, 172, 98);
glVertex2f(586.385 ,519.385);
glColor3ub(226, 172, 98);
glVertex2f(586.385 ,431.381);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(247, 197, 129);
glVertex2f(495.536,564.892);
glColor3ub(247, 197, 129);
glVertex2f(495.536,476.888 );
glColor3ub(247, 197, 129);
glVertex2f(540.09,519.052 );
glColor3ub(247, 197, 129);
glVertex2f(540.09,587.34);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(226, 172, 98);
glVertex2f(540.09,519.052 );
glColor3ub(226, 172, 98);
glVertex2f(540.09,587.34);
glColor3ub(226, 172, 98);
glVertex2f(603.519 ,555.936 );
glColor3ub(226, 172, 98);
glVertex2f(603.519 ,487.649);
glEnd();

//atap2
glBegin(GL_POLYGON);
glColor3ub(255, 232, 202);;
glVertex2f(307.737 ,427.175 );
glColor3ub(255, 232, 202);
glVertex2f(445.859 ,357.585 );
glColor3ub(255, 232, 202);
glVertex2f(520.158 ,332.315);
glColor3ub(255, 232, 202);
glVertex2f(380.702,402.596);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(255, 232, 202);
glVertex2f(520.158 ,332.315);
glColor3ub(255, 232, 202);
glVertex2f(380.702,402.596);
glColor3ub(255, 232, 202);
glVertex2f(452.011  ,506.56 );
glColor3ub(255, 232, 202);
glVertex2f(591.467,436.279);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(255, 232, 202);;
glVertex2f(498.216 ,471.605 );
glColor3ub(255, 232, 202);
glVertex2f(543.566 ,521.202);
glColor3ub(255, 232, 202);
glVertex2f(607.483,490.721);
glColor3ub(255, 232, 202);
glVertex2f(558.341,437.701);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(310.728 ,434.606 );
glColor3ub(210, 176, 131);
glVertex2f(307.737 ,427.175);
glColor3ub(210, 176, 131);
glVertex2f(380.702,402.596 );
glColor3ub(210, 176, 131);
glVertex2f(380.702,408.517);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(380.702,402.596 );
glColor3ub(210, 176, 131);
glVertex2f(380.702,408.517);
glColor3ub(210, 176, 131);
glVertex2f(452.011,506.56 );
glColor3ub(210, 176, 131);
glVertex2f(450.677,501.375);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(496.222,483.169 );
glColor3ub(210, 176, 131);
glVertex2f(502.31,483.169);
glColor3ub(210, 176, 131);
glVertex2f(540.647,519.45 );
glColor3ub(210, 176, 131);
glVertex2f(534.558,519.45);
glEnd();

//pintu1
glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(196.014,464.433);
glColor3ub(210, 176, 131);
glVertex2f(196.014,377.098);
glColor3ub(210, 176, 131);
glVertex2f(237.959,398.872);
glColor3ub(210, 176, 131);
glVertex2f(237.959,486.349);
glEnd();

//jendela1
glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(149.7,392.877);
glColor3ub(210, 176, 131);
glVertex2f(149.7,355.646);
glColor3ub(210, 176, 131);
glVertex2f(185.56 ,374.261);
glColor3ub(210, 176, 131);
glVertex2f(185.56,411.492);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(248.414,444.12);
glColor3ub(210, 176, 131);
glVertex2f(248.414 ,406.889) ;
glColor3ub(210, 176, 131);
glVertex2f(284.274,425.504);
glColor3ub(210, 176, 131);
glVertex2f(284.274,462.735);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(248.414,444.12);
glColor3ub(210, 176, 131);
glVertex2f(248.414 ,406.889) ;
glColor3ub(210, 176, 131);
glVertex2f(284.274,425.504);
glColor3ub(210, 176, 131);
glVertex2f(284.274,462.735);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(210, 176, 131);
glVertex2f(324.398,358.034);
glColor3ub(210, 176, 131);
glVertex2f(360.259 ,339.418 ) ;
glColor3ub(210, 176, 131);
glVertex2f(360.259,376.649 );
glColor3ub(210, 176, 131);
glVertex2f(324.398,395.264);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(234, 194, 144);
glVertex2f(149.7,283.916);
glColor3ub(234, 194, 144);
glVertex2f(185.56 ,302.531 ) ;
glColor3ub(234, 194, 144);
glVertex2f(185.56,339.762 );
glColor3ub(234, 194, 144);
glVertex2f(149.7,321.146 );
glEnd();


glBegin(GL_POLYGON);
glColor3ub(234, 194, 144);
glVertex2f(196.03,304.824 );
glColor3ub(234, 194, 144);
glVertex2f(237.944 ,326.582 ) ;
glColor3ub(234, 194, 144);
glVertex2f(237.944,370.097  );
glColor3ub(234, 194, 144);
glVertex2f(196.03,348.339 );
glEnd();


glBegin(GL_POLYGON);
glColor3ub(234, 194, 144);
glVertex2f(248.414,335.159);
glColor3ub(234, 194, 144);
glVertex2f(284.274 ,353.774 ) ;
glColor3ub(234, 194, 144);
glVertex2f(284.274,391.005  );
glColor3ub(234, 194, 144);
glVertex2f(248.414,372.389 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(174, 132, 83);
glVertex2f(324.398 ,358.034);
glColor3ub(174, 132, 83);
glVertex2f(360.259 ,339.418) ;
glColor3ub(174, 132, 83);
glVertex2f(360.259,376.649);
glColor3ub(174, 132, 83);
glVertex2f(324.398,395.264 );
glEnd();

//pintugarasi
glBegin(GL_POLYGON);
glColor3ub(154, 196, 82);
glVertex2f(345.162 ,535.447 );
glColor3ub(154, 196, 82);
glVertex2f(411.426 ,569.536 );
glColor3ub(154, 196, 82);
glVertex2f(347.043,601.684);
glColor3ub(154, 196, 82);
glVertex2f(280.779,567.595);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(117, 99, 71);
glVertex2f(339.906 ,450.927);
glColor3ub(117, 99, 71);
glVertex2f(410.661 ,487.656) ;
glColor3ub(117, 99, 71);
glVertex2f(410.661,570.834);
glColor3ub(117, 99, 71);
glVertex2f(339.906,534.105);
glEnd();

//lotengrumah1
glBegin(GL_POLYGON);
glColor3ub(255, 228, 192);
glVertex2f(330.691 ,312.456 ) ;
glColor3ub(255, 228, 192);
glVertex2f(330.691,285.412);
glColor3ub(255, 228, 192);
glVertex2f(301.759,271.898 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(214, 176, 133);
glVertex2f(330.691 ,312.456 ) ;
glColor3ub(214, 176, 133);
glVertex2f(330.691,285.412);
glColor3ub(214, 176, 133);
glVertex2f(367.093 ,212.144 );
glColor3ub(214, 176, 133);
glVertex2f(400.054,249.788);
glColor3ub(214, 176, 133);
glVertex2f(402.086 ,275.394);
glEnd();

//ataploteng
glBegin(GL_POLYGON);
glColor3ub(122, 30, 3);
glVertex2f(330.691 ,287.737) ;
glColor3ub(122, 30, 3);
glVertex2f(300.774,271.885);
glColor3ub(122, 30, 3);
glVertex2f(321.268 ,182.847 );
glColor3ub(122, 30, 3);
glVertex2f(368.42,206.145);
glColor3ub(122, 30, 3);
glVertex2f(367.093,212.144);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(122, 30, 3);
glVertex2f(368.42,206.145);
glColor3ub(122, 30, 3);
glVertex2f(367.093,212.144);
glColor3ub(122, 30, 3);
glVertex2f(400.054,249.788 );
glColor3ub(122, 30, 3);
glVertex2f(404.117 ,246.912);
glEnd();


//dindingrumah2
glBegin(GL_POLYGON);
glColor3ub(247, 197, 129);
glVertex2f(378.705,396.763);
glColor3ub(247, 197, 129);
glVertex2f(379.514,344.466);
glColor3ub(247, 197, 129);
glVertex2f(420.621,344.466);
glColor3ub(247, 197, 129);
glVertex2f(420.621,384.1);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(247, 197, 129);
glVertex2f(420.621,344.466);
glColor3ub(247, 197, 129);
glVertex2f(420.621,384.1);
glColor3ub(247, 197, 129);
glVertex2f(460.876,443.19 );
glColor3ub(247, 197, 129);
glVertex2f(462.538,387.255);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(226, 172, 98);
glVertex2f(460.876,443.19 );
glColor3ub(226, 172, 98);
glVertex2f(462.538,387.255);
glColor3ub(226, 172, 98);
glVertex2f(496.395,341.58 );
glColor3ub(226, 172, 98);
glVertex2f(530.047,354.719);
glColor3ub(226, 172, 98);
glVertex2f(528.814 ,409.455 );
glEnd();

//atepnya
glBegin(GL_POLYGON);
glColor3ub(255, 232, 202);
glVertex2f(376.983,346.862);
glColor3ub(255, 232, 202);
glVertex2f(460.002,389.655);
glColor3ub(255, 232, 202);
glVertex2f(496.41,340.031);
glColor3ub(255, 232, 202);
glVertex2f(412.668,295.859 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(255, 232, 202);
glVertex2f(496.41,340.031);
glColor3ub(255, 232, 202);
glVertex2f(412.668,295.859 );
glColor3ub(255, 232, 202);
glVertex2f(449.195 ,308.618);
glColor3ub(255, 232, 202);
glVertex2f(531.56,351.065 );
glEnd();

//jendelalotengrumah2
glBegin(GL_POLYGON);
glColor3ub(155, 130, 96);
glVertex2f(516.077,363.59 );
glColor3ub(155, 130, 96);
glVertex2f(483.951,379.498);
glColor3ub(155, 130, 96);
glVertex2f(483.951 ,413.42);
glColor3ub(155, 130, 96);
glVertex2f(516.077,397.511 );
glEnd();

//pintukeduagarasi
glBegin(GL_POLYGON);
glColor3ub(155, 130, 96);
glVertex2f(500.79,502.02 );
glColor3ub(155, 130, 96);
glVertex2f(534.837,533.556);
glColor3ub(155, 130, 96);
glVertex2f(534.837,584.693);
glColor3ub(155, 130, 96);
glVertex2f(500.79,567.538 );
glEnd();

//atepkecillt2rumah1
glBegin(GL_POLYGON);
glColor3ub(174, 132, 83);
glVertex2f(359.215,252.608);
glColor3ub(174, 132, 83);
glVertex2f(380.533,241.542);
glColor3ub(174, 132, 83);
glVertex2f(380.533,263.675);
glColor3ub(174, 132, 83);
glVertex2f(359.215,274.741);
glEnd();

//rumput
glBegin(GL_POLYGON);
glColor3ub(154, 196, 82);
glVertex2f(196.014,464.433 );
glColor3ub(154, 196, 82);
glVertex2f(237.959,486.349 );
glColor3ub(154, 196, 82);
glVertex2f(176.986,518);
glColor3ub(154, 196, 82);
glVertex2f(134.905,496.155);
glEnd();

//accgarasi
glBegin(GL_POLYGON);
glColor3ub(153, 153, 101);
glVertex2f(344.496,466.197);
glColor3ub(153, 153, 101);
glVertex2f(344.496,474.537 );
glColor3ub(153, 153, 101);
glVertex2f(406.072,506.501);
glColor3ub(153, 153, 101);
glVertex2f(406.072,498.161);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(153, 153, 101);
glVertex2f(344.496,493.412);
glColor3ub(153, 153, 101);
glVertex2f(344.496,485.072);
glColor3ub(153, 153, 101);
glVertex2f(406.072,517.036);
glColor3ub(153, 153, 101);
glVertex2f(406.072,525.376);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(153, 153, 101);
glVertex2f(344.496,509.923);
glColor3ub(153, 153, 101);
glVertex2f(344.496,501.583 );
glColor3ub(153, 153, 101);
glVertex2f(406.072,533.547 );
glColor3ub(153, 153, 101);
glVertex2f(406.072,541.887);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(153, 153, 101);
glVertex2f(344.496,527.638);
glColor3ub(153, 153, 101);
glVertex2f(344.496,519.299);
glColor3ub(153, 153, 101);
glVertex2f(406.072,551.262);
glColor3ub(153, 153, 101);
glVertex2f(406.072,559.602 );
glEnd();

//jendela
glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(153.195 ,319.332);
glColor3ub(101, 179, 220);
glVertex2f(153.195,289.359);
glColor3ub(101, 179, 220);
glVertex2f(182.065,304.346);
glColor3ub(101, 179, 220);
glVertex2f(182.065,334.319);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(153.195 ,361.089);
glColor3ub(101, 179, 220);
glVertex2f(153.195,391.063);
glColor3ub(101, 179, 220);
glVertex2f(182.065,406.049);
glColor3ub(101, 179, 220);
glVertex2f(182.065,376.076);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(251.909,442.306);
glColor3ub(101, 179, 220);
glVertex2f(251.909,412.332);
glColor3ub(101, 179, 220);
glVertex2f(280.779,427.319);
glColor3ub(101, 179, 220);
glVertex2f(280.779,457.292);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(251.909,370.575 );
glColor3ub(101, 179, 220);
glVertex2f(251.909,340.602);
glColor3ub(101, 179, 220);
glVertex2f(280.779,355.588 );
glColor3ub(101, 179, 220);
glVertex2f(280.779,385.562 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(327.893,389.821);
glColor3ub(101, 179, 220);
glVertex2f(327.893,359.848);
glColor3ub(101, 179, 220);
glVertex2f(356.763,344.862);
glColor3ub(101, 179, 220);
glVertex2f(356.763,374.835);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(361.293,271.505);
glColor3ub(101, 179, 220);
glVertex2f(361.293,253.687);
glColor3ub(101, 179, 220);
glVertex2f(378.456,244.777);
glColor3ub(101, 179, 220);
glVertex2f(378.456,262.596);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(101, 179, 220);
glVertex2f(200.115,346.219);
glColor3ub(101, 179, 220);
glVertex2f(200.115,311.186);
glColor3ub(101, 179, 220);
glVertex2f(233.859,328.702);
glColor3ub(101, 179, 220);
glVertex2f(233.859,363.735);
glEnd();

glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
