
#include <windows.h>
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

float camera1 = 0;
float camera2 = 1;

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    if (key == GLFW_KEY_LEFT && action == GLFW_PRESS){
        camera1 = camera1 - 1.0;
    } else if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS){
        camera1 = camera1 + 1.0;
    } else if (key == GLFW_KEY_UP && action == GLFW_PRESS){
        camera2 = camera2 - 1.0;
    } else if (key == GLFW_KEY_DOWN && action == GLFW_PRESS){
        camera2 = camera2 + 1.0;
    }
}

void cube(float panjang, float lebar, float tinggi, float *pos, int *r, int *g, int *b){

    glPushMatrix();
    glTranslatef(pos[0],pos[1],pos[2]);

    glPushMatrix();
    glBegin(GL_QUADS);

    glColor3ub(128,128,128);       //bawah
    glVertex3f(-0,-0,panjang);
    glVertex3f(-0,-0,-0);
    glVertex3f(lebar,-0,-0);
    glVertex3f(lebar,-0,panjang);

    glColor3ub(r[1],g[1],b[1]);      //belakang kiri
    glVertex3f(-0,tinggi,panjang);
    glVertex3f(-0,tinggi,-0);
    glVertex3f(-0,-0,-0);
    glVertex3f(-0,-0,panjang);

    glColor3ub(r[2]+20,g[2]+20,b[2]+20);      //belakang kanan
    glVertex3f(lebar,tinggi,-0);
    glVertex3f(-0,tinggi,-0);
    glVertex3f(-0,-0,-0);
    glVertex3f(lebar,-0,-0);

    glColor3ub(r[1]-10,g[1]-10,b[1]-10);        //kiri
    glVertex3f(-0,tinggi,panjang);
    glVertex3f(lebar,tinggi,panjang);
    glVertex3f(lebar,-0,panjang);
    glVertex3f(-0,-0,panjang);

    glColor3ub(r[2],g[2],b[2]);        //kanan
    glVertex3f(lebar,tinggi,panjang);
    glVertex3f(lebar,tinggi,-0);
    glVertex3f(lebar,-0,-0);
    glVertex3f(lebar,-0,panjang);

    glColor3ub(r[0],g[0],b[0]);        //atas
    glVertex3f(-0,tinggi,panjang);
    glVertex3f(-0,tinggi,-0);
    glVertex3f(lebar,tinggi,-0);
    glVertex3f(lebar,tinggi,panjang);
    glEnd();
    glPopMatrix();

    glPopMatrix();


}

void display()
{
    int r[3], g[3], b[3];   // 0 = top, 1 = left, 2 = right
    float pos[3];
    glPushMatrix();
    glTranslatef(0,0,0);
    glRotated(camera2 * 32,1,0,0);
    glRotated(camera1 *-45,0,1,0);
    glRotated(-45,0,1,0);

    glPushMatrix();
    glTranslatef(-50,0,-50);

    pos[0] = 0; pos[1] = 0; pos[2] = 0;     //land
    r[0] = 154; g[0] = 205; b[0] = 50;
    r[1] = 160; g[1] = 82; b[1] = 45;
    r[2] = 205; g[2] = 133; b[2] = 63;
    cube(100,100,2,pos,r,g,b);

    glPushMatrix();
    glTranslatef(25,0,25);
    pos[0] = 0; pos[1] = 2; pos[2] = 0;     //land adder
    r[0] = 241-15; g[0] = 232-15; b[0] = 233-15;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(50,50,0.5,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();     //house
    glTranslatef(25,0.5,25);

    pos[0] = 5; pos[1] = 2; pos[2] = 5;     //back building
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(20,40,25,pos,r,g,b);

    pos[0] = 5; pos[1] = 27; pos[2] = 5;     //top building adder (back)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(4,40,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 27; pos[2] = 5;     //top building adder (left)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(40,4,1,pos,r,g,b);

    pos[0] = 41; pos[1] = 27; pos[2] = 5;     //top building adder (right back)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(20,4,1,pos,r,g,b);

    pos[0] = 27.5; pos[1] = 27; pos[2] = 21;     //top building adder (middle)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(4,17.5,1,pos,r,g,b);

    pos[0] = 23.5; pos[1] = 27; pos[2] = 21;     //top building adder (right front)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(24,4,1,pos,r,g,b);

    pos[0] = 9; pos[1] = 27; pos[2] = 41;     //top building adder (front)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(4,17.5,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 2; pos[2] = 25;       //left front building
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(20,22.5,25,pos,r,g,b);

    glPushMatrix();     //balcony
    pos[0] = 27.5; pos[1] = 2; pos[2] = 25;     //balcony building
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(20,17.5,13,pos,r,g,b);

    pos[0] = 43; pos[1] = 14; pos[2] = 25;     //balcony fence right
    r[0] = 127; g[0] = 126; b[0] = 70;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(20,2,3,pos,r,g,b);

    pos[0] = 27; pos[1] = 14; pos[2] = 43;     //balcony fence left
    r[0] = 127; g[0] = 126; b[0] = 70;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(2,17.5,3,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();         //front entrance
    glTranslatef(0,-0.5,0);
    pos[0] = 5; pos[1] = 2; pos[2] = 45;       //left pillar entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,2,9,pos,r,g,b);

    pos[0] = 22.5; pos[1] = 2; pos[2] = 45;     //right pillar entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(10,2,9,pos,r,g,b);

    pos[0] = 5; pos[1] = 11; pos[2] = 45;       //roof entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,19.5,2,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (back)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(3,19.5,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (left)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,3,1,pos,r,g,b);

    pos[0] = 21.5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (right)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,3,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 54;       //roof entrance adder (front)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(3,19.5,1,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //front entrance door
    glTranslatef(-1,-13.5,0);
    pos[0] = 10; pos[1] = 15.5; pos[2] = 45;       //door base
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 11.5; pos[1] = 16; pos[2] = 45.5;       //door left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);

    pos[0] = 16.5; pos[1] = 16; pos[2] = 45.5;       //door right
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();
    pos[0] = 9; pos[1] = 15.5; pos[2] = 45;       //window left base
    r[0] = 138; g[0] = 147; b[0] = 94;
    r[1] = 138; g[1] = 147; b[1] = 94;
    r[2] = 138; g[2] = 147; b[2] = 94;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 10.5; pos[1] = 17; pos[2] = 45.5;       //window left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,8,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //window near garage
    glTranslatef(20,-10,0);
    pos[0] = 10; pos[1] = 15.5; pos[2] = 45;       //window left base
    r[0] = 138; g[0] = 147; b[0] = 94;
    r[1] = 138; g[1] = 147; b[1] = 94;
    r[2] = 138; g[2] = 147; b[2] = 94;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 11.5; pos[1] = 17; pos[2] = 45.5;       //window left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,8,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //balcony door
    glTranslatef(20,0,-20);
    pos[0] = 10; pos[1] = 15.5; pos[2] = 45;       //door base
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 11.5; pos[1] = 16; pos[2] = 45.5;       //door left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);

    pos[0] = 16.5; pos[1] = 16; pos[2] = 45.5;       //door right
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();
    pos[0] = 30; pos[1] = 25.5; pos[2] = 25;     //balcony ceiling bar
    r[0] = 194; g[0] = 189; b[0] = 31;
    r[1] = 141; g[1] = 139; b[1] = 91;
    r[2] = 89; g[2] = 89; b[2] = 53;
    cube(25,1,1,pos,r,g,b);

    pos[0] = 34; pos[1] = 25.5; pos[2] = 25;     //balcony ceiling bar
    r[0] = 194; g[0] = 189; b[0] = 31;
    r[1] = 141; g[1] = 139; b[1] = 91;
    r[2] = 89; g[2] = 89; b[2] = 53;
    cube(25,1,1,pos,r,g,b);

    pos[0] = 38; pos[1] = 25.5; pos[2] = 25;     //balcony ceiling bar
    r[0] = 194; g[0] = 189; b[0] = 31;
    r[1] = 141; g[1] = 139; b[1] = 91;
    r[2] = 89; g[2] = 89; b[2] = 53;
    cube(25,1,1,pos,r,g,b);

    pos[0] = 42; pos[1] = 25.5; pos[2] = 25;     //balcony ceiling bar
    r[0] = 194; g[0] = 189; b[0] = 31;
    r[1] = 141; g[1] = 139; b[1] = 91;
    r[2] = 89; g[2] = 89; b[2] = 53;
    cube(25,1,1,pos,r,g,b);

    pos[0] = 27; pos[1] = 24; pos[2] = 42;     //balcony ceiling bar fetch
    r[0] = 245; g[0] = 219; b[0] = 194;
    r[1] = 199; g[1] = 178; b[1] = 135;
    r[2] = 157; g[2] = 130; b[2] = 111;
    cube(2,17.5,2,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //right side window
    pos[0] = 45; pos[1] = 4.5; pos[2] = 17;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 17;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 12;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 12;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 7;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 7;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //left side window
    glTranslatef(-40.5,0,0);
    pos[0] = 45; pos[1] = 4.5; pos[2] = 17;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 17;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 12;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 12;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 7;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 7;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();         //back entrance
    glTranslatef(0,-0.5,-52);
    pos[0] = 5; pos[1] = 2; pos[2] = 45;       //left pillar entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,2,9,pos,r,g,b);

    pos[0] = 22.5; pos[1] = 2; pos[2] = 47;     //right pillar entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(10,2,9,pos,r,g,b);

    pos[0] = 5; pos[1] = 11; pos[2] = 45;       //roof entrance
    r[0] = 207; g[0] = 136; b[0] = 108;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,19.5,2,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (back)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(3,19.5,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (left)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,3,1,pos,r,g,b);

    pos[0] = 21.5; pos[1] = 13; pos[2] = 45;       //roof entrance adder (right)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(12,3,1,pos,r,g,b);

    pos[0] = 5; pos[1] = 13; pos[2] = 54;       //roof entrance adder (front)
    r[0] = 241; g[0] = 232; b[0] = 233;
    r[1] = 203; g[1] = 174; b[1] = 134;
    r[2] = 153; g[2] = 125; b[2] = 113;
    cube(3,19.5,1,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //back entrance door
    glTranslatef(-1,-13.5,-40.5);
    pos[0] = 10; pos[1] = 15.5; pos[2] = 45;       //door base
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 11.5; pos[1] = 16; pos[2] = 44.5;       //door left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);

    pos[0] = 16.5; pos[1] = 16; pos[2] = 44.5;       //door right
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,3,7,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //left side window
    glTranslatef(-40.5,0,20);
    pos[0] = 45; pos[1] = 4.5; pos[2] = 17;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 17;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 12;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 12;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 7;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 7;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(22,0,50);
    glRotatef(90,0,1,0);
    //glTranslatef(20,0,0);                             //back side window
    pos[0] = 45; pos[1] = 4.5; pos[2] = 17;       //low side window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 17;       //up side window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 12;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 12;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 7;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 18.5; pos[2] = 7;       //up side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,6,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                             //right side window
    glTranslatef(0,0,20);
    pos[0] = 45; pos[1] = 4.5; pos[2] = 17;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 12;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);

    pos[0] = 45; pos[1] = 4.5; pos[2] = 7;       //low side right window
    r[0] = 108; g[0] = 79; b[0] = 84;
    r[1] = 108; g[1] = 79; b[1] = 84;
    r[2] = 108; g[2] = 79; b[2] = 84;
    cube(4,0.5,10,pos,r,g,b);
    glPopMatrix();

    glPushMatrix();                 //back window
    glTranslatef(29,0,89.5);
    glRotatef(180,0,1,0);
    glTranslatef(0,0,39.5);
    pos[0] = 9; pos[1] = 15.5; pos[2] = 45;       //window left base
    r[0] = 138; g[0] = 147; b[0] = 94;
    r[1] = 138; g[1] = 147; b[1] = 94;
    r[2] = 138; g[2] = 147; b[2] = 94;
    cube(0.5,11,9,pos,r,g,b);

    pos[0] = 10.5; pos[1] = 17; pos[2] = 45.5;       //window left
    r[0] = 121; g[0] = 99; b[0] = 102;
    r[1] = 121; g[1] = 99; b[1] = 102;
    r[2] = 121; g[2] = 99; b[2] = 102;
    cube(0.5,8,6,pos,r,g,b);
    glPopMatrix();

    glPopMatrix();

    glPopMatrix();
    glPopMatrix();


}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(1000, 1000, "Rumah", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    glEnable(GL_DEPTH_TEST);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClearColor(255, 255, 255, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-100.f, 100.f, -100.f, 100.f, -100.f, 100.f);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glScalef(1.4,1.4,1.4);
        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
