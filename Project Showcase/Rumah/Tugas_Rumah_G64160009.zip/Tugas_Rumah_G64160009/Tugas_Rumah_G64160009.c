#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define xmin 0
#define xmax 800
#define ymin 800
#define ymax 0



static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void Setcircle(float size)
{
    int N = 10000;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*3.14 / N);
        pY = cos(i*3.14 / N);
        glVertex2f(pY * size,pX * size);
    }
    glEnd();
}

void DrawEllipse(float radiusX, float radiusY)
{
   int i;
   const float DEG2RAD = 3.14159/180.0;
   glBegin(GL_POLYGON);

   for(i=0;i<360;i++){
      float rad = i*DEG2RAD;
      glVertex2f(cos(rad)*radiusX,sin(rad)*radiusY);
   }

   glEnd();
}

static void grid(int x, int y)
{
    int i;
    glColor3f(.2,.2,.2);
    glBegin(GL_LINES);
    for(i=-x; i<=x; i+=100)
    {
        glVertex2f(i,-y);
        glVertex2f(i,y);
    }
    for(i=-y; i<=y; i++)
    {
        glVertex2f(-x,i);
        glVertex2f(x,i);
    }
    glColor3f(0.7,1,0.7);
    glVertex2f(-x,0);
    glVertex2f(x,0);
    glVertex2f(0,-y);
    glVertex2f(0,y);
    glEnd();
}

void alas(){
    //bawah
    glPushMatrix();
    glColor3ub(255,218,198);
    glBegin(GL_POLYGON);
    glVertex2d(81,548);
    glVertex2d(294,424);
    glVertex2d(505,546);
    glVertex2d(294,668);
    glEnd();
    glPopMatrix();

    //atas
    glPushMatrix();
    glColor3ub(255,239,196);
    glBegin(GL_POLYGON);
    glVertex2d(294,320);
    glVertex2d(505,199);
    glVertex2d(716,320);
    glVertex2d(505,442);
    glEnd();
    glPopMatrix();
}

void wall()
{
    //dinding bawah

    glPushMatrix();
    glColor3ub(255,180,130);
    glBegin(GL_POLYGON);
    glVertex2d(81,548);
    glVertex2d(81,442);
    glVertex2d(294,320);
    glVertex2d(294,424);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,180,130);
    glBegin(GL_POLYGON);
    glVertex2d(294,424);
    glVertex2d(294,320);
    glVertex2d(505,442);
    glVertex2d(505,546);
    glEnd();
    glPopMatrix();

    //dinding atas
    glPushMatrix();
    glColor3ub(255,225,132);
    glBegin(GL_POLYGON);
    glVertex2d(294,320);
    glVertex2d(294,216);
    glVertex2d(505,94);
    glVertex2d(505,199);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,225,132);
    glBegin(GL_POLYGON);
    glVertex2d(505,199);
    glVertex2d(505,94);
    glVertex2d(715,215);
    glVertex2d(715,322);
    glEnd();
    glPopMatrix();
}

void dinding()
{
    glPushMatrix();
    glColor3ub(241,197,120);
    glBegin(GL_POLYGON);
    glVertex2d(475,222);
    glVertex2d(475,112);
    glVertex2d(505,129);
    glVertex2d(505,239);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(241,197,120);
    glBegin(GL_POLYGON);
    glVertex2d(505,239);
    glVertex2d(505,129);
    glVertex2d(535,112);
    glVertex2d(535,222);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,238,198);
    glBegin(GL_POLYGON);
    glVertex2d(475,112);
    glVertex2d(505,94);
    glVertex2d(535,112);
    glVertex2d(505,129);
    glEnd();
    glPopMatrix();

    //dobelan dinding bawah
    glPushMatrix();
    glColor3ub(226,96,7);
    glBegin(GL_POLYGON);
    glVertex2d(81,442);
    glVertex2d(81,440);
    glVertex2d(292,319);
    glVertex2d(294,320);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(226,96,7);
    glBegin(GL_POLYGON);
    glVertex2d(81,548);
    glVertex2d(81,440);
    glVertex2d(84,442);
    glVertex2d(84,546);
    glVertex2d(294,668);
    glVertex2d(294,671);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(226,96,7);
    glBegin(GL_POLYGON);
    glVertex2d(505,546);
    glVertex2d(508,548);
    glVertex2d(294,671);
    glVertex2d(294,668);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(226,96,7);
    glBegin(GL_POLYGON);
    glVertex2d(505,546);
    glVertex2d(505,442);
    glVertex2d(508,440);
    glVertex2d(508,548);
    glEnd();
    glPopMatrix();

    //dobelan dinding atas
    glPushMatrix();
    glColor3ub(191,131,25);
    glBegin(GL_POLYGON);
    glVertex2d(292,319);
    glVertex2d(294,320);
    glVertex2d(294,216);
    glVertex2d(292,214);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(225,180,89);
    glBegin(GL_POLYGON);
    glVertex2d(294,216);
    glVertex2d(292,214);
    glVertex2d(505,92);
    glVertex2d(505,94);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(225,180,89);
    glBegin(GL_POLYGON);
    glVertex2d(505,92);
    glVertex2d(505,94);
    glVertex2d(718,215);
    glVertex2d(716,216);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(225,180,89);
    glBegin(GL_POLYGON);
    glVertex2d(718,215);
    glVertex2d(715,216);
    glVertex2d(715,320);
    glVertex2d(718,322);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(225,180,89);
    glBegin(GL_POLYGON);
    glVertex2d(508,440);
    glVertex2d(508,443);
    glVertex2d(718,322);
    glVertex2d(716,320);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,225,132);
    glBegin(GL_POLYGON);
    glVertex2d(81,330);
    glVertex2d(81,443);
    glVertex2d(292,322);
    glVertex2d(292,215);
    glEnd();
    glPopMatrix();
}

void tangga()
{
    glPushMatrix();
    glColor3ub(255,239,196);
    glBegin(GL_POLYGON);
    glVertex2d(210,368);
    glVertex2d(294,320);
    glVertex2d(325,338);
    glVertex2d(240,385);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,180,130);
    glBegin(GL_POLYGON);
    glVertex2d(174,529);
    glVertex2d(174,515);
    glVertex2d(264,372);
    glVertex2d(325,338);
    glVertex2d(325,442);
    glEnd();
    glPopMatrix();

}

void anak_tangga()
{
    glPushMatrix();
    glColor3ub(215,132,84);
    glBegin(GL_POLYGON);
    glVertex2d(144,511);
    glVertex2d(144,499);
    glVertex2d(174,517);
    glVertex2d(174,529);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,218,198);
    glBegin(GL_POLYGON);
    glVertex2d(144,500);
    glVertex2d(154,494);
    glVertex2d(184,511);
    glVertex2d(174,517);
    glEnd();
    glPopMatrix();
}

void anak()
{
    glPushMatrix();
    for(int i=0;i<9;i++){
    glTranslated(7.5,-14.5,0);
    anak_tangga();
    }
    glPopMatrix();
}

void jendela_atas()
{
    //Jendela atas 1
    glPushMatrix();
    glColor3ub(210,164,90);
    glBegin(GL_POLYGON);
    glVertex2d(315,216);
    glVertex2d(315,262);
    glVertex2d(455,181);
    glVertex2d(455,135);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(139,112,79);
    glBegin(GL_POLYGON);
    glVertex2d(315,216);
    glVertex2d(315,259);
    glVertex2d(452,180);
    glVertex2d(452,140);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(228,185,142);
    glBegin(GL_POLYGON);
    glVertex2d(315,216);
    glVertex2d(315,258);
    glVertex2d(451,178);
    glVertex2d(451,138);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,249,232);
    glBegin(GL_POLYGON);
    glVertex2d(315,216);
    glVertex2d(315,256);
    glVertex2d(450,178);
    glVertex2d(450,138);
    glEnd();
    glPopMatrix();

    //Jendela Atas 2
    glPushMatrix();
    glColor3ub(210,164,90);
    glBegin(GL_POLYGON);
    glVertex2d(499,137);
    glVertex2d(482,127);
    glVertex2d(482,174);
    glVertex2d(499,183);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(139,112,79);
    glBegin(GL_POLYGON);
    glVertex2d(499,137);
    glVertex2d(485,129);
    glVertex2d(485,172);
    glVertex2d(499,180);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(228,185,142);
    glBegin(GL_POLYGON);
    glVertex2d(499,137);
    glVertex2d(486,130);
    glVertex2d(486,171);
    glVertex2d(499,178);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,249,232);
    glBegin(GL_POLYGON);
    glVertex2d(499,137);
    glVertex2d(487,130);
    glVertex2d(487,170);
    glVertex2d(499,177);
    glEnd();
    glPopMatrix();

    //Jendela Atas 3
    glPushMatrix();
    glColor3ub(210,164,90);
    glBegin(GL_POLYGON);
    glVertex2d(606,166);
    glVertex2d(565,140);
    glVertex2d(565,175);
    glVertex2d(606,199);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(139,112,79);
    glBegin(GL_POLYGON);
    glVertex2d(606,166);
    glVertex2d(568,142);
    glVertex2d(568,172);
    glVertex2d(606,195);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(228,185,142);
    glBegin(GL_POLYGON);
    glVertex2d(606,166);
    glVertex2d(570,143);
    glVertex2d(570,173);
    glVertex2d(606,194);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,249,232);
    glBegin(GL_POLYGON);
    glVertex2d(606,166);
    glVertex2d(570,144);
    glVertex2d(570,172);
    glVertex2d(606,193);
    glEnd();
    glPopMatrix();
}

void jendela_bawah()
{
    glPushMatrix();
    glColor3ub(210,164,90);
    glBegin(GL_POLYGON);
    glVertex2d(94,448);
    glVertex2d(94,494);
    glVertex2d(144,465);
    glVertex2d(144,419);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(139,112,79);
    glBegin(GL_POLYGON);
    glVertex2d(94,448);
    glVertex2d(94,491);
    glVertex2d(141,464);
    glVertex2d(141,420);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(228,185,142);
    glBegin(GL_POLYGON);
    glVertex2d(94,448);
    glVertex2d(94,489);
    glVertex2d(140,463);
    glVertex2d(140,421);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,249,232);
    glBegin(GL_POLYGON);
    glVertex2d(94,448);
    glVertex2d(94,488);
    glVertex2d(139,462);
    glVertex2d(139,422);
    glEnd();
    glPopMatrix();
}

void garis()
{
        glPushMatrix();
        glColor3ub(158,156,151);
        glBegin(GL_POLYGON);
        glVertex2d(508,455);
        glVertex2d(508,457);
        glVertex2d(718,336);
        glVertex2d(718,334);
        glEnd();
        glPopMatrix();
}

void garasi()
{

    glPushMatrix();
    glColor3ub(96,96,96);
    glBegin(GL_POLYGON);
    glVertex2d(508,447);
    glVertex2d(508,548);
    glVertex2d(718,426);
    glVertex2d(718,326);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(158,156,151);
    glBegin(GL_POLYGON);
    glVertex2d(505,442);
    glVertex2d(505,449);
    glVertex2d(718,327);
    glVertex2d(718,320);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    for(int i=0;i<9;i++){
    glTranslated(0,9,0);
    garis();
    }
    glPopMatrix();

}

void dinding_tambahan()
{

    glPushMatrix();
    glColor3ub(255,201,171);
    glBegin(GL_POLYGON);
    glVertex2d(81,341);
    glVertex2d(81,553);
    glVertex2d(297,672);
    glVertex2d(300,454);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,225,206);
    glBegin(GL_POLYGON);
    glVertex2d(297,672);
    glVertex2d(300,454);
    glVertex2d(511,342);
    glVertex2d(511,551);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,225,206);
    glBegin(GL_POLYGON);
    glVertex2d(511,342);
    glVertex2d(511,439);
    glVertex2d(718,320);
    glVertex2d(718,215);
    glEnd();
    glPopMatrix();

}

void atap()
{
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(224,173,153);
    glVertex2d(78,346);
    glVertex2d(298,442);
    glVertex2d(713,220);
    glVertex2d(504,100);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(226,181,181);
    glVertex2d(503,101);
    glVertex2d(503,80);
    glVertex2d(68,327);
    glVertex2d(68,352);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(188,148,128);
    glVertex2d(68,327);
    glVertex2d(68,352);
    glVertex2d(298,467);
    glVertex2d(298,442);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(188,148,128);
    glVertex2d(732,209);
    glVertex2d(732,231);
    glVertex2d(503,101);
    glVertex2d(503,80);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(226,181,181);
    glVertex2d(298,467);
    glVertex2d(298,442);
    glVertex2d(732,209);
    glVertex2d(732,231);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(226,107,80);
    glVertex2d(79,335);
    glVertex2d(201,252);
    glVertex2d(298,442);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(255,118,91);
    glVertex2d(201,252);
    glVertex2d(298,442);
    glVertex2d(594,283);
    glVertex2d(423,125);
    glEnd();
    glPopMatrix();
}

void pintu_jendela()
{
    //pintu
    glPushMatrix();
    glColor3ub(97,46,29);
    glBegin(GL_POLYGON);
    glVertex2d(114,476);
    glVertex2d(114,572);
    glVertex2d(157,595);
    glVertex2d(157,501);
    glEnd();
    glPopMatrix();

    //Pegangan pintu
    glPushMatrix();
    glTranslated(127,533,0);
    glColor3ub(249,210,0);
    DrawEllipse(3,9);
    glPopMatrix();

    glPushMatrix();
    glTranslated(140,539,0);
    glColor3ub(249,210,0);
    DrawEllipse(3,9);
    glPopMatrix();

    //jendela
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);
    glVertex2d(183,503);
    glVertex2d(252,543);
    glVertex2d(252,600);
    glVertex2d(183,562);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(60,199,219);
    glBegin(GL_POLYGON);
    glVertex2d(185,506);
    glVertex2d(249,544);
    glVertex2d(249,595);
    glVertex2d(185,560);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(185,506);
    glVertex2d(185,510);
    glVertex2d(249,573);
    glVertex2d(249,560);
    glVertex2d(218,525);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(185,529);
    glVertex2d(185,545);
    glVertex2d(223,582);
    glVertex2d(249,595);
    glVertex2d(249,592);
    glEnd();
    glPopMatrix();

    //jendela lagi
    glPushMatrix();
    glColor3ub(0,0,0);
    glBegin(GL_POLYGON);
    glVertex2d(318,545);
    glVertex2d(455,465);
    glVertex2d(455,524);
    glVertex2d(318,603);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(60,199,219);
    glBegin(GL_POLYGON);
    glVertex2d(319,546);
    glVertex2d(453,468);
    glVertex2d(453,523);
    glVertex2d(319,601);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(319,585);
    glVertex2d(341,588);
    glVertex2d(356,579);
    glVertex2d(319,573);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(319,545);
    glVertex2d(319,555);
    glVertex2d(383,564);
    glVertex2d(397,555);
    glVertex2d(322,544);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(344,531);
    glVertex2d(360,522);
    glVertex2d(438,532);
    glVertex2d(421,542);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(377,513);
    glVertex2d(390,504);
    glVertex2d(453,513);
    glVertex2d(453,523);
    glVertex2d(451,524);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(95,232,255);
    glBegin(GL_POLYGON);
    glVertex2d(412,492);
    glVertex2d(428,483);
    glVertex2d(453,486);
    glVertex2d(453,498);
    glEnd();
    glPopMatrix();
}

void cerobong()
{
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(237,199,148);
    glVertex2d(558,172);
    glVertex2d(598,195);
    glVertex2d(598,152);
    glVertex2d(558,129);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(175,148,113);
    glVertex2d(598,152);
    glVertex2d(598,195);
    glVertex2d(633,174);
    glVertex2d(633,131);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(249,233,210);
    glVertex2d(548,132);
    glVertex2d(594,106);
    glVertex2d(643,135);
    glVertex2d(598,161);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(252,223,179);
    glVertex2d(568,132);
    glVertex2d(594,118);
    glVertex2d(623,135);
    glVertex2d(598,149);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(87,85,84);
    glVertex2d(571,135);
    glVertex2d(598,149);
    glVertex2d(620,136);
    glVertex2d(594,122);
    glEnd();
    glPopMatrix();
}

void ruang_bawah()
{
    //karpet
    glPushMatrix();
    glColor3ub(167,158,210);
    glBegin(GL_POLYGON);
    glVertex2d(268,526);
    glVertex2d(318,555);
    glVertex2d(378,521);
    glVertex2d(328,492);
    glEnd();
    glPopMatrix();

    //meja
    glPushMatrix();
    glColor3ub(108,92,79);
    glBegin(GL_POLYGON);
    glVertex2d(294,535);
    glVertex2d(312,546);
    glVertex2d(312,537);
    glVertex2d(294,526);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(108,92,79);
    glBegin(GL_POLYGON);
    glVertex2d(348,525);
    glVertex2d(330,515);
    glVertex2d(330,505);
    glVertex2d(348,516);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(172,137,110);
    glBegin(GL_POLYGON);
    glVertex2d(312,546);
    glVertex2d(317,543);
    glVertex2d(317,534);
    glVertex2d(312,537);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(172,137,110);
    glBegin(GL_POLYGON);
    glVertex2d(348,525);
    glVertex2d(352,522);
    glVertex2d(352,513);
    glVertex2d(348,516);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(136,115,95);
    glBegin(GL_POLYGON);
    glVertex2d(293,529);
    glVertex2d(315,541);
    glVertex2d(315,532);
    glVertex2d(293,519);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(172,137,110);
    glBegin(GL_POLYGON);
    glVertex2d(315,532);
    glVertex2d(353,510);
    glVertex2d(353,519);
    glVertex2d(315,541);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(233,197,171);
    glBegin(GL_POLYGON);
    glVertex2d(293,519);
    glVertex2d(315,532);
    glVertex2d(353,510);
    glVertex2d(331,497);
    glEnd();
    glPopMatrix();

    //meja tipi
    void kaki()
    {
    glPushMatrix();
    glColor3ub(144,144,144);
    glBegin(GL_POLYGON);
    glVertex2d(350,599);
    glVertex2d(350,593);
    glVertex2d(352,593);
    glVertex2d(353,593);
    glVertex2d(353,598);
    glVertex2d(352,599);
    glEnd();
    glPopMatrix();
    }
    kaki();
    glPushMatrix();
    glTranslated(13,9,0);
    kaki();
    glPopMatrix();

    glPushMatrix();
    glTranslated(56,-32,0);
    glTranslated(13,9,0);
    kaki();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(98,84,76);
    glBegin(GL_POLYGON);
    glVertex2d(350,577);
    glVertex2d(350,597);
    glVertex2d(365,606);
    glVertex2d(365,585);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(126,109,100);
    glBegin(GL_POLYGON);
    glVertex2d(365,606);
    glVertex2d(365,585);
    glVertex2d(422,552);
    glVertex2d(422,573);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(173,149,137);
    glBegin(GL_POLYGON);
    glVertex2d(368,587);
    glVertex2d(368,601);
    glVertex2d(419,571);
    glVertex2d(419,557);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(51,43,39);
    glBegin(GL_POLYGON);
    glVertex2d(419,571);
    glVertex2d(419,557);
    glVertex2d(407,564);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(173,149,137);
    glBegin(GL_POLYGON);
    glVertex2d(365,585);
    glVertex2d(350,577);
    glVertex2d(407,544);
    glVertex2d(422,552);
    glEnd();
    glPopMatrix();

    //tipi
    glPushMatrix();
    glColor3ub(67,57,52);
    glBegin(GL_POLYGON);
    glVertex2d(359,571);
    glVertex2d(359,533);
    glVertex2d(411,503);
    glVertex2d(411,541);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(67,57,52);
    glBegin(GL_POLYGON);
    glVertex2d(385,565);
    glVertex2d(385,545);
    glVertex2d(390,542);
    glVertex2d(390,562);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(67,57,52);
    glBegin(GL_POLYGON);
    glVertex2d(367,571);
    glVertex2d(377,573);
    glVertex2d(406,555);
    glVertex2d(399,552);
    glEnd();
    glPopMatrix();

    //sofa
    void pegangan()
    {
    glPushMatrix();
    glColor3ub(191,125,49);
    glBegin(GL_POLYGON);
    glVertex2d(232,491);
    glVertex2d(232,510);
    glVertex2d(257,524);
    glVertex2d(256,506);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(227,149,58);
    glBegin(GL_POLYGON);
    glVertex2d(256,524);
    glVertex2d(256,506);
    glVertex2d(262,503);
    glVertex2d(262,520);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(198,66,7);
    glBegin(GL_POLYGON);
    glVertex2d(231,489);
    glVertex2d(237,486);
    glVertex2d(262,501);
    glVertex2d(256,504);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(145,48,5);
    glBegin(GL_POLYGON);
    glVertex2d(231,489);
    glVertex2d(231,491);
    glVertex2d(256,506);
    glVertex2d(256,504);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(250,98,30);
    glBegin(GL_POLYGON);
    glVertex2d(256,506);
    glVertex2d(256,504);
    glVertex2d(262,501);
    glVertex2d(262,503);
    glEnd();
    glPopMatrix();

    }
    glPushMatrix();
    glTranslated(60,-34,0);
    pegangan();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(239,186,149);
    glBegin(GL_POLYGON);
    glVertex2d(236,470);
    glVertex2d(288,440);
    glVertex2d(295,466);
    glVertex2d(243,496);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(204,162,133);
    glBegin(GL_POLYGON);
    glVertex2d(295,466);
    glVertex2d(243,496);
    glVertex2d(262,507);
    glVertex2d(314,477);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(255,198,159);
    glBegin(GL_POLYGON);
    glVertex2d(262,507);
    glVertex2d(262,513);
    glVertex2d(314,483);
    glVertex2d(314,477);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(158,103,41);
    glBegin(GL_POLYGON);
    glVertex2d(262,513);
    glVertex2d(262,516);
    glVertex2d(312,487);
    glVertex2d(312,484);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(219,171,137);
    glBegin(GL_POLYGON);
    glVertex2d(237,494);
    glVertex2d(243,496);
    glVertex2d(236,470);
    glVertex2d(231,469);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(173,138,115);
    glBegin(GL_POLYGON);
    glVertex2d(231,469);
    glVertex2d(236,470);
    glVertex2d(288,439);
    glVertex2d(282,439);
    glEnd();
    glPopMatrix();

    pegangan();
    lampu();
    perapian();


}

void ruang_atas()
{
    //kasur
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3b(78,52,46);
    glVertex2d(361,282);
    glVertex2d(361,258);
    glVertex2d(448,306);
    glVertex2d(448,330);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3b(109,76,65);
    glVertex2d(448,330);
    glVertex2d(448,306);
    glVertex2d(500,277);
    glVertex2d(500,301);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(101,193,208);
    glVertex2d(365,255);
    glVertex2d(448,301);
    glVertex2d(500,272);
    glVertex2d(417,226);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(101,193,208);
    glVertex2d(448,306);
    glVertex2d(448,301);
    glVertex2d(500,272);
    glVertex2d(500,277);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(101,193,208);
    glVertex2d(448,306);
    glVertex2d(448,301);
    glVertex2d(365,255);
    glVertex2d(361,258);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3b(78,52,46);
    glVertex2d(365,260);
    glVertex2d(365,236);
    glVertex2d(361,233);
    glVertex2d(361,258);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3b(78,52,46);
    glVertex2d(365,236);
    glVertex2d(361,233);
    glVertex2d(413,204);
    glVertex2d(417,207);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3b(109,76,65);
    glVertex2d(365,236);
    glVertex2d(365,255);
    glVertex2d(417,226);
    glVertex2d(417,207);
    glEnd();
    glPopMatrix();

    void bantal()
    {
        glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(254,204,128);
        glVertex2d(369,248);
        glVertex2d(387,238);
        glVertex2d(400,245);
        glVertex2d(382,255);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(250,166,40);
        glVertex2d(369,248);
        glVertex2d(382,255);
        glVertex2d(382,260);
        glVertex2d(369,253);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glBegin(GL_POLYGON);
        glColor3ub(252,182,77);
        glVertex2d(382,255);
        glVertex2d(382,260);
        glVertex2d(400,250);
        glVertex2d(400,245);
        glEnd();
        glPopMatrix();
    }
    bantal();
    glPushMatrix();
    glTranslated(26,-15,0);
    bantal();
    glPopMatrix();

    //selimut
    glPushMatrix();
    glTranslated(3,2,0);
    glBegin(GL_POLYGON);
    glColor3ub(81,93,237);
    glVertex2d(385,288);
    glVertex2d(385,266);
    glVertex2d(439,236);
    glVertex2d(496,268);
    glVertex2d(441,298);
    glVertex2d(441,319);
    glEnd();

    glPopMatrix();
    glPushMatrix();
    glBegin(GL_POLYGON);
    glColor3ub(52,77,226);
    glVertex2d(385,288);
    glVertex2d(385,266);
    glVertex2d(439,236);
    glVertex2d(496,268);
    glVertex2d(441,298);
    glVertex2d(441,319);
    glEnd();
    glPopMatrix();
}

void lampu()
{
    glPushMatrix();
    glColor3ub(144,131,112);
    glTranslated(325,455,0);
    DrawEllipse(10,6);
    glPopMatrix();

    glPushMatrix();
    glColor3ub(228,207,180);
    glBegin(GL_POLYGON);
    glVertex2d(323,388);
    glVertex2d(326,388);
    glVertex2d(326,455);
    glVertex2d(323,455);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glColor3ub(118,131,78);
    glBegin(GL_POLYGON);
    glVertex2d(316,388);
    glVertex2d(314,398);
    glVertex2d(335,398);
    glVertex2d(333,388);
    glEnd();
    glPopMatrix();


    glPushMatrix();
    glColor3ub(118,131,78);
    glTranslated(324.5,397.5,0);
    Setcircle(9.5);
    glPopMatrix();

    glPushMatrix();
    glColor3ub(178,192,117);
    glTranslated(324.5,391,0);
    DrawEllipse(9.5,5.5);
    glPopMatrix();
}

void perapian()
{
    glPushMatrix();
    glColor3ub(226,130,121);
    //glTranslated(5,5,0);
    glBegin(GL_POLYGON);
    glVertex2d(612,165);
    glVertex2d(624,162);
    glVertex2d(672,188);
    glVertex2d(662,194);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(226,130,121);
    glBegin(GL_POLYGON);
    glVertex2d(662,194);
    glVertex2d(672,188);
    glVertex2d(672,294);
    glVertex2d(662,300);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(178,68,63);
    glTranslated(5,5,0);
    glBegin(GL_POLYGON);
    glVertex2d(607,160);
    glVertex2d(657,189);
    glVertex2d(657,295);
    glVertex2d(607,267);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(66,66,66);
    glTranslated(0,3,0);
    glBegin(GL_POLYGON);
    glVertex2d(624,232);
    glVertex2d(654.2,246);
    glVertex2d(654.2,281);
    glVertex2d(624,264);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(48,45,45);
    glTranslated(0,-3,0);
    glBegin(GL_POLYGON);
    glVertex2d(624,232);
    glVertex2d(649,246);
    glVertex2d(649,279);
    glVertex2d(624,264);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(0,0,0);
    glTranslated(5,0,0);
    glBegin(GL_POLYGON);
    glVertex2d(624,232);
    glVertex2d(649,246);
    glVertex2d(649,279);
    glVertex2d(624,264);
    glEnd();
    glPopMatrix();
}

void display()
{
    alas();
    wall();
    dinding();
    tangga();
    anak_tangga();
    anak();
    jendela_atas();
    jendela_bawah();
    garasi();
    ruang_bawah();
    ruang_atas();

}

void luar()
{
    dinding_tambahan();
    atap();
    pintu_jendela();
    cerobong();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Simple example", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width * 10 / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(xmin, xmax, ymin, ymax, 1, -1);
        //glOrtho(-ratio, ratio, ymin, ymax, 1, -1);
        int stateD = glfwGetKey(window, GLFW_KEY_D);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        display();
        luar();
        if(stateD == GLFW_PRESS)
            {
                glClear(GL_COLOR_BUFFER_BIT);
                display();
            }
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}


