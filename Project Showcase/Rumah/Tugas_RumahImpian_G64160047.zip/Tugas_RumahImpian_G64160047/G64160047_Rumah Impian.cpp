#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(0.2711, 0.8667, 0.9778, 0.567);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1000, 1000, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void jalan(){
    glBegin(GL_TRIANGLES);
    glColor3f(0.5066,0.5066,0.5644);

    glVertex2d(0,1000);
    glVertex2d(0,940);
    glVertex2d(854,1000);
    glEnd();
}
void halaman1(){
    glBegin(GL_POLYGON);
    glColor3f(0.3155,0.5911,0.2000);

    glVertex2d(116,906);
    glVertex2d(0,944);
    glVertex2d(505,977);
    glVertex2d(596,927);
    glEnd();
}
void halaman2(){
    glBegin(GL_POLYGON);
    glColor3f(0.8800,0.8844,0.8000);

    glVertex2d(911,909);
    glVertex2d(635,905);
    glVertex2d(505,977);
    glVertex2d(910,1010);
    glEnd();
}
void tembokluar(){
    glBegin(GL_POLYGON);
    glColor3f(0.8444,0.7866,0.9555);

    glVertex2d(0,944);
    glVertex2d(0,778);
    glVertex2d(115,788);
    glVertex2d(116,910);
    glEnd();
}
void tembokluar1(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.4044,0.4355);

    glVertex2d(108,913);
    glVertex2d(108,645);
    glVertex2d(160,645);
    glVertex2d(160,912);
    glEnd();
}
void tembokluar2(){
    glBegin(GL_POLYGON);
    glColor3f(0.6177,0.4844,0.4444);

    glVertex2d(300,920);
    glVertex2d(300,645);
    glVertex2d(160,645);
    glVertex2d(160,912);
    glEnd();
}
void tembokluar3(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.9198);

    glVertex2d(300,920);
    glVertex2d(300,905);
    glVertex2d(371,905);
    glVertex2d(371,922);
    glEnd();
}
void lantai1(){
    glBegin(GL_POLYGON);
    glColor3f(0.7777,0.7866,0.800);

    glVertex2d(347,895);
    glVertex2d(300,905);
    glVertex2d(371,905);
    glVertex2d(371,895);
    glEnd();
}
void tembokdalam1(){
    glBegin(GL_POLYGON);
    glColor3f(0.6622,0.6711,0.6844);

    glVertex2d(347,895);
    glVertex2d(300,905);
    glVertex2d(300,677);
    glVertex2d(345,684);
    glEnd();
}
void tembokdalam2(){
    glBegin(GL_POLYGON);
    glColor3f(0.6266,0.6400,0.6488);

    glVertex2d(347,895);
    glVertex2d(345,684);
    glVertex2d(371,684);
    glVertex2d(371,895);
    glEnd();
}

void lantaiatas1(){
    glBegin(GL_POLYGON);
    glColor3f(0.7777,0.7866,0.800);

    glVertex2d(342,684);
    glVertex2d(300,677);
    glVertex2d(300,668);
    glVertex2d(371,669);
    glVertex2d(371,684);
    glEnd();
}
void tembokluar4(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(365,922);
    glVertex2d(367,615);
    glVertex2d(457,615);
    glVertex2d(457,926);
    glEnd();
}
void tembokluar5a(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.9198);

    glVertex2d(457,926);
    glVertex2d(457,910);
    glVertex2d(591,913);
    glVertex2d(591,933);
    glEnd();
}
void tembokluar5b(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.9198);

    glVertex2d(567,913);
    glVertex2d(567,668);
    glVertex2d(591,668);
    glVertex2d(591,913);
    glEnd();
}
void tembokputih(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(468,909);
    glVertex2d(473,849);
    glVertex2d(510,849);
    glVertex2d(510,901);
    glEnd();
}
void tembokluarorange1(){
    glBegin(GL_POLYGON);
    glColor3f(1.0267,0.7288,0.1555);

    glVertex2d(411,910);
    glVertex2d(411,677);
    glVertex2d(470,677);
    glVertex2d(470,910);
    glEnd();
}
void tembokluarorange2(){
    glBegin(GL_POLYGON);
    glColor3f(0.6800,0.4888,0.0711);

    glVertex2d(478,906);
    glVertex2d(478,675);
    glVertex2d(470,677);
    glVertex2d(470,913);
    glEnd();
}
void tembokpintu1(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(569,902);
    glVertex2d(510,901);
    glVertex2d(510,849);
    glVertex2d(569,849);
    glEnd();
}
void tembokpintu2(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(569,849);
    glVertex2d(478,849);
    glVertex2d(478,692);
    glVertex2d(567,692);
    glEnd();
}
void lantai2(){
glBegin(GL_POLYGON);
    glColor3f(0.7333,0.7422,0.7555);

    glVertex2d(458,911);
    glVertex2d(510,901);
    glVertex2d(569,901);
    glVertex2d(569,913);
    glEnd();
}
void tembokataspintu1(){
    glBegin(GL_POLYGON);
    glColor3f(0.5600,0.5688,0.5822);

    glVertex2d(478,692);
    glVertex2d(478,676);
    glVertex2d(568,675);
    glVertex2d(568,692);
    glEnd();
}
void tembokataspintu2(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.9198);

    glVertex2d(478,833);
    glVertex2d(478,710);
    glVertex2d(500,710);
    glVertex2d(500,833);
    glEnd();
}
void tembokataspintu3(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(457,668);
    glVertex2d(457,660);
    glVertex2d(591,660);
    glVertex2d(591,668);
    glEnd();
}
void jendela(){
    glBegin(GL_POLYGON);
    glColor3f(0.4755,0.4800,0.4933);

    glVertex2d(457,677);
    glVertex2d(457,668);
    glVertex2d(567,668);
    glVertex2d(567,677);
    glEnd();
}
void pintu1(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(528,802);
    glVertex2d(528,715);
    glVertex2d(569,715);
    glVertex2d(569,802);
    glEnd();
}
void pintu2(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(528,882);
    glVertex2d(528,816);
    glVertex2d(569,816);
    glVertex2d(569,882);
    glEnd();
}
void kasauA(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.4933,1.0356);

    glVertex2d(246,673);
    glVertex2d(246,657);
    glVertex2d(563,657);
    glVertex2d(563,673);
    glEnd();
}
void kasauB(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.4933,1.0356);

    glVertex2d(151,651);
    glVertex2d(151,638);
    glVertex2d(308,638);
    glVertex2d(308,651);
    glEnd();
}
void atap(){
    glBegin(GL_POLYGON);
    glColor3f(0.3600,0.3733,0.4222);

    glVertex2d(591,660);
    glVertex2d(591,422);
    glVertex2d(296,628);
    glVertex2d(296,660);
    glEnd();
}
void atap1(){
    glBegin(GL_POLYGON);
    glColor3f(1.1111,0.7466,0.2133);

    glVertex2d(591,422);
    glVertex2d(591,296);
    glVertex2d(161,616);
    glVertex2d(161,638);
    glVertex2d(296,638);
    glEnd();
}
void temboksamping1(){
    glBegin(GL_POLYGON);
    glColor3f(0.4533,0.3466,0.1111);

    glVertex2d(591,933);
    glVertex2d(591,296);
    glVertex2d(618,344);
    glVertex2d(618,919);
    glEnd();
}
void temboksamping2a(){
    glBegin(GL_POLYGON);
    glColor3f(0.7777,0.7866,0.8000);

    glVertex2d(618,344);
    glVertex2d(618,644);
    glVertex2d(635,644);
    glVertex2d(689,615);
    glVertex2d(689,466);
    glEnd();
}
void temboksamping2b(){
    glBegin(GL_POLYGON);
    glColor3f(0.7777,0.7866,0.8000);

    glVertex2d(644,645);
    glVertex2d(644,900);
    glVertex2d(618,919);
    glVertex2d(618,642);
    glEnd();
}
void temboksamping3(){
    glBegin(GL_POLYGON);
    glColor3f(1.1288,1.0844,0.6355);

    glVertex2d(635,909);
    glVertex2d(635,655);
    glVertex2d(911,655);
    glVertex2d(911,909);
    glEnd();
}
void kasauC(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.4933,1.0356);

    glVertex2d(640,684);
    glVertex2d(640,676);
    glVertex2d(893,676);
    glVertex2d(893,684);
    glEnd();
}
void kasauD(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.4933,1.0356);

    glVertex2d(635,660);
    glVertex2d(635,642);
    glVertex2d(911,642);
    glVertex2d(911,660);
    glEnd();
}
void atap3(){
    glBegin(GL_POLYGON);
    glColor3f(0.6266,0.4222,0.0755);

    glVertex2d(635,642);
    glVertex2d(689,515);
    glVertex2d(901,515);
    glVertex2d(910,642);
    glEnd();
}
void mainanatap(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(689,515);
    glVertex2d(689,500);
    glVertex2d(901,500);
    glVertex2d(901,515);
    glEnd();
}
void tembokluarsekali(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.4044,0.4355);

    glVertex2d(910,1000);
    glVertex2d(910,775);
    glVertex2d(935,775);
    glVertex2d(935,1000);
    glEnd();
}
void atasatap1a(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.8711);

    glVertex2d(160,628);
    glVertex2d(58,623);
    glVertex2d(644,178);
    glVertex2d(668,242);
    glEnd();
}
void atasatap1b(){
    glBegin(GL_POLYGON);
    glColor3f(0.9080,0.9148,0.8711);

    glVertex2d(689,485);
    glVertex2d(745,447);
    glVertex2d(668,242);
    glVertex2d(591,296);
    glEnd();
}
void atasatap2(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(58,623);
    glVertex2d(58,598);
    glVertex2d(605,178);
    glVertex2d(644,178);
    glEnd();
}
void jendela1l(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(708,870);
    glVertex2d(708,723);
    glVertex2d(756,723);
    glVertex2d(756,870);
    glEnd();
}
void jendela1d(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(721,861);
    glVertex2d(721,738);
    glVertex2d(745,738);
    glVertex2d(745,861);
    glEnd();
}
void jendela2l(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(778,871);
    glVertex2d(778,723);
    glVertex2d(828,723);
    glVertex2d(828,871);
    glEnd();
}
void jendela2d(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(790,861);
    glVertex2d(790,738);
    glVertex2d(816,738);
    glVertex2d(816,861);
    glEnd();
}
void pentilasi1(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(708,710);
    glVertex2d(708,692);
    glVertex2d(734,692);
    glVertex2d(734,710);
    glEnd();
}
void pentilasi2(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(754,710);
    glVertex2d(754,692);
    glVertex2d(779,692);
    glVertex2d(779,710);
    glEnd();
}
void pentilasi3(){
    glBegin(GL_POLYGON);
    glColor3f(0.4044,0.3333,0.1288);

    glVertex2d(803,710);
    glVertex2d(803,692);
    glVertex2d(828,692);
    glVertex2d(828,710);
    glEnd();
}
void outdoor(){
    glBegin(GL_POLYGON);
    glColor3f(0.3733,0.8222,0.3200);

    glVertex2d(935,1000);
    glVertex2d(935,905);
    glVertex2d(1000,905);
    glVertex2d(1000,1000);
    glEnd();
}
void hiasatap1(){
    glBegin(GL_POLYGON);
    glColor3f(0.3600,0.3733,0.4222);

    glVertex2d(111,625);
    glVertex2d(123,625);
    glVertex2d(661,219);
    glVertex2d(657,210);
    glEnd();
}
void pohon1(){
    glBegin(GL_POLYGON);
    glColor3f(0.4088,0.3333,0.1288);

    glVertex2d(1000,905);
    glVertex2d(972,905);
    glVertex2d(972,849);
    glVertex2d(1000,849);
    glEnd();
}
void pohon2(){
    glBegin(GL_POLYGON);
    glColor3f(0.5111,0.8488,0.3022);

    glVertex2d(1000,849);
    glVertex2d(939,849);
    glVertex2d(976,802);
    glVertex2d(1000,802);
    glEnd();
}
void pohon3(){
    glBegin(GL_POLYGON);
    glColor3f(0.5111,0.8488,0.3022);

    glVertex2d(1000,802);
    glVertex2d(953,802);
    glVertex2d(986,758);
    glVertex2d(1000,758);
    glEnd();
}
void pohon4(){
    glBegin(GL_POLYGON);
    glColor3f(0.5111,0.8488,0.3022);

    glVertex2d(1000,758);
    glVertex2d(970,758);
    glVertex2d(1000,710);

    glEnd();
}
void tambahan1(){
    glBegin(GL_POLYGON);
    glColor3f(0.8444,0.7866,0.9555);

    glVertex2d(468,677);
    glVertex2d(457,677);
    glVertex2d(457,615);
    glVertex2d(468,615);
    glEnd();
}
void hiasankasauA(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.2266,1.0356);

    glVertex2d(563,657);
    glVertex2d(563,673);
    glVertex2d(591,673);
    glVertex2d(591,657);
    glEnd();
}
void hiasankasauB(){
    glBegin(GL_POLYGON);
    glColor3f(0.9422,0.2266,1.0356);

    glVertex2d(308,638);
    glVertex2d(308,651);
    glVertex2d(320,651);
    glVertex2d(320,638);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1000, 1000, "Rumah Impian", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        setup_viewport(window);
        jalan();
        halaman1();
        halaman2();
        outdoor();
        atasatap1a();
        atasatap1b();
        temboksamping1();
        temboksamping2a();
        temboksamping2b();
        atap();
        atap1();
        tembokataspintu1();
        tembokataspintu3();
        tembokputih();
        jendela();
        tembokpintu1();
        tembokpintu2();
        pintu1();
        pintu2();
        tembokluar4();
        tembokluar();
        tembokluar1();
        tembokluar2();
        tembokluar3();
        lantai1();
        tembokdalam1();
        tembokdalam2();
        lantaiatas1();
        tembokluarorange1();
        tembokluarorange2();
        lantai2();
        tembokluar5a();
        tembokluar5b();
        tembokataspintu2();
        tambahan1();
        kasauA();
        kasauB();
        temboksamping3();
        kasauC();
        kasauD();
        atap3();
        mainanatap();
        tembokluarsekali();
        atasatap2();
        jendela1l();
        jendela1d();
        jendela2l();
        jendela2d();
        pentilasi1();
        pentilasi2();
        pentilasi3();
        hiasatap1();
        pohon1();
        pohon2();
        pohon3();
        pohon4();
        hiasankasauA();
        hiasankasauB();

        glfwSwapBuffers(window);
        glfwPollEvents();

    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
