#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 600, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void BG(){
    // BG
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f(0,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(0,600);
    glEnd();
}

void kotak(float a, float b, float c, float d, float e, float f, float g, float h){
    glBegin(GL_POLYGON);
    glVertex2f(a,b);
    glVertex2f(c,d);
    glVertex2f(e,f);
    glVertex2f(g,h);
    glEnd();
}

void garis(){
    glColor3ub(216,216,216);
    kotak(56.77,169.21, 67.09,175.19, 66.95,330.7, 56.77,324.61);

    glColor3ub(245,245,241);
    kotak(56.77,169.21, 239.62,68.11, 249.18,73.69, 67.09,175.19);

    glColor3ub(245,245,241);
    kotak(229.79,74, 239.33,68.4, 307.1,107.24, 297.17,113.01);

    glColor3ub(245,245,241);
    kotak(286.84,107.04, 387.32,49.84, 396.87,55.42, 297.16,113.01);

    glColor3ub(245,245,241);
    kotak(387.32,60.97, 396.87,55.42, 555.82,146.47, 545.17,152.15);

    glColor3ub(229,229,229);
    kotak(545.17,152.15, 592.21,124.99, 601.91,130.48, 555.82,157.49);

    glColor3ub(245,245,241);
    kotak(592.21,136.35, 601.91,130.48, 743.23,212.07, 733.53,217.94);

    glColor3ub(135,124,78);
    kotak(733.53,217.94, 743.23,212.07, 743.23,373.16, 733.53,378.79);

    glColor3ub(135,124,78);
    kotak(435.22,543.43, 743.23,364.44, 743.21,373.16, 435.2,552.16);

    glColor3ub(135,124,78);
    kotak(56.77,333.33, 56.77,324.65, 435.22,543.43, 435.2,552.16);
}

void animasi(){
    glPushMatrix();
    glRotatef((float) glfwGetTime() * 75.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(100,250,116);
    glVertex2f(100,150);
    glVertex2f(150,150);
    glVertex2f(150,200);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(255,0,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * -500.f, 0.f, 0.f);
    glColor3ub(255,255,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.f , (float) glfwGetTime() * 200.f, 0.f);
    glColor3ub(0,255,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.f, (float) glfwGetTime() * -200.f, 0.f);
    glColor3ub(0,255,255);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(0,0,255);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();
}

void tambahan(){
    for(int i=0;i<3;i++){
        for(int j=0;j<6;j++){
            glBegin(GL_POLYGON);
            glColor3ub(0,193,198);
            glVertex2f(70+(j*40),530+(i*25));
            glVertex2f(90+(j*40),510+(i*25));
            glVertex2f(110+(j*40),530+(i*25));
            glEnd();
        }
    }

        for(int i=0;i<3;i++){
        for(int j=0;j<6;j++){
            glBegin(GL_POLYGON);
            glColor3ub(0,193,198);
            glVertex2f(880+(j*40),40+(i*25));
            glVertex2f(900+(j*40),20+(i*25));
            glVertex2f(920+(j*40),40+(i*25));
            glEnd();
        }
    }
}

void hiasan(){
    // 1
    glBegin(GL_POLYGON);
    glColor3ub(255,152,0);
    glVertex2f(470,425);
    glVertex2f(435,315);
    glVertex2f(725,600);
    glVertex2f(640,600);
    glEnd();

    // 2
    glBegin(GL_POLYGON);
    glColor3ub(244,44,43);
    glVertex2f(350,215);
    glVertex2f(350,100);
    glVertex2f(850,600);
    glVertex2f(740,600);
    glEnd();

    //3
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(210,0);
    glVertex2f(310,0);
    glVertex2f(670,360);
    glVertex2f(680,470);
    glEnd();

    // 4
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(650,370);
    glColor3ub(255,152,2);
    glVertex2f(740,410);
    glColor3ub(255,204,0);
    glVertex2f(760,480);
    glEnd();

    // 5
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(450,20);
    glColor3ub(255,152,2);
    glVertex2f(570,60);
    glColor3ub(255,204,0);
    glVertex2f(580,145);
    glEnd();

    // 6
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(630,190);
    glColor3ub(255,152,2);
    glVertex2f(600,60);
    glColor3ub(255,204,0);
    glVertex2f(860,320);
    glColor3ub(255,204,0);
    glVertex2f(860,420);
    glEnd();

    // 7
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(380,0);
    glColor3ub(255,51,51);
    glVertex2f(400,0);
    glColor3ub(204,0,0);
    glVertex2f(860,460);
    glColor3ub(204,0,0);
    glVertex2f(840,460);
    glEnd();

    // 8
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(860,490);
    glColor3ub(255,51,51);
    glVertex2f(880,490);
    glColor3ub(204,0,0);
    glVertex2f(1000,600);
    glColor3ub(204,0,0);
    glVertex2f(980,600);
    glEnd();

    // 9
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(380,25);
    glColor3ub(255,51,51);
    glVertex2f(385,25);
    glColor3ub(204,0,0);
    glVertex2f(945,580);
    glColor3ub(204,0,0);
    glVertex2f(940,580);
    glEnd();

    glPushMatrix();
    glRotatef((float) glfwGetTime() * 100.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(241,95,116);
    glVertex2f(100,150);
    glVertex2f(150,150);
    glVertex2f(150,200);
    glVertex2f(100,200);
    glEnd();
    glPopMatrix();
}

void tembok(){
    glColor3ub(233,118,115);
    kotak(66.95,330.7, 66.95,167.75, 239.98,79.91, 239.98,230.15);

    glColor3ub(189,93,93);
    kotak(239.86,230.22, 239.98,79.91, 297.16,113.01, 297.16,264.49);

    glColor3ub(152,211,234);
    kotak(297.16,113.01, 387.56,60.84, 387.56,212.23, 297.16,264.49);

    glColor3ub(137,203,244);
    kotak(387.32,61.07, 545.17,152.24, 545.17,303.11, 387.56,212.04);

    glColor3ub(216,216,216);
    kotak(545.17,152.15, 555.82,157.49, 555.82,298.8, 545.17,292.67);

    glColor3ub(235,220,150);
    kotak(555.82,157.49, 592.21,136.35, 592.21,288.48, 555.82,309.63);

    glColor3ub(221,205,135);
    kotak(592.21,136.35, 733.53,217.94, 733.53,370.07, 592.21,288.48);
}

void lantai(){
    glColor3ub(255,231,178);
    kotak(66.95,330.7, 239.98,230.15, 373.75,309.2, 200.96,408.18);

    glColor3ub(255,204,163);
    kotak(211.61,414.33, 363.18,325.88, 587.24,455.09, 435.22,543.43);

    glColor3ub(117,195,242);
    kotak(297.16,264.49, 387.56,212.04, 545.17,303.11, 454.27,355.94);

    glColor3ub(231,229,226);
    kotak(445.36,373.53, 592.21,288.48, 734.5,370.6, 587.69,455.34);

    // plus1
    glColor3ub(255,204,163);
    kotak(265.75,382.81, 264.33,371.26, 293.68,354.19, 304.29,360.32);

    // plus2
    glColor3ub(231,229,226);
    kotak(454.27,355.94, 480.64,340.61, 491.51,347, 465.22,362.28);
}

void batas(){
    // 1
    glColor3ub(216,216,216);
    kotak(200.96,397.36, 255.1,365.94, 265.75,372.09, 211.61,403.5);

    glColor3ub(204,155,122);
    kotak(211.61,403.5, 265.75,372.09, 265.75,382.81, 211.61,414.33);

    glColor3ub(114,103,57);
    kotak(200.96,409.61, 200.96,397.36, 251.63,426.42, 251.63,438.77);

    glColor3ub(216,216,216);
    kotak(200.96,397.36, 208.4,392.92, 259.07,422.11, 251.63,426.21);

    glColor3ub(135,124,78);
    kotak(251.63,426.21, 259.07,421.78, 259.07,434.35, 251.63,438.79);

    // 2
    glColor3ub(216,216,216);
    kotak(293.68,343.55, 363.31,303.11, 373.75,309.2, 304.29,349.67);

    glColor3ub(204,155,122);
    kotak(293.68,354.19, 293.68,343.55, 304.29,349.67, 304.29,360.32);

    glColor3ub(204,155,122);
    kotak(304.29,360.32, 304.29,349.67, 363.58,315.12, 363.18,325.88);

    // 3
    glColor3ub(216,216,216);
    kotak(334.01,297.8, 344.22,291.96, 485.07,373.82, 474.83,379.9);

    glColor3ub(204,155,122);
    kotak(363.18,325.88, 363.58,315.12, 474.83,379.56, 474.83,390.39);

    glColor3ub(204,155,122);
    kotak(474.83,379.9, 485.07,373.82, 485.07,384.39, 474.9,390.43);

    glColor3ub(224,199,148);
    kotak(334.01,308.8, 334.01,297.8, 353.15,309.01, 343.73,314.48);

    // 4
    glColor3ub(114,103,57);
    kotak(285.1,444.95, 335.77,474.02, 335.77,486.37, 285.1,457.21);

    glColor3ub(216,216,216);
    kotak(285.1,444.95, 292.55,440.52, 343.22,469.7, 335.77,474.02);

    glColor3ub(198,198,198);
    kotak(335.77,486.37, 335.77,474.02, 343.22,469.7, 343.22,481.98);

    // 5
    glColor3ub(216,216,216);
    kotak(480.64,330.16, 545.17,292.76, 555.82,298.8, 491.47,336.19);

    glColor3ub(226,210,141);
    kotak(480.64,340.67, 480.64,330.16, 491.47,336.19, 491.47,347);

    glColor3ub(235,220,150);
    kotak(491.47,347, 491.47,336.19, 555.82,298.8, 555.82,309.63);
}

void meja(){
    glColor3ub(45,38,35);
    kotak(86.09,331.79, 86.16,307.73, 102.31,317.05, 102.24,341.12);

    glColor3ub(72,61,56);
    kotak(84.34,306.79, 103.21,295.82, 121.14,306.18, 102.27,317.14);

    glColor3ub(64,55,50);
    kotak(102.24,341.12, 102.31,317.05, 119.31,307.17, 119.25,331.24);

    glColor3ub(53,46,43);
    kotak(84.34,306.79, 102.27,317.14, 102.27,319.17, 84.34,308.82);

    glColor3ub(53,46,43);
    kotak(102.27,317.14, 121.14,306.18, 121.14,308.2, 102.27,319.17);
}

void kasur(){
    meja();

    // kasur
    glColor3ub(239,234,228);
    kotak(108.57,333.98, 178.91,293.1, 237.58,326.96, 167.23,367.85);

    glColor3ub(242,242,242);
    kotak(112.84,325.52, 177.4,288, 231.23,319.09, 166.67,356.6);

    glColor3ub(178,82,82);
    kotak(137.98,310.73, 142.47,308.12, 196.48,339.3, 191.82,342.01);

    glColor3ub(164,25,22);
    kotak(142.3,308.22, 177.39,287.83, 231.23,319.11, 196.48,339.31);

    glColor3ub(178,28,28);
    kotak(150.81,335.6, 161.3,329.51, 180.68,340.7, 170.2,346.8);

    glColor3ub(221,221,221);
    kotak(166.67,356.6, 231.23,319.09, 231.21,327.43, 166.65,364.95);

    glColor3ub(178,82,82);
    kotak(191.81,350.34, 191.82,342.01, 196.48,339.3, 196.48,347.62);

    glColor3ub(158,27,27);
    kotak(196.48,347.62, 196.48,339.3, 231.23,319.11, 231.23,327.44);

    glColor3ub(244,228,217);
    kotak(167.2,376.94, 167.23,367.85, 237.58,326.96, 237.55,336.06);

    glColor3ub(244,228,217);
    kotak(166.98,382.67, 166.98,373.56, 177.09,367.74, 177.09,376.83);

    glColor3ub(244,228,217);
    kotak(227.46,347.62, 227.46,341.89, 237.56,336.06, 237.58,341.78);

    glColor3ub(229,213,202);
    kotak(222.55,344.78, 227.48,341.91, 227.48,347.62, 222.55,344.78);

    // plus
    glColor3ub(244,228,217);
    kotak(108.67,320.07, 112.84,318.05, 171.27,351.51, 167.21,353.87);

    glColor3ub(227,211,203);
    kotak(108.67,343.07, 108.67,320.07, 167.21,353.87, 167.21,376.94);

    glColor3ub(227,211,203);
    kotak(108.67,348.8, 108.67,343.07, 118.65,348.91, 118.65,354.64);

    glColor3ub(227,212,203);
    kotak(157.09,376.83, 157.09,371.1, 167.2,376.94, 167.2,382.67);

    glColor3ub(211,194,186);
    kotak(118.65,354.64, 118.65,348.91, 123.62,351.78, 118.65,354.64);

    glColor3ub(244,228,217);
    kotak(167.21,353.87, 171.27,351.51, 171.18,380.62, 167.13,382.98);

    glPushMatrix();
    glTranslatef(91.4,53.18,0.f);
    meja();
    glPopMatrix();
}

void lemari(){
    glColor3ub(183,146,98);
    kotak(175.74,277.61, 175.74,263.2, 178.65,261.53, 178.65,275.94);

    glColor3ub(183,146,98);
    kotak(193.38,287.92, 193.38,273.51, 196.28,275.18, 196.28,289.59);

    glColor3ub(183,146,98);
    kotak(255.28,252.16, 255.28,237.75, 258.18,239.42, 258.18,253.83);

    glColor3ub(234,201,157);
    kotak(172.66,202.4, 237.48,164.98, 260.92,178.61, 196.12,216.02);

    glColor3ub(196,161,106);
    kotak(172.84,261.54, 172.67,202.4, 196.12,216.02, 196.28,275.16);

    glColor3ub(188,152,100);
    kotak(196.28,275.16, 196.12,216.02, 260.92,178.61, 261.09,237.75);

    glColor3ub(209,173,125);
    kotak(199.02,217.7, 226.69,201.73, 226.69,254.26, 199.17,270.15);

    glColor3ub(209,173,125);
    kotak(230.52,199.51, 258.04,183.63, 258.18,236.07, 230.52,252.05);

    glColor3ub(196,161,106);
    kotak(172.83,275.94, 172.83,261.53, 175.74,263.2, 175.74,277.61);

    glColor3ub(196,161,106);
    kotak(196.28,289.59, 196.28,275.18, 199.19,273.51, 199.19,287.92);

    glColor3ub(196,161,106);
    kotak(258.18,253.83, 258.18,239.42, 261.09,237.75, 261.09,252.16);

    glColor3ub(170,130,77);
    kotak(222.39,235.59, 222.39,222.05, 223.88,221.2, 223.88,234.74);

    glColor3ub(170,130,77);
    kotak(233.43,228.85, 233.43,215.31, 234.92,214.46, 234.92,228);
}

void kursiloop(){
    glColor3ub(19,112,122);
    kotak(335.18,432.13, 335.18,422.7, 361.18,437.82, 361.18,447.16);

    glColor3ub(19,112,122);
    kotak(361.18,437.82, 385.16,423.95, 385.16,433.29, 361.18,447.16);

    glColor3ub(18,119,134);
    kotak(361.18,437.82, 341.07,426.13, 365.02,412.23, 385.16,423.95);
}

void kursismp(){
    //kotak kiri
    glColor3ub(13,94,96);
    kotak(325.13,443.97, 325.13,413.68, 355.68,431.46, 355.68,461.06);

    glColor3ub(81,173,189);
    kotak(325.13,413.68, 335.29,407.81, 365.84,425.58, 355.68,431.46);

    glColor3ub(15,102,109);
    kotak(355.68,461.06, 355.68,431.46, 365.84,425.58, 365.84,455.05);
}

void kursiatas(){
    glColor3ub(18,119,134);
    kotak(341.07,426.21, 340.96,388.54, 364.91,374.71, 365.02,412.39);

    glColor3ub(19,112,122);
    kotak(335.29,422.85, 335.18,385.18, 340.96,388.54, 341.07,426.21);

    glColor3ub(81,173,189);
    kotak(340.96,388.54, 335.18,385.18, 356.99,372.59, 364.91,374.71);
}

void kursi(){
    // kursi kanan
    glPushMatrix();
    glTranslatef(84.16,-48.82,0.f);
    kursismp();
    glPopMatrix();

    //
    glPushMatrix();
    glTranslatef(53.04,-30.8,0.f);
    kursiatas();
    glPopMatrix();

    //
    glPushMatrix();
    glTranslatef(26.52,-15.4,0.f);
    kursiatas();
    glPopMatrix();

    // kursi atas
    kursiatas();

    //
    glColor3ub(11,78,81);
    kotak(360.76,449.94, 332.75,427.5, 418.04,377.83, 439.85,403.13);

    //
    glPushMatrix();
    glTranslatef(53.04,-30.8,0.f);
    kursiloop();
    glPopMatrix();

    //
    glPushMatrix();
    glTranslatef(26.52,-15.4,0.f);
    kursiloop();
    glPopMatrix();

    //
    kursiloop();

    //
    glColor3ub(15,102,109);
    kotak(355.68,461.06, 355.68,451.92, 450,397.25, 450,406.32);

    // kursi kiri
    kursismp();
}

void mejatp(){
    glColor3ub(119,91,60);
    kotak(399.93,464.55, 399.93,458.72, 488.7,447.97, 428.61,481.21);

    glColor3ub(173,136,87);
    kotak(394.9,473.69, 394.9,455.85, 397.86,457.54, 397.86,475.37);

    glColor3ub(145,112,73);
    kotak(397.86,475.37, 397.86,457.54, 400.82,455.85, 400.82,473.69);

    glColor3ub(145,112,73);
    kotak(425.66,491.59, 425.66,473.76, 428.62,475.44, 428.62,493.28);

    glColor3ub(173,136,87);
    kotak(428.62,493.28, 428.62,475.44, 431.58,473.76, 431.58,491.59);

    glColor3ub(173,136,87);
    kotak(394.91,455.86, 394.9,452.79, 428.61,472.38, 428.62,475.45);

    glColor3ub(173,136,87);
    kotak(428.62,475.45, 428.61,472.38, 493.13,435.14, 493.13,438.21);

    glColor3ub(196,161,106);
    kotak(394.9,452.79, 459.42,415.55, 493.13,435.14, 428.61,472.38);
}

void alastp(){
    glColor3ub(102,102,102);
    kotak(448.21,506.95, 448.21,488.4, 463.52,497.27, 463.52,515.85);

    glColor3ub(124,124,124);
    kotak(463.52,515.85, 463.52,497.27, 534.33,456.39, 534.33,474.97);

    glColor3ub(234,234,234);
    kotak(443.8,485.8, 443.79,483.37, 463.52,494.84, 463.52,497.27);

    glColor3ub(234,234,234);
    kotak(463.52,497.27, 463.52,494.84, 538.75,451.41, 538.76,453.83);

    glColor3ub(242,242,242);
    kotak(463.52,494.84, 443.79,483.37, 519.02,439.94, 538.75,451.41);
}

void tp(){
    glColor3ub(59,59,59);
    kotak(479.66,474.04, 479.65,471.74, 488.67,476.98, 488.68,479.29);

    glColor3ub(41,41,41);
    kotak(488.67,476.98, 488.68,479.29, 506.5,466.68, 506.51,468.99);

    glColor3ub(66,66,66);
    kotak(479.65,471.74, 497.48,461.45, 506.5,466.68, 488.67,476.98);

    glColor3ub(41,41,41);
    kotak(493.59,474.14, 500.95,469.89, 500.95,463.46, 486.22,469.89);

    glColor3ub(77,77,77);
    kotak(465.71,481.83, 465.61,446.17, 468.04,447.58, 468.14,483.25);

    glColor3ub(77,77,77);
    kotak(465.61,446.17, 515.58,417.31, 518.02,418.73, 468.04,447.58);

    glColor3ub(51,51,51);
    kotak(468.14,483.25, 468.04,447.58, 518.02,418.73, 518.12,454.39);
}

void kakikursi(){
    glColor3ub(173,136,87);
    kotak(502.18,391.1, 502.18,371.31, 505.04,372.98, 505.04,392.76);

    glColor3ub(165,126,78);
    kotak(505.04,392.76, 505.04,372.98, 507.91,371.31, 507.91,391.1);

}

void kursisender(){
    glColor3ub(196,161,106);
    kotak(502.18,371.29, 520.87,360.42, 539.69,371.29, 520.99,382.15);

    glColor3ub(165,126,78);
    kotak(520.99,384.59, 520.99,382.15, 539.69,371.29, 539.68,373.73);

    glColor3ub(173,136,87);
    kotak(502.17,373.73, 502.17,347.12, 520.99,357.98, 520.99,384.59);

    glColor3ub(196,161,106);
    kotak(502.17,347.12, 505.05,345.47, 523.86,356.31, 520.99,357.98);

    glColor3ub(165,126,78);
    kotak(520.99,382.15, 520.99,357.98, 523.86,356.31, 523.86,380.48);
}

void kursimakan1(){
    kakikursi();

    //
    glPushMatrix();
    glTranslatef(15.95,9.18,0.f);
    kakikursi();
    glPopMatrix();

    //
    glPushMatrix();
    glTranslatef(15.76+15.95,0.f,0.f);
    kakikursi();
    glPopMatrix();

    kursisender();
}

void kursimakan(){
    kursimakan1();

    glPushMatrix();
    glTranslatef(29.82,17.8,0.f);
    kursimakan1();
    glPopMatrix();
}

void kakimeja(){
    glColor3ub(173,136,87);
    kotak(581.93,409.72, 581.93,379.08, 585.33,381.01, 585.33,411.66);

    glColor3ub(145,112,73);
    kotak(585.33,411.66, 585.33,381.01, 588.73,379.08, 588.73,409.72);
}

void mejakaki(){
    kakimeja();

    glPushMatrix();
    glTranslatef(-70.79,-40.88,0.f);
    kakimeja();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(35.37,-20.59,0.f);
    kakimeja();
    glPopMatrix();
}

void mejamakan(){
    glColor3ub(196,161,106);
    kotak(516.86,348.12, 516.86,341.5, 583.19,341.5, 585.34,387.65);

    glColor3ub(196,161,106);
    kotak(585.34,387.65, 583.19,341.5, 618.32,361.78, 618.32,368.49);

    //
    mejakaki();

    //
    glColor3ub(196,161,106);
    kotak(511.15,334.67, 549.92,312.14, 624.11,354.97, 585.34,377.5);

    glColor3ub(173,136,87);
    kotak(511.14,338.2, 511.15,334.67, 585.34,377.5, 585.33,381.03);

    glColor3ub(173,136,87);
    kotak(585.34,377.5, 585.33,381.03, 624.1,358.5, 624.11,354.97);
}

void bak(){
    glColor3ub(188,188,188);
    kotak(344.15,295.66, 344.21,273.55, 426.46,321.03, 426.4,343.15);

    glColor3ub(204,204,204);
    kotak(426.4,343.15, 426.46,321.03, 464.78,298.77, 464.71,322.02);

    glColor3ub(230,230,230);
    kotak(344.21,273.55, 382.53,251.28, 464.78,298.77, 426.46,321.03);

    glColor3ub(196,196,196);
    kotak(351.91,274.28, 383.81,255.74, 457.08,298.04, 425.18,316.58);

    glColor3ub(40,206,234);
    kotak(354.2,275.6, 382.6,259.09, 453.58,300.07, 425.18,316.58);
}

void jendela(){
    glColor3ub(242,242,242);
    kotak(606.9,231.65, 607.04,181.72, 635.79,198.32, 635.64,248.24);

    glColor3ub(208,208,208);
    kotak(607.04,181.72, 609.16,180.5, 637.9,197.09, 635.79,198.32);

    glColor3ub(208,208,208);
    kotak(635.64,248.24, 635.79,198.32, 637.9,197.09, 637.76,247.01);

    glColor3ub(140,204,221);
    kotak(609.99,230.21, 610.05,210.08, 632.63,223.12, 632.58,243.25);

    glColor3ub(140,204,221);
    kotak(610.06,206.85, 610.11,186.71, 632.7,199.75, 632.64,219.89);
}

void jendelaok(){
    jendela();

    glPushMatrix();
    glTranslatef(51.54,27.98,0.f);
    jendela();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-110.55,-20.82,0.f);
    jendela();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-110.55-100,-20.82-20.82-20.82,0.f);
    jendela();
    glPopMatrix();
}

void display()
{
    BG();
    glPushMatrix();
    glTranslatef(-60.f,0.f,0.f);
    hiasan();
    glPopMatrix();
    tembok();
    garis();
    lantai();
    kasur();
    lemari();
    bak();
    batas();
    kursi();
    mejatp();
    alastp();
    tp();
    mejamakan();
    kursimakan();
    jendelaok();
    glPushMatrix();
    glTranslatef(-200.f,0.f,0.f);
    tambahan();
    glPopMatrix();
    animasi();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 600, "Hello Triangle", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
