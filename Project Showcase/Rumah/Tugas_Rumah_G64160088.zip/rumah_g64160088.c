#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define drawLine(x1,y1,x2,y2)  glBegin(GL_LINES);  \
   glVertex2f ((x1),(y1)); glVertex2f ((x2),(y2)); glEnd();

int clindex1=0,buff1=0,
    clindex2=0,buff2=0,
    clindex3=0,buff3=0,
    clindex4=0,buff4=0,
    clindex5=0,buff5=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void lingkaran(int xp, int yp, int r, int n){
    float a,x,y;
    glBegin(GL_POLYGON);
        a=6.28/n;
        for (int i=0; i<n; i++){
            x = xp+r * cos(i*a);
            y = yp+r * sin(i*a);
            glVertex2d(x,y);
        }
    glEnd();
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClearColor(0.043, 0.333, 0.623, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(0.043, 0.333, 0.623, 0);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1000, 700, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void tree() {
    //1
    glBegin(GL_POLYGON);
        glVertex2d(577.331,160.593);
        glVertex2d(539.331,242.953);
        glVertex2d(565.331,238.734);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(577.331,160.593);
        glVertex2d(565.331,238.734);
        glVertex2d(589.819,238.734);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(577.331,160.593);
        glVertex2d(589.819,238.734);
        glVertex2d(616.876,242.953);
    glEnd();

    //2
    glBegin(GL_POLYGON);
        glVertex2d(565.331,238.734);
        glVertex2d(507.331,314.766);
        glVertex2d(555.331,282.929);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(565.331,238.734);
        glVertex2d(555.331,282.929);
        glVertex2d(600.225,282.929);
        glVertex2d(589.819,238.734);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(589.819,238.734);
        glVertex2d(600.225,282.929);
        glVertex2d(650.178,314.766);
    glEnd();

    //3
    glBegin(GL_POLYGON);
        glVertex2d(555.331,282.929);
        glVertex2d(559.331,341.383);
        glVertex2d(494.331,377.924);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(555.331,282.929);
        glVertex2d(559.331,341.383);
        glVertex2d(596.063,341.383);
        glVertex2d(600.225,282.929);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(596.063,341.383);
        glVertex2d(600.225,282.929);
        glVertex2d(663.707,377.924);
    glEnd();

    //4
    glBegin(GL_POLYGON);
        glVertex2d(559.331,341.383);
        glVertex2d(566.331,396.845);
        glVertex2d(500.331,421.193);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(559.331,341.383);
        glVertex2d(566.331,396.845);
        glVertex2d(588.778,396.845);
        glVertex2d(596.063,341.383);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(588.778,396.845);
        glVertex2d(596.063,341.383);
        glVertex2d(657.463,421.193);
    glEnd();

    //5
    glBegin(GL_POLYGON);
        glVertex2d(566.331,396.845);
        glVertex2d(562.331,454.061);
        glVertex2d(505.331,461.508);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(566.331,396.845);
        glVertex2d(562.331,454.061);
        glVertex2d(592.941,454.061);
        glVertex2d(588.778,396.845);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(592.941,454.061);
        glVertex2d(588.778,396.845);
        glVertex2d(652.259,461.508);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(562.331,454.061);
        glVertex2d(592.941,454.061);
        glVertex2d(620.519,493.102);
        glVertex2d(535.831,493.102);
    glEnd();

}

void ellipse(float cx, float cy, float rx, float ry, int num_segments)
{
    float c = cosf(2 * 3.1415926 / num_segments);//precalculate the sine and cosine
    float s = sinf(2 * 3.1415926 / num_segments);
    float t;

    float x = 1;//we start at angle = 0
    float y = 0;

    glBegin(GL_POLYGON);
    for(int i = 0; i < num_segments; i++)
    {
        //apply radius and offset
        glVertex2d(x * rx + cx, y * ry + cy);//output vertex

        //apply the rotation matrix
        t = x;
        x = c * x - s * y;
        y = s * t + c * y;
    }
    glEnd();
}

void displaybackground() {

    if(buff1==0)clindex1++; buff1++; buff1=buff1%50;
    if(buff2==0)clindex2++; buff2++; buff2=buff2%72;
    if(buff3==0)clindex3++; buff3++; buff3=buff3%98;
    if(buff4==0)clindex4++; buff4++; buff4=buff4%61;
    if(buff5==0)clindex5++; buff5++; buff5=buff5%80;

    int colorf1[2]={0.6*255,0.8*255};

    //mount1
    glBegin(GL_POLYGON);
        glColor4ub(58, 63, 63, 0.32*255);
        glVertex2d(0, 438.083);
        glVertex2d(401.859, 167.667);
        glVertex2d(628.539, 96.004);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(401.859, 167.667);
        glVertex2d(510.434, 54);
        glVertex2d(585.964, 35.573);
        glVertex2d(628.539, 96.004);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(0, 438.083);
        glVertex2d(628.539, 96.004);
        glVertex2d(863.999, 438.083);
    glEnd();
    glBegin(GL_POLYGON);
        glColor4ub(44,58,96, 0.62*255);
        glVertex2d(628.539, 96.004);
        glVertex2d(747.98, 136.407);
        glVertex2d(686.752, 179.522);
    glEnd();

    //mount2
    glBegin(GL_POLYGON);
        glColor3ub(44,58,96);
        glVertex2d(834.934, 101.274);
        glVertex2d(1000, 156.333);
        glVertex2d(1000, 272.707);
    glEnd();
    glBegin(GL_POLYGON);
        glColor4ub(47, 74, 112,255);
        glVertex2d(1000, 530.456);
        glVertex2d(419.31, 438.083);
        glVertex2d(640, 229.556);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1000, 530.456);
        glVertex2d(640, 229.556);
        glVertex2d(714.336, 150);
        glVertex2d(834.934, 101.274);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1000, 530.456);
        glVertex2d(640, 229.556);
        glVertex2d(714.336, 150);
        glVertex2d(834.934, 101.274);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1000, 530.456);
        glVertex2d(834.934, 101.274);
        glVertex2d(953, 210.521);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1000, 530.456);
        glVertex2d(953, 210.521);
        glVertex2d(1000, 239.667);
    glEnd();


    //trees
    float center_x = 579.019,
          center_y = 338.343;
    glColor4ub(39,43,61,0.84*255);
    tree();

    glPushMatrix();
        glTranslated(679.467-center_x,314.315-center_y,0);
        glColor4ub(39,43,61,0.55*255);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslated(850.347-center_x,348.833-center_y,0);
        glColor4ub(39,43,61,0.8*255);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslated(963.085-center_x,390.667-center_y,0);
        glColor4ub(39,43,61,0.55*255);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslated(51.167-center_x,345.329-center_y,0);
        glColor4ub(39,43,61,0.55*255);
        tree();
    glPopMatrix();

    glPushMatrix();
        glTranslated(135.098-center_x,360.083-center_y,0);
        glColor4ub(39,43,61,0.70*255);
        tree();
    glPopMatrix();


    //land
    glBegin(GL_POLYGON);
        glColor4ub(65,75,112,255);
        glVertex2d(0, 438.083);
        glVertex2d(714.336, 438.083);
        glVertex2d(889.521, 477.5);
        glVertex2d(1000, 530.456 );
        glVertex2d(0, 700);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(1000, 530.456 );
        glVertex2d(0, 700);
        glVertex2d(1000,700);
    glEnd();
    glBegin(GL_POLYGON);
        glColor4ub(39,43,61,0.17*255);
        glVertex2d(1000,700);
        glVertex2d(561.483,700);
        glVertex2d(889.521, 477.5);
        glVertex2d(1000, 530.456 );
    glEnd();

    //path
    glBegin(GL_POLYGON);
        glColor4ub(124,121,101,0.45*255);
        glVertex2d(-52.717,700);
        glVertex2d(248.841,700);
        glVertex2d(289, 579);
        glVertex2d(145.105, 552.191 );
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(289, 579);
        glVertex2d(145.105, 552.191 );
        glVertex2d(367.523, 488.333 );
        glVertex2d(473.84, 493.524 );
    glEnd();

    glColor3ub(169,180,181);
    lingkaran(168.583,90.696,45,1000);

    //twinkling stars
    glColor4ub(255,255,255,colorf1[clindex1%2]);
    lingkaran(51.167,141.243,6,1000);

    glColor4ub(255,255,255,colorf1[clindex2%2]);
    lingkaran(275.65,32.272,3,1000);

    glColor4ub(255,255,255,colorf1[clindex3%2]);
    lingkaran(418,49,6,1000);

    glColor4ub(255,255,255,colorf1[clindex4%2]);
    lingkaran(732,86,6,1000);

    glColor4ub(255,255,255,colorf1[clindex5%2]);
    lingkaran(962,26,6,1000);

    //default stars
    glColor4ub(255,255,255,0.6*255);
    lingkaran(38.775,32.272,3,1000);
    lingkaran(204.962,184.433,3,1000);
    lingkaran(321,112,6,1000);
    lingkaran(923,90,6,1000);
    lingkaran(635.91,30.294,3,1000);
    lingkaran(819.745,34.991,3,1000);

}

void displayshadow() {
    //1st
    glColor4ub(128,113,127,255);
    glBegin(GL_POLYGON);
        glVertex2d(108.983,448.189);
        glVertex2d(35.667,453.064);
        glVertex2d(49.703,488.75);
        glVertex2d(134.119,479.569);
    glEnd();

    glColor4ub(123,106,116,0.8*255);
    glBegin(GL_POLYGON);
        glVertex2d(316.709,528.218);
        glVertex2d(315.5,489);
        glVertex2d(208.431,473.972);
        glVertex2d(189.18,505.175);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(208.431,473.972);
        glVertex2d(189.18,505.175);
        glVertex2d(45.5,489);
        glVertex2d(124.5,480.615);
    glEnd();

    glColor4ub(153,129,127,0.74*255);
    glBegin(GL_POLYGON);
        glVertex2d(316.709,528.218);
        glVertex2d(315.5,489);
        glVertex2d(345.831,482.311);
        glVertex2d(494.331,489);
    glEnd();

    glColor4ub(123,106,116,0.5*255);
    glBegin(GL_POLYGON);
        glVertex2d(714.336,438.083);
        glVertex2d(480.167,438.083);
        glVertex2d(480.167,493.833);
        glVertex2d(535.691,497);
    glEnd();

    //2nd
    glColor4ub(123,106,116,0.5*255);
    glBegin(GL_POLYGON);
        glVertex2d(317.626,567.537);
        glVertex2d(316.417,489.15);
        glVertex2d(50.62,488.9);
        glVertex2d(-27.417,504.811);
    glEnd();

    glColor4ub(123,106,116,0.5*255);
    glBegin(GL_POLYGON);
        glVertex2d(317.626,567.537);
        glVertex2d(316.417,489.15);
        glVertex2d(50.62,488.9);
        glVertex2d(-27.417,504.811);
    glEnd();

    glColor4ub(153,129,127,0.5*255);
    glBegin(GL_POLYGON);
        glVertex2d(535.691,497);
        glVertex2d(473.84,493.524);
        glVertex2d(316.709,528.218);
        glVertex2d(316.709,567.387);
    glEnd();

    glColor4ub(123,106,116,255);
    glBegin(GL_POLYGON);
        glVertex2d(612.333,453.462);
        glVertex2d(419.31,438.083);
        glVertex2d(541.833,473.333);
    glEnd();

    glColor4ub(25,20,20,0.12*255);
    glBegin(GL_POLYGON);
        glVertex2d(187.833,485.05);
        glVertex2d(124.5,480.615);
        glVertex2d(-28.333,504.661);
        glVertex2d(147.844,536.689);
    glEnd();

    glColor4ub(128,113,127,0.51*255);
    glBegin(GL_POLYGON);
        glVertex2d(35.667,453.064);
        glVertex2d(49.703,488.75);
        glVertex2d(-28.333,504.661);
        glVertex2d(-49.5,458.727);
    glEnd();

}

void displayroof() {
    //upper
    glColor3ub(28,40,63);
    glBegin(GL_POLYGON);
        glVertex2d(332.333,167.667);
        glVertex2d(42.833,338.75);
        glVertex2d(31.25,338.75);
        glVertex2d(332.333,156.333);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2d(332.333,156.333);
        glVertex2d(519.456,267.865);
        glVertex2d(398.462,199.082);
        glVertex2d(398.611,204.252);
        glVertex2d(332.333,167.667);
    glEnd();

    //lower
    glColor3ub(95,77,71);
    glBegin(GL_POLYGON);
        glVertex2d(332.333,167.667);
        glVertex2d(317,217);
        glVertex2d(112.339,345);
        glVertex2d(42.833,338.75);
    glEnd();

    glColor3ub(112,87,80);
    glBegin(GL_POLYGON);
        glVertex2d(332.333,167.667);
        glVertex2d(317,217);
        glVertex2d(340.375,226.25);
        glVertex2d(393.789,201.486);
    glEnd();

    //line_left
    glColor4ub(52,42,41,0.58*255);
    drawLine(330.566,173.354,51.167,337.001);
    drawLine(328.313,181.569,58.017,336.095);
    drawLine(325.522,189.58,64.99,334.65);
    drawLine(323.226,196.968,72.248,333.25);

    //line_back
    drawLine(51.167,337.001,112.411,342.512);
    drawLine(58.017,336.095,112.523,340.293);
    drawLine(64.99,334.65,112.411,337.833);
    drawLine(72.248,333.25,112.583,335.75);

    //line_right
    drawLine(330.566,173.354,388.019,204.161);
    drawLine(328.313,181.569,381.852,207.02);
    drawLine(325.522,189.58,374.301,210.521);
    drawLine(323.226,196.968,367.363,213.737);

    //chimney shadow
    glColor4ub(52,42,41,64*2.55);
    glBegin(GL_POLYGON);
        glVertex2d(213.531,251.939);
        glVertex2d(213.5,266.25);
        glVertex2d(125,297.25);
        glVertex2d(130.891,286.63);
        glVertex2d(199.644,246.064);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2d(340.375,226.25);
        glVertex2d(393.789,201.486);
        glVertex2d(361,183.442);
        glVertex2d(332.833,223.226);
    glEnd();

}

void displayleftside(){

    //wall
    glColor3ub(66,65,58);
    glBegin(GL_POLYGON);
        glVertex2d(316.709,217.141);
        glVertex2d(229.299,259.457);
        glVertex2d(227.363,473.972);
        glVertex2d(315.5,481);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2d(125.003,320.376);
        glVertex2d(112.875,326.5);
        glVertex2d(109.305,466.381);
        glVertex2d(125.003,467.722);
    glEnd();

    //chimney
    glColor3ub(86,70,59);
    glBegin(GL_POLYGON);
        glVertex2d(229.589,259.316);
        glVertex2d(213.531,251.939);
        glVertex2d(211.1,475.334);
        glVertex2d(227.363,473.972);
    glEnd();

    glColor3ub(107,89,77);
    glBegin(GL_POLYGON);
        glVertex2d(211.714,475.334);
        glVertex2d(187.883,477.385);
        glVertex2d(189.5,260);
        glVertex2d(213.5,266.25);
    glEnd();

    glColor3ub(52,42,41);
    glBegin(GL_POLYGON);
        glVertex2d(213.531,251.939);
        glVertex2d(196.004,261.651);
        glVertex2d(213.287,266.04);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2d(189.5,260);
        glVertex2d(187.833,477.385);
        glVertex2d(124.5,473);
        glVertex2d(124.5,297.5);
    glEnd();

    //chimney lines
    glColor4ub(52,42,41,0.58*255);
    drawLine(205.365,263.833,205.12,475.901);
    drawLine(201.923,262.836,201.677,476.189);
    drawLine(198.094,262.157,197.908,476.52);
    drawLine(194.386,261.045,193.5,476.986);

    //windows
    //left windows
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(122.917,338.31);
        glVertex2d(116.406,342);
        glVertex2d(114,450.375);
        glVertex2d(122.914,450.797);
    glEnd();
    //---
    //lights
    glColor3ub(242,195,90);
    glBegin(GL_POLYGON);
        glVertex2d(122.917,339.756);
        glVertex2d(117.154,342.25);
        glVertex2d(115.406,450.474);
        glVertex2d(122.914,450.797);
    glEnd();
    //---
    //sills
    glColor3ub(66,55,58);
    glBegin(GL_POLYGON);
        glVertex2d(122.917,355.706);
        glVertex2d(122.932,357.54);
        glVertex2d(116.049,358.075);
        glVertex2d(116.082,356.31);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(122.917,431.807);
        glVertex2d(122.932,435.264);
        glVertex2d(114.346,434.805);
        glVertex2d(114.38,431.517);
    glEnd();


    //middle windows
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(306.667,234.167);
        glVertex2d(234.5,276);
        glVertex2d(233,455.875);
        glVertex2d(305.833,459.357);
    glEnd();
    //---
    //lights
    glColor3ub(242,195,90);
    glBegin(GL_POLYGON);
        glVertex2d(306.667,239.667);
        glVertex2d(239,275.93);
        glVertex2d(236.833,456.063);
        glVertex2d(305.833,459.357);
    glEnd();
    //---
    //sills
    glColor3ub(66,55,58);
    glBegin(GL_POLYGON);
        glVertex2d(306.667,278);
        glVertex2d(306.49,281.929);
        glVertex2d(234.125,293.167);
        glVertex2d(234.259,290.124);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(306.277,339.489 );
        glVertex2d(306.263,343.321);
        glVertex2d(233.333,349.208);
        glVertex2d(233.327,346.001);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(248.841,378.313);
        glVertex2d(233.333,378.75);
        glVertex2d(233,382.209);
        glVertex2d(248.85 ,381.75);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(305.912,438.024);
        glVertex2d(305.833,442.5);
        glVertex2d(233,440);
        glVertex2d(233,435.917);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(248.841,348.083);
        glVertex2d(251.583,348.083);
        glVertex2d(251.749,436.277);
        glVertex2d(248.85,436.337);
    glEnd();
    //===
    //minor sill
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(251.583,348.083);
        glVertex2d(251.749,436.277);
        glVertex2d(253.625,436.337);
        glVertex2d(253.244,347.939);
    glEnd();

    //foundation
    glColor3ub(38,35,46);
    glBegin(GL_POLYGON);
        glVertex2d(109.305,466.381);
        glVertex2d(108.983,472.214);
        glVertex2d(124.59,473.972);
        glVertex2d(125.003,467.722);
    glEnd();

    glColor3ub(25,21,21);
    glBegin(GL_POLYGON);
        glVertex2d(124.5,473);
        glVertex2d(124.5,480.615);
        glVertex2d(187.833,485.05);
        glVertex2d(187.833,477.385);
    glEnd();

    glColor3ub(30,26,25);
    glBegin(GL_POLYGON);
        glVertex2d(187.833,485.05);
        glVertex2d(187.833,477.385);
        glVertex2d(227.363,473.972);
        glVertex2d(227.363,481);
    glEnd();

    glColor3ub(45,36,35);
    glBegin(GL_POLYGON);
        glVertex2d(227.363,473.972);
        glVertex2d(227.363,481);
        glVertex2d(315.5,489);
        glVertex2d(315.5,481);
    glEnd();


}

void displayrightside(){

    //upper floor side
    glColor3ub(112,87,80);
    glBegin(GL_POLYGON);
        glVertex2d(340.375,226.25);
        glVertex2d(393.789,201.486);
        glVertex2d(397,360);
        glVertex2d(341.125,363.417);
    glEnd();

    //upper floor front
    glColor3ub(28,40,63);
    glBegin(GL_POLYGON);
        glVertex2d(393.789,201.486);
        glVertex2d(398.611,204.252);
        glVertex2d(403.134,361.053);
        glVertex2d(397,360);
    glEnd();
    glColor3ub(56,43,42);
    glBegin(GL_POLYGON);
        glVertex2d(519.456,267.865);
        glVertex2d(398.462,199.082);
        glVertex2d(403.134,361.053);
        glVertex2d(524,378.833);
    glEnd();

    //upper floor base
    glColor3ub(165,131,106);
    glBegin(GL_POLYGON);
        glVertex2d(397,360.083);
        glVertex2d(341.125,363.5);
        glVertex2d(479.75,380.833);
        glVertex2d(524,378.833);
    glEnd();
    glColor3ub(255,255,255);
    ellipse(410.077,367.403,11.49/2,4.139/2,1000);
    ellipse(410.077,367.403,11.49/2,4.139/2,1000);

    //upper floor window
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(459,265.542);
        glVertex2d(469.667,271.333);
        glVertex2d(472.333,344.78);
        glVertex2d(460.667,342);
    glEnd();
    //--lights
    glColor3ub(242,195,90);
    glBegin(GL_POLYGON);
        glVertex2d(459.09,269.664);
        glVertex2d(467.579,273.875);
        glVertex2d(469.394,344.08);
        glVertex2d(460.667,342);
    glEnd();

    //sidewall1
    glColor3ub(52,42,41);
    glBegin(GL_POLYGON);
        glVertex2d(315.5,481);
        glVertex2d(317,217);
        glVertex2d(340.375,226.25);
        glVertex2d(341.589,476.431);
    glEnd();

    //sidewall2
    glColor3ub(67,54,46);
    glBegin(GL_POLYGON);
        glVertex2d(341.589,476.431);
        glVertex2d(341.125,363.417);
        glVertex2d(479.75,380.833);
        glVertex2d(483.333,380.833);
        glVertex2d(485.551,455.169);
    glEnd();

    //terrace
    glColor3ub(214,193,169);//upper
    glBegin(GL_POLYGON);
        glVertex2d(411.875,453.458);
        glVertex2d(345.625,461.125);
        glVertex2d(492.788,467);
        glVertex2d(536.397,456.48);
    glEnd();
    glColor3ub(103,81,70);//sideleft
    glBegin(GL_POLYGON);
        glVertex2d(345.831,461.034);
        glVertex2d(345.831,482.311);
        glVertex2d(492.788,489.333);
        glVertex2d(492.788,467);
    glEnd();
    //----
    glColor3ub(214,193,169);//upper2
    glBegin(GL_POLYGON);
        glVertex2d(386.125,473.333);
        glVertex2d(492.788,478.988);
        glVertex2d(480.167,483.167);
        glVertex2d(367.523,476.986);
    glEnd();
    glColor3ub(73,58,52);//sideleft2
    glBegin(GL_POLYGON);
        glVertex2d(480.167,483.167);
        glVertex2d(367.523,476.986);
        glVertex2d(367.523,487.167);
        glVertex2d(480.167,493.833);
    glEnd();
    glColor3ub(73,58,52);//sideleft2
    glBegin(GL_POLYGON);
        glVertex2d(480.167,483.167);
        glVertex2d(367.523,476.986);
        glVertex2d(367.523,487.167);
        glVertex2d(480.167,493.833);
    glEnd();
    //---
    glColor3ub(62,59,76);//sideright
    glBegin(GL_POLYGON);
        glVertex2d(492.788,478.988);
        glVertex2d(480.167,483.167);
        glVertex2d(480.167,493.833);
        glVertex2d(492.788,489.333);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(492.788,467);
        glVertex2d(536.397,456.48);
        glVertex2d(536.397,474.583);
        glVertex2d(492.788,489.333);
    glEnd();

    //windows
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(319.167,231.625);
        glVertex2d(338.667,240.458);
        glVertex2d(338.676,458.569);
        glVertex2d(318.875,459.665);
    glEnd();
    //---
    //lights
    glColor3ub(242,195,90);
    glBegin(GL_POLYGON);
        glVertex2d(319.167,236.958);
        glVertex2d(336.167,243.792);
        glVertex2d(336.509,458.569);
        glVertex2d(318.875,459.665);
    glEnd();
    //---
    //sills
    glColor3ub(52,42,41);
    glBegin(GL_POLYGON);
        glVertex2d(319.167,277.583);
        glVertex2d(338.676,283.167);
        glVertex2d(338.676,287.167);
        glVertex2d(319.167,282.333);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(319.167,339);
        glVertex2d(338.676,342);
        glVertex2d(338.676,345.583);
        glVertex2d(319.167,342.833);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(318.875,438.337);
        glVertex2d(338.676,438.083);
        glVertex2d(338.676,442.599);
        glVertex2d(318.875,442.875);
    glEnd();


    //DOOR
    //base
    glColor3ub(102,70,56);
    glBegin(GL_POLYGON);
        glVertex2d(344.792,366.125);
        glVertex2d(410.805,375.367);
        glVertex2d(411.875,453.458);
        glVertex2d(345.625,461.125);
    glEnd();
    //---
    //windows
    glColor3ub(178,169,131);
    glBegin(GL_POLYGON);
        glVertex2d(347.163,370.504);
        glVertex2d(406.281,377.223);
        glVertex2d(406.692,449.25);
        glVertex2d(347.923,455.169);
    glEnd();
    //---
    //lights
    glColor3ub(242,195,90);
    glBegin(GL_POLYGON);
        glVertex2d(347.177,372.127);
        glVertex2d(405.001,378.125);
        glVertex2d(405.486,448.58);
        glVertex2d(347.923,453.431);
    glEnd();
    //---
    //sills
    glColor3ub(102,70,56);
    glBegin(GL_POLYGON);
        glVertex2d(359.972,371.96);
        glVertex2d(365.156,372.549);
        glVertex2d(365.693,453.462);
        glVertex2d(361,454);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(378.322,374.046);
        glVertex2d(383.327,374.614);
        glVertex2d(384.071,451.842);
        glVertex2d(379.012,452.182);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(392.702,375.68);
        glVertex2d(397.021,376.171);
        glVertex2d(397.36,450.679);
        glVertex2d(392.702,451.044);
    glEnd();
    //---
    //handles
    glColor3ub(67,54,46);
    glBegin(GL_POLYGON);
        glVertex2d(378.141,406.086);
        glVertex2d(379.711,406.228);
        glVertex2d(379.882,419.441);
        glVertex2d(378.141,419.587);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(382.922,406.396);
        glVertex2d(384.28,406.501);
        glVertex2d(384.415,419.099);
        glVertex2d(383.039,419.18);
    glEnd();

    //lamps
    glColor3ub(255,255,255);
    ellipse(410.077,367.403,11.49/2,4.139/2,100);
    ellipse(470.712,375.932,8.423/2,2.677/2,100);

    //lines
    glColor4ub(52,42,41,0.58*255);
    drawLine(388.019,204.161,390.75,360.382);
    drawLine(381.852,207.02,384.818,360.745);
    drawLine(374.301,210.521,378.141,361.237);
    drawLine(367.363,213.737,370.763,361.604);

    //foundation
    glColor3ub(30,26,25);
    glBegin(GL_POLYGON);
        glVertex2d(315.5,481);
        glVertex2d(315.5,489);
        glVertex2d(345.831,482.404);
        glVertex2d(345.831,475.805);
    glEnd();

    //shadow
    glColor4ub(67,54,46,0.76*255);
    glBegin(GL_POLYGON);
        glVertex2d(340.375,226.25);
        glVertex2d(393.789,201.486);
        glVertex2d(394.352,229.243);
        glVertex2d(340.375,239.667);
    glEnd();
}

int main(void)
{
    glfwInit();

    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    glfwWindowHint(GLFW_SAMPLES, 4);
    window = glfwCreateWindow(1100, 770, "M y  D r e a m L o d g e . . .", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {


        glEnable (GL_BLEND); glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        setup_viewport(window);
        displaybackground();
        displayshadow();
        displayroof();
        displayleftside();
        displayrightside();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
}

