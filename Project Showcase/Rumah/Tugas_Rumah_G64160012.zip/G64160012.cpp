#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display(){
    glClear(GL_COLOR_BUFFER_BIT) ;

    glFlush();
}

void bg(){
    glBegin(GL_POLYGON);

    glColor3ub(255,255,255);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(23,255,255);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();
}

void Rumput(){
    glBegin(GL_POLYGON);

    glColor3ub(138,171,81);
    glVertex2d(151,443);
    glVertex2d(435,248);
    glVertex2d(744,432);
    glVertex2d(440,626);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(96,117,56);
    glVertex2d(151,443);
    glVertex2d(440,626);
    glVertex2d(440,634);
    glVertex2d(151,450);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(126,126,72);
    glVertex2d(440,626);
    glVertex2d(744,432);
    glVertex2d(744,440);
    glVertex2d(440,634);

    glEnd();

}

void kolam(){
    glBegin(GL_POLYGON);
    glColor3ub(124,209,242);
    glVertex2d(578,388);
    glVertex2d(613,367);
    glVertex2d(678,405);
    glVertex2d(643,426);
    glEnd();
}

void tembok(){
    glBegin(GL_POLYGON);

    glColor3ub(31,78,35);
    glVertex2d(254,433);
    glVertex2d(254,239);
    glVertex2d(340,293);
    glVertex2d(339,487);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,89,36);
    glVertex2d(339,487);
    glVertex2d(340,293);
    glVertex2d(388,267);
    glVertex2d(436,354);
    glVertex2d(435,548);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(52,128,54);
    glVertex2d(435,548);
    glVertex2d(436,354);
    glVertex2d(544,284);
    glVertex2d(544,479);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(31,78,32);
    glVertex2d(504,504);
    glVertex2d(503,402);
    glVertex2d(540,436);
    glVertex2d(540,527);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(47,114,46);
    glVertex2d(540,527);
    glVertex2d(540,436);
    glVertex2d(580,411);
    glVertex2d(580,502);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(31,78,32);
    glVertex2d(503,402);
    glVertex2d(544,376);
    glVertex2d(580,411);
    glVertex2d(540,436);



    glEnd();
}

void jendela(){
//pintu
    glBegin(GL_POLYGON); //pintu kanan
    glColor3ub(210,173,75);
    glVertex2d(464,440);
    glVertex2d(489,424);
    glVertex2d(489,491);
    glVertex2d(464,508);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(182,152,71);
    glVertex2d(467,445);
    glVertex2d(486,433);
    glVertex2d(486,487);
    glVertex2d(467,499);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(155,131,67);
    glVertex2d(465,473);
    glVertex2d(467,470);
    glVertex2d(469,471);
    glVertex2d(467,474);
    glEnd();

    glBegin(GL_POLYGON); //pintu kiri
    glColor3ub(182,152,71);
    glVertex2d(284,361);
    glVertex2d(309,377);
    glVertex2d(309,445);
    glVertex2d(284,429);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(138,121,55);
    glVertex2d(287,370);
    glVertex2d(306,382);
    glVertex2d(306,436);
    glVertex2d(287,424);
    glEnd();


//jendela
    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(269,273);
    glVertex2d(293,288);
    glVertex2d(293,320);
    glVertex2d(269,305);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(301,293);
    glVertex2d(325,308);
    glVertex2d(325,340);
    glVertex2d(301,325);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(357,329);
    glVertex2d(383,345);
    glVertex2d(383,405);
    glVertex2d(357,389);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(393,351);
    glVertex2d(418,367);
    glVertex2d(418,428);
    glVertex2d(393,411);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(357,415);
    glVertex2d(383,431);
    glVertex2d(383,491);
    glVertex2d(357,475);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(393,437);
    glVertex2d(418,453);
    glVertex2d(418,514);
    glVertex2d(393,498);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(452,374);
    glVertex2d(478,357);
    glVertex2d(478,409);
    glVertex2d(452,426);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(508,339);
    glVertex2d(533,323);
    glVertex2d(533,375);
    glVertex2d(508,391);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(164,164,164);
    glVertex2d(549,450);
    glVertex2d(573,435);
    glVertex2d(573,471);
    glVertex2d(549,486);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(274,281);
    glVertex2d(288,291);
    glVertex2d(288,311);
    glVertex2d(274,302);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(306,302);
    glVertex2d(320,311);
    glVertex2d(320,332);
    glVertex2d(306,323);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(362,337);
    glVertex2d(378,348);
    glVertex2d(378,397);
    glVertex2d(362,386);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(397,360);
    glVertex2d(413,370);
    glVertex2d(413,419);
    glVertex2d(397,409);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(362,423);
    glVertex2d(378,434);
    glVertex2d(378,483);
    glVertex2d(362,472);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(397,446);
    glVertex2d(413,456);
    glVertex2d(413,505);
    glVertex2d(397,495);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(457,376);
    glVertex2d(473,366);
    glVertex2d(473,407);
    glVertex2d(457,417);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(512,342);
    glVertex2d(529,331);
    glVertex2d(529,372);
    glVertex2d(512,382);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,138,124);
    glVertex2d(554,453);
    glVertex2d(568,444);
    glVertex2d(569,468);
    glVertex2d(554,477);
    glEnd();
}

void tiang(){
    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(254,457);
    glVertex2d(254,449);
    glVertex2d(299,478);
    glVertex2d(299,486);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(225,225,225);
    glVertex2d(254,449);
    glVertex2d(260,446);
    glVertex2d(305,474);
    glVertex2d(299,478);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(260,446);
    glVertex2d(260,438);
    glVertex2d(305,467);
    glVertex2d(305,474);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(225,225,225);
    glVertex2d(260,438);
    glVertex2d(266,434);
    glVertex2d(311,463);
    glVertex2d(305,467);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(266,434);
    glVertex2d(266,427);
    glVertex2d(311,455);
    glVertex2d(311,463);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(225,225,225);
    glVertex2d(266,427);
    glVertex2d(273,422);
    glVertex2d(318,451);
    glVertex2d(311,455);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(266,434);
    glVertex2d(266,427);
    glVertex2d(311,455);
    glVertex2d(311,463);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(212,212,212);
    glVertex2d(299,478);
    glVertex2d(305,474);
    glVertex2d(305,481);
    glVertex2d(299,486);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(305,481);
    glVertex2d(305,467);
    glVertex2d(311,463);
    glVertex2d(311,478);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(311,478);
    glVertex2d(311,455);
    glVertex2d(318,451);
    glVertex2d(318,474);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(254,363);
    glVertex2d(257,365);
    glVertex2d(257,451);
    glVertex2d(254,449);

    glEnd();
    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(295,391);
    glVertex2d(299,392);
    glVertex2d(299,478);
    glVertex2d(295,476);

    glEnd(); //tiang
    glBegin(GL_POLYGON);

    glColor3ub(227,227,227);
    glVertex2d(257,451);
    glVertex2d(257,365);
    glVertex2d(260,364);
    glVertex2d(260,446);

    glEnd();
    glBegin(GL_POLYGON);

    glColor3ub(227,227,227);
    glVertex2d(299,478);
    glVertex2d(299,392);
    glVertex2d(302,391);
    glVertex2d(302,476);

    glEnd();
}

void genteng(){
    glBegin(GL_POLYGON);

    glColor3ub(186,164,85);
    glVertex2d(241,237);
    glVertex2d(335,153);
    glVertex2d(443,224);
    glVertex2d(331,295);

    glEnd();
    glBegin(GL_POLYGON);

    glColor3ub(149,144,68);
    glVertex2d(335,153);
    glVertex2d(368,168);
    glVertex2d(449,220);
    glVertex2d(443,224);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(141,128,64);
    glVertex2d(328,297);
    glVertex2d(449,220);
    glVertex2d(506,188);
    glVertex2d(388,263);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(225,198,102);
    glVertex2d(388,263);
    glVertex2d(506,188);
    glVertex2d(565,298);
    glVertex2d(448,373);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(146,131,67);
    glVertex2d(328,297);
    glVertex2d(388,263);
    glVertex2d(388,268);
    glVertex2d(330,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,131,67);
    glVertex2d(388,263);
    glVertex2d(448,373);
    glVertex2d(446,375);
    glVertex2d(388,268);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,151,78);
    glVertex2d(243,364);
    glVertex2d(274,337);
    glVertex2d(327,368);
    glVertex2d(295,395);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,125,64);
    glVertex2d(244,367);
    glVertex2d(243,364);
    glVertex2d(295,395);
    glVertex2d(297,399);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(211,184,93);
    glVertex2d(295,395);
    glVertex2d(327,368);
    glVertex2d(329,371);
    glVertex2d(297,399);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(221,194,101);
    glVertex2d(499,403);
    glVertex2d(544,375);
    glVertex2d(588,415);
    glVertex2d(542,444);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(145,130,67);
    glVertex2d(498,406);
    glVertex2d(499,403);
    glVertex2d(542,444);
    glVertex2d(542,447);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(170,150,74);
    glVertex2d(542,444);
    glVertex2d(588,415);
    glVertex2d(587,418);
    glVertex2d(542,447);
    glEnd();

}

void tanggak(){
    //tangga kanan
    glBegin(GL_POLYGON);
    glColor3ub(159,159,159);
    glVertex2d(453,536);
    glVertex2d(453,514);
    glVertex2d(460,518);
    glVertex2d(460,541);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(159,159,159);
    glVertex2d(460,526);
    glVertex2d(467,529);
    glVertex2d(467,544);
    glVertex2d(460,541);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(159,159,159);
    glVertex2d(467,544);
    glVertex2d(467,537);
    glVertex2d(473,541);
    glVertex2d(473,548);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,225,225);
    glVertex2d(453,514);
    glVertex2d(499,485);
    glVertex2d(506,489);
    glVertex2d(460,518);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(211,211,211);
    glVertex2d(460,518);
    glVertex2d(506,489);
    glVertex2d(506,497);
    glVertex2d(460,526);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,225,225);
    glVertex2d(460,526);
    glVertex2d(506,497);
    glVertex2d(512,501);
    glVertex2d(467,529);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(211,211,211);
    glVertex2d(467,529);
    glVertex2d(512,501);
    glVertex2d(512,508);
    glVertex2d(467,537);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,225,225);
    glVertex2d(467,537);
    glVertex2d(512,508);
    glVertex2d(518,512);
    glVertex2d(473,541);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(211,211,211);
    glVertex2d(473,541);
    glVertex2d(518,512);
    glVertex2d(518,519);
    glVertex2d(473,548);
    glEnd();
}

void kursi(){
    glBegin(GL_POLYGON);
    glColor3ub(186,134,82);
    glVertex2d(354,482);
    glVertex2d(391,505);
    glVertex2d(388,518);
    glVertex2d(351,494);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(216,169,125);
    glVertex2d(354,482);
    glVertex2d(356,481);
    glVertex2d(392,504);
    glVertex2d(391,505);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(140,91,47);
    glVertex2d(391,505);
    glVertex2d(392,504);
    glVertex2d(390,517);
    glVertex2d(388,518);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(124,79,35);
    glVertex2d(368,524);
    glVertex2d(379,526);
    glVertex2d(379,529);
    glVertex2d(368,534);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(204,160,113);
    glVertex2d(350,497);
    glVertex2d(386,520);
    glVertex2d(375,526);
    glVertex2d(338,503);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(137,129,125);
    glVertex2d(342,503);
    glVertex2d(350,499);
    glVertex2d(382,520);
    glVertex2d(375,524);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(178,126,70);
    glVertex2d(338,503);
    glVertex2d(375,526);
    glVertex2d(374,529);
    glVertex2d(338,505);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(140,91,47);
    glVertex2d(375,526);
    glVertex2d(386,520);
    glVertex2d(386,523);
    glVertex2d(375,529);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(178,126,70);
    glVertex2d(343,508);
    glVertex2d(345,509);
    glVertex2d(344,520);
    glVertex2d(343,519);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(124,79,35);
    glVertex2d(345,509);
    glVertex2d(354,515);
    glVertex2d(344,520);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(178,126,70);
    glVertex2d(366,523);
    glVertex2d(368,524);
    glVertex2d(368,534);
    glVertex2d(366,533);
    glEnd();



}


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(8000, 800, "Grid", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        bg(); //Background
        Rumput();
        kolam();
        tembok();
        jendela();
        tiang();
        genteng();
        tanggak();
        kursi();




        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
