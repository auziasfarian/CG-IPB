#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1200, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void bg()
{
     glBegin(GL_POLYGON);
        glColor3ub(113,220,252);
        glVertex2d(0,0);

        glColor3ub(17,177,255);
        glVertex2d(0,800);

        glColor3ub(163,220,237);
        glVertex2d(1200,800);

        glVertex2d(1200,0);
    glEnd();
}

void tanah()
{
    glBegin(GL_POLYGON);
        glColor3ub(158,176,134);
        glVertex2d(163,506);
        glVertex2d(574,270);
        glVertex2d(1045,538);
        glVertex2d(634,777);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(133,145,109);
        glVertex2d(163,506);
        glVertex2d(634,777);
        glVertex2d(634,797);
        glVertex2d(163,526);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(105,120,89);
        glVertex2d(634,777);
        glVertex2d(1045,538);
        glVertex2d(1045,556);
        glVertex2d(634,797);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(131,147,110);
        glVertex2d(457,609);
        glVertex2d(691,473);
        glVertex2d(925,608);
        glVertex2d(686,747);
    glEnd();
}

void kolam()
{
    glBegin(GL_POLYGON);
        glColor3ub(135,189,189);
        glVertex2d(541,608);
        glVertex2d(723,503);
        glVertex2d(723,513);
        glVertex2d(550,614);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(135,189,189);
        glVertex2d(723,503);
        glVertex2d(846,573);
        glVertex2d(837,578);
        glVertex2d(723,513);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(163,209,209);
        glVertex2d(550,614);
        glVertex2d(723,513);
        glVertex2d(723,523);
        glVertex2d(560,619);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(163,209,209);
        glVertex2d(723,513);
        glVertex2d(837,578);
        glVertex2d(827,584);
        glVertex2d(723,524);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(174,219,222);
        glVertex2d(560,619);
        glVertex2d(723,523);
        glVertex2d(827,584);
        glVertex2d(664,679);
    glEnd();
}

void pagar()
{
    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(283,139);
        glVertex2d(457,239);
        glVertex2d(457,270);
        glVertex2d(283,169);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(457,239);
        glVertex2d(691,104);
        glVertex2d(691,134);
        glVertex2d(457,270);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(283,139);
        glVertex2d(516,2);
        glVertex2d(516,32);
        glVertex2d(283,169);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(516,2);
        glVertex2d(691,104);
        glVertex2d(691,134);
        glVertex2d(516,32);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(292,329);
        glVertex2d(322,312);
        glVertex2d(322,338);
        glVertex2d(293,357);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(292,329);
        glVertex2d(379,378);
        glVertex2d(379,405);
        glVertex2d(293,357);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(379,378);
        glVertex2d(406,361);
        glVertex2d(406,388);
        glVertex2d(379,405);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(506,343);
        glVertex2d(533,359);
        glVertex2d(533,403);
        glVertex2d(506,387);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(533,359);
        glVertex2d(661,289);
        glVertex2d(661,330);
        glVertex2d(533,403);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(208,233,237);
        glVertex2d(661,289);
        glVertex2d(634,271);
        glVertex2d(634,315);
        glVertex2d(661,330);
    glEnd();

}

void dinding()
{
    glBegin(GL_POLYGON);
        glColor3ub(228,238,237);
        glVertex2d(283,169);
        glVertex2d(457,270);
        glVertex2d(457,609);
        glVertex2d(283,506);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189,204,201);
        glVertex2d(457,270);
        glVertex2d(691,134);
        glVertex2d(691,473);
        glVertex2d(457,609);
    glEnd();
}

void atap()
{
    glBegin(GL_POLYGON);
        glColor3ub(170,147,129);
        glVertex2d(283,169);
        glVertex2d(516,32);
        glVertex2d(691,134);
        glVertex2d(457,270);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(170,147,129);
        glVertex2d(292,355);
        glVertex2d(322,338);
        glVertex2d(405,387);
        glVertex2d(378,404);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(170,147,129);
        glVertex2d(506,386);
        glVertex2d(633,313);
        glVertex2d(660,329);
        glVertex2d(533,402);
    glEnd();

}

void pintu()
{
    glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(340,435);
        glVertex2d(383,460);
        glVertex2d(383,561);
        glVertex2d(340,535);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(38,65,55);
        glVertex2d(335,537);
        glVertex2d(335,427);
        glVertex2d(340,435);
        glVertex2d(340,535);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(38,65,55);
        glVertex2d(335,427);
        glVertex2d(386,457);
        glVertex2d(383,460);
        glVertex2d(340,435);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(38,65,55);
        glVertex2d(383,460);
        glVertex2d(386,457);
        glVertex2d(386,566);
        glVertex2d(383,565);
    glEnd();

     glBegin(GL_POLYGON);
        glColor3ub(38,65,55);
        glVertex2d(343,491);
        glVertex2d(345,493);
        glVertex2d(345,506);
        glVertex2d(343,505);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(225,229,230);
        glVertex2d(348,450);
        glVertex2d(356,455);
        glVertex2d(356,498);
        glVertex2d(348,493);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(225,229,230);
        glVertex2d(365,461);
        glVertex2d(373,466);
        glVertex2d(373,510);
        glVertex2d(365,505);
    glEnd();

}

void keset()
{
    glBegin(GL_POLYGON);
        glColor3ub(236,227,210);
        glVertex2d(269,569);
        glVertex2d(335,537);
        glVertex2d(386,566);
        glVertex2d(324,599);
    glEnd();
}

void jendeladepan()
{
    glBegin(GL_POLYGON);
        glColor3ub(182,241,249);
        glVertex2d(300,405);
        glVertex2d(322,419);
        glVertex2d(322,500);
        glVertex2d(300,489);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(300,405);
        glVertex2d(322,419);
        glVertex2d(322,500);
        glVertex2d(300,489);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(182,241,249);
        glVertex2d(406,466);
        glVertex2d(429,479);
        glVertex2d(429,561);
        glVertex2d(406,549);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(406,466);
        glVertex2d(429,479);
        glVertex2d(429,561);
        glVertex2d(406,549);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(182,241,249);
        glVertex2d(330,230);
        glVertex2d(394,267);
        glVertex2d(394,380);
        glVertex2d(330,342);
    glEnd();

     glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(330,230);
        glVertex2d(394,267);
        glVertex2d(394,380);
        glVertex2d(330,342);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glColor3ub(0,0,0);
        glVertex2d(362,249);
        glVertex2d(362,361);

    glEnd();
}

void jendelasamping()
{
    glBegin(GL_POLYGON);
        glColor3ub(151,210,214);
        glVertex2d(520,458);
        glVertex2d(637,392);
        glVertex2d(637,504);
        glVertex2d(520,573);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(520,458);
        glVertex2d(637,392);
        glVertex2d(637,504);
        glVertex2d(520,573);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glColor3ub(0,0,0);
        glVertex2d(559,436);
        glVertex2d(559,550);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glColor3ub(0,0,0);
        glVertex2d(601,412);
        glVertex2d(601,526);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(151,210,214);
        glVertex2d(545,252);
        glVertex2d(610,215);
        glVertex2d(610,327);
        glVertex2d(545,364);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glColor3ub(0,0,0);
        glVertex2d(545,252);
        glVertex2d(610,215);
        glVertex2d(610,327);
        glVertex2d(545,364);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glColor3ub(0,0,0);
        glVertex2d(578,233);
        glVertex2d(578,346);
    glEnd();
}

void display(){
glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1200, 800, "G64160077", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        setup_viewport(window);

        display();
        bg();
        tanah();
        kolam();
        dinding();
        pintu();
        keset();
        jendeladepan();
        jendelasamping();
        atap();
        pagar();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
