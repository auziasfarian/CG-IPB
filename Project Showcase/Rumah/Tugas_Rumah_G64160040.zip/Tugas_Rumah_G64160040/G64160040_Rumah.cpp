#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


int clindex=0,buff=0;
int colorf[3][3]={{230,230,255},{217,217,255},{192,192,255}};
//int colorg[3][3]={{56,50,50},{30,28,28},{0,0,0}};
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT) ;

    glFlush();
}
void BG()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colorf[clindex%3][0],colorf[(clindex)%3][1], colorf[(clindex)%3][2]);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(255,255,255);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

}

void alas()
{

       glBegin(GL_POLYGON);
        glColor3ub(119,123,60);
        glVertex2d(333,571);
        glVertex2d(639,376);
        glVertex2d(639,386);
        glVertex2d(333,581);
        glVertex2d(333,571);
        glVertex2d(333,581);
        glVertex2d(49,391);
        glVertex2d(49,381);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(112,158,64);
        glVertex2d(333,571);
        glVertex2d(639,376);
        glVertex2d(342,182);
        glVertex2d(49,381);

        glEnd();

}
void pohon()
{

         glBegin(GL_POLYGON);
        glColor3ub(64,37,5);
        glVertex2d(586,391);
        glVertex2d(607,382);
        glVertex2d(598,318);
        glVertex2d(588,313);

        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(76,51,21);
        glVertex2d(567,381);
        glVertex2d(586,391);
        glVertex2d(588,313);
        glVertex2d(573,324);

        glEnd();


         glBegin(GL_POLYGON);
        glColor3ub(47,87,69);
        glVertex2d(584,346);
        glVertex2d(636,321);
        glVertex2d(584,296);
        glVertex2d(532,321);

        glEnd();


         glBegin(GL_POLYGON);
        glColor3ub(47,87,69);
        glVertex2d(584,327);
        glVertex2d(632,304);
        glVertex2d(584,281);
        glVertex2d(536,304);

        glEnd();


         glBegin(GL_POLYGON);
        glColor3ub(47,87,69);
        glVertex2d(584,309);
        glVertex2d(630,287);
        glVertex2d(584,264);
        glVertex2d(538,287);

        glEnd();


         glBegin(GL_POLYGON);
        glColor3ub(47,87,69);
        glVertex2d(584,289);
        glVertex2d(623,271);
        glVertex2d(584,252);
        glVertex2d(545,271);

        glEnd();


         glBegin(GL_POLYGON);
        glColor3ub(47,87,69);
        glVertex2d(584,271);
        glVertex2d(613,257);
        glVertex2d(584,243);
        glVertex2d(555,257);

        glEnd();
        //ribet
         glBegin(GL_POLYGON);
        glColor3ub(52,102,86);
        glVertex2d(584,346);
        glVertex2d(636,321);
        glVertex2d(636,325);
        glVertex2d(584,350);

        glEnd();

        //ribet
         glBegin(GL_POLYGON);
        glColor3ub(52,102,86);
        glVertex2d(584,327);
        glVertex2d(632,304);
        glVertex2d(632,308);
        glVertex2d(584,331);

        glEnd();
        //ribet
         glBegin(GL_POLYGON);
        glColor3ub(52,102,86);
        glVertex2d(584,309);
        glVertex2d(630,287);
        glVertex2d(630,290);
        glVertex2d(584,313);

        glEnd();

        //ribet
         glBegin(GL_POLYGON);
        glColor3ub(52,102,86);
        glVertex2d(584,289);
        glVertex2d(623,271);
        glVertex2d(623,274);
        glVertex2d(584,293);

        glEnd();

        //ribet
         glBegin(GL_POLYGON);
        glColor3ub(52,102,86);
        glVertex2d(584,271);
        glVertex2d(613,257);
        glVertex2d(613,259);
        glVertex2d(584,273);

        glEnd();

        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(27,70,51);
        glVertex2d(532,321);
        glVertex2d(584,346);
        glVertex2d(584,350);
        glVertex2d(532,325);

        glEnd();

        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(27,70,51);
        glVertex2d(536,304);
        glVertex2d(584,327);
        glVertex2d(584,331);
        glVertex2d(536,308);

        glEnd();
        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(27,70,51);
        glVertex2d(538,287);
        glVertex2d(584,309);
        glVertex2d(584,313);
        glVertex2d(538,290);

        glEnd();

        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(27,70,51);
        glVertex2d(545,271);
        glVertex2d(584,289);
        glVertex2d(584,293);
        glVertex2d(545,274);

        glEnd();
        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(27,70,51);
        glVertex2d(555,257);
        glVertex2d(584,271);
        glVertex2d(584,273);
        glVertex2d(555,259);

        glEnd();


}
void jalan()
{

       glBegin(GL_POLYGON);
        glColor3ub(229,229,229);
        glVertex2d(328,461);
        glVertex2d(368,436);
        glVertex2d(459,491);
        glVertex2d(417,518);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(229,229,229);
        glVertex2d(496,467);
        glVertex2d(564,424);
        glVertex2d(498,383);
        glVertex2d(433,425);

        glEnd();

}
void rumahkiri()
{
         //bayngan
         glBegin(GL_POLYGON);
        glColor3ub(91,93,96);
        glVertex2d(95,411);
        glVertex2d(354,370);
        glVertex2d(282,491);

        glEnd();
    //rumahkanannyempilhehe
         glBegin(GL_POLYGON);
        glColor3ub(116,123,128);
        glVertex2d(446,447);
        glVertex2d(446,265);
        glVertex2d(282,159);
        glVertex2d(282,345);

        glEnd();
       glBegin(GL_POLYGON);
        glColor3ub(246,240,240);
        glVertex2d(282,491);
        glVertex2d(397,416);
        glVertex2d(397,341);
        glVertex2d(282,414);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(229,229,229);
        glVertex2d(283,491);
        glVertex2d(283,414);
        glVertex2d(169,340);
        glVertex2d(169,417);

        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(182,183,185);
        glVertex2d(282,415);
        glVertex2d(168,346);
        glVertex2d(168,390);

        glEnd();



        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(276,419);
        glVertex2d(276,413);
        glVertex2d(149,328);
        glVertex2d(149,334);
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(180,181,183);
        glVertex2d(276,419);
        glVertex2d(276,413);
        glVertex2d(413,326);
        glVertex2d(413,331);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(144,145,147);
        glVertex2d(413,326);
        glVertex2d(276,413);
        glVertex2d(149,328);
        glVertex2d(280,243);

        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(226,228,227);
        glVertex2d(276,407);
        glVertex2d(397,329);
        glVertex2d(280,256);
        glVertex2d(163,331);

        glEnd();

        //pintu
         glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(334,398);
        glVertex2d(360,383);
        glVertex2d(360,440);
        glVertex2d(334,457);

        glEnd();

        //jendela
         glBegin(GL_POLYGON);
        glColor3ub(189,225,241);
        glVertex2d(370,376);
        glVertex2d(388,365);
        glVertex2d(388,404);
        glVertex2d(370,415);

        glEnd();

        //jendela
         glBegin(GL_POLYGON);
        glColor3ub(189,225,241);
        glVertex2d(301,417);
        glVertex2d(318,406);
        glVertex2d(318,445);
        glVertex2d(301,456);

        glEnd();

        //jendela
         glBegin(GL_POLYGON);
        glColor3ub(189,225,241);
        glVertex2d(274,427);
        glVertex2d(274,438);
        glVertex2d(173,372);
        glVertex2d(173,362);

        glEnd();

         //kolam
         glBegin(GL_POLYGON);
        glColor3ub(237,244,249);
        glVertex2d(280,267);
        glVertex2d(357,311);
        glVertex2d(258,377);
        glVertex2d(182,324);

        glEnd();
         //kolam
         glBegin(GL_POLYGON);
        glColor3ub(39,220,244);
        glVertex2d(259,370);
        glVertex2d(196,325);
        glVertex2d(280,276);
        glVertex2d(343,312);

        glEnd();

        //kolam
         glBegin(GL_POLYGON);
        glColor3ub(171,173,176);
        glVertex2d(280,276);
        glVertex2d(280,275);
        glVertex2d(195,324);
        glVertex2d(196,325);

        glEnd();

          //kolam
         glBegin(GL_POLYGON);
        glColor3ub(212,216,219);
        glVertex2d(280,276);
        glVertex2d(280,275);
        glVertex2d(344,311);
        glVertex2d(343,312);

        glEnd();


         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(184,187,188);
        glVertex2d(371,345);
        glVertex2d(372,345);
        glVertex2d(372,338);
        glVertex2d(371,339);

        glEnd();


         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(128,130,131);
        glVertex2d(371,345);
        glVertex2d(369,345);
        glVertex2d(369,338);
        glVertex2d(371,339);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(184,187,188);
        glVertex2d(323,374);
        glVertex2d(324,373);
        glVertex2d(324,367);
        glVertex2d(323,367);

        glEnd();


         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(128,130,131);
        glVertex2d(323,374);
        glVertex2d(321,373);
        glVertex2d(321,366);
        glVertex2d(323,367);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(128,130,131);
        glVertex2d(303,362);
        glVertex2d(301,361);
        glVertex2d(301,355);
        glVertex2d(303,356);

        glEnd();


         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(119,123,125);
        glVertex2d(324,366);
        glVertex2d(324,369);
        glVertex2d(301,355);
        glVertex2d(301,352);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(155,161,163);
        glVertex2d(388,309);
        glVertex2d(386,308);
        glVertex2d(372,337);
        glVertex2d(374,340);

        glEnd();
        //kursi
        glBegin(GL_POLYGON);
        glColor3ub(155,161,163);
        glVertex2d(324,366);
        glVertex2d(324,369);
        glVertex2d(374,340);
        glVertex2d(372,337);
        glEnd();


         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(150,18,24);
        glVertex2d(384,308);
        glVertex2d(386,309);
        glVertex2d(372,337);
        glVertex2d(370,336);

        glEnd();

        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(150,18,24);
        glVertex2d(370,336);
        glVertex2d(324,363);
        glVertex2d(324,366);
        glVertex2d(372,337);

        glEnd();

        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(150,18,24);
        glVertex2d(324,363);
        glVertex2d(324,366);
        glVertex2d(301,352);
        glVertex2d(301,349);

        glEnd();

        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(239,242,244);
        glVertex2d(388,309);
        glVertex2d(386,308);
        glVertex2d(363,295);
        glVertex2d(366,296);

        glEnd();
        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(150,18,24);
        glVertex2d(386,309);
        glVertex2d(384,308);
        glVertex2d(361,295);
        glVertex2d(363,295);

        glEnd();

        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(234,57,33);
        glVertex2d(361,295);
        glVertex2d(384,308);
        glVertex2d(371,335);
        glVertex2d(348,322);

        glEnd();

        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(220,26,34);
        glVertex2d(347,322);
        glVertex2d(370,336);
        glVertex2d(324,363);
        glVertex2d(301,349);

        glEnd();


        //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(359,299);
        glVertex2d(381,312);
        glVertex2d(380,316);
        glVertex2d(357,303);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(355,307);
        glVertex2d(378,320);
        glVertex2d(376,324);
        glVertex2d(353,311);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(351,315);
        glVertex2d(374,328);
        glVertex2d(372,332);
        glVertex2d(349,319);

        glEnd();
         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(347,322);
        glVertex2d(370,336);
        glVertex2d(366,338);
        glVertex2d(344,325);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(340,327);
        glVertex2d(363,340);
        glVertex2d(359,342);
        glVertex2d(336,329);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(332,331);
        glVertex2d(355,345);
        glVertex2d(351,347);
        glVertex2d(328,334);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(324,336);
        glVertex2d(347,349);
        glVertex2d(343,351);
        glVertex2d(320,338);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(316,341);
        glVertex2d(339,354);
        glVertex2d(335,356);
        glVertex2d(312,343);

        glEnd();

         //kursi
         glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(308,345);
        glVertex2d(331,358);
        glVertex2d(327,361);
        glVertex2d(304,347);

        glEnd();
}

void rumahkanan()
{

       glBegin(GL_POLYGON);
        glColor3ub(177,186,194);
        glVertex2d(446,447);
        glVertex2d(446,265);
        glVertex2d(527,212);
        glVertex2d(527,394);

        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(445,271);
        glVertex2d(282,235);
        glVertex2d(282,164);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(226,228,227);
        glVertex2d(335,225);
        glVertex2d(361,240);
        glVertex2d(361,299);
        glVertex2d(335,282);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(180,181,183);
        glVertex2d(448,274);
        glVertex2d(448,268);
        glVertex2d(541,210);
        glVertex2d(541,215);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(448,274);
        glVertex2d(448,268);
        glVertex2d(267,152);
        glVertex2d(267,157);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(144,145,147);
        glVertex2d(448,268);
        glVertex2d(541,210);
        glVertex2d(354,96);
        glVertex2d(267,152);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(203,203,204);
        glVertex2d(448,262);
        glVertex2d(530,210);
        glVertex2d(354,102);
        glVertex2d(277,152);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(226,228,227);
        glVertex2d(525,214);
        glVertex2d(354,109);
        glVertex2d(282,155);
        glVertex2d(448,262);
        glEnd();

        //jendela
        glBegin(GL_POLYGON);
        glColor3ub(189,225,241);
        glVertex2d(493,344);
        glVertex2d(514,331);
        glVertex2d(514,243);
        glVertex2d(493,255);
        glEnd();
        //pintu
        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(462,437);
        glVertex2d(516,402);
        glVertex2d(516,344);
        glVertex2d(462,377);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        glVertex2d(462,386);
        glVertex2d(516,352);

        glEnd();
        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(177,186,194);
        glVertex2d(358,105);
        glVertex2d(369,98);
        glVertex2d(369,118);
        glVertex2d(358,125);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(116,123,128);
        glVertex2d(343,96);
        glVertex2d(358,105);
        glVertex2d(358,125);
        glVertex2d(343,115);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(180,181,183);
        glVertex2d(370,99);
        glVertex2d(370,100);
        glVertex2d(358,107);
        glVertex2d(358,106);
        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(358,106);
        glVertex2d(358,107);
        glVertex2d(342,96);
        glVertex2d(342,96);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(203,203,204);
        glVertex2d(358,106);
        glVertex2d(369,99);
        glVertex2d(353,89);
        glVertex2d(343,96);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(226,228,227);
        glVertex2d(358,106);
        glVertex2d(368,99);
        glVertex2d(353,90);
        glVertex2d(344,96);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(127,128,128);
        glVertex2d(358,103);
        glVertex2d(363,99);
        glVertex2d(353,93);
        glVertex2d(348,96);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(177,186,194);
        glVertex2d(343,115);
        glVertex2d(354,109);
        glVertex2d(354,128);
        glVertex2d(343,135);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(116,123,128);
        glVertex2d(343,115);
        glVertex2d(343,135);
        glVertex2d(328,126);
        glVertex2d(328,106);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(180,181,183);
        glVertex2d(355,109);
        glVertex2d(355,110);
        glVertex2d(343,118);
        glVertex2d(343,117);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(343,118);
        glVertex2d(343,117);
        glVertex2d(327,106);
        glVertex2d(327,107);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(144,145,147);
        glVertex2d(343,117);
        glVertex2d(355,109);
        glVertex2d(338,99);
        glVertex2d(327,106);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(226,228,227);
        glVertex2d(328,106);
        glVertex2d(338,100);
        glVertex2d(353,110);
        glVertex2d(343,116);

        glEnd();

        //cerobong asap
        glBegin(GL_POLYGON);
        glColor3ub(127,128,128);
        glVertex2d(343,113);
        glVertex2d(348,110);
        glVertex2d(338,103);
        glVertex2d(333,106);

        glEnd();

}

void jalan2()
{

       glBegin(GL_POLYGON);
        glColor3ub(65,64,66);
        glVertex2d(638,385);
        glVertex2d(710,434);
        glVertex2d(403,624);
        glVertex2d(323,583);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(65,64,66);
        glVertex2d(323,675);
        glVertex2d(403,624);
        glVertex2d(52,389);
        glVertex2d(-25,438);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(101,466);
        glVertex2d(122,482);
        glVertex2d(118,488);
        glVertex2d(97,472);

        glEnd();


    //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(49,428);
        glVertex2d(70,444);
        glVertex2d(66,450);
        glVertex2d(45,433);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(149,500);
        glVertex2d(170,517);
        glVertex2d(166,522);
        glVertex2d(145,506);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(194,532);
        glVertex2d(215,548);
        glVertex2d(211,554);
        glVertex2d(190,538);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(241,563);
        glVertex2d(263,580);
        glVertex2d(259,585);
        glVertex2d(238,569);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(293,600);
        glVertex2d(314,617);
        glVertex2d(311,622);
        glVertex2d(289,606);

        glEnd();
        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(334,616);
        glVertex2d(356,601);
        glVertex2d(360,606);
        glVertex2d(338,621);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(383,586);
        glVertex2d(406,571);
        glVertex2d(410,576);
        glVertex2d(388,591);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(433,553);
        glVertex2d(455,538);
        glVertex2d(459,543);
        glVertex2d(437,558);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(475,522);
        glVertex2d(498,507);
        glVertex2d(502,512);
        glVertex2d(480,527);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(521,490);
        glVertex2d(543,475);
        glVertex2d(547,480);
        glVertex2d(525,495);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(566,461);
        glVertex2d(588,446);
        glVertex2d(592,451);
        glVertex2d(570,467);

        glEnd();

        //garisjalan
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2d(611,430);
        glVertex2d(633,415);
        glVertex2d(637,420);
        glVertex2d(615,435);

        glEnd();
}

void ayunan()
{
    glBegin(GL_POLYGON);
    glColor3ub(217,172,0);
    glVertex2d(153,376);
    glVertex2d(153,373);
    glVertex2d(116,373);
    glVertex2d(116,397);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(217,172,0);
    glVertex2d(116,397);
    glVertex2d(116,373);
    glVertex2d(79,373);
    glVertex2d(79,376);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,202,0);
    glVertex2d(116,395);
    glVertex2d(153,373);
    glVertex2d(116,352);
    glVertex2d(79,373);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(119,320);
    glVertex2d(120,320);
    glVertex2d(120,348);
    glVertex2d(119,348);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(110,315);
    glVertex2d(111,315);
    glVertex2d(110,345);
    glVertex2d(111,345);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(119,320);
    glVertex2d(120,320);
    glVertex2d(120,348);
    glVertex2d(119,348);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(240,231,216);
    glVertex2d(108,339);
    glVertex2d(120,345);
    glVertex2d(120,351);
    glVertex2d(108,344);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(103,347);
    glVertex2d(109,344);
    glVertex2d(120,350);
    glVertex2d(114,354);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(108,339);
    glVertex2d(109,338);
    glVertex2d(121,345);
    glVertex2d(120,345);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(220,206,182);
    glVertex2d(120,345);
    glVertex2d(121,345);
    glVertex2d(120,350);
    glVertex2d(121,351);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(220,206,182);
    glVertex2d(120,350);
    glVertex2d(120,351);
    glVertex2d(114,355);
    glVertex2d(114,354);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(237,206,186);
    glVertex2d(114,354);
    glVertex2d(114,355);
    glVertex2d(103,348);
    glVertex2d(103,347);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(99,368);
    glVertex2d(101,369);
    glVertex2d(101,312);
    glVertex2d(99,310);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(99,310);
    glVertex2d(99,307);
    glVertex2d(126,323);
    glVertex2d(126,326);

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(128,324);
    glVertex2d(126,323);
    glVertex2d(125,383);
    glVertex2d(128,384);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(101,369);
    glVertex2d(104,367);
    glVertex2d(104,312);
    glVertex2d(101,312);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(128,384);
    glVertex2d(131,383);
    glVertex2d(131,322);
    glVertex2d(128,324);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(254,111,106);
    glVertex2d(99,307);
    glVertex2d(102,306);
    glVertex2d(131,322);
    glVertex2d(128,324);

    glEnd();
    //gagangpintu
    glBegin(GL_POLYGON);
    glColor3ub(28,28,28);
    glVertex2d(356,262);
    glVertex2d(357,262);
    glVertex2d(357,271);
    glVertex2d(356,271);

    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(211,211,211);
    glVertex2d(357,419);
    glVertex2d(358,419);
    glVertex2d(358,409);
    glVertex2d(357,409);

    glEnd();

}

void lampugarasi()
{

       glBegin(GL_POLYGON);
        glColor3ub(188,190,192);
        glVertex2d(468,447);
        glVertex2d(473,444);
        glVertex2d(473,475);
        glVertex2d(468,479);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(188,190,192);
        glVertex2d(463,444);
        glVertex2d(468,447);
        glVertex2d(468,479);
        glVertex2d(463,475);

        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(473,473);
        glVertex2d(473,479);
        glVertex2d(468,482);
        glVertex2d(468,476);

        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(463,473);
        glVertex2d(468,476);
        glVertex2d(468,482);
        glVertex2d(463,479);

        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,231,11);
        glVertex2d(466,434);
        glVertex2d(471,434);
        glVertex2d(471,444);
        glVertex2d(466,444);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(188,190,192);
        glVertex2d(576,378);
        glVertex2d(576,411);
        glVertex2d(571,414);
        glVertex2d(571,381);

        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(188,190,192);
        glVertex2d(566,380);
        glVertex2d(571,383);
        glVertex2d(571,414);
        glVertex2d(566,411);

        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(571,412);
        glVertex2d(576,408);
        glVertex2d(576,414);
        glVertex2d(571,418);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(109,110,113);
        glVertex2d(566,408);
        glVertex2d(571,412);
        glVertex2d(571,418);
        glVertex2d(566,414);

        glEnd();
        //ribetlagi
         glBegin(GL_POLYGON);
        glColor3ub(230,231,232);
        glVertex2d(571,383);
        glVertex2d(576,380);
        glVertex2d(571,377);
        glVertex2d(566,380);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,231,11);
        glVertex2d(567,369);
        glVertex2d(572,369);
        glVertex2d(572,379);
        glVertex2d(567,379);

        glEnd();

}

void atasrumah()
{

       glBegin(GL_POLYGON);
        glColor3ub(182,183,185);
        glVertex2d(435,230);
        glVertex2d(464,217);
        glVertex2d(473,235);
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(182,183,185);
        glVertex2d(438,200);
        glVertex2d(446,219);
        glVertex2d(408,213);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(47,69,78);
        glVertex2d(465,215);
        glVertex2d(466,215);
        glVertex2d(466,229);
        glVertex2d(465,228);
        glVertex2d(466,215);
        glVertex2d(467,215);
        glVertex2d(467,228);
        glVertex2d(466,229);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(47,69,78);
        glVertex2d(438,198);
        glVertex2d(439,198);
        glVertex2d(439,212);
        glVertex2d(438,212);
        glVertex2d(439,198);
        glVertex2d(440,198);
        glVertex2d(440,212);
        glVertex2d(439,212);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(54,177,86);
        glVertex2d(462,214);
        glVertex2d(504,189);
        glVertex2d(514,210);
        glVertex2d(473,236);

        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(71,98,109);
        glVertex2d(464,213);
        glVertex2d(505,188);
        glVertex2d(516,209);
        glVertex2d(474,235);

        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(54,177,86);
        glVertex2d(435,197);
        glVertex2d(477,172);
        glVertex2d(487,193);
        glVertex2d(446,220);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(71,98,109);
        glVertex2d(437,196);
        glVertex2d(478,171);
        glVertex2d(489,193);
        glVertex2d(447,219);


        glEnd();
}
void lampujalan(){

       glBegin(GL_POLYGON);
        glColor3ub(229,211,189);
        glVertex2d(328,575);
        glVertex2d(333,573);
        glVertex2d(333,479);
        glVertex2d(328,481);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(246,232,215);
        glVertex2d(328,575);
        glVertex2d(328,486);
        glVertex2d(323,484);
        glVertex2d(323,573);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(229,211,189);
        glVertex2d(313,489);
        glVertex2d(333,479);
        glVertex2d(333,484);
        glVertex2d(313,494);
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(252,242,232);
        glVertex2d(308,487);
        glVertex2d(328,477);
        glVertex2d(333,479);
        glVertex2d(313,489);
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(212,237,237);
        glVertex2d(279,495);
        glVertex2d(300,484);
        glVertex2d(321,495);
        glVertex2d(300,506);
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(172,222,224);
        glVertex2d(300,506);
        glVertex2d(321,495);
        glVertex2d(321,497);
        glVertex2d(300,508);
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(192,229,231);
        glVertex2d(279,495);
        glVertex2d(300,506);
        glVertex2d(300,508);
        glVertex2d(279,497);
        glEnd();


}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Grid", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();

        //panggil fungsi m
        BG();
        alas();
        pohon();
        jalan();
        rumahkiri();
        rumahkanan();
        jalan2();
        lampugarasi();
        atasrumah();
        ayunan();
        lampujalan();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
