#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1500, 1500, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);// your code here, maybe
    glFlush();
}

void bg(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(0,0);
    glVertex2d(1500,0);
    glVertex2d(1500,1500);
    glColor3ub(212,236,250);
    glVertex2d(0,1500);
    glEnd();

}

void pondasi(){

    glBegin(GL_POLYGON);
    glColor3ub(152,160,90);
    glVertex2d(59.15,786.57);
    glVertex2d(861.28,1249.72);
    glVertex2d(861.28,1272.71);
    glVertex2d(59.15,809.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,139,78);
    glVertex2d(861.28,1249.72);
    glVertex2d(1444.58,912.96);
    glVertex2d(1444.58,935.95);
    glVertex2d(861.28,1272.71);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(121,162,110);
    glVertex2d(642.51,449.75);
    glVertex2d(1444.58,912.96);
    glVertex2d(861.28,1249.72);
    glColor3ub(175,183,103);
    glVertex2d(58.15,787.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204,198,202);
    glVertex2d(423.94,826.65);
    glVertex2d(788.42,1039.25);
    glVertex2d(642.63,1123.42);
    glVertex2d(278.18,913.05);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204,198,202);
    glVertex2d(607.36,934.72);
    glVertex2d(654.43,923.73);
    glVertex2d(821.46,1020.17);
    glVertex2d(788.42,1039.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204,198,202);
    glVertex2d(680.37,588.22);
    glVertex2d(1329.68,912.96);
    glVertex2d(985.41,1114.82);
    glVertex2d(569.79,874.87);
    glEnd();

}

void kacagede(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(416.34,681.41);
    glVertex2d(602.61,788.96);
    glVertex2d(601.61,900.16);
    glVertex2d(416.34,792.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(552.01,741.14);
    glVertex2d(561.42,752.49);
    glVertex2d(444.86,838.89);
    glVertex2d(433.01,833.95);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(606.57,765.83);
    glVertex2d(618.5,789.63);
    glVertex2d(502.72,883.15);
    glVertex2d(474.26,864.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(620.99,812.08);
    glVertex2d(620.99,835.57);
    glVertex2d(534.3,896.65);
    glVertex2d(531.46,880.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(416.34,681.41);
    glVertex2d(469.9,712.33);
    glVertex2d(469.6,823.57);
    glVertex2d(416.34,792.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(469.9,712.36);
    glVertex2d(474.26,714.86);
    glVertex2d(474.26,819.24);
    glVertex2d(469.9,821.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(469.9,818.21);
    glVertex2d(469.9,816.3);
    glVertex2d(474.26,813.88);
    glVertex2d(602.61,887.59);
    glVertex2d(602.61,894.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(469.69,815.01);
    glVertex2d(602.61,891.75);
    glVertex2d(602.61,898.4);
    glVertex2d(469.69,821.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(469.69,712.23);
    glVertex2d(602.61,788.96);
    glVertex2d(602.61,795.61);
    glVertex2d(469.69,718.9);
    glEnd();

}

void garasi(){

    glBegin(GL_POLYGON);
    glColor3ub(56,80,91);
    glVertex2d(365.84,816.84);
    glVertex2d(477.77,881.51);
    glVertex2d(477.77,989.39);
    glVertex2d(365.84,924.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,816.84);
    glVertex2d(477.77,881.51);
    glVertex2d(477.77,886.1);
    glVertex2d(365.84,821.56);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,826.36);
    glVertex2d(477.77,891.02);
    glVertex2d(477.77,895.62);
    glVertex2d(365.84,831.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,835.87);
    glVertex2d(477.77,900.53);
    glVertex2d(477.77,905.13);
    glVertex2d(365.84,840.59);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,845.38);
    glVertex2d(477.77,910.05);
    glVertex2d(477.77,914.64);
    glVertex2d(365.84,850.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,854.9);
    glVertex2d(477.77,919.56);
    glVertex2d(477.77,924.16);
    glVertex2d(365.84,859.61);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,864.41);
    glVertex2d(477.77,929.07);
    glVertex2d(477.77,933.67);
    glVertex2d(365.84,869.13);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,873.92);
    glVertex2d(477.77,938.59);
    glVertex2d(477.77,943.18);
    glVertex2d(365.84,878.64);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,883.43);
    glVertex2d(477.77,948.1);
    glVertex2d(477.77,952.7);
    glVertex2d(365.84,888.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,892.95);
    glVertex2d(477.77,957.61);
    glVertex2d(477.77,962.21);
    glVertex2d(365.84,897.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,902.46);
    glVertex2d(477.77,967.13);
    glVertex2d(477.77,971.72);
    glVertex2d(365.84,907.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(102,134,150);
    glVertex2d(365.84,911.98);
    glVertex2d(477.77,976.64);
    glVertex2d(477.77,983.09);
    glVertex2d(365.84,918.54);
    glEnd();

}

void td(){
    /*
    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(350.77,618.16);
    glVertex2d(642.5,786.59);
    glVertex2d(642.5,955.01);
    glVertex2d(496.66,870.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(350.77,618.16);
    glVertex2d(496.66,870.8);
    glVertex2d(496.66,1000.22);
    glVertex2d(350.83,916.13);
    glEnd();
*/

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(350.77,618.16);
    glVertex2d(642.53,786.59);
    glVertex2d(602.61,788.96);
    glVertex2d(416.34,681.41);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(642.53,786.59);
    glVertex2d(642.53,955.01);
    glVertex2d(602.61,900.16);
    glVertex2d(602.61,788.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(642.53,955.01);
    glVertex2d(602.61,900.16);
    glVertex2d(416.34,792.68);
    glVertex2d(496.66,870.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(416.34,792.68);
    glVertex2d(496.66,870.8);
    glVertex2d(477.77,881.51);
    glVertex2d(365.84,816.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(350.77,618.16);
    glVertex2d(416.34,681.41);
    glVertex2d(416.34,792.68);
    glVertex2d(365.84,816.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(350.77,618.16);
    glVertex2d(365.84,816.84);
    glVertex2d(365.84,924.85);
    glVertex2d(350.83,916.13);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(477.77,881.51);
    glVertex2d(496.66,870.8);
    glVertex2d(496.66,1000.22);
    glVertex2d(477.77,989.39);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,236,235);
    glVertex2d(618.68,941.26);
    glVertex2d(642.52,955.02);
    glVertex2d(642.52,1084.56);
    glVertex2d(618.68,1070.8);
    glEnd();

    //garasi

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(365.84,816.84);
    glVertex2d(371.56,820.15);
    glVertex2d(371.56,921.85);
    glVertex2d(365.84,924.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(185,190,198);
    glVertex2d(365.84,924.85);
    glVertex2d(371.56,921.85);
    glVertex2d(477.77,982.94);
    glVertex2d(477.77,989.39);
    glEnd();

    //kaca
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(416.34,681.41);
    glVertex2d(417.84,682.29);
    glVertex2d(417.84,791.84);
    glVertex2d(416.34,792.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(185,190,198);
    glVertex2d(416.34,792.68);
    glVertex2d(417.84,791.84);
    glVertex2d(602.61,898.2);
    glVertex2d(602.61,900.16);
    glEnd();

}

void depan(){
    kacagede();
    garasi();
    td();
}

//kumpulan kaca deket kaca gede :)
void kkdkg(){
    //kaca-batas kanan -batas bawah
    //left
    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(691.66,787.84);
    glVertex2d(707.47,778.96);
    glVertex2d(707.47,892.91);
    glVertex2d(691.66,902.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(703.51,781.23);
    glVertex2d(707.47,778.96);
    glVertex2d(707.47,892.91);
    glVertex2d(703.51,890.69);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(691.66,897.38);
    glVertex2d(703.51,890.53);
    glVertex2d(707.47,892.91);
    glVertex2d(691.66,902.06);
    glEnd();

    /*
    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(671.23,765.97);
    glVertex2d(677.9,759.34);
    glVertex2d(726.72,779.34);
    glVertex2d(718.59,805.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(674.59,806.82);
    glVertex2d(676.41,798.34);
    glVertex2d(741.46,835.93);
    glVertex2d(732.43,849.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(676.41,824.08);
    glVertex2d(731.52,863.18);
    glVertex2d(726.72,878.67);
    glVertex2d(676.41,835.93);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(668.22,861.22);
    glVertex2d(673.22,856.67);
    glVertex2d(721.43,890.69);
    glVertex2d(715.27,905.53);
    glEnd();*/

    //left~middle
    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(724.81,769.08);
    glVertex2d(740.63,760.05);
    glVertex2d(740.63,873.99);
    glVertex2d(724.81,883.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(736.66,762.32);
    glVertex2d(740.63,760.05);
    glVertex2d(740.63,873.99);
    glVertex2d(736.66,871.78);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(724.81,878.47);
    glVertex2d(736.66,871.78);
    glVertex2d(740.63,873.99);
    glVertex2d(724.81,883.15);
    glEnd();

    //right~middle
    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(757.97,750.17);
    glVertex2d(773.78,741.14);
    glVertex2d(773.78,855.08);
    glVertex2d(757.97,864.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(769.82,743.4);
    glVertex2d(773.78,741.14);
    glVertex2d(773.78,855.08);
    glVertex2d(769.82,852.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(757.97,859.56);
    glVertex2d(769.82,852.86);
    glVertex2d(773.78,855.08);
    glVertex2d(757.97,864.23);
    glEnd();

    //right
    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(791.13,731.26);
    glVertex2d(806.94,722.22);
    glVertex2d(806.94,836.17);
    glVertex2d(791.13,845.32);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(802.98,724.49);
    glVertex2d(806.94,722.22);
    glVertex2d(806.94,836.17);
    glVertex2d(802.98,833.95);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(791.13,840.64);
    glVertex2d(802.98,833.95);
    glVertex2d(806.94,836.17);
    glVertex2d(791.13,845.32);
    glEnd();

}

//pintu kaca
void pk(){
    //kaca
    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(877.72,700.3);
    glVertex2d(944.43,661.95);
    glVertex2d(944.43,780.69);
    glVertex2d(877.72,819.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(917.95,662.51);
    glVertex2d(954.74,651.15);
    glVertex2d(957.41,690.01);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(871.22,674.76);
    glVertex2d(884.4,676.43);
    glVertex2d(962.24,749.04);
    glVertex2d(959.07,778.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(857.02,715.25);
    glVertex2d(871.22,697.75);
    glVertex2d(960.72,801.32);
    glVertex2d(937.68,803.98);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(850.67,754.38);
    glVertex2d(929.94,817.37);
    glVertex2d(857.9,831.88);
    glEnd();

    //pembatas abu
    glBegin(GL_POLYGON);
    glColor3ub(166,169,171);
    glVertex2d(877.72,815.3);
    glVertex2d(941.13,778.89);
    glVertex2d(944.43,780.78);
    glVertex2d(877.72,819.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(151,152,153);
    glVertex2d(941.12,663.83);
    glVertex2d(944.43,661.95);
    glVertex2d(944.43,780.78);
    glVertex2d(941.12,778.89);
    glEnd();

    //pembatas
    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(939.08,665.04);
    glVertex2d(940.84,664.02);
    glVertex2d(940.84,781.11);
    glVertex2d(939.08,780.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(877.72,718.06);
    glVertex2d(941.11,681.5);
    glVertex2d(942.59,682.33);
    glVertex2d(877.72,719.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(911.31,702.19);
    glVertex2d(912.49,701.51);
    glVertex2d(912.49,796.57);
    glVertex2d(911.31,795.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,73,73);
    glVertex2d(908.33,704.08);
    glVertex2d(909.51,703.4);
    glVertex2d(909.51,798.45);
    glVertex2d(908.33,797.76);
    glEnd();

    //pembatas lainya
    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(877.72,700.25);
    glVertex2d(942.59,663.01);
    glVertex2d(942.77,665.77);
    glVertex2d(877.72,703.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(940.84,664.02);
    glVertex2d(943.79,662.33);
    glVertex2d(943.79,779.44);
    glVertex2d(940.84,781.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(877.72,719.7);
    glVertex2d(942.59,682.29);
    glVertex2d(942.59,685.21);
    glVertex2d(877.72,722.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(912.49,701.51);
    glVertex2d(914.47,700.37);
    glVertex2d(914.47,795.45);
    glVertex2d(912.49,796.59);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,95,95);
    glVertex2d(909.51,703.4);
    glVertex2d(911.49,702.26);
    glVertex2d(911.49,797.33);
    glVertex2d(909.51,798.48);
    glEnd();

}

//kumpulan kaca sebelah pintu kaca
void kkspk(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(954.74,655.84);
    glVertex2d(1130.62,555.14);
    glVertex2d(1130.62,656.37);
    glVertex2d(954.74,757.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(954.74,753.34);
    glVertex2d(1127.31,654.48);
    glVertex2d(1130.62,656.37);
    glVertex2d(954.74,757.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1127.31,557.01);
    glVertex2d(1127.31,654.48);
    glVertex2d(1130.62,656.37);
    glVertex2d(1130.62,555.14);
    glEnd();

    //pembatas kaca
        //right
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(1098.46,573.58);
    glVertex2d(1101.08,572.07);
    glVertex2d(1101.08,671.38);
    glVertex2d(1098.46,672.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1096.89,574.48);
    glVertex2d(1098.46,573.58);
    glVertex2d(1098.46,672.86);
    glVertex2d(1096.89,671.95);
    glEnd();

        //right~middle
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(1068.44,590.72);
    glVertex2d(1071.05,589.22);
    glVertex2d(1071.05,688.52);
    glVertex2d(1068.44,690.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1066.87,591.62);
    glVertex2d(1068.44,590.72);
    glVertex2d(1068.44,690.01);
    glVertex2d(1066.87,689.09);
    glEnd();

        //middle
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(1038.42,607.92);
    glVertex2d(1041.03,606.42);
    glVertex2d(1041.03,705.72);
    glVertex2d(1038.42,707.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1036.85,608.82);
    glVertex2d(1038.42,607.92);
    glVertex2d(1038.42,707.23);
    glVertex2d(1036.85,706.29);
    glEnd();

        //left~middle
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(1008.39,625.12);
    glVertex2d(1011.01,623.62);
    glVertex2d(1011.01,722.92);
    glVertex2d(1008.39,724.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1006.83,626.02);
    glVertex2d(1008.39,625.12);
    glVertex2d(1008.39,724.4);
    glVertex2d(1006.83,723.49);
    glEnd();

        //left
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(978.37,642.27);
    glVertex2d(980.99,640.76);
    glVertex2d(980.99,740.07);
    glVertex2d(978.37,741.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(976.81,643.17);
    glVertex2d(978.37,642.27);
    glVertex2d(978.37,741.55);
    glVertex2d(976.81,740.64);
    glEnd();

}

void ts(){

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(642.51,786.59);
    glVertex2d(1153,491.89);
    glVertex2d(806.94,722.22);
    glVertex2d(691.66,787.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(642.51,786.59);
    glVertex2d(691.66,787.84);
    glVertex2d(691.66,902.06);
    glVertex2d(642.51,955.01);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(642.51,955.01);
    glVertex2d(691.66,902.06);
    glVertex2d(806.94,836.17);
    glVertex2d(877.72,819.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(806.94,722.22);
    glVertex2d(877.72,700.25);
    glVertex2d(877.72,819.19);
    glVertex2d(806.94,836.17);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(806.94,722.22);
    glVertex2d(877.72,700.25);
    glVertex2d(1130.62,555.14);
    glVertex2d(1153,491.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(642.52,955.02);
    glVertex2d(660.4,944.7);
    glVertex2d(660.4,1074.24);
    glVertex2d(642.52,1084.56);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(707.47,778.96);
    glVertex2d(724.81,768.93);
    glVertex2d(724.81,883.15);
    glVertex2d(707.47,892.91);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(740.63,760.05);
    glVertex2d(757.97,750.01);
    glVertex2d(757.97,864.23);
    glVertex2d(740.63,873.99);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(773.78,741.14);
    glVertex2d(791.13,731.1);
    glVertex2d(791.13,845.32);
    glVertex2d(773.78,855.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(944.43,661.95);
    glVertex2d(954.74,655.84);
    glVertex2d(954.74,757.23);
    glVertex2d(944.43,780.78);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(944.43,780.78);
    glVertex2d(954.74,757.23);
    glVertex2d(1130.62,656.36);
    glVertex2d(1152.99,660.27);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(1130.62,656.36);
    glVertex2d(1152.99,660.27);
    glVertex2d(1153,491.89);
    glVertex2d(1130.62,555.14);
    glEnd();

}

void sampinglt2(){
    kkdkg();
    pk();
    kkspk();
    ts();
}

//pager teras
void pt(){

    //akar kanan
        //1
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1147.91,626.9);
    glVertex2d(1151.22,628.8);
    glVertex2d(1151.22,665.03);
    glVertex2d(1147.91,663.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1151.22,628.8);
    glVertex2d(1153.22,629.96);
    glVertex2d(1153.22,663.88);
    glVertex2d(1151.22,665.03);
    glEnd();

        //2
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1157.24,632.27);
    glVertex2d(1160.55,634.18);
    glVertex2d(1160.55,670.41);
    glVertex2d(1157.24,668.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1160.55,634.18);
    glVertex2d(1162.56,635.34);
    glVertex2d(1162.56,669.25);
    glVertex2d(1160.55,670.41);
    glEnd();

        //3
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1166.58,637.64);
    glVertex2d(1169.88,639.55);
    glVertex2d(1168.88,675.78);
    glVertex2d(1166.58,673.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1169.88,639.55);
    glVertex2d(1171.89,640.71);
    glVertex2d(1171.89,674.63);
    glVertex2d(1168.88,675.78);
    glEnd();

        //4
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1175.91,642.98);
    glVertex2d(1179.22,644.89);
    glVertex2d(1179.22,681.12);
    glVertex2d(1175.91,679.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1179.22,644.89);
    glVertex2d(1181.22,646.05);
    glVertex2d(1181.22,679.97);
    glVertex2d(1179.22,681.12);
    glEnd();

        //5
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1185.24,648.39);
    glVertex2d(1188.55,650.3);
    glVertex2d(1188.55,686.53);
    glVertex2d(1185.24,684.64);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1188.55,650.3);
    glVertex2d(1190.56,651.46);
    glVertex2d(1190.56,685.37);
    glVertex2d(1188.55,686.53);
    glEnd();

        //6
    glBegin(GL_POLYGON);
    glColor3ub(70,72,72);
    glVertex2d(1194.58,653.76);
    glVertex2d(1197.89,655.67);
    glVertex2d(1197.89,691.9);
    glVertex2d(1194.58,690.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,94,94);
    glVertex2d(1197.89,655.67);
    glVertex2d(1199.89,656.83);
    glVertex2d(1199.89,690.75);
    glVertex2d(1197.89,691.9);
    glEnd();



}

void teras(){

    glBegin(GL_POLYGON);
    glColor3ub(217,162,103);
    glVertex2d(861.28,828.69);
    glVertex2d(1152.99,660.27);
    glColor3ub(236,172,113);
    glVertex2d(1298.83,744.49);
    glVertex2d(1007.21,912.96);
    glEnd();

    pt();

}

//kaca gede lantai 1
void kglt1(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(858.42,861.66);
    glVertex2d(977.49,930.15);
    glVertex2d(977.49,1035.11);
    glVertex2d(858.42,966.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(829.24,874.87);
    glVertex2d(867.39,850.38);
    glVertex2d(885.58,867.59);
    glVertex2d(833.54,896.38);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(844.67,935.91);
    glVertex2d(915.06,884.9);
    glVertex2d(921.91,892.91);
    glVertex2d(846.39,948.39);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(848.26,973.3);
    glVertex2d(944.73,900.6);
    glVertex2d(953.39,909.91);
    glVertex2d(867.39,992.63);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(900.83,1011.3);
    glVertex2d(981.49,931.34);
    glVertex2d(989.08,958.26);
    glVertex2d(920.73,1021.64);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186,207,234);
    glVertex2d(938.75,1032.43);
    glVertex2d(994.75,964.51);
    glVertex2d(1007.22,1007.78);
    glVertex2d(962.73,1058.1);
    glEnd();

    //batas

    //batas lainya
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(858.42,861.66);
    glVertex2d(861.84,863.6);
    glVertex2d(861.84,964.5);
    glVertex2d(858.42,966.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166,168,171);
    glVertex2d(858.42,966.46);
    glVertex2d(861.84,964.51);
    glVertex2d(977.49,1031.09);
    glVertex2d(977.49,1035.11);
    glEnd();

        //left
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(885.58,877.27);
    glVertex2d(888.29,878.83);
    glVertex2d(888.29,981.64);
    glVertex2d(885.58,980.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(888.29,878.83);
    glVertex2d(889.91,879.76);
    glVertex2d(889.91,980.67);
    glVertex2d(888.29,981.64);
    glEnd();

        //middle
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(916.66,895.26);
    glVertex2d(919.37,896.82);
    glVertex2d(919.37,999.63);
    glVertex2d(916.66,998.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(919.37,896.82);
    glVertex2d(920.99,897.75);
    glVertex2d(920.99,998.65);
    glVertex2d(919.37,999.63);
    glEnd();

        //right
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(947.74,913.21);
    glVertex2d(950.45,914.77);
    glVertex2d(950.45,1017.58);
    glVertex2d(947.74,1016.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(950.45,914.77);
    glVertex2d(952.07,915.7);
    glVertex2d(952.07,1016.61);
    glVertex2d(950.45,1017.58);
    glEnd();

}

//kaca tembok lantai 1
void klt1(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(749.3,893.46);
    glVertex2d(799.4,864.5);
    glVertex2d(799.4,935.08);
    glVertex2d(749.3,907.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(749.3,893.46);
    glVertex2d(753.67,891.08);
    glVertex2d(753.67,905.38);
    glVertex2d(749.3,907.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(781.97,874.56);
    glVertex2d(786.34,872.04);
    glVertex2d(786.34,922.55);
    glVertex2d(781.97,924.99);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(749.3,907.82);
    glVertex2d(753.67,905.38);
    glVertex2d(766.73,912.73);
    glVertex2d(766.73,917.91);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(781.97,924.99);
    glVertex2d(786.34,922.55);
    glVertex2d(799.4,929.92);
    glVertex2d(799.4,935.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(766.73,883.29);
    glVertex2d(781.97,874.56);
    glVertex2d(781.97,924.99);
    glVertex2d(766.73,917.91);
    glEnd();

}

//tembok samping lantai 1 kiri
void tslt1kr(){

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(861.26,828.65);
    glVertex2d(858.42,861.66);
    glVertex2d(858.42,966.46);
    glVertex2d(715.43,912.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(861.26,828.65);
    glVertex2d(1007.21,912.96);
    glVertex2d(977.49,930.15);
    glVertex2d(858.42,861.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(977.49,930.15);
    glVertex2d(1007.21,912.96);
    glVertex2d(1007.21,1081.35);
    glVertex2d(977.49,1035.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(858.42,966.46);
    glVertex2d(977.49,1035.11);
    glVertex2d(1007.22,1081.35);
    glVertex2d(715.43,912.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(252,228,229);
    glVertex2d(496.66,870.68);
    glVertex2d(607.36,934.72);
    glVertex2d(496.66,1000.22);
    glEnd();

}

//tambok samping lantai 1 kanan
void tslt1ka(){

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1007.22,909.91);
    glVertex2d(1298.91,744.56);
    glVertex2d(1298.91,912.94);
    glVertex2d(1007.22,1081.35);
    glEnd();

}

//kaca lantai 1 kanan
void klt1k(){

    glBegin(GL_POLYGON);
    glColor3ub(156,186,225);
    glVertex2d(1039.3,925.2);
    glVertex2d(1272.74,790.45);
    glVertex2d(1272.74,904.4);
    glVertex2d(1039.3,1039.42);
    glEnd();

    //left1
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1051.15,918.59);
    glVertex2d(1055.11,916.32);
    glVertex2d(1055.11,1030.27);
    glVertex2d(1051.15,1028.05);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1039.3,1034.74);
    glVertex2d(1055.11,1030.27);
    glVertex2d(1051.15,1028.05);
    glVertex2d(1039.3,1039.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1055.11,916.32);
    glVertex2d(1075.57,903.98);
    glVertex2d(1075.57,1018.19);
    glVertex2d(1055.11,1030.27);
    glEnd();

    //left2
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1087.42,897.36);
    glVertex2d(1091.39,895.1);
    glVertex2d(1091.39,1009.04);
    glVertex2d(1087.42,1006.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1075.57,1013.52);
    glVertex2d(1091.39,1009.04);
    glVertex2d(1087.42,1006.82);
    glVertex2d(1075.57,1018.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1091.39,895.1);
    glVertex2d(1111.84,883.24);
    glVertex2d(1111.84,997.46);
    glVertex2d(1091.39,1009.04);
    glEnd();

    //left3
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1123.69,876.63);
    glVertex2d(1127.66,874.37);
    glVertex2d(1127.66,988.31);
    glVertex2d(1123.69,986.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1111.84,992.78);
    glVertex2d(1127.66,988.31);
    glVertex2d(1123.69,986.09);
    glVertex2d(1111.84,997.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1127.66,874.37);
    glVertex2d(1148.11,862.29);
    glVertex2d(1148.11,976.51);
    glVertex2d(1127.66,988.31);
    glEnd();

    //middle
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1159.96,855.68);
    glVertex2d(1163.93,853.41);
    glVertex2d(1163.93,967.35);
    glVertex2d(1159.96,965.14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1148.11,971.83);
    glVertex2d(1163.93,967.35);
    glVertex2d(1159.96,965.14);
    glVertex2d(1148.11,976.51);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1163.93,853.41);
    glVertex2d(1184.39,841.24);
    glVertex2d(1184.39,955.46);
    glVertex2d(1163.93,967.35);
    glEnd();

    //right3
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1196.23,834.63);
    glVertex2d(1200.2,832.36);
    glVertex2d(1200.2,946.31);
    glVertex2d(1196.23,944.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1184.39,950.78);
    glVertex2d(1200.2,946.31);
    glVertex2d(1196.23,944.09);
    glVertex2d(1184.39,955.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1200.2,832.36);
    glVertex2d(1220.66,820.42);
    glVertex2d(1220.66,934.64);
    glVertex2d(1200.2,946.31);
    glEnd();

    //right2
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1232.51,813.81);
    glVertex2d(1236.47,811.54);
    glVertex2d(1236.47,925.49);
    glVertex2d(1232.51,923.27);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1220.66,929.96);
    glVertex2d(1236.47,925.49);
    glVertex2d(1232.51,923.27);
    glVertex2d(1220.66,934.64);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,234,233);
    glVertex2d(1236.47,811.54);
    glVertex2d(1256.93,799.33);
    glVertex2d(1256.93,913.55);
    glVertex2d(1236.47,925.49);
    glEnd();

    //right1
    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1268.78,792.72);
    glVertex2d(1272.74,790.45);
    glVertex2d(1272.74,904.4);
    glVertex2d(1268.78,902.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187,189,191);
    glVertex2d(1256.93,908.87);
    glVertex2d(1272.74,904.4);
    glVertex2d(1268.78,902.18);
    glVertex2d(1256.93,913.55);
    glEnd();

}

void sampinglt1(){
    teras();
    kglt1();
    tslt1kr();
    klt1();
    tslt1ka();
    klt1k();
}

//warna atap
void wa(){

    glBegin(GL_POLYGON);
    glColor3ub(190,148,89);
    glVertex2d(1153,491.89);
    glColor3ub(248,178,120);
    glVertex2d(642.53,786.59);
    glVertex2d(350.77,618.16);
    glVertex2d(861.28,323.46);
    glEnd();

}

//pinggir atap
void pa(){

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(861.28,323.46);
    glVertex2d(1153,491.89);
    glVertex2d(1131.46,491.89);
    glVertex2d(861.28,335.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(1131.46,491.89);
    glVertex2d(1153,491.89);
    glVertex2d(642.53,786.59);
    glVertex2d(642.53,774.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(372.31,618.16);
    glVertex2d(642.53,774.16);
    glVertex2d(642.53,786.59);
    glVertex2d(350.77,618.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(208,210,211);
    glVertex2d(861.28,323.46);
    glVertex2d(861.28,335.9);
    glVertex2d(372.31,618.16);
    glVertex2d(350.77,618.16);
    glEnd();

    //sisi
    glBegin(GL_POLYGON);
    glColor3ub(230,231,232);
    glVertex2d(372.31,618.16);
    glVertex2d(861.25,335.89);
    glVertex2d(861.25,349.57);
    glVertex2d(385.14,625.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(241,241,242);
    glVertex2d(861.25,349.57);
    glVertex2d(861.25,335.89);
    glVertex2d(1131.46,491.89);
    glVertex2d(1119.6,498.73);
    glEnd();

}

void atap(){
    wa();
    pa();
}

void rumah(){
    depan();
    sampinglt2();
    sampinglt1();
    atap();
}

int main(void){
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1500, 1500, "Tugas Rumah M. Reyhan Nuur Akbar - <G64160115>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        bg();
        pondasi();
        rumah();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
