#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//ini buat menerima input dari user dan apa yang harus dilakukan
// esc -> exit
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

// ini tempat set view, perhitungan segala macem
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f); // kiri, kanan, bottom, top, depan, belakang
    //glOrtho(0, 800, 800, 0, 1.f, -1.f); // kiri, kanan, bottom, top, depan, belakang -> ala ala editor

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}



void display()  {
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}
const double PI = 3.141592653589793;
int i;
float sudut = 0.0;
float p=2*M_PI/100;
float kedip;
void lingkaran(float radius, float jumlah_titik, float x_tengah, float y_tengah) {
    glBegin(GL_POLYGON);
    for (i=0;i<=360;i++){
        float sudut=i*(2*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}


//////////////////////////////FUNGSI BUAT SENDIRI
void background(){
    /* BACKGROUND */
    glBegin(GL_POLYGON);
    glColor3ub(132,113,189);
    glVertex2d(0,0);
    glVertex2d(0,800);
    glVertex2d(800,800);
    glVertex2d(800,0);
    glEnd();

    //bulan
    glColor3ub(255,201,14);
    lingkaran(110,70,210,170);
    glColor3ub(132,113,189);
    lingkaran(110,70,260,130);
}

void rumput(){
    /* BACKGROUND */
    glBegin(GL_POLYGON);
    glColor3ub(133, 178, 79);
    glVertex2f(0, 427);
    glVertex2f(0, 800);
    glVertex2f(800, 800);
    glVertex2f(800, 427);
    glEnd();

}


void K()
{
    //PAGAR
    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);   //
    glVertex2d(11,574);    // 146 681 // +97 +224
    glVertex2d(15,574);   // 225 493 // +98 +223
    glVertex2d(11,516);   // 243 542 // +98 +223
    glVertex2d(15,516);
    glEnd();

    // Alas Rumah
    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(82,566);
    glVertex2d(82,531);
    glVertex2d(280,660);
    glVertex2d(280,695);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,97,73);
    glVertex2d(280,696);
    glVertex2d(280,661);
    glVertex2d(415,573);
    glVertex2d(415,607);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(511,670);
    glVertex2d(511,635);
    glVertex2d(415,573);
    glVertex2d(415,607);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,97,73);
    glVertex2d(511,670);
    glVertex2d(511,628);
    glVertex2d(683,514);
    glVertex2d(683,557);
    glEnd();

    // Tembok
    glBegin(GL_POLYGON);
    glColor3ub(210,195,154);
    glVertex2d(82,531);
    glVertex2d(280,662);
    glVertex2d(281,497);
    glVertex2d(82,367);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(210,195,154);
    glVertex2d(82,531);
    glVertex2d(280,662);
    glVertex2d(281,497);
    glVertex2d(82,367);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(210,195,154);
    glVertex2d(82,366);
    glVertex2d(281,500);
    glVertex2d(594,292);
    glVertex2d(189,298);
    glVertex2d(82,380);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,223,171);
    glVertex2d(280,662);
    glVertex2d(593,456);
    glVertex2d(594,292);
    glVertex2d(281,496);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(210,195,154);
    glVertex2d(415,575);
    glVertex2d(511,635);
    glVertex2d(511,467);
    glVertex2d(416,405);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,223,171);
    glVertex2d(511,635);
    glVertex2d(511,467);
    glVertex2d(683,354);
    glVertex2d(683,522);
    glEnd();

    // ATAP

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(64,393);
    glVertex2d(169,334);
    glVertex2d(169,310);
    glVertex2d(64,369);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(169,334);
    glVertex2d(265,515);
    glVertex2d(273,506);
    glVertex2d(169,310);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(169,310);
    glVertex2d(273,506);
    glVertex2d(613,283);
    glVertex2d(509,87);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(55,179,74);
    glVertex2d(64,369);
    glVertex2d(169,310);
    glVertex2d(509,88);
    glVertex2d(198,283);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(340,217);
    glVertex2d(416,405);
    glVertex2d(511,486);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(511,486);
    glVertex2d(708,358);
    glVertex2d(516,101);
    glVertex2d(340,217);
    glEnd();

    // ATAP Kecil //Dinding
    glBegin(GL_POLYGON);
    glColor3ub(210,195,154);
    glVertex2d(468,315);
    glVertex2d(519,370);
    glVertex2d(519,308);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,223,171);
    glVertex2d(519,308);
    glVertex2d(519,370);
    glVertex2d(601,316);
    glVertex2d(601,254);
    glEnd();

    glBegin(GL_POLYGON); //<--------- INI ATO ATASNYA
    glColor3ub(237,223,171);
    glVertex2d(519,308);
    glVertex2d(601,254);
    glVertex2d(519,200);
    glVertex2d(437,254);
    glEnd();

    // ATAP KECIL
    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(435,293);
    glVertex2d(508,341);
    glVertex2d(508,329);
    glVertex2d(435,281);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(435,281);
    glVertex2d(508,329);
    glVertex2d(564,223);
    glVertex2d(434,138);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(564,223);
    glVertex2d(620,255);
    glVertex2d(491,170);
    glVertex2d(434,138);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(508,329);
    glVertex2d(564,236);
    glVertex2d(563,220);
    glVertex2d(508,329);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(564,236);
    glVertex2d(563,220);
    glVertex2d(620,255);
    glVertex2d(619,268);
    glEnd();

    // JENDELA 1

    glBegin(GL_POLYGON);
    glColor3ub(244,241,251);
    glVertex2d(162,454);
    glVertex2d(162,551);
    glVertex2d(126,528);
    glVertex2d(126,431);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,241,251);
    glVertex2d(166,457);
    glVertex2d(201,480);
    glVertex2d(201,577);
    glVertex2d(166,554);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(158,553);
    glVertex2d(165,548);
    glVertex2d(130,525);
    glVertex2d(123,530);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(123,530);
    glVertex2d(130,525);
    glVertex2d(130,428);
    glVertex2d(123,433);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(162,556);
    glVertex2d(197,579);
    glVertex2d(205,574);
    glVertex2d(170,551);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(170,551);
    glVertex2d(170,454);
    glVertex2d(162,459);
    glVertex2d(162,556);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(118,533);
    glVertex2d(202,588);
    glVertex2d(202,582);
    glVertex2d(118,526);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(158,553);
    glVertex2d(162,556);
    glVertex2d(162,455);
    glVertex2d(158,452);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(118,424);
    glVertex2d(118,533);
    glVertex2d(123,536);
    glVertex2d(123,427);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(202,588);
    glVertex2d(202,479);
    glVertex2d(197,476);
    glVertex2d(197,583);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(202,588);
    glVertex2d(209,583);
    glVertex2d(209,474);
    glVertex2d(202,479);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(198,482);
    glVertex2d(210,475);
    glVertex2d(210,462);
    glVertex2d(198,470);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(113,414);
    glVertex2d(113,426);
    glVertex2d(198,482);
    glVertex2d(198,470);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(198,470);
    glVertex2d(210,462);
    glVertex2d(125,406);
    glVertex2d(113,414);
    glEnd();

    // PINTU

    glBegin(GL_POLYGON);
    glColor3ub(175,128,93);
    glVertex2d(526,625);
    glVertex2d(597,672);
    glVertex2d(753,571);
    glVertex2d(683,522);
    glEnd();
    ///
    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(632,563);
    glVertex2d(676,535);
    glVertex2d(676,411);
    glVertex2d(632,445);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,223,171);
    glVertex2d(637,555);
    glVertex2d(668,535);
    glVertex2d(668,428);
    glVertex2d(637,448);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(627,559);
    glVertex2d(632,563);
    glVertex2d(632,445);
    glVertex2d(627,441);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(60,123,101);
    glVertex2d(668,535);
    glVertex2d(671,537);
    glVertex2d(671,425);
    glVertex2d(668,428);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,128,93);
    glVertex2d(637,555);
    glVertex2d(637,565);
    glVertex2d(672,547);
    glVertex2d(671,537);
    glVertex2d(668,535);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,149,122);
    glVertex2d(626,449);
    glVertex2d(682,413);
    glVertex2d(654,417);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(626,449);
    glVertex2d(654,417);
    glVertex2d(648,413);
    glVertex2d(620,446);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,173,158);
    glVertex2d(654,417);
    glVertex2d(648,413);
    glVertex2d(676,409);
    glVertex2d(682,413);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,128,93);
    glVertex2d(663,499);
    glVertex2d(660,504);
    glVertex2d(663,506);
    glVertex2d(665,501);
    glEnd();


    // TERAS
    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(735,626);
    glVertex2d(744,631);
    glVertex2d(744,590);
    glVertex2d(735,585);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(588,722);
    glVertex2d(597,727);
    glVertex2d(597,677);
    glVertex2d(588,672);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(597,672);
    glVertex2d(526,625);
    glVertex2d(526,639);
    glVertex2d(597,686);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,97,73);
    glVertex2d(597,727);
    glVertex2d(606,722);
    glVertex2d(606,673);
    glVertex2d(597,677);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,97,73);
    glVertex2d(597,686);
    glVertex2d(753,584);
    glVertex2d(753,571);
    glVertex2d(597,672);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,97,73);
    glVertex2d(753,625);
    glVertex2d(753,572);
    glVertex2d(744,578);
    glVertex2d(744,631);
    glEnd();


    //TANGGA

    glBegin(GL_POLYGON);
    glColor3ub(107,81,69);
    glVertex2d(680,618);
    glVertex2d(680,632);
    glVertex2d(713,689);
    glVertex2d(725,699);
    glVertex2d(725,662);
    glVertex2d(692,620);
    glEnd();

    for(int i=0;i<5;i++){
        glBegin(GL_POLYGON);
        glColor3ub(175,128,93);
        glVertex2d(680+11*i,618+20*i); //691 638 // 11 20
        glVertex2d(692+11*i,625+20*i);
        glVertex2d(742+11*i,592+20*i);
        glVertex2d(730+11*i,585+20*i);
        glEnd();
    }

    for(int i=0;i<4;i++){
        glBegin(GL_POLYGON);
        glColor3ub(158,97,73);
        glVertex2d(692+11*i,638+20*i); //691 638 // 11 20
        glVertex2d(692+11*i,625+20*i);
        glVertex2d(742+11*i,592+20*i);
        glVertex2d(742+11*i,605+20*i);
        glEnd();
    }

/*
    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 2, 0,0);
    for(int i=0, j=-100; i<100; i++, j+=15){
        lingkaran(-400+j,140,1,1, 0.7);
        lingkaran(-400+j,395,1,1, 0.7);
        lingkaran(-400+j,640,1,1, 0.7);
    }
    glPopMatrix();
*/

}
void lingkaranforawan(float radius, float jumlah_titik, float x_tengah, float y_tengah){
        glBegin(GL_POLYGON);
        int i;
        for(i=0; i<=360; i++){
            //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
            float sudut = i*(2*3.14/jumlah_titik);
            float x = x_tengah+radius*cos(sudut);
            float y = y_tengah+radius*sin(sudut);
            glVertex2f(x,y);
        }
        glEnd();
}

void awan(float x, float y)
{
        int i, j;
        glPushMatrix();
        glTranslatef((float)glfwGetTime() * 30,0,0);
        for(i=0, j=-10000; i<100; i++,j+=400){
            glColor3ub(209, 207, 231);
            lingkaranforawan(17, 70, 17.61 + x + j, 211.32 + y);
            lingkaranforawan(20, 70, 43.18 + x + j, 203.5 + y);
            lingkaranforawan(35, 70, 171.27 + x + j, 196.91 + y);
            lingkaranforawan(33, 70, 73.52 + x + j, 196.91 + y);
            lingkaranforawan(45, 70, 116.26 + x + j, 187.1 + y);
        }
        glPopMatrix();
}


/////////////////////////////////////////////////


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Rumah - G64150010", NULL, NULL); // ini buat ukuran window nya ,, terus namanya

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))//kecepatan FPS dari while ini tergantung komputer masing masing
    {
        setup_viewport(window);

        display();
        background();
        rumput();
        ////////////////////////////////////////////////////////////
        awan(500, -100);
        awan(600, 0);
        awan(700, -150);
        //panggil fungsi K
        K();




        ////////////////////////////////////////////////////////////

        glfwSwapBuffers(window);
        glfwPollEvents();



        //y
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
