#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void bulat(float x, float y)
{
    glBegin(GL_POLYGON);
    glColor3ub(0, 170, 0);
    for(int i=0; i<=360; i++)
    {
        float rad = i*3.14159 / 180;
        glVertex2f(x+cos(rad)*20,y+sin(rad)*20);
    }
    glEnd();
}

void kotak(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
{
    glBegin(GL_POLYGON);

    glVertex2d(x1, y1);
    glVertex2d(x2, y2);
    glVertex2d(x3, y3);
    glVertex2d(x4, y4);

    glEnd();
}

void segitiga(int x1, int y1, int x2, int y2, int x3, int y3)
{
    glBegin(GL_TRIANGLES);

    glVertex2d(x1, y1);
    glVertex2d(x2, y2);
    glVertex2d(x3, y3);

    glEnd();
}

void garis(int x1, int y1, int x2, int y2)
{
    glBegin(GL_LINES);

    glColor3ub(151, 150, 156);

    glVertex2d(x1, y1);
    glVertex2d(x2, y2);

    glEnd();
}

void lahan()
{
    glColor3ub(73, 129, 37);
    kotak(165, 366, 440, 525, 756, 341, 488, 172);
    glColor3ub(70, 35, 0);
    kotak(440, 525, 440, 532, 756, 350, 756, 341);
    kotak(440, 525, 440, 532, 165, 375, 165, 366);
}

void atap()
{
    glColor3ub(206, 114, 73);
    kotak(427, 137, 427, 124, 251, 225, 305, 208);
    glColor3ub(174, 91, 61);
    kotak(427, 137, 427, 286, 391, 306, 305, 208);
    glColor3ub(227, 139, 89);
    kotak(556, 211, 556, 359, 427, 286, 427, 137);
    glColor3ub(159, 85, 56);
    kotak(427, 137, 427, 124, 695, 280, 556, 211);
    glColor3ub(180, 95, 64);
    segitiga(556, 211, 556, 359, 695, 280);
    glColor3ub(70, 35, 0);
    kotak(556, 359, 556, 365, 696, 286, 696, 279);
    kotak(556, 359, 556, 365, 427, 292, 427, 286);
    kotak(427, 286, 427, 292, 391, 312, 391, 306);
    kotak(391, 306, 391, 312, 305, 215, 305, 208);
    kotak(305, 208, 305, 215, 251, 230, 251, 225);
}

void dinding()
{
    glColor3ub(210, 195, 174);
    kotak(556, 365, 556, 423, 684, 350, 684, 290);
    glColor3ub(255, 248, 237);
    kotak(556, 365, 556, 423, 549, 427, 549, 360);
    glColor3ub(255, 248, 237);
    kotak(549, 360, 549, 427, 440, 363, 440, 299);
    glColor3ub(180, 165, 146);
    kotak(427, 292, 427, 370, 440, 363, 440, 299);
    glColor3ub(180, 165, 146);
    kotak(427, 292, 427, 370, 391, 390, 391, 312);
    glColor3ub(180, 165, 146);
    kotak(386, 306, 386, 393, 391, 390, 391, 312);
    glColor3ub(249, 240, 231);
    kotak(386, 306, 386, 393, 265, 325, 265, 226);
    glColor3ub(249, 240, 231);
    segitiga(386, 306, 265, 226, 305, 215);
}

void tanah()
{
    glColor3ub(153, 120, 101);
    kotak(549, 427, 549, 432, 684, 355, 684, 350);
    kotak(549, 427, 549, 432, 440, 370, 440, 363);
    kotak(440, 362, 440, 370, 386, 400, 386, 393);
    kotak(386, 393, 386, 400, 265, 332, 265, 325);
}

void pintu()
{
    glColor3ub(151, 126, 104);
    kotak(448, 311, 470, 324, 470, 333, 448, 320);
    glColor3ub(139, 107, 92);
    kotak(470, 333, 470, 384, 448, 371, 448, 320);
    glColor3ub(187, 178, 171);
    kotak(450, 350, 452, 350, 452, 359, 450, 359);
    glColor3ub(65, 91, 140);
    kotak(450, 314, 450, 318, 467, 328, 467, 324);
    //garasi
    glColor3ub(120, 96, 86);
    kotak(476, 326, 476, 387, 537, 422, 537, 361);
    glColor3ub(106, 77, 63);
    kotak(479, 333, 479, 387, 533, 418, 533, 365);

    for(int i=0; i<55; i+=5){
        glColor3ub(90, 61, 47);
        garis(479, 336+i, 533, 367+i);
    }
}

void bayangan()
{
    glColor3ub(204, 197, 191);
    kotak(440, 299, 440, 313, 556, 375, 556, 362);
    kotak(308, 217, 308, 234, 386, 319, 386, 306);
    kotak(304, 215, 304, 236, 308, 234, 308, 217);
    kotak(265, 225, 265, 248, 304, 236, 304, 215);
}

void aspal()
{
    glColor3ub(166, 165, 170);
    kotak(445, 370, 312, 451, 415, 511, 548, 430);
    garis(494, 398, 361, 479);
    garis(405, 395, 507, 455);
    garis(356, 424, 459, 484);
}

void jendela()
{
    glColor3ub(156, 120, 106);
    kotak(641, 317, 641, 351, 671, 335, 671, 297);
    glColor3ub(65, 91, 140);
    kotak(643, 315, 643, 345, 654, 340, 654, 308);
    kotak(658, 306, 658, 337, 668, 334, 668, 301);

    glColor3ub(156, 120, 106);
    kotak(335, 295, 335, 343, 364, 360, 364, 312);
    glColor3ub(65, 91, 140);
    kotak(339, 300, 339, 341, 347, 345, 347, 307);
    kotak(352, 308, 352, 347, 362, 353, 362, 314);

    glColor3ub(156, 120, 106);
    kotak(282, 265, 282, 313, 311, 330, 311, 282);
    glColor3ub(65, 91, 140);
    kotak(284, 269, 284, 311, 294, 317, 294, 277);
    kotak(299, 277, 299, 317, 308, 324, 308, 283);

    glColor3ub(156, 120, 106);
    kotak(308, 217, 308, 242, 338, 259, 338, 250);
    glColor3ub(65, 91, 140);
    kotak(312, 222, 312, 239, 321, 244, 321, 231);
    kotak(326, 238, 326, 246, 335, 251, 335, 244);
}

void pohon()
{
    glColor3ub(70, 35, 0);
    kotak(239, 330, 239, 371, 245, 371, 245, 330);
    glColor3ub(0, 200, 0);
    bulat(243, 330);
}

void lat()
{
    glColor3ub(255, 255, 255);
    kotak(0, 0, 0, 800, 800, 800, 800, 0);
}

int main(void)
{

    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Rumah Impian Leni", NULL, NULL);
    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        display();

        lat(); lahan(); dinding(); bayangan();
        jendela(); atap(); tanah(); pintu(); aspal();
        pohon();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
