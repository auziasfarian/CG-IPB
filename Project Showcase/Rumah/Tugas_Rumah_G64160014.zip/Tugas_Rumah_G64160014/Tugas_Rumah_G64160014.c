#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define xmin -10
#define xmax 10
#define ymin -10
#define ymax 10

int clindex=0,buff=0;
int color[3][3]={{244,176,176},{175,104,104},{140,49,49}};
int colors[3][3]={{156,255,203},{121,219,165},{125,178,147}};
int i=0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 700, 700, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void Lingkaran(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
    glColor3ub(242,234,85);
        for(i=0; i<360;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void cloud(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
    glColor3ub(128,225,244);
        for(i=0; i<360;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void awan(){
 cloud(240,220,40);
 cloud(190,260,40);
 cloud(150,270,20);
 cloud(200,290,40);
 cloud(244,301,50);
 cloud(130,350,20);
 cloud(200,350,20);
 glBegin(GL_POLYGON);
 glColor3ub(128,225,244);
 glVertex2d(200,330);
 glVertex2d(200,370);
 glVertex2d(130,370);
 glVertex2d(130,330);
 glEnd();
 cloud(580,140,30);
 cloud(540,160,30);
 cloud(580,198,40);
 cloud(520,200,30);
 cloud(545,250,30);
}

void ground(){
    glBegin(GL_POLYGON);
    glColor3ub(140,192,4);
    glVertex2d(0,491);
    glVertex2d(0,750);
    glVertex2d(750,750);
    glVertex2d(750,491);
    glEnd();
}
void sky(){
    glBegin(GL_POLYGON);
    glColor3ub(45,108,234);
    glVertex2d(0,0);
    glColor3ub(100,146,237);
    glVertex2d(750,0);
    glColor3ub(201,216,247);
    glVertex2d(750,491);
    glColor3ub(156,186,247);
    glVertex2d(0,491);
    glEnd();
}
void build(){

    glBegin(GL_POLYGON); //fond1
    glColor3ub(160,234,190);
    glVertex2d(151,518);
    glVertex2d(151,506);
    glVertex2d(622,506);
    glVertex2d(622,518);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(215,251,246); //sq1
    glVertex2d(169,506);
    glVertex2d(169,375);
    glVertex2d(357,375);
    glVertex2d(357,506);
    glEnd();

    glBegin(GL_POLYGON);//atapnya
    glColor3ub(72,224,228);
    glVertex2d(156,375);
    glVertex2d(156,362);
    glVertex2d(357,362);
    glVertex2d(357,375);
    glEnd();

    glBegin(GL_POLYGON);//garasii
    glColor3ub(204,204,204);
    glVertex2d(357,506);
    glVertex2d(357,375);
    glVertex2d(604,375);
    glVertex2d(604,506);
    glEnd();

    glBegin(GL_POLYGON);//atap garasi
    glColor3ub(123,111,99);
    glVertex2d(357,375);
    glVertex2d(357,362);
    glVertex2d(615,362);
    glVertex2d(615,375);
    glEnd();

    glBegin(GL_POLYGON);//batas lantai2
    glColor3ub(228,4,117);
    glVertex2d(169,362);
    glVertex2d(169,345);
    glVertex2d(604,345);
    glVertex2d(604,362);
    glEnd();

    glBegin(GL_POLYGON);//pagar
    glColor3ub(61,58,51);
    glVertex2d(169,344);
    glVertex2d(173,344);
    glVertex2d(173,276);
    glVertex2d(169,276);
    glEnd();

    for(i=278;i<=340;i+=8){//pagar
        glBegin(GL_POLYGON);
        glColor3ub(61,58,51);
        glVertex2d(171,i);
        glVertex2d(171,i+3);
        glVertex2d(243,i+3);
        glVertex2d(243,i);
        glEnd();
    }

    glBegin(GL_POLYGON);//sq2
    glColor3ub(204,204,204);
    glVertex2d(243,345);
    glVertex2d(329,345);
    glVertex2d(329,130);
    glVertex2d(243,170);
    glEnd();

    glBegin(GL_POLYGON);//trapesium
    glColor3ub(215,251,246);
    glVertex2d(329,345);
    glVertex2d(329,206);
    glVertex2d(604,275);
    glVertex2d(604,345);
    glEnd();

    glBegin(GL_POLYGON);//sshadow atap
    glColor3ub(135,249,229);
    glVertex2d(329,206);
    glVertex2d(329,191);
    glVertex2d(604,260);
    glVertex2d(604,275);
    glEnd();

    glBegin(GL_POLYGON);//atap trapesium
    glColor3ub(14,2,32);
    glVertex2d(329,191);
    glVertex2d(329,175);
    glVertex2d(610,247);
    glVertex2d(610,263);
    glEnd();

    glBegin(GL_POLYGON);//atap pagar
    glColor3ub(73,70,77);
    glVertex2d(329,124);
    glVertex2d(329,142);
    glVertex2d(167,221);
    glVertex2d(167,204);
    glEnd();
}
void door(){
    glBegin(GL_POLYGON); //kusen bawah
    glColor3ub(61,58,51);
    glVertex2d(254,506);
    glVertex2d(254,407);
    glVertex2d(328,407);
    glVertex2d(328,506);
    glEnd();

    glBegin(GL_POLYGON); //pintu bawah
    glColor3ub(97,79,68);
    glVertex2d(257,506);
    glVertex2d(257,411);
    glVertex2d(325,411);
    glVertex2d(325,506);
    glEnd();

    glBegin(GL_POLYGON);//garis tengah
    glColor3ub(61,58,51);
    glVertex2d(290,506);
    glVertex2d(291,506);
    glVertex2d(291,408);
    glVertex2d(290,408);
    glEnd();

    glBegin(GL_POLYGON); //kaca kiri
    glColor3ub(133,188,218);
    glVertex2d(275,495);
    glVertex2d(275,424);
    glVertex2d(283,424);
    glVertex2d(283,495);
    glEnd();

    glBegin(GL_POLYGON);//shadow
    glColor3ub(112,153,175);
    glVertex2d(275,424);
    glVertex2d(275,416);
    glVertex2d(283,416);
    glVertex2d(283,424);
    glEnd();

    glBegin(GL_POLYGON);//kaca kanan
    glColor3ub(133,188,218);
    glVertex2d(299,495);
    glVertex2d(299,424);
    glVertex2d(306,424);
    glVertex2d(306,495);
    glEnd();

    glBegin(GL_POLYGON);//shadow
    glColor3ub(112,153,175);
    glVertex2d(299,424);
    glVertex2d(299,416);
    glVertex2d(306,416);
    glVertex2d(306,424);
    glEnd();

    glBegin(GL_POLYGON);//gagang kiri
    glColor3ub(61,58,51);
    glVertex2d(285,474);
    glVertex2d(285,440);
    glVertex2d(287,440);
    glVertex2d(287,474);
    glEnd();

    glBegin(GL_POLYGON);//gagang kanan
    glColor3ub(61,58,51);
    glVertex2d(295,474);
    glVertex2d(295,440);
    glVertex2d(297,440);
    glVertex2d(297,474);
    glEnd();

    glBegin(GL_POLYGON);//kusen garasi
    glColor3ub(61,58,51);
    glVertex2d(389,518);
    glVertex2d(389,404);
    glVertex2d(578,404);
    glVertex2d(578,518);
    glEnd();

    glBegin(GL_POLYGON);//pintu garasi
    glColor3ub(97,79,68);
    glVertex2d(394,506);
    glVertex2d(394,408);
    glVertex2d(573,408);
    glVertex2d(573,506);
    glEnd();

    for(i=408;i<=515;i+=16){
        glBegin(GL_POLYGON);
        glColor3ub(121,110,98);
        glVertex2d(394,i);
        glVertex2d(394,i+6);
        glVertex2d(573,i+6);
        glVertex2d(573,i);
        glEnd();
    }
    for(i=413;i<=521;i+=16){
        glBegin(GL_POLYGON);
        glColor3ub(80,66,56);
        glVertex2d(394,i);
        glVertex2d(394,i+6);
        glVertex2d(573,i+6);
        glVertex2d(573,i);
        glEnd();
    }

    glBegin(GL_POLYGON);//kusen geser
    glColor3ub(80,66,56);
    glVertex2d(409,345);
    glVertex2d(409,271);
    glVertex2d(550,271);
    glVertex2d(550,345);
    glEnd();

    glBegin(GL_POLYGON);//kaca
    glColor3ub(133,188,218);
    glVertex2d(413,345);
    glVertex2d(413,283);
    glVertex2d(546,283);
    glVertex2d(546,345);
    glEnd();

    glBegin(GL_POLYGON);//shadow2
    glColor3ub(182,219,235);
    glVertex2d(413,338);
    glVertex2d(413,325);
    glVertex2d(453,274);
    glVertex2d(463,274);
    glEnd();

    glBegin(GL_POLYGON);//shadow3
    glColor3ub(182,219,235);
    glVertex2d(413,345);
    glVertex2d(413,344);
    glVertex2d(468,274);
    glVertex2d(471,274);
    glEnd();

    glBegin(GL_POLYGON);//shadow4
    glColor3ub(182,219,235);
    glVertex2d(494,345);
    glVertex2d(546,281);
    glVertex2d(546,294);
    glVertex2d(503,345);
    glEnd();

    glBegin(GL_POLYGON);//shadow5
    glColor3ub(182,219,235);
    glVertex2d(507,345);
    glVertex2d(546,299);
    glVertex2d(546,304);
    glVertex2d(510,345);
    glEnd();


    glBegin(GL_POLYGON);//shadow1
    glColor3ub(112,153,175);
    glVertex2d(413,283);
    glVertex2d(413,274);
    glVertex2d(546,274);
    glVertex2d(546,283);
    glEnd();


    glBegin(GL_POLYGON);//gagang
    glColor3ub(61,58,51);
    glVertex2d(418,329);
    glVertex2d(418,306);
    glVertex2d(421,306);
    glVertex2d(421,329);
    glEnd();

    glBegin(GL_POLYGON);//batas1
    glColor3ub(61,58,51);
    glVertex2d(411,292);
    glVertex2d(411,290);
    glVertex2d(550,290);
    glVertex2d(550,292);
    glEnd();

    glBegin(GL_POLYGON);//batas2
    glColor3ub(61,58,51);
    glVertex2d(477,345);
    glVertex2d(477,274);
    glVertex2d(481,274);
    glVertex2d(481,345);
    glEnd();

    /*glBegin(GL_POLYGON);//pagar kaca
    glColor4f(0.69,0.13,0.26,0.5);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE);
    glVertex2d(331,345);
    glVertex2d(331,303);
    glVertex2d(594,303);
    glVertex2d(594,345);
    glEnd();*/

    glBegin(GL_POLYGON);//kusen jendela
    glColor3ub(61,58,51);
    glVertex2d(359,314);
    glVertex2d(359,234);
    glVertex2d(400,234);
    glVertex2d(400,314);
    glEnd();

    glBegin(GL_POLYGON);//kaca
    glColor3ub(133,188,218);
    glVertex2d(361,311);
    glVertex2d(361,237);
    glVertex2d(398,237);
    glVertex2d(398,311);
    glEnd();

    glBegin(GL_POLYGON);//shadow1
    glColor3ub(182,219,235);
    glVertex2d(361,311);
    glVertex2d(361,303);
    glVertex2d(398,246);
    glVertex2d(398,263);
    glVertex2d(367,311);
    glEnd();

    glBegin(GL_POLYGON);//shadow2
    glColor3ub(182,219,235);
    glVertex2d(372,311);
    glVertex2d(398,271);
    glVertex2d(398,277);
    glVertex2d(376,311);
    glEnd();

    glBegin(GL_POLYGON);//shadow3
    glColor3ub(112,153,175);
    glVertex2d(361,247);
    glVertex2d(361,237);
    glVertex2d(398,237);
    glVertex2d(398,247);
    glEnd();

    glBegin(GL_POLYGON);//batas
    glColor3ub(61,58,51);
    glVertex2d(360,258);
    glVertex2d(360,260);
    glVertex2d(400,260);
    glVertex2d(400,258);
    glEnd();

    /*for(i=124;i<=180;i+=14){
        glBegin(GL_POLYGON);//garis kanan
        glColor3ub(123,111,99);
        glVertex2d(243,i);
        glVertex2d(329,i);
        glVertex2d(329,i+7);
        glVertex2d(243,i+7);
        glEnd();
        }*/
   /* for(i=131;i<=336;i+=14){
        glBegin(GL_POLYGON);//garis kiri
        glColor3ub(243,201,244);
        glVertex2d(243,i);
        glVertex2d(329,i);
        glVertex2d(329,i+7);
        glVertex2d(243,i+7);
        glEnd();
        }*/

    glBegin(GL_POLYGON);//kusen
    glColor3ub(92,102,107);
    glVertex2d(273,314);
    glVertex2d(273,199);
    glVertex2d(307,199);
    glVertex2d(307,314);
    glEnd();

    glBegin(GL_POLYGON);//kaca
    glColor3ub(133,188,218);
    glVertex2d(276,310);
    glVertex2d(276,212);
    glVertex2d(304,212);
    glVertex2d(304,310);
    glEnd();

    glBegin(GL_POLYGON);//shadow
    glColor3ub(112,153,175);
    glVertex2d(276,215);
    glVertex2d(276,206);
    glVertex2d(304,206);
    glVertex2d(304,215);
    glEnd();

    glBegin(GL_POLYGON);//shadow2
    glColor3ub(182,219,235);
    glVertex2d(276,282);
    glVertex2d(276,264);
    glVertex2d(304,221);
    glVertex2d(304,239);
    glEnd();

    glBegin(GL_POLYGON);//shadow3
    glColor3ub(182,219,235);
    glVertex2d(276,296);
    glVertex2d(276,289);
    glVertex2d(304,247);
    glVertex2d(304,253);
    glEnd();

    glBegin(GL_POLYGON);//interkom
    glColor3ub(217,217,217);
    glVertex2d(332,462);
    glVertex2d(332,441);
    glVertex2d(355,441);
    glVertex2d(355,462);
    glEnd();

    glBegin(GL_POLYGON);//layar
    glColor3ub(133,188,219);
    glVertex2d(334,454);
    glVertex2d(334,444);
    glVertex2d(353,444);
    glVertex2d(353,454);
    glEnd();

    glBegin(GL_POLYGON);//red
    glColor3ub(232,78,27);
    glVertex2d(338,460);
    glVertex2d(338,457);
    glVertex2d(341,457);
    glVertex2d(341,460);
    glEnd();

    glBegin(GL_POLYGON);//green
    glColor3ub(51,171,102);
    glVertex2d(343,460);
    glVertex2d(343,457);
    glVertex2d(345,457);
    glVertex2d(345,460);
    glEnd();

    glBegin(GL_POLYGON);//peach
    glColor3ub(201,186,159);
    glVertex2d(347,460);
    glVertex2d(347,457);
    glVertex2d(350,457);
    glVertex2d(350,460);
    glEnd();

    glBegin(GL_POLYGON);//jendela bawah
    glColor3ub(0,65,92);
    glVertex2d(174,493);
    glVertex2d(174,411);
    glVertex2d(242,411);
    glVertex2d(242,493);
    glEnd();

    glBegin(GL_POLYGON);//kaca
    glColor3ub(133,188,219);
    glVertex2d(178,413);
    glVertex2d(178,491);
    glVertex2d(238,491);
    glVertex2d(238,413);
    glEnd();


    glBegin(GL_POLYGON);//shadow2
    glColor3ub(182,219,235);
    glVertex2d(178,456);
    glVertex2d(178,447);
    glVertex2d(196,414);
    glVertex2d(202,414);
    glEnd();

    glBegin(GL_POLYGON);//shadow3
    glColor3ub(182,219,235);
    glVertex2d(178,462);
    glVertex2d(178,459);
    glVertex2d(205,414);
    glVertex2d(207,414);
    glEnd();

    glBegin(GL_POLYGON);//shadow1
    glColor3ub(112,153,175);
    glVertex2d(178,413);
    glVertex2d(178,424);
    glVertex2d(238,424);
    glVertex2d(238,413);
    glEnd();

    glBegin(GL_POLYGON);//shadow4
    glColor3ub(182,219,235);
    glVertex2d(210,491);
    glVertex2d(238,448);
    glVertex2d(238,456);
    glVertex2d(216,491);
    glEnd();

    glBegin(GL_POLYGON);//shadow5
    glColor3ub(182,219,235);
    glVertex2d(220,491);
    glVertex2d(238,463);
    glVertex2d(238,467);
    glVertex2d(225,491);
    glEnd();


    glBegin(GL_POLYGON);//batas
    glColor3ub(0,65,92);
    glVertex2d(208,493);
    glVertex2d(208,411);
    glVertex2d(210,411);
    glVertex2d(210,493);
    glEnd();
}

void pot(){
    glBegin(GL_POLYGON);//potkiri
    glColor3ub(123,111,99);
    glVertex2d(357,506);
    glVertex2d(357,481);
    glVertex2d(389,481);
    glVertex2d(389,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(92,85,73);
    glVertex2d(357,481);
    glVertex2d(357,475);
    glVertex2d(389,475);
    glVertex2d(389,481);
    glEnd();

    for(i=357;i<=389;i+=3){
        glBegin(GL_TRIANGLES);
        glColor3ub(89,128,49);
        glVertex2d(i,475);
        glVertex2d(i+1,451);
        glVertex2d(i+2,475);
        glEnd();
    }

    glBegin(GL_POLYGON);//potkanan
    glColor3ub(92,85,73);
    glVertex2d(578,506);
    glVertex2d(578,481);
    glVertex2d(604,481);
    glVertex2d(604,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(123,111,99);
    glVertex2d(578,481);
    glVertex2d(578,475);
    glVertex2d(604,475);
    glVertex2d(604,481);
    glEnd();

    for(i=578;i<=604;i+=3){
        glBegin(GL_TRIANGLES);
        glColor3ub(89,128,49);
        glVertex2d(i,475);
        glVertex2d(i+1,451);
        glVertex2d(i+2,475);
        glEnd();
    }
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(700, 700, "Rumah", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
         if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();
        sky();
        awan();
        ground();
        build();
        door();
        pot();
        Lingkaran(89,92,40);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
