#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#define white 255,255,255
#define black 0,0,0
int buff=0, colorA=0, colorB=0, buff2=0, buff3=0, moveA=200, moveB=-20,moveC=0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window){
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glEnable( GL_BLEND ) ;
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA ) ; // works fine, except cracks
    //glBlendFunc( GL_SRC_ALPHA_SATURATE, GL_ONE ) ; // works only on black background...
    glPolygonMode( GL_FRONT, GL_FILL ) ;
    glEnable( GL_POLYGON_SMOOTH ) ;
    glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST ) ;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void sstree();
void bg(){
    glBegin(GL_POLYGON);
        glColor3ub(0,236-colorA,255-colorA);
        glVertex2d(0,0);
        glVertex2d(400,0);
        glVertex2d(400,800);
        glVertex2d(0,800);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(0,220-colorA,255-colorA);
        glVertex2d(400,0);
        glVertex2d(800,0);
        glVertex2d(800,800);
        glVertex2d(400,800);
    glEnd();
}
void ground(){
    double x=0.0;
    x=glfwGetTime();
    glBegin(GL_POLYGON);
        glColor3ub(120,50,20);
        glVertex2f(413.28,712.88+colorA);
        glVertex2f(44.64+737.21,500.05+colorA);
        glVertex2f(413.27,277.64+9.58+colorA);
        glVertex2f(44.64,500.05+colorA);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(157,216-colorA,100);
        glVertex2f(44.64,490.47);
        glVertex2f(413.27,277.64);
        glVertex2f(781.91,490.47);
        glVertex2f(413.28,703.3);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(197,249-colorA,147);
        glVertex2f(413.28,703.3);
        glVertex2f(44.64,490.47);
        glVertex2f(44.64,500.05);
        glVertex2f(413.28,712.88);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(250,179,122);
        glVertex2f(44.64,500.05+colorA);
        glVertex2f(44.64,800);//525.6
        glVertex2f(413.28,800);//738.43
        glVertex2f(413.28,712.88+colorA);

    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(102,153,21);
        glVertex2f(413.28,703.3);
        glVertex2f(44.64+737.21,490.47);
        glVertex2f(44.64+737.21,500.05);
        glVertex2f(413.28,712.88);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(135,73,31);
        glVertex2f(44.64+737.21,500.05+colorA);
        glVertex2f(44.64+737.21,800);//525.6
        glVertex2f(413.28,800);//738.43
        glVertex2f(413.28,712.88+colorA);
    glEnd();
    glPushMatrix();
          glTranslatef(561.14,29.16-60,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(53+53+53,-90,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(53+53,-60,0);
          sstree();
     glPopMatrix();

}
void road(){
    glBegin(GL_POLYGON);
        glColor3ub(220,239,219);
        glVertex2f(285.58,419.56);
        glVertex2f(461,521);
        glVertex2f(288.38,631.18);
        glVertex2f(109.05,527.66);
    glEnd();
}
void firstfloor(){
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(536.3,487.59); //TL
        glVertex2f(654.4,419.36); //TR
        glVertex2f(654.4,496.08); //DR
        glVertex2f(536.3,564.31); //DL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(71,82,96); //LIGHTGREY
        glVertex2f(536.3,487.59); //TR
        glVertex2f(536.3,564.31); //DR
        glVertex2f(285.58,419.56); //DL
        glVertex2f(285.62,342.86); //TL
    glEnd();
    //SHADOW
    glBegin(GL_POLYGON);
        glColor4ub(46,65,73,50);
        glVertex2f(536.3,564.31); //DL
        glVertex2f(654.4,470.02); //DR
        glVertex2f(696.84,494.52); //DL
        glVertex2f(575.97,564.31); //TL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(240,245,247);
        glVertex2f(403.31,487.52); //TR
        glVertex2f(445.84,512.04); //DR
        glVertex2f(445.84,423.27); //TR
        glVertex2f(403.31,398.75); //TR
     glEnd();
}
void secondfloor(){
    glBegin(GL_POLYGON);
        glColor3ub(34,112,172); //DARKBLUE
        glVertex2f(518.65,406.3); //TL
        glVertex2f(518.65,497.75); //DL
        glVertex2f(654.4,419.36); // DR
        glVertex2f(654.4,301.11); //TR
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(46,167,212); //LIGHTBLUE
        glVertex2f(518.65,406.3); //TR
        glVertex2f(518.65,497.75); //DR
        glVertex2f(267.93,353); //DL
        glVertex2f(267.93,261.54); //TL
    glEnd();

    float dy=13.89;
     int i;
     for(i=0;i<5;i++){
          glBegin(GL_POLYGON);
             glColor3ub(55,50,63); //DARKGREY
             glVertex2f(518.63,428.76+i*dy); //U
             glVertex2f(518.63,431.76+i*dy); //L
             glVertex2f(267.96,291.6+i*dy); //D
             glVertex2f(267.96,289+i*dy); //R
          glEnd();
     }
}
void roof(){
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(509.97,407.21); //TL
        glVertex2f(509.97,413.01); //DL
        glVertex2f(654.4,301.11); // DR
        glVertex2f(654.4,295.3); //TR
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71,82,96); //LIGHTGREY
        glVertex2f(509.97,407.21); //TR
        glVertex2f(509.97,413.01); //DR
        glVertex2f(259.25,268.26); //DL
        glVertex2f(259.25,262.46); //TL
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(48,60,73); //MEDGREY
        glVertex2f(259.25,262.46); //L
        glVertex2f(403.72,150.57); //U
        glVertex2f(654.4,295.3); // R
        glVertex2f(509.97,407.21); //D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(75,71,81); //DARKGREY
        glVertex2f(380.78,117.59); //U
        glVertex2f(282.76,267.3); //L
        glVertex2f(499.09,392.2); //D
        glVertex2f(597.11,242.49); //R
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(34,112,172); //DARKBLUE
        glVertex2f(499.09,392.2); //D
        glVertex2f(597.11,242.49); //R
        glVertex2f(626,290); //R
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(46,65,73); //DARKBLUE
        glVertex2f(474.39,342.91); //D
        glVertex2f(542.38,248.37); //R
        glVertex2f(503.12,342.91); //R
    glEnd();
    float dx=4.61,dy=7.11;
     int i;
     for(i=0;i<21;i++){
          glBegin(GL_POLYGON);
             glColor3ub(55,50,63); //DARKGREY
             glVertex2f(285.58+i*dx,263-i*dy); //U
             glVertex2f(286.39+i*dx,261.76-i*dy); //L
             glVertex2f(502.85+i*dx,386.46-i*dy); //D
             glVertex2f(502.04+i*dx,389.7-i*dy); //R
          glEnd();
     }

}
void frontpart(){
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(311.78,423.54); //L
        glVertex2f(311.78,521.69); //U
        glVertex2f(384.61,478.62); // R
        glVertex2f(384.61,422.36); //D
        glVertex2f(366.87,412.15); //D
        glVertex2f(366.87,391.73); //D
    glEnd();
    //SHADOW
    glBegin(GL_POLYGON);
        glColor4ub(46,65,73,50);
        glVertex2f(311.78,521.69); //U
        glVertex2f(384.61,476.62); // R
        glVertex2f(398.95,484.95); //U
        glVertex2f(340.78,518.69); // R
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(71,82,96); //LIGHTGREY
        glVertex2f(212.79,367.49); //L
        glVertex2f(212.75,464.62); //U
        glVertex2f(311.78,521.69); // R
        glVertex2f(311.78,423.54); //D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(48,60,73); //MEDGREY
        glVertex2f(212.79,367.49); //L
        glVertex2f(311.78,423.54); //D
        glVertex2f(366.87,391.73); //D
        glVertex2f(267.88,335.69); //D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(226.16,367.97); //L
        glVertex2f(267.88,343.92); //D
        glVertex2f(267.88,349.17); //D
        glVertex2f(230.71,370.6); //D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(353.47,393.24); //D
        glVertex2f(348.92,395.87); //D
        glVertex2f(267.88,349.17); //D
        glVertex2f(267.88,343.92); //D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(128,172,183); //LIGHTGREY
        glVertex2f(216.53,463.62); //L
        glVertex2f(216.5,382.83); //U
        glVertex2f(306.5,432.96); // R
        glVertex2f(306.5,515.65); //D
    glEnd();

 }
void thirdfloor(){
    //THIRD FLOOR
    glBegin(GL_POLYGON);
        glColor3ub(34,112,172); //DARKBLUE
        glVertex2f(474.39,298.53); //TL
        glVertex2f(531.24,263.51); //R
        glVertex2f(474.39,342.91); // D
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(46,167,212); //LIGHTBLUE
        glVertex2f(474.39,298.53); //T
        glVertex2f(474.39,342.91); // DR
        glVertex2f(334.94,262.39); // DL
        glVertex2f(334.94,215.7); // TL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(37,32,45);
        glVertex2f(469.45,293.63); //TL
        glVertex2f(469.45,297.74); // DL
        glVertex2f(536.8,255.95); // DR
        glVertex2f(542.38,248.37); //TR
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(128,173,182);
        glVertex2f(469.45,297.74); // TL
        glVertex2f(536.8,255.95); // TR
        glVertex2f(531.24,263.51); //DR
        glVertex2f(469.45,301.84); //DL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(65,59,73);
        glVertex2f(330.28,213.11); //TL
        glVertex2f(469.45,293.63); //TR
        glVertex2f(469.45,297.74); // DR
        glVertex2f(330.28,217.21); //DL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(white);
        glVertex2f(469.45,297.74); // TR
        glVertex2f(330.28,217.21); //TL
        glVertex2f(330.28,221.31); //DR
        glVertex2f(469.45,301.84); //DL
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(35,47,58); //DARKGREY
        glVertex2f(403.21,167.84); //U
        glVertex2f(330.28,213.11); //L
        glVertex2f(469.45,293.63); //D
        glVertex2f(542.38,248.37); //R
    glEnd();
    float dy=8.2;
     int i;
     for(i=0;i<5;i++){
          glBegin(GL_POLYGON);
             glColor3ub(55,50,63); //DARKGREY
             glVertex2f(474.39,309.07+i*dy); //U
             glVertex2f(474.39,310.6+i*dy); //L
             glVertex2f(334.94,230.1+i*dy); //D
             glVertex2f(334.94,228.56+i*dy); //R
          glEnd();
     }
}
void window(){
     glBegin(GL_POLYGON);
        glColor3ub(white);
        glVertex2f(355.84,243.95); //TL
        glVertex2f(358.44,245.49); //TR
        glVertex2f(358.43,261.64); //DR
        glVertex2f(355.83,262.85); //DL
     glEnd();

     glBegin(GL_POLYGON);
        glColor3ub(191,215,221);
        glVertex2f(358.43,261.64); //TR
        glVertex2f(355.83,262.85); //TL
        glVertex2f(369.78,270.95); //DL
        glVertex2f(369.78,268.19); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(0,155,191);
        glVertex2f(358.44,245.49); //TR
        glVertex2f(358.43,261.64); //DR
        glVertex2f(360.12,260.66); //TR
        glVertex2f(360.13,246.47); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(0,155,191);
        glVertex2f(358.43,261.64); //DR
        glVertex2f(360.12,260.66); //TR
        glVertex2f(369.78,266.24); //TR
        glVertex2f(369.78,268.19); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(0,155,191);
        glVertex2f(360.13,246.47); //TR
        glVertex2f(361.4,247.2); //DR
        glVertex2f(361.4,259.88); //TR
        glVertex2f(360.12,260.66); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(77,208,225);
        glVertex2f(360.13,246.47); //TR
        glVertex2f(369.79,252.05); //DR
        glVertex2f(369.78,266.24); //TR
        glVertex2f(360.12,260.66); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(178,235,242);
        glVertex2f(361.4,247.2); //TR
        glVertex2f(361.4,259.88); //DR
        glVertex2f(369.79,252.05); //TR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(178,235,242);
        glVertex2f(362.64,260.6); //TR
        glVertex2f(363.89,261.32); //DR
        glVertex2f(369.79,255.88); //TR
        glVertex2f(369.79,253.93); //TR
     glEnd();
}
void windows(){
     window();
     glPushMatrix();
          glTranslatef(41.85,24.3,0);
          window();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(83.71,48.59,0);
          window();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(54.79,194.71,0);
          window();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(71.11,205.13,0);
          window();
     glPopMatrix();

}
void pillarwood(){
     glBegin(GL_POLYGON);
        glColor3ub(128,172,183);
        glVertex2f(371.9,412.9); //TL
        glVertex2f(377,415.05); //TR
        glVertex2f(377,497); //DR
        glVertex2f(372,500); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(white);
        glVertex2f(366.87,410.15); //TL
        glVertex2f(371.9,412.9); //TR
        glVertex2f(372,500); //DR
        glVertex2f(367,496); //DL
     glEnd();
}
void pillar(){
    pillarwood();
     glPushMatrix();
          glTranslatef(146.65,84.64,0);
          pillarwood();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(73.325,42.32,0);
          pillarwood();
     glPopMatrix();
}
void vwindow(){
     glBegin(GL_POLYGON);
        glColor3ub(71,82,96);
        glVertex2f(553.5,403.74); //TL
        glVertex2f(576.65,390.37); //TR
        glVertex2f(576.65,450.89); //DR
        glVertex2f(553.5,464.25); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(35,47,58);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(574.27,394.5); //TR
        glVertex2f(574.27,449.51); //DR
        glVertex2f(555.88,460.13); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(0,155,191);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(571.89,395.81); //TR
        glVertex2f(571.89,448.14); //DR
        glVertex2f(555.88,457.38); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(70,208,225);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(569.51,397.25); //TR
        glVertex2f(569.51,446.76); //DR
        glVertex2f(555.88,454.63); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(71,82,96);
        glVertex2f(555.88,424.63); //TR
        glVertex2f(573.32,414.56);
        glVertex2f(573.32,416.03); //TR
        glVertex2f(555.88,426.1);
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(35,47,58);
        glVertex2f(555.88,422.98); //TL
        glVertex2f(555.88,424.63); //TR
        glVertex2f(573.32,414.56); //DR
        glVertex2f(571.89,413.74); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(178,235,242);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(567.71,398.29); //TR
        glVertex2f(567.71,416.16); //DR/DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(178,235,242);
        glVertex2f(555.88,407.77); //TL
        glVertex2f(555.88,410.52); //TR
        glVertex2f(564.2,418.18); //DR
        glVertex2f(565.95,417.17); //DL
     glEnd();
}
void hwindow(){
     glBegin(GL_POLYGON);
        glColor3ub(71,82,96);
        glVertex2f(553.5,403.74); //TL
        glVertex2f(576.65,390.37); //TR
        glVertex2f(576.65,450.89); //DR
        glVertex2f(553.5,464.25); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(35,47,58);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(574.27,394.5); //TR
        glVertex2f(574.27,449.51); //DR
        glVertex2f(555.88,460.13); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(0,155,191);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(571.89,395.81); //TR
        glVertex2f(571.89,448.14); //DR
        glVertex2f(555.88,457.38); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(178,235,242);
        glVertex2f(555.88,405.11); //TL
        glVertex2f(569.51,397.25); //TR
        glVertex2f(569.51,446.76); //DR
        glVertex2f(555.88,454.63); //DL
     glEnd();
}
void vhwindow(){
     vwindow();

     glPushMatrix();
          glTranslatef(49.57,-27.22,0);
          vwindow();
     glPopMatrix();
//     553.5,403.74
     glPushMatrix();
          glTranslatef(1.0,82,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(24,69,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(72,42,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(49.57,-27.22,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(553.5,0,0);
          glScalef(-1.0,1.0,1.0);
          glTranslatef(-485.72,3.66,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(553.5,0,0);
          glScalef(-1.0,1.0,1.0);
          glTranslatef(-436.15,-25.43,0);
          vwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(369.55,344.17,0);
          glRotatef( 29.162+90, 0.0, 0.0, 1.0);
          glScalef(1.5,1.5,1.0);
          glTranslatef(-553.5,-403.74,0);
          hwindow();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(519,498,0);
          glRotatef( 29.162+90, 0.0, 0.0, 1.0);
          glScalef(1,1,1.0);
          glTranslatef(-553.5,-403.74,0);
          hwindow();
     glPopMatrix();
}
void sstree(){
     glBegin(GL_POLYGON);
        glColor3ub(150,180-colorA,80); //SHADOW
          glVertex2f(78.64,490.31); //D
          glVertex2f(110,472.32); //L
          glVertex2f(140.72,490.31); //L
          glVertex2f(109.68,508.23); //D
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(139,78,64); //TRUNK
          glVertex2f(105,494); //D
          glVertex2f(114.54,494); //L
          glVertex2f(114.54,434); //L
          glVertex2f(105,434); //D
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(100,143,27); //LIGHTGREEN
          glVertex2f(109.69,419.23); //TL
          glVertex2f(140.73,401.31); //TR
          glVertex2f(140.73,458.53); //DR
          glVertex2f(109.69,476.45); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(100,143,27); //LIGHTGREEN
        glVertex2f(121.09,425.79); //TL
        glVertex2f(142.75,413.59); //TR
        glVertex2f(142.68,461.86); //DR
        glVertex2f(120.96,474.29); //DL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(76,105,17); //DARKGREEN
          glVertex2f(121.09,425.79); //TR
          glVertex2f(121.09,474.29); //DR
          glVertex2f(115.98,470.94); //D:
          glVertex2f(115.98,422.64); //TL
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(94,130,6); //MEDGREEN
          glVertex2f(121.09,425.79); //D
          glVertex2f(115.67,422.64); //L
          glVertex2f(137.42,410.19); //U
          glVertex2f(142.75,413.59); //R
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(159,193,88); //GREEN
          glVertex2f(109.69,419.23); //TL
          glVertex2f(140.73,401.31); //TR
          glVertex2f(110.01,383.32); //DR
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(94,130,6); //MEDGREEN
          glVertex2f(109.72,406.53); //D
          glVertex2f(133.46,392.82); //L
          glVertex2f(133.46,399.67); //U
          glVertex2f(109.72,413.38); //R
     glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(159,193,88); //GREEN
          glVertex2f(109.72,406.53); //D
          glVertex2f(133.46,392.82); //R
          glVertex2f(108.97,379.04); //U
     glEnd();
     glPushMatrix();
          glTranslatef(109.69,0,0);
          glScalef(-1.0,1.0,1.0);
          glTranslatef(-109.69,0,0);
          glBegin(GL_POLYGON);
               glColor3ub(137,176,53); //LIGHTGREEN
               glVertex2f(109.69,419.23); //TL
               glVertex2f(140.73,401.31); //TR
               glVertex2f(140.73,458.53); //DR
               glVertex2f(109.69,476.45); //DL
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(137,176,53); //LIGHTGREEN
             glVertex2f(121.09,425.79); //TL
             glVertex2f(142.75,413.59); //TR
             glVertex2f(142.68,461.86); //DR
             glVertex2f(120.96,474.29); //DL
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(76,105,17); //DARKGREEN
               glVertex2f(121.09,425.79); //TR
               glVertex2f(120.96,474.29); //DR
               glVertex2f(115.98,470.94); //D:
               glVertex2f(115.98,422.64); //TL
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(94,130,6); //MEDGREEN
               glVertex2f(121.09,425.79); //D
               glVertex2f(115.67,422.64); //L
               glVertex2f(137.42,410.19); //U
               glVertex2f(142.75,413.59); //R
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(159,193,88); //GREEN
               glVertex2f(109.69,419.23); //TL
               glVertex2f(140.73,401.31); //TR
               glVertex2f(110.01,383.32); //DR
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(94,130,6); //MEDGREEN
               glVertex2f(109.72,406.53); //D
               glVertex2f(133.46,392.82); //L
               glVertex2f(133.46,399.67); //U
               glVertex2f(109.72,413.38); //R
          glEnd();
          glBegin(GL_POLYGON);
             glColor3ub(159,193,88); //GREEN
               glVertex2f(109.72,406.53); //D
               glVertex2f(133.46,392.82); //R
               glVertex2f(108.97,379.04); //U
          glEnd();
     glPopMatrix();
}
void stree(){
    glPushMatrix();
          glTranslatef(561.14+53,29.16-30,0);
          sstree();
     glPopMatrix();
    glPushMatrix();
          glTranslatef(561.14,29.16,0);
          sstree();
     glPopMatrix();

     glPushMatrix();
          glTranslatef(561.14-53,29.16+30,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(561.14-53-53,29.16+60,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(561.14-53-53-53,29.16+90,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(561.14-53-53-53-53,29.16+120,0);
          sstree();
     glPopMatrix();
     glPushMatrix();
          glTranslatef(53,-30,0);
          sstree();
     glPopMatrix();
     sstree();
}
void house()
{
    if(buff==0&&colorB==0){
        colorA++;
        if(colorA==60){
            colorB=1;
            moveB=-20;
            //Sleep(600);
        }
    }
    if(buff==0&&colorB==1){
        colorA--;
        if(colorA==0){
        colorB=0;
        moveB=20;
            //Sleep(600);
            }
    }
    buff++;
    buff=buff%50;
    if(buff%7==0&&colorB==1){
        moveA++;
    }
    if(buff%7==0&&colorB==0){
        moveA--;
    }
    bg();
    ground();
    road();
    firstfloor();
    secondfloor();
    roof();
    thirdfloor();
    windows();
    frontpart();
    vhwindow();
    pillar();
    stree();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "House", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);


    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        house();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
