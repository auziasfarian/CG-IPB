#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(767, 767, "G64160054", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);


while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 767, 767, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();

glBegin(GL_POLYGON);
glColor3ub(117,198,195);
glVertex2f(0,0);
glColor3ub(117,198,195);
glVertex2f(0,767);
glColor3ub(117,198,195);
glVertex2f(767,767);
glColor3ub(117,198,195);
glVertex2f(767,0);
glEnd();

//tanah left shadow
glBegin(GL_POLYGON);
glColor3ub(143,117,92);
glVertex2f(21,410);
glColor3ub(143,117,92);
glVertex2f(21,380);
glColor3ub(143,117,92);
glVertex2f(384,590);
glColor3ub(143,117,92);
glVertex2f(384,620);
glEnd();

//tanah right shadow
glBegin(GL_POLYGON);
glColor3ub(85,67,46);
glVertex2f(384,590);
glColor3ub(85,67,46);
glVertex2f(384,620);
glColor3ub(85,67,46);
glVertex2f(745,413);
glColor3ub(85,67,46);
glVertex2f(745,383);
glEnd();

//jalan aspal
glBegin(GL_POLYGON);
glColor3ub(122,111,124);
glVertex2f(384,590);
glColor3ub(122,111,124);
glVertex2f(21,380);
glColor3ub(122,111,124);
glVertex2f(82.5,346.5);
glColor3ub(122,111,124);
glVertex2f(444.5,556.5);
glEnd();

//white line
glBegin(GL_POLYGON);
glColor3ub(255,255,255);
glVertex2f(75,351);
glColor3ub(255,255,255);
glVertex2f(79,349);
glColor3ub(255,255,255);
glVertex2f(442,558);
glColor3ub(255,255,255);
glVertex2f(438.74,559.85);
glEnd();

//permukaan tanah ijo
glBegin(GL_POLYGON);
glColor3ub(179,179,100);
glVertex2f(83,344);
glColor3ub(179,179,100);
glVertex2f(380,168);
glColor3ub(179,179,100);
glVertex2f(745,380);
glColor3ub(179,179,100);
glVertex2f(445,552);
glEnd();

//TROTOAR AHOY
//left shadow
glBegin(GL_POLYGON);
glColor3ub(203,175,164);
glVertex2f(83,344);
glColor3ub(203,175,164);
glVertex2f(445,552);
glColor3ub(203,175,164);
glVertex2f(444.5,556.5);
glColor3ub(203,175,164);
glVertex2f(82.5,346.5);
glEnd();

//right shadow
glBegin(GL_POLYGON);
glColor3ub(136,122,126);
glVertex2f(444.5,556.5);
glColor3ub(136,122,126);
glVertex2f(445,552);
glColor3ub(136,122,126);
glVertex2f(745,380);
glColor3ub(136,122,126);
glVertex2f(745,384);
glEnd();

//trotoar permukaan
glBegin(GL_POLYGON);
glColor3ub(237,205,200);
glVertex2f(83,344);
glColor3ub(237,205,200);
glVertex2f(445,552);
glColor3ub(237,205,200);
glVertex2f(465,541);
glColor3ub(237,205,200);
glVertex2f(101,332);
glEnd();

//GARAGE
glBegin(GL_POLYGON);
glColor3ub(216,185,171);
glVertex2f(141 ,356);
glColor3ub(216,185,171);
glVertex2f(180  ,333);
glColor3ub(216,185,171);
glVertex2f(250  ,374  );
glColor3ub(216,185,171);
glVertex2f(211.651 ,395.533 );
glEnd();

//lantai
glBegin(GL_POLYGON);
glColor3ub(253,239,232);
glVertex2f(244 ,361 );
glColor3ub(253,239,232);
glVertex2f(235.933 ,365.761);
glColor3ub(253,239,232);
glVertex2f(180 ,333 );
glColor3ub(253,239,232);
glVertex2f(359 ,240 ); //ini woiii
glColor3ub(253,239,232);
glVertex2f(636 ,400 );
glColor3ub(253,239,232);
glVertex2f(472  ,493  );
glEnd();

//lantai_2
glBegin(GL_POLYGON);
glColor3ub(253,239,232);
glVertex2f(165 ,320 );
glColor3ub(253,239,232);
glVertex2f(184,331);
glColor3ub(253,239,232);
glVertex2f(236,305);
glColor3ub(253,239,232);
glVertex2f(214 ,292 );
glEnd();

//fence lantai
glBegin(GL_POLYGON);
glColor3ub(203,175,164);
glVertex2f(180  ,333);
glColor3ub(203,175,164);
glVertex2f(180  ,329);
glColor3ub(203,175,164);
glVertex2f(165 ,320 );
glColor3ub(203,175,164);
glVertex2f(165,325);
glEnd();

//fence_2 lantai
glBegin(GL_POLYGON);
glColor3ub(136,122,126);
glVertex2f(180  ,333);
glColor3ub(136,122,126);
glVertex2f(180  ,329);
glColor3ub(136,122,126);
glVertex2f(184 ,326  );
glColor3ub(136,122,126);
glVertex2f(184 ,331 );
glEnd();

//Pager
glBegin(GL_POLYGON);
glColor3ub(136,122,126);
glVertex2f(465,541);
glColor3ub(136,122,126);
glVertex2f(465,535);
glColor3ub(136,122,126);
glVertex2f(468,533);
glColor3ub(136,122,126);
glVertex2f(468,540);
glEnd();

//right front fence
glBegin(GL_POLYGON);
glColor3ub(203,175,164);
glVertex2f(211.651 ,395.533 );
glColor3ub(203,175,164);
glVertex2f(211.651,389 );
glColor3ub(203,175,164);
glVertex2f(465,535);
glColor3ub(203,175,164);
glVertex2f(465,541);
glEnd();

//right up fence
glBegin(GL_POLYGON);
glColor3ub(237,205,200);
glVertex2f(211.651,389);
glColor3ub(237,205,200);
glVertex2f(465,535 );
glColor3ub(237,205,200);
glVertex2f(468,533);
glColor3ub(237,205,200);
glVertex2f(215 ,386 );
glEnd();

//left front fence
glBegin(GL_POLYGON);
glColor3ub(203,175,164);
glVertex2f(101,332);
glColor3ub(203,175,164);
glVertex2f(101,325);
glColor3ub(203,175,164);
glVertex2f(141 ,348 );
glColor3ub(203,175,164);
glVertex2f(141 ,356);
glEnd();

//left rightside fence
glBegin(GL_POLYGON);
glColor3ub(136,122,126);
glVertex2f(141 ,348 );
glColor3ub(136,122,126);
glVertex2f(141 ,356);
glColor3ub(136,122,126);
glVertex2f(145 ,353 );
glColor3ub(136,122,126);
glVertex2f(145 ,346 );
glEnd();

//left up fence
glBegin(GL_POLYGON);
glColor3ub(237,205,200);
glVertex2f(101,325);
glColor3ub(237,205,200);
glVertex2f(141 ,348 );
glColor3ub(237,205,200);
glVertex2f(145 ,346 );
glColor3ub(237,205,200);
glVertex2f(105 ,323 );
glEnd();

//GARAGE
glBegin(GL_POLYGON);
glColor3ub(216,185,171);
glVertex2f(141 ,356);
glColor3ub(216,185,171);
glVertex2f(180  ,333);
glColor3ub(216,185,171);
glVertex2f(250  ,374  );
glColor3ub(216,185,171);
glVertex2f(211.651 ,395.533 );
glEnd();

//pager rumput
glBegin(GL_POLYGON);
glColor3ub(125,132,77);
glVertex2f(460  ,525);
glColor3ub(125,132,77);
glVertex2f(460 ,500);
glColor3ub(125,132,77);
glVertex2f(232 ,368 );
glColor3ub(125,132,77);
glVertex2f(232 ,394) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(125,132,77);
glVertex2f(733   ,386 );
glColor3ub(125,132,77);
glVertex2f(733  ,361);
glColor3ub(125,132,77);
glVertex2f(548   ,259 );
glColor3ub(125,132,77);
glVertex2f(548  ,283) ;
glEnd();

//pager rightside rumput
glBegin(GL_POLYGON);
glColor3ub(106,107,59);
glVertex2f(460  ,525);
glColor3ub(106,107,59);
glVertex2f(460 ,500);
glColor3ub(106,107,59);
glVertex2f(472 ,494 );
glColor3ub(106,107,59);
glVertex2f(472 ,518) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(106,107,59);
glVertex2f(733   ,386 );
glColor3ub(106,107,59);
glVertex2f(733  ,361);
glColor3ub(106,107,59);
glVertex2f(745  ,355 );
glColor3ub(106,107,59);
glVertex2f(745  ,379) ;
glEnd();

//pager up rumput
glBegin(GL_POLYGON);
glColor3ub(175,175,103);
glVertex2f(460 ,500);
glColor3ub(175,175,103);
glVertex2f(472 ,494);
glColor3ub(175,175,103);
glVertex2f(245  ,361  );
glColor3ub(175,175,103);
glVertex2f(232  ,368 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(175,175,103);
glVertex2f(733  ,361);
glColor3ub(175,175,103);
glVertex2f(745  ,355);
glColor3ub(175,175,103);
glVertex2f(562 ,254  );
glColor3ub(175,175,103);
glVertex2f(548   ,259 ) ;
glEnd();

//TEMBOK RUMAH EUY
//depan_1
glBegin(GL_POLYGON);
glColor3ub(220,196,177);
glVertex2f(325 ,242);
glColor3ub(220,196,177);
glVertex2f(325   ,344);
glColor3ub(220,196,177);
glVertex2f(421   ,398 );
glColor3ub(220,196,177);
glVertex2f(421  ,298) ;
glEnd();

//depan_2
glBegin(GL_POLYGON);
glColor3ub(220,196,177);
glVertex2f(275  ,181);
glColor3ub(220,196,177);
glVertex2f(275    ,218 );
glColor3ub(220,196,177);
glVertex2f(353    ,249 );
glColor3ub(220,196,177);
glVertex2f(353   ,226) ;
glEnd();

//KUSEN jendela depan
glBegin(GL_POLYGON);
glColor3ub(50,33,26);
glVertex2f(370,336);
glColor3ub(50,33,26);
glVertex2f(361,331);
glColor3ub(50,33,26);
glVertex2f(361,352 );
glColor3ub(50,33,26);
glVertex2f(370,357) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(50,33,26);
glVertex2f(384 ,346);
glColor3ub(50,33,26);
glVertex2f(376 ,340);
glColor3ub(50,33,26);
glVertex2f(376 ,360 );
glColor3ub(50,33,26);
glVertex2f(384 ,364) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(50,33,26);
glVertex2f(401  ,354);
glColor3ub(50,33,26);
glVertex2f(392  ,349);
glColor3ub(50,33,26);
glVertex2f(392  ,369 );
glColor3ub(50,33,26);
glVertex2f(401  ,374) ;
glEnd();

//jendela depan
glBegin(GL_POLYGON);
glColor3ub(221,203,197);
glVertex2f(370   ,336);
glColor3ub(221,203,197);
glVertex2f(362     ,331 );
glColor3ub(125,103,108);
glVertex2f(362     ,351 );
glColor3ub(125,103,108);
glVertex2f(370    ,356) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(221,203,197);
glVertex2f(385    ,345);
glColor3ub(221,203,197);
glVertex2f(377      ,340 );
glColor3ub(125,103,108);
glVertex2f(377      ,359 );
glColor3ub(125,103,108);
glVertex2f(385     ,364) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(221,203,197);
glVertex2f(401,354);
glColor3ub(221,203,197);
glVertex2f(393,349);
glColor3ub(125,103,108);
glVertex2f(393,368 );
glColor3ub(125,103,108);
glVertex2f(401,373) ;
glEnd();

//TEMBOK COKLAT DEPAN
glBegin(GL_POLYGON);
glColor3ub(144,115,92);
glVertex2f(289  ,287);
glColor3ub(144,115,92);
glVertex2f(326  ,308.398 );
glColor3ub(144,115,92);
glVertex2f(326   ,358);
glColor3ub(144,115,92);
glVertex2f(289   ,335 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(85,64,44);
glVertex2f(326  ,308.398 );
glColor3ub(85,64,44);
glVertex2f(326   ,358);
glColor3ub(85,64,44);
glVertex2f(337   ,352);
glColor3ub(85,64,44);
glVertex2f(337    ,314 ) ;
glEnd();

//frame putih
glBegin(GL_POLYGON);
glColor3ub(221,203,197);
glVertex2f(316  ,314);
glColor3ub(221,203,197);
glVertex2f(316  ,347);
glColor3ub(221,203,197);
glVertex2f(323  ,351);
glColor3ub(221,203,197);
glVertex2f(323  ,318 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(221,203,197);
glVertex2f(306 ,308);
glColor3ub(221,203,197);
glVertex2f(313   ,312);
glColor3ub(221,203,197);
glVertex2f(313   ,345);
glColor3ub(221,203,197);
glVertex2f(306   ,341 ) ;
glEnd();

//JENDELA NYA CUY
glBegin(GL_POLYGON);
glColor3ub(127,102,110);
glVertex2f(317 ,316);
glColor3ub(127,102,110);
glVertex2f(322 ,319);
glColor3ub(56,31,25);
glVertex2f(322 ,349);
glColor3ub(56,31,25);
glVertex2f(317 ,346 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(127,102,110);
glVertex2f(307  ,310);
glColor3ub(127,102,110);
glVertex2f(312  ,313);
glColor3ub(56,31,25);
glVertex2f(312  ,343);
glColor3ub(56,31,25);
glVertex2f(307  ,340 ) ;
glEnd();

//tiang hijau
glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(289  ,316.71 );
glColor3ub(198,186,163);
glVertex2f(296   ,321);
glColor3ub(198,186,163);
glVertex2f(285   ,327);
glColor3ub(198,186,163);
glVertex2f(277.97   ,323.114  ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(285   ,327);
glColor3ub(155,149,130);
glVertex2f(277.97   ,323.114  );
glColor3ub(155,149,130);
glVertex2f(273 ,326);
glColor3ub(155,149,130);
glVertex2f(273 ,364) ;
glColor3ub(155,149,130);
glVertex2f(285  ,371) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(99,89,78);
glVertex2f(296   ,321);
glColor3ub(99,89,78);
glVertex2f(285   ,327);
glColor3ub(99,89,78);
glVertex2f(285  ,371) ;
glColor3ub(99,89,78);
glVertex2f(296   ,365 );
glEnd();

//tembok L
//frontside
glBegin(GL_POLYGON);
glColor3ub(220,196,177);
glVertex2f(198 ,283 );
glColor3ub(220,196,177);
glVertex2f(198  ,320 );
glColor3ub(220,196,177);
glVertex2f(187   ,314 );
glColor3ub(220,196,177);
glVertex2f(187,264 ) ;
glColor3ub(220,196,177);
glVertex2f(273 ,313  ) ;
glColor3ub(220,196,177);
glVertex2f(273 ,326  ) ;
glEnd();

//rightside
glBegin(GL_POLYGON);
glColor3ub(145,127,109);
glVertex2f(198  ,320 );
glColor3ub(145,127,109);
glVertex2f(198 ,283 );
glColor3ub(145,127,109);
glVertex2f(210,290);
glColor3ub(145,127,109);
glVertex2f(210,314 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(154,136,118);
glVertex2f(273 ,313  );
glColor3ub(154,136,118);
glVertex2f(273 ,326);
glColor3ub(154,136,118);
glVertex2f(304 ,308);
glColor3ub(154,136,118);
glVertex2f(304,295 ) ;
glEnd();

//upperside
glBegin(GL_POLYGON);
glColor3ub(253,239,229);
glVertex2f(187,264);
glColor3ub(253,239,229);
glVertex2f(265  ,219 );
glColor3ub(253,239,229);
glVertex2f(346  ,270 );
glColor3ub(253,239,229);
glVertex2f(273 ,313) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(158,136,121);
glVertex2f(336       ,351);
glColor3ub(158,136,121);
glVertex2f(349       ,357);
glColor3ub(158,136,121);
glVertex2f(349,321);
glColor3ub(158,136,121);
glVertex2f(336 ,314.5 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(158,136,121);
glVertex2f(383,328);
glColor3ub(158,136,121);
glVertex2f(375       ,333);
glColor3ub(158,136,121);
glVertex2f(391 ,342);
glColor3ub(158,136,121);
glVertex2f(391  ,300 );
glColor3ub(158,136,121);
glVertex2f(383   ,286 );
glEnd();


//tembok ROOFTOP
glBegin(GL_POLYGON);
glColor3ub(251,238,227);
glVertex2f(291 ,181);
glColor3ub(251,238,227);
glVertex2f(364 ,139 );
glColor3ub(251,238,227);
glVertex2f(364 ,130);
glColor3ub(251,238,227);
glVertex2f(275 ,181) ;
glColor3ub(251,238,227);
glVertex2f(353 ,226);
glColor3ub(251,238,227);
glVertex2f(370  ,226) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(251,238,227);
glVertex2f(342 ,242);
glColor3ub(251,238,227);
glVertex2f(370  ,226);
glColor3ub(251,238,227);
glVertex2f(353 ,226);
glColor3ub(251,238,227);
glVertex2f(325 ,242) ;
glColor3ub(251,238,227);
glVertex2f(421  ,298);
glColor3ub(251,238,227);
glVertex2f(421 ,287) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(251,238,227);
glVertex2f(493  ,246);
glColor3ub(251,238,227);
glVertex2f(421 ,287) ;
glColor3ub(251,238,227);
glVertex2f(421  ,298);
glColor3ub(251,238,227);
glVertex2f(510   ,246);
glColor3ub(251,238,227);
glVertex2f(454  ,214);
glColor3ub(251,238,227);
glVertex2f(436  ,214) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(251,238,227);
glVertex2f(463   ,197);
glColor3ub(251,238,227);
glVertex2f(436  ,214) ;
glColor3ub(251,238,227);
glVertex2f(454  ,214);
glColor3ub(251,238,227);
glVertex2f(480  ,198) ;
glColor3ub(251,238,227);
glVertex2f(364 ,130);
glColor3ub(251,238,227);
glVertex2f(364 ,139 );
glEnd();

//LANTAI ROOFTOP
glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(436  ,214);
glColor3ub(198,186,163);
glVertex2f(463   ,197) ;
glColor3ub(198,186,163);
glVertex2f(440.849,184.023 );
glColor3ub(198,186,163);
glVertex2f(342 ,242) ;
glColor3ub(198,186,163);
glVertex2f(421 ,287);
glColor3ub(198,186,163);
glVertex2f(493  ,246);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(364 ,145);
glColor3ub(198,186,163);
glVertex2f(296.306 ,184.023 ) ;
glColor3ub(198,186,163);
glVertex2f(372 ,226.88 );
glColor3ub(198,186,163);
glVertex2f(436.066  ,187 ) ;
glEnd();

//SIDE TEMBOK ROOFTOP
glBegin(GL_POLYGON);
glColor3ub(144,127,113);
glVertex2f(370  ,226);
glColor3ub(144,127,113);
glVertex2f(342,242) ;
glColor3ub(144,127,113);
glVertex2f(346.684 ,244.635 );
glColor3ub(144,127,113);
glVertex2f(370 ,231 ) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(144,127,113);
glVertex2f(364 ,139 );
glColor3ub(144,127,113);
glVertex2f(291 ,181) ;
glColor3ub(144,127,113);
glVertex2f(296.2,184.2);
glColor3ub(144,127,113);
glVertex2f(364  ,145) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(220,196,177);
glVertex2f(364  ,139);
glColor3ub(220,196,177);
glVertex2f(364    ,146 );
glColor3ub(220,196,177);
glVertex2f(458,201);
glColor3ub(220,196,177);
glVertex2f(463   ,197) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(220,196,177);
glVertex2f(436 ,214);
glColor3ub(220,196,177);
glVertex2f(436 ,220 );
glColor3ub(220,196,177);
glVertex2f(488.346 ,248.688 );
glColor3ub(220,196,177);
glVertex2f(493  ,246) ;
glEnd();

//TEMBOK KANAN NTAPSS
glBegin(GL_POLYGON);
glColor3ub(147,129,111);
glVertex2f(421  ,298);
glColor3ub(147,129,111);
glVertex2f(421  ,398 );
glColor3ub(147,129,111);
glVertex2f(510 ,349);
glColor3ub(147,129,111);
glVertex2f(510   ,246) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(147,129,111);
glVertex2f(480   ,198);
glColor3ub(147,129,111);
glVertex2f(454   ,214 );
glColor3ub(147,129,111);
glVertex2f(480  ,229);
glEnd();

//jendela ijo kiri
//front
glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(267 ,227);
glColor3ub(155,149,130);
glVertex2f(267  ,221  );
glColor3ub(155,149,130);
glVertex2f(289   ,233 );
glColor3ub(155,149,130);
glVertex2f(283  ,237) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(289  ,213);
glColor3ub(155,149,130);
glVertex2f(267   ,199  );
glColor3ub(155,149,130);
glVertex2f(267    ,192 );
glColor3ub(155,149,130);
glVertex2f(302   ,212) ;
glColor3ub(155,149,130);
glVertex2f(302  ,226) ;
glColor3ub(155,149,130);
glVertex2f(289 ,233) ;
glEnd();

//up
glBegin(GL_POLYGON);
glColor3ub(195,186,165);
glVertex2f(275,220);
glColor3ub(195,186,165);
glVertex2f(275,217);
glColor3ub(195,186,165);
glVertex2f(274,216);
glColor3ub(195,186,165);
glVertex2f(267 ,221) ;
glColor3ub(195,186,165);
glVertex2f(289   ,233) ;
glColor3ub(195,186,165);
glVertex2f(289  ,228) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(195,186,165);
glVertex2f(275 ,191);
glColor3ub(195,186,165);
glVertex2f(275,187 );
glColor3ub(195,186,165);
glVertex2f(267 ,192);
glColor3ub(195,186,165);
glVertex2f(302  ,212) ;
glColor3ub(195,186,165);
glVertex2f(307 ,210) ;
glEnd();

//right
glBegin(GL_POLYGON);
glColor3ub(100,90,78);
glVertex2f(302  ,212);
glColor3ub(100,90,78);
glVertex2f(302 ,226 );
glColor3ub(100,90,78);
glVertex2f(307  ,223);
glColor3ub(100,90,78);
glVertex2f(307   ,210) ;
glEnd();

//kacatua
glBegin(GL_POLYGON);
glColor3ub(148,129,132);
glVertex2f(289   ,228);
glColor3ub(124,102,107);
glVertex2f(275 ,220);
glColor3ub(148,129,132);
glVertex2f(275  ,204.1);
glColor3ub(124,102,107);
glVertex2f(289  ,212);
glEnd();


//jendela ijo kanan
//front
glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(289,251);
glColor3ub(155,149,130);
glVertex2f(289,287);
glColor3ub(155,149,130);
glVertex2f(280  ,282);
glColor3ub(155,149,130);
glVertex2f(280  ,239);
glColor3ub(155,149,130);
glVertex2f(351  ,280);
glColor3ub(155,149,130);
glVertex2f(351,287) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(351 ,311);
glColor3ub(155,149,130);
glVertex2f(289,276);
glColor3ub(155,149,130);
glVertex2f(289,287);
glColor3ub(155,149,130);
glVertex2f(372   ,335);
glColor3ub(155,149,130);
glVertex2f(372   ,292);
glColor3ub(155,149,130);
glVertex2f(351 ,280) ;
glEnd();

//up
glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(326,242 );
glColor3ub(198,186,163);
glVertex2f(345 ,231);
glColor3ub(198,186,163);
glVertex2f(320,216);
glColor3ub(198,186,163);
glVertex2f(280    ,239);
glColor3ub(198,186,163);
glVertex2f(316.414 ,260.028 );
glColor3ub(198,186,163);
glVertex2f(326   ,253) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(316.414 ,260.028 );
glColor3ub(198,186,163);
glVertex2f(326   ,253) ;
glColor3ub(198,186,163);
glVertex2f(383 ,286 );
glColor3ub(198,186,163);
glVertex2f(372  ,292);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(289 ,276);
glColor3ub(198,186,163);
glVertex2f(293 ,272) ;
glColor3ub(198,186,163);
glVertex2f(351 ,304);
glColor3ub(198,186,163);
glVertex2f(351,311 );
glEnd();

glBegin(GL_POLYGON);
glColor3ub(198,186,163);
glVertex2f(293  ,263);
glColor3ub(198,186,163);
glVertex2f(293 ,267.667 ) ;
glColor3ub(198,186,163);
glVertex2f(305.449  ,260.551 );
glColor3ub(198,186,163);
glVertex2f(301.231 ,258.102  );
glEnd();

//rightside
glBegin(GL_POLYGON);
glColor3ub(99,89,78);
glVertex2f(372  ,292);
glColor3ub(99,89,78);
glVertex2f(383 ,286 ) ;
glColor3ub(99,89,78);
glVertex2f(383,328 );
glColor3ub(99,89,78);
glVertex2f(372 ,335);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(99,89,78);
glVertex2f(289 ,276);
glColor3ub(99,89,78);
glVertex2f(293 ,272) ;
glColor3ub(99,89,78);
glVertex2f(293,253.323 );
glColor3ub(99,89,78);
glVertex2f(289 ,251 );
glEnd();

//tembok dalem kanan
glBegin(GL_POLYGON);
glColor3ub(122,112,98);
glVertex2f(293  ,268);
glColor3ub(122,112,98);
glVertex2f(305  ,260) ;
glColor3ub(122,112,98);
glVertex2f(313.691 ,265.337 );
glColor3ub(122,112,98);
glVertex2f(298.686  ,275.333  );
glColor3ub(122,112,98);
glVertex2f(293 ,272);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(206,197,183);
glVertex2f(351   ,306);
glColor3ub(206,197,183);
glVertex2f(351,287 ) ;
glColor3ub(99,89,78);
glVertex2f(314 ,265);
glColor3ub(99,89,78);
glVertex2f(298.686  ,275.333  );
glEnd();

//SHADOW UHU
glBegin(GL_POLYGON);
glColor3ub(161,146,130);
glVertex2f(551  ,361);
glColor3ub(161,146,130);
glVertex2f(571  ,371);
glColor3ub(161,146,130);
glVertex2f(579   ,367);
glColor3ub(161,146,130);
glVertex2f(541  , 344) ;
glColor3ub(161,146,130);
glVertex2f(424,412);
glColor3ub(161,146,130);
glVertex2f(462, 412) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(161,146,130);
glVertex2f(510   ,349);
glColor3ub(161,146,130);
glVertex2f(510   ,326);
glColor3ub(161,146,130);
glVertex2f(541  , 344);
glColor3ub(161,146,130);
glVertex2f(490 ,375) ;
glColor3ub(161,146,130);
glVertex2f(488 ,360);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(121,124,84);
glVertex2f(555   ,320);
glColor3ub(121,124,84);
glVertex2f(582    ,304);
glColor3ub(121,124,84);
glVertex2f(535     ,275);
glColor3ub(121,124,84);
glVertex2f(510,289);
glColor3ub(121,124,84);
glVertex2f(510 ,326);
glColor3ub(121,124,84);
glVertex2f(579  ,368);
glColor3ub(121,124,84);
glVertex2f(610   ,351);
glEnd();

//garasi blkg
glBegin(GL_POLYGON);
glColor3ub(216,185,171);
glVertex2f(535    ,275);
glColor3ub(216,185,171);
glVertex2f(548     ,266);
glColor3ub(216,185,171);
glVertex2f(510     ,245);
glColor3ub(216,185,171);
glVertex2f(510     ,262);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(151,133,118);
glVertex2f(535    ,275);
glColor3ub(151,133,118);
glVertex2f(510    ,261); //z
glColor3ub(151,133,118);
glVertex2f(510    ,289);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(151,133,118);
glVertex2f(233     ,320);
glColor3ub(151,133,118);
glVertex2f(198     ,320);
glColor3ub(151,133,118);
glVertex2f(210     ,314);
glColor3ub(151,133,118);
glVertex2f(248.5     ,312);
glColor3ub(151,133,118);
glVertex2f(273      ,326);
glColor3ub(151,133,118);
glVertex2f(273       ,342);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(151,133,118);
glVertex2f(296      ,365);
glColor3ub(151,133,118);
glVertex2f(285      ,371);
glColor3ub(151,133,118);
glVertex2f(330      ,371);
glColor3ub(151,133,118);
glVertex2f(342  ,364);
glColor3ub(151,133,118);
glVertex2f(296      ,339);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(151,133,118);
glVertex2f(336       ,357);
glColor3ub(151,133,118);
glVertex2f(349       ,357);
glColor3ub(151,133,118);
glVertex2f(338       ,351);
glColor3ub(151,133,118);
glVertex2f(328  ,356);
glColor3ub(151,133,118);
glVertex2f(332      ,359);
glEnd();



//jendela ijo bawah
glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(406 ,316);
glColor3ub(155,149,130);
glVertex2f(424 ,326);
glColor3ub(155,149,130);
glVertex2f(424   ,412);
glColor3ub(155,149,130);
glVertex2f(406   ,402);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(155,149,130);
glVertex2f(424 ,326);
glColor3ub(155,149,130);
glVertex2f(424   ,412);
glColor3ub(99,89,78);
glVertex2f(489   ,375);
glColor3ub(99,89,78);
glVertex2f(489  ,289) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(99,89,78);
glVertex2f(422  ,313);
glColor3ub(99,89,78);
glVertex2f(476    ,281);
glColor3ub(99,89,78);
glVertex2f(489    ,289);
glColor3ub(198,186,163);
glVertex2f(424   ,326) ;
glColor3ub(198,186,163);
glVertex2f(406    ,316) ;
glColor3ub(198,186,163);
glVertex2f(415    ,310) ;
glEnd();

//jendela 4 coklat
glBegin(GL_POLYGON);
glColor3ub(56,31,25);
glVertex2f(447   ,324);
glColor3ub(56,31,25);
glVertex2f(453     ,321);

glColor3ub(99,76,72);
glVertex2f(453     ,392);
glColor3ub(99,76,72);
glVertex2f(447    ,395) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(56,31,25);
glVertex2f(458   ,318);
glColor3ub(56,31,25);
glVertex2f(464,315);

glColor3ub(99,76,72);
glVertex2f(464,386);
glColor3ub(99,76,72);
glVertex2f(458,389) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(56,31,25);
glVertex2f(468 ,312);
glColor3ub(56,31,25);
glVertex2f(474 ,309);

glColor3ub(99,76,72);
glVertex2f(474 ,380);
glColor3ub(99,76,72);
glVertex2f(468 ,383) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(56,31,25);
glVertex2f(479  ,306);
glColor3ub(56,31,25);
glVertex2f(485  ,303);

glColor3ub(99,76,72);
glVertex2f(485  ,374);
glColor3ub(99,76,72);
glVertex2f(479  ,377) ;
glEnd();

//kolam renang
glBegin(GL_POLYGON);
glColor3ub(117,198,195);
glVertex2f(527 ,433);
glColor3ub(117,198,195);
glVertex2f(485  ,433);
glColor3ub(117,198,195);
glVertex2f(431 ,465);
glColor3ub(117,198,195);
glVertex2f(468 ,486) ;
glColor3ub(117,198,195);
glVertex2f(602  ,409) ;
glColor3ub(117,198,195);
glVertex2f(584  ,400) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(105,184,179);
glVertex2f(602  ,409);
glColor3ub(105,184,179);
glVertex2f(584  ,400);
glColor3ub(105,184,179);
glVertex2f(571  ,374);
glColor3ub(105,184,179);
glVertex2f(617  ,400) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(74,161,159);
glVertex2f(485  ,433);
glColor3ub(74,161,159);
glVertex2f(527 ,433);
glColor3ub(74,161,159);
glVertex2f(584  ,400);
glColor3ub(74,161,159);
glVertex2f(550   ,380) ;
glColor3ub(74,161,159);
glVertex2f(417,457) ;
glColor3ub(74,161,159);
glVertex2f(431,465) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(35,130,134);
glVertex2f(550   ,380);
glColor3ub(35,130,134);
glVertex2f(584  ,400);
glColor3ub(35,130,134);
glVertex2f(571  ,374);
glColor3ub(35,130,134);
glVertex2f(552,363) ;
glColor3ub(35,130,134);
glVertex2f(404 ,449) ;
glColor3ub(35,130,134);
glVertex2f(417,457) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(115,126,112);
glVertex2f(552,363);
glColor3ub(115,126,112);
glVertex2f(571  ,374);
glColor3ub(115,126,112);
glVertex2f(571 ,371);
glColor3ub(115,126,112);
glVertex2f(552, 360) ;
glColor3ub(115,126,112);
glVertex2f(401  ,447) ;
glColor3ub(115,126,112);
glVertex2f(404 ,449) ;
glEnd();

glBegin(GL_POLYGON);
glColor3ub(226,195,177);
glVertex2f(571 ,371);
glColor3ub(226,195,177);
glVertex2f(571  ,374);
glColor3ub(226,195,177);
glVertex2f(617  ,400);
glColor3ub(226,195,177);
glVertex2f(619 , 399) ;
glEnd();



glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
