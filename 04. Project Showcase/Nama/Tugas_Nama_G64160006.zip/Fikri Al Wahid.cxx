#include <GLFW/glfw3.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define phi 3.1415926535897932384626433832795

#include "huruf.h"

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    // float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 0, 800, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Fikri Al Wahid (G64160006)", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
	int M = 0;
	
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
		
		
        setup_viewport(window);

		Tampilan();
        Display();   
        // Back();
        
        
        
        // Huruf F
        F();
        F2();
        F3();
        
        // Huruf I
        I();
        
        // Huruf K
        K();
        K2();
        K3();
        K4();
        
        // Huruf R
		R();
		R2();
		R3();
		R4();
		R5();
		R6();
		R7();
		R8();
		R9();
		R10();
		R11();
		
		// Huruf I
		I2();
		
		// Bayangan F
		Fshadow();
		Fshadow1();
		Fshadow2();
		
		// Bayangan I
		Ishadow();
		
		// Bayangan K
		Kshadow();
		Kshadow2();
		Kshadow3();
		Kshadow4();
		
		// Bayangan R
		Rshadow();
		Rshadow2();
		Rshadow3();
		Rshadow4();
		Rshadow5();
		Rshadow6();
		Rshadow7();
		Rshadow8();
		Rshadow9();
		Rshadow10();
		Rshadow11();
		
		// Bayangan I
		Ishadow2();
		
		// Awan
		glPushMatrix();
		{Awan1(M%800);}
		glPopMatrix();
		
		glPushMatrix();
		{Awan2(M%800);}
		glPopMatrix();
		
		glPushMatrix();
		{Awan3(M%800);}
		glPopMatrix();
		
		M++;
		
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
