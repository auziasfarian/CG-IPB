#include <GLFW/glfw3.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define phi 3.1415926535897932384626433832795

void Tampilan()
{
	glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void Display()
{
    // your drawing code here, maybe
    glPushMatrix();
    glBegin(GL_POLYGON);
	glColor3f(0.3f,0.7f,0.7f);
	glVertex2d(0,0);
	glVertex2d(800,0);
	glVertex2d(800,800);
	glVertex2d(0,800);
	Tampilan();
	glEnd();
	glPopMatrix();
}
/*
void Awan()
{
	glBegin(GL_POLYGON);
	glColor3ub(1,1,1);
		for (int i=0; i <= 360; i++)
   {
		float rad = i*3.14159/180;
		glVertex2f(141.42+cos(rad)*20,501.05+sin(rad)*20);
   }
   glEnd();
}
*/

// Background
void Back(){

	glBegin(GL_POLYGON);
	glColor3ub(100,142,20);
	glVertex2d(0,0);
	glVertex2d(800,0);
	glVertex2d(800,800);
	glVertex2d(0,800);
	glEnd();
}

// Huruf F
void F() 
{
    glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
    glVertex2d(247,348);
    glVertex2d(247,456);
    glVertex2d(259,456);
    glVertex2d(259,348);
    glEnd();
}

void F2()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(247,456);
	glVertex2d(298,456);
    glVertex2d(298,444);
    glVertex2d(259,444);
    glEnd();
}

void F3() 
{
    glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
    glVertex2d(259,412);
    glVertex2d(294,412);
    glVertex2d(294,400);
    glVertex2d(259,400);
    glEnd();

}

// Huruf I
void I()
{
	glBegin(GL_POLYGON);		
	glColor3ub(77,77,77);
	glVertex2d(317,456);
	glVertex2d(329,456);
	glVertex2d(329,348);
	glVertex2d(317,348);
	glEnd();	
}

// Huruf K
void K()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(352,456);
	glVertex2d(364,456);
	glVertex2d(364,348);
	glVertex2d(352,348);			
	glEnd();	
}

void K2()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(364,410);
	glVertex2d(404,456);
	glVertex2d(419,456);
	glVertex2d(375,406);
	glEnd();	
}

void K3()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(375,406);
	glVertex2d(422,348);
	glVertex2d(407,348);
	glVertex2d(364,400);
	glEnd();
}

void K4()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(364,410);
	glVertex2d(375,406);
	glVertex2d(364,400);
	glEnd();
}

// Huruf R
void R()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(432,456);
	glVertex2d(444,456);
	glVertex2d(444,348);
	glVertex2d(432,348);
	glEnd();
}

void R2()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(432,456);
	glVertex2d(459,456);
	glVertex2d(459,444);
	glVertex2d(444,444);
	glEnd();
}	

void R3()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(444,406);
	glVertex2d(459,406);
	glVertex2d(457,394);
	glVertex2d(444,394);
	glEnd();
}	

void R4()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(459,406);
	glVertex2d(473,399);
	glVertex2d(468,390);
	glVertex2d(457,394);
	glEnd();
}	

void R5()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(473,399);
	glVertex2d(481,392);
	glVertex2d(468,390);
	glEnd();
}

void R6()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(481,392);
	glVertex2d(488,378);
	glVertex2d(476,376);
	glVertex2d(468,390);
	glEnd();
}

void R7()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(488,378);
	glVertex2d(500,348);
	glVertex2d(487,348);
	glVertex2d(476,376);
	glEnd();
}


void R8()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(472,411);
	glVertex2d(485,408);
	glVertex2d(473,399);
	glVertex2d(459,406);
	glEnd();
}

void R9()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(476,425);
	glVertex2d(488,425);
	glVertex2d(485,408);
	glVertex2d(472,411);
	glEnd();
}

void R10()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(472,439);
	glVertex2d(481,448);
	glVertex2d(488,425);
	glVertex2d(476,425);
	glEnd();
}

void R11()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(459,456);
	glVertex2d(481,448);
	glVertex2d(472,439);
	glVertex2d(459,444);
	glEnd();
}

// Huruf I
void I2()
{
	glBegin(GL_POLYGON);
	glColor3ub(77,77,77);
	glVertex2d(516,456);
	glVertex2d(528,456);
	glVertex2d(528,348);
	glVertex2d(516,348);
	glEnd();
}

// Bayangan Huruf F
void Fshadow()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(242,456);
	glVertex2d(254,456);
	glVertex2d(254,349);
	glVertex2d(242,349);
	glEnd();
}

void Fshadow1()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(242,456);
	glVertex2d(292,456);
	glVertex2d(292,444);
	glVertex2d(254,444);
	glEnd();
}

void Fshadow2()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(254,412);
	glVertex2d(288,412);
	glVertex2d(288,400);
	glVertex2d(254,400);
	glEnd();
}

// Bayangan Huruf I
void Ishadow()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(311,456);
	glVertex2d(323,456);
	glVertex2d(323,348);
	glVertex2d(311,348);
	glEnd();
}

// Bayangan Huruf K
void Kshadow()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(346,456);
	glVertex2d(358,456);
	glVertex2d(358,349);
	glVertex2d(346,349);
	glEnd();
}

void Kshadow2()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(358,411);
	glVertex2d(369,406);
	glVertex2d(358,400);
	glEnd();
}

void Kshadow3()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(358,411);
	glVertex2d(397,456);
	glVertex2d(413,456);
	glVertex2d(369,406);
	glEnd();
}

void Kshadow4()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(369,406);
	glVertex2d(416,349);
	glVertex2d(400,349);
	glVertex2d(358,400);
	glEnd();
}

// Bayangan Huruf R
void Rshadow()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(427,457);
	glVertex2d(439,457);
	glVertex2d(439,348);
	glVertex2d(427,348);
	glEnd();
}

void Rshadow2()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(427,457);
	glVertex2d(454,457);
	glVertex2d(454.009,445.329);
	glVertex2d(439.030,445.329);
	glEnd();
}	

void Rshadow3()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(439,407);
	glVertex2d(454,407);
	glVertex2d(452.004,395.315);
	glVertex2d(439.030,395.315);
	glEnd();
}	

void Rshadow4()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(454,407);
	glVertex2d(468.870,400.273);
	glVertex2d(463.149,391.794);
	glVertex2d(452.004,395.315);
	glEnd();
}	

void Rshadow5()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(454,407);
	glVertex2d(466,412);
	glVertex2d(480.074,409.543);
	glVertex2d(468.870,400.273);
	glEnd();
}

void Rshadow6()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(468.870,400.273);
	glVertex2d(476.300,393.518);
	glVertex2d(463.149,391.794);
	glEnd();
}

void Rshadow7()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(463.149,391.794);
	glVertex2d(476.300,393.518);
	glVertex2d(483.613,379.290);
	glVertex2d(471.641,377.494);
	glEnd();
}


void Rshadow8()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(471.641,377.494);
	glVertex2d(483.613,379.290);
	glVertex2d(495.702,348);
	glVertex2d(482.905,348);
	glEnd();
}

void Rshadow9()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(471,426);
	glVertex2d(483.966,426.358);
	glVertex2d(480,409);
	glVertex2d(466,412);
	glEnd();
}

void Rshadow10()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(466,440);
	glVertex2d(476,449);
	glVertex2d(483,426);
	glVertex2d(471,426);
	glEnd();
}

void Rshadow11()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(454,457);
	glVertex2d(476,449);
	glVertex2d(466,440);
	glVertex2d(454.009,445.329);
	glEnd();
}

// Bayangan Huruf I
void Ishadow2()
{
	glBegin(GL_POLYGON);
	glColor3ub(255,255,0);
	glVertex2d(511,456);
	glVertex2d(523,456);
	glVertex2d(523,348);
	glVertex2d(511,348);
	glEnd();
}

void circle(float size1, float size2)
{
    int N = 180;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(int i = 0; i <= 360; i++)
    {
        pX = cos(i*phi / N)*20;
        pY = sin(i*phi / N)*20;
        glVertex2f(pX + size1, pY + size2);
    }
    Tampilan();
    glEnd();
}

// Awan 
void Awan1(int M)
{
	// glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glTranslatef(M, 0.f, 0.f);
	glColor3ub(255,255,255);
	circle(-79.97, 530.86);
	circle(-94.76, 528.04);
	circle(-111.65, 523.82);
	circle(-100.39, 509.74);
	circle(-79.97, 513.26);
	circle(-67.30, 521.71);
}

void Awan2(int M)
{
	// glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glTranslatef(M, 0.f, 0.f);
	glColor3ub(255,255,255);
	circle(-49.97, 630.86);
	circle(-64.76, 628.04);
	circle(-81.65, 623.82);
	circle(-70.39, 609.74);
	circle(-49.97, 613.26);
	circle(-37.30, 621.71);
}

void Awan3(int M)
{
	// glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
	glTranslatef(M, 0.f, 0.f);
	glColor3ub(255,255,255);
	circle(29.97, 590.86);
	circle(44.76, 608.04);
	circle(61.65, 599.82);
	circle(50.39, 589.74);
	circle(29.97, 593.26);
	circle(17.30, 591.71);
}
