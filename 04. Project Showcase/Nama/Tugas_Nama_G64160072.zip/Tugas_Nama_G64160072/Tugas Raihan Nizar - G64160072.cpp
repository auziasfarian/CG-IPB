#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-320, 320, -100, 100, 0, 0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    //float r_pink = 0.960784, g_pink = 0.596078, b_pink = 0.615686;
    float r[3] = {0.960784, 0.74902, 1};
    float g[3] = {0.74902, 0.74902, 1};
    float b[3] = {0.615686, 0.74902, 1};
    //float r_grey = 0.74902, g_grey = 0.74902, b_grey = 0.74902;
    //float r_white = 1, g_white = 1, b_white = 1;
    for(int i=0; i<100 ;i++){
        // your drawing code here, maybe
        //glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
        glClearColor(0.305882, 0.345098, 0.737255, 0);

        glBegin(GL_POLYGON);//R left
        glColor3f(r[i+1], g[i+1], b[i+1]);
        glVertex2f(-0.89375, 0.43); glVertex2f(-0.809375, 0.43); glVertex2f(-0.809375, -0.39); glVertex2f(-0.89375, -0.39);
        glEnd();

        glBegin(GL_POLYGON);//R head
        glColor3f(1, 1, 1);
        glVertex2f(-0.84375, 0.43); glVertex2f(-0.646875, 0.43); glVertex2f(-0.646875, -0.08); glVertex2f(-0.84375, -0.08);
        glEnd();

        glBegin(GL_POLYGON);//R leg
        glColor3f(0.960784, 0.596078, 0.615686);
        glVertex2f(-0.78125, 0.13); glVertex2f(-0.84375, -0.08); glVertex2f(-0.696875, -0.54); glVertex2f(-0.634375, -0.34);
        glEnd();

        glBegin(GL_POLYGON);//A first
        glColor3f(r[i+1], g[i+1], b[i+1]);
        glVertex2f(-0.5875, -0.38); glVertex2f(-0.29375, -0.38); glVertex2f(-0.440625, 0.44);
        glEnd();

        glBegin(GL_POLYGON);//I
        glColor3f(1, 1, 1);
        glVertex2f(-0.23125, 0.43); glVertex2f(-0.23125, -0.38); glVertex2f(-0.128125, -0.38); glVertex2f(-0.128125, 0.43);
        glEnd();

        glBegin(GL_POLYGON);//H left
        glColor3f(0.960784, 0.596078, 0.615686);
        glVertex2f(-0.065625, 0.43); glVertex2f(-0.065625, -0.38); glVertex2f(0.0375, -0.38); glVertex2f(0.0375, 0.43);
        glEnd();

        glBegin(GL_POLYGON);//H center
        glColor3f(r[i+1], g[i+1], b[i+1]);
        glVertex2f(-0.015625, 0.11); glVertex2f(-0.015625, -0.07); glVertex2f(0.11875, -0.07); glVertex2f(0.11875, 0.11);
        glEnd();

        glBegin(GL_POLYGON);//H right
        glColor3f(1, 1, 1);
        glVertex2f(0.115625, 0.43); glVertex2f(0.21875, 0.43); glVertex2f(0.21875, -0.38); glVertex2f(0.115625, -0.38);
        glEnd();

        glBegin(GL_POLYGON);//A second
        glColor3f(0.960784, 0.596078, 0.615686);
        glVertex2f(0.278125, -0.38); glVertex2f(0.575, -0.38); glVertex2f(0.428125, 0.44);
        glEnd();

        glBegin(GL_POLYGON);//N leg
        glColor3f(r[i+1], g[i+1], b[i+1]);
        glVertex2f(0.875, -0.38); glVertex2f(0.875, 0.43); glVertex2f(0.76875, 0.43); glVertex2f(0.76875, -0.38);
        glEnd();

        glBegin(GL_POLYGON);//N triangle
        glColor3f(1, 1, 1);
        glVertex2f(0.634375, 0.44); glVertex2f(0.634375, -0.38); glVertex2f(0.875, -0.38);
        glEnd();
    }
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1280, 400, "Hello Triangle", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
