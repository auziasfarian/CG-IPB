#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h>
#define xmin 0
#define xmax 10
#define ymin 10
#define ymax 0

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}
void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width * 10 / (float) height;
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(xmin, xmax, ymin, ymax, 1, -1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void circle(float size)
{
    int i, N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}
//Huruf A
void A ()
{
    glBegin(GL_POLYGON);
        glVertex2f(3.45,2.3);
        glVertex2f(4.2,2.3);
        glVertex2f(3.4,4.2);
        glVertex2f(3.04,4.2);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(4.2,2.3);
        glVertex2f(3.66,3.36);
        glVertex2f(3.95,4.2);
        glVertex2f(4.63,4.2);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(3.85,3.8);
        glVertex2f(3.9,4.04);
        glVertex2f(3.6,4.24);
        glVertex2f(3.46,3.96);
        glVertex2f(3.5,3.85);
    glEnd();
}
//Huruf L
void L ()
{
    glBegin(GL_POLYGON);
        glVertex2f(4.67,2.3);
        glVertex2f(5.53,2.3);
        glVertex2f(5.45,3.9);
        glVertex2f(4.76,4.2);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(5.45,3.9);
        glVertex2f(4.76,4.2);
        glVertex2f(5.88,4.2);
        glVertex2f(5.95,3.84);
    glEnd();
}
//Huruf I atas
void I ()
{
    glBegin(GL_POLYGON);
        glVertex2f(6,2.3);
        glVertex2f(6.9,2.3);
        glVertex2f(6.8,4.2);
        glVertex2f(6.1,4.2);
    glEnd();
}
//Huruf I bawah
void II ()
{
    glBegin(GL_POLYGON);
        glVertex2f(0.97,5.37);
        glVertex2f(1.8,5.37);
        glVertex2f(1.74,7.25);
        glVertex2f(1.05,7.25);
    glEnd();
}
//Huruf M
void M ()
{
    glBegin(GL_POLYGON);
        glVertex2f(1.94,5.37);
        glVertex2f(2.63,5.37);
        glVertex2f(2.46,7.25);
        glVertex2f(2.02,7.25);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(2.63,5.37);
        glVertex2f(2.95,6);
        glVertex2f(2.95,7.29);
        glVertex2f(2.49,6.68);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(2.95,6);
        glVertex2f(2.95,7.29);
        glVertex2f(3.38,6.68);
        glVertex2f(3.28,5.37);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(3.28,5.37);
        glVertex2f(3.92,5.37);
        glVertex2f(3.84,7.25);
        glVertex2f(3.4,7.25);
    glEnd();
}
//Huruf R
void R()
{
    glBegin(GL_POLYGON);
        glVertex2f(4.12,7.25);
        glVertex2f(4.8,7.25);
        glVertex2f(4.83,5.37);
        glVertex2f(4.03,5.37);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(4.6,6.5);
        glVertex2f(5.1,6.3);
        glVertex2f(5.5,7);
        glVertex2f(5,7.4);
    glEnd();
}
//Huruf N
void N ()
{
    glBegin(GL_POLYGON);
        glVertex2f(7.35,5.37);
        glVertex2f(7.98,5.37);
        glVertex2f(7.85,7.29);
        glVertex2f(7.46,7.29);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(7.97,5.37);
        glVertex2f(8.44,5.84);
        glVertex2f(8.78,7.29);
        glVertex2f(7.87,6.64);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(8.78,7.29);
        glVertex2f(8.44,5.84);
        glVertex2f(8.41,5.37);
        glVertex2f(8.87,5.37);
    glEnd();
}
int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(750 , 800, "Ali Imron - G64150016", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    PlaySound(TEXT("sound.wav"), NULL, SND_FILENAME|SND_LOOP|SND_ASYNC);
    float r = 0;
	float g = 0;
	float b = 0;
    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        //Bintang
        glPointSize(70.f);
        GLfloat posX, posY;
        glColor3f(g,b,r);
        glBegin(GL_POINTS);
        for (posX=0.5f;posX<=10.0f;posX+=0.5f) {
            for (posY=-0.5f;posY<=10.0f;posY+=0.1f){
        glVertex2f(rand()%50,rand()%50);
            }
        }
        glEnd();
        //Ganti Warna
        r = fmod(r + 0.00001, 1);
        g = fmod(g + 0.0004, 0.8);
        b = fmod(b + 0.00008, 0.6);
        glColor3f(r,g,b);
        A();
        L();
        I();
        II();
        M ();
        R();
        N();
        //Huruf R
        glTranslatef(4.88,6,0);
        circle(0.64);

        //Huruf O
        glTranslatef(1.55,0.3,0);
        circle(0.9);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
