#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define clchange color,color,color

int clindex=0,buff=0;
int colorf[3][3]={{255,255,0},{255,255,100},{255,255,179}};
int colory[3][3]={{0,153,0},{51,204,51},{0,255,0}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void background(){
   glBegin(GL_POLYGON);
   glColor3ub(100,255,255);
   glVertex2d(0,0); //kiri atas
   glVertex2d(0,300); //kiri bawah
   glVertex2d(800,0);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(150,255,255);
   glVertex2d(0,300); //kiri bawah
   glVertex2d(800,300);  //kanan bawah
   glVertex2d(800,0);  //kanan atas
   glEnd();

}

void R()
{
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(80,87); //kiri atas
   glVertex2d(80,289); //kiri bawah
   glVertex2d(95,270);  //kanan bawah
   glVertex2d(95,72);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(95,72);
   glVertex2d(130,70);
   glVertex2d(180,87);
   glVertex2d(170,97);
   glVertex2d(150,80);
   glVertex2d(80,87);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(180,87);
   glVertex2d(200,115);
   glVertex2d(190,125);
   glVertex2d(170,97);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(200,115);
   glVertex2d(200,140);
   glVertex2d(190,150);
   glVertex2d(190,125);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(200,140);
   glVertex2d(180,168);
   glVertex2d(170,178);
   glVertex2d(190,150);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(80,168);  //kanan atas
   glVertex2d(95,158); //kiri atas
   glVertex2d(185,270);  //kanan bawah
   glVertex2d(170,289);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(95,153); //kiri atas
   glVertex2d(125,170); //tengah atas
   glVertex2d(115,185); //kiri atas
   glVertex2d(80,168);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(125,170); //tengah atas
   glVertex2d(180,168);
   glVertex2d(170,178);
   glVertex2d(115,185);
   glEnd();
}

void H(){
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(210,87); //kiri atas
   glVertex2d(210,289); //kiri bawah
   glVertex2d(225,270);  //kanan bawah
   glVertex2d(225,72);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(225,171);  //kanan atas
   glVertex2d(295,171);  //kanan atas
   glVertex2d(280,188); //kiri atas
   glVertex2d(210,188); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(280,87); //kiri atas
   glVertex2d(280,289); //kiri bawah
   glVertex2d(295,270);  //kanan bawah
   glVertex2d(295,72);  //kanan atas
   glEnd();


}

void E(){
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(320,87); //kiri atas
   glVertex2d(320,289); //kiri bawah
   glVertex2d(335,270);  //kanan bawah
   glVertex2d(335,72);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(335,72);  //kanan atas
   glVertex2d(405,72);  //kanan atas
   glVertex2d(390,87); //kiri atas
   glVertex2d(320,87); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(335,171);  //kanan atas
   glVertex2d(405,171);  //kanan atas
   glVertex2d(390,188); //kiri atas
   glVertex2d(320,188); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(335,270);  //kanan atas
   glVertex2d(405,270);  //kanan atas
   glVertex2d(390,289); //kiri atas
   glVertex2d(320,289); //kiri atas
   glEnd();

}

void I(){
   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(430,270);
   glVertex2d(480,270);
   glVertex2d(465,289);
   glVertex2d(415,289);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(440,87); //kiri atas
   glVertex2d(440,289); //kiri bawah
   glVertex2d(455,270);  //kanan bawah
   glVertex2d(455,72);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(430,72);
   glVertex2d(480,72);
   glVertex2d(465,87);
   glVertex2d(415,87);
   glEnd();


}

void S(){

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(520,100);
   glVertex2d(510,125);
   glVertex2d(495,135);
   glVertex2d(510,110);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(510,125);
   glVertex2d(530,160);
   glVertex2d(515,170);
   glVertex2d(495,135);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(525,95);
   glVertex2d(560,73);
   glVertex2d(610,87);
   glVertex2d(600,97);
   glVertex2d(570,90);
   glVertex2d(510,110);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(610,87);
   glVertex2d(630,115);
   glVertex2d(620,125);
   glVertex2d(600,97);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(630,115);
   glVertex2d(630,140);
   glVertex2d(620,150);
   glVertex2d(620,125);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(530,160); //kiri atas
   glVertex2d(545,170); //tengah atas
   glVertex2d(535,185); //kiri atas
   glVertex2d(515,170);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(545,170); //tengah atas
   glVertex2d(610,180);
   glVertex2d(600,195);
   glVertex2d(535,185);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(610,180);
   glVertex2d(630,208);
   glVertex2d(620,218);
   glVertex2d(600,195);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(630,208);
   glVertex2d(630,243);
   glVertex2d(620,253);
   glVertex2d(620,218);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(630,208);
   glVertex2d(630,238);
   glVertex2d(620,248);
   glVertex2d(620,218);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(630,243);
   glVertex2d(610,271);
   glVertex2d(600,285);
   glVertex2d(620,253);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(525,256); //kiri atas
   glVertex2d(555,273); //tengah atas
   glVertex2d(545,288); //kiri atas
   glVertex2d(510,271);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(555,273); //tengah atas
   glVertex2d(610,271);
   glVertex2d(600,285);
   glVertex2d(545,288);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(510,225);
   glVertex2d(525,256);
   glVertex2d(510,271);
   glVertex2d(495,240);
   glEnd();


}

void A()
{


   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(680,171); //kiri
   glVertex2d(710,72);  //kanan atas
   glVertex2d(695,87);
   glVertex2d(665,188);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(680,171); //kiri atas
    glVertex2d(655,270);  //kanan bawah
   glVertex2d(640,289); //kiri bawah
   glVertex2d(665,188);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(680,171);  //kanan atas
   glVertex2d(750,171);  //kanan atas
   glVertex2d(735,188); //kiri atas
   glVertex2d(665,188); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(750,171);  //kanan atas
   glVertex2d(710,72);  //kanan atas
   glVertex2d(695,87);
   glVertex2d(735,188); //kiri
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(750,171); //kiri atas
   glVertex2d(775,270);  //kanan bawah
   glVertex2d(760,289); //kiri bawah
   glVertex2d(735,188);  //kanan atas
   glEnd();

}

void E2(){
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(210,387); //kiri atas
   glVertex2d(210,589); //kiri bawah
   glVertex2d(225,570);  //kanan bawah
   glVertex2d(225,372);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(225,372);  //kanan atas
   glVertex2d(295,372);  //kanan atas
   glVertex2d(280,387); //kiri atas
   glVertex2d(210,387); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(225,471);  //kanan atas
   glVertex2d(295,471);  //kanan atas
   glVertex2d(280,488); //kiri atas
   glVertex2d(210,488); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(225,570);  //kanan atas
   glVertex2d(295,570);  //kanan atas
   glVertex2d(280,589); //kiri atas
   glVertex2d(210,589); //kiri atas
   glEnd();

}

void C2()
{
      //tengah
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(335,395);
   glVertex2d(325,488);
   glVertex2d(305,488);
   glVertex2d(320,410);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(325,488);
   glVertex2d(330,525);
   glVertex2d(315,540);
   glVertex2d(305,488);
   glEnd();

    //atas
   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(335,395);
   glVertex2d(370,373);
   glVertex2d(420,387);
   glVertex2d(410,397);
   glVertex2d(380,390);
   glVertex2d(320,410);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(420,387);
   glVertex2d(440,415);
   glVertex2d(430,425);
   glVertex2d(410,397);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(440,415);
   glVertex2d(440,440);
   glVertex2d(430,450);
   glVertex2d(430,425);
   glEnd();

    //bawah
   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(450,543);
   glVertex2d(430,571);
   glVertex2d(420,585);
   glVertex2d(440,553);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(345,556); //kiri atas
   glVertex2d(375,573); //tengah atas
   glVertex2d(365,588); //kiri atas
   glVertex2d(330,571);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(375,573); //tengah atas
   glVertex2d(430,571);
   glVertex2d(420,585);
   glVertex2d(365,588);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(330,525);
   glVertex2d(345,556);
   glVertex2d(330,571);
   glVertex2d(315,540);
   glEnd();

}

void H2(){
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(460,387); //kiri atas
   glVertex2d(460,589); //kiri bawah
   glVertex2d(475,570);  //kanan bawah
   glVertex2d(475,372);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(475,471);  //kanan atas
   glVertex2d(545,471);  //kanan atas
   glVertex2d(530,488); //kiri atas
   glVertex2d(460,488); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(530,387); //kiri atas
   glVertex2d(530,589); //kiri bawah
   glVertex2d(545,570);  //kanan bawah
   glVertex2d(545,372);  //kanan atas
   glEnd();


}


void A2()
{
   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(600,471); //kiri
   glVertex2d(630,372);  //kanan atas
   glVertex2d(615,387);
   glVertex2d(585,488);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(14,155,193);
   glVertex2d(600,471); //kiri atas
    glVertex2d(575,570);  //kanan bawah
   glVertex2d(560,589); //kiri bawah
   glVertex2d(585,488);  //kanan atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(32,100,237);
   glVertex2d(600,471);  //kanan atas
   glVertex2d(670,471);  //kanan atas
   glVertex2d(655,488); //kiri atas
   glVertex2d(585,488); //kiri atas
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(670,471);  //kanan atas
   glVertex2d(630,372);  //kanan atas
   glVertex2d(615,387);
   glVertex2d(655,488); //kiri
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(0,0,200);
   glVertex2d(670,471); //kiri atas
   glVertex2d(695,570);  //kanan bawah
   glVertex2d(680,589); //kiri bawah
   glVertex2d(655,488);  //kanan atas
   glEnd();

}


void Bintang1(){
   //glRotatef((float) glfwGetTime() * 20, 80, 200, 0);
   //glTranslatef(1,1,1);
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,345);
   glVertex2d(120,390);
   glVertex2d(100,370);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,345);
   glVertex2d(80,390);
   glVertex2d(100,370);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,370);
   glVertex2d(70,360);
   glVertex2d(130,360);
   glEnd();
}

void Bintang2(){
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(150,415);
   glVertex2d(170,460);
   glVertex2d(150,440);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(150,415);
   glVertex2d(130,460);
   glVertex2d(150,440);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(150,440);
   glVertex2d(120,430);
   glVertex2d(180,430);
   glEnd();

}

void Bintang3(){

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(50,415);
   glVertex2d(70,460);
   glVertex2d(50,440);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(50,415);
   glVertex2d(30,460);
   glVertex2d(50,440);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(50,440);
   glVertex2d(20,430);
   glVertex2d(80,430);
   glEnd();

}

void Bintang4(){
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,495);
   glVertex2d(120,540);
   glVertex2d(100,520);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,495);
   glVertex2d(80,540);
   glVertex2d(100,520);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(100,520);
   glVertex2d(70,510);
   glVertex2d(130,510);
   glEnd();
}

void Bintang5(){
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,495);
   glVertex2d(770,540);
   glVertex2d(750,520);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,495);
   glVertex2d(730,540);
   glVertex2d(750,520);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,520);
   glVertex2d(720,510);
   glVertex2d(780,510);
   glEnd();
}

void Bintang6(){
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,395);
   glVertex2d(770,440);
   glVertex2d(750,420);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,395);
   glVertex2d(730,440);
   glVertex2d(750,420);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(750,420);
   glVertex2d(720,410);
   glVertex2d(780,410);
   glEnd();
}

void Bintang7(){
   glPushMatrix();
   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(700,325);
   glVertex2d(720,370);
   glVertex2d(700,350);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(700,325);
   glVertex2d(680,370);
   glVertex2d(700,350);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
   glVertex2d(700,350);
   glVertex2d(670,340);
   glVertex2d(730,340);
   glEnd();
   glPopMatrix();
}

void list(){

   glBegin(GL_POLYGON);
   glColor3ub(colory[(clindex+2)%3][0],colory[(clindex+2)%3][1],colory[(clindex+2)%3][2]);
   glVertex2d(0,800);
   glVertex2d(0,700);
   glVertex2d(100,600);
   glVertex2d(200,700);
   glVertex2d(300,600);
   glVertex2d(400,700);
   glVertex2d(500,600);
   glVertex2d(600,700);
   glVertex2d(700,600);
   glVertex2d(800,700);
   glVertex2d(800,800);
   glEnd();

}

void grass(){

   glTranslatef((float)glfwGetTime()*-20,0,0);
   glBegin(GL_POLYGON);
   glColor3ub(colory[(clindex+2)%3][0],colory[(clindex+2)%3][1],colory[(clindex+2)%3][2]);
   glVertex2d(0,800);
   glVertex2d(0,700);
   glVertex2d(100,600);
   glVertex2d(200,700);
   glVertex2d(300,600);
   glVertex2d(400,700);
   glVertex2d(500,600);
   glVertex2d(600,700);
   glVertex2d(700,600);
   glVertex2d(800,700);
   glVertex2d(800,800);
   glEnd();

   glTranslatef((float)glfwGetTime()*50,0,0);
   glBegin(GL_POLYGON);
   glColor3ub(colory[(clindex+2)%3][0],colory[(clindex+2)%3][1],colory[(clindex+2)%3][2]);
   glVertex2d(0,800);
   glVertex2d(0,700);
   glVertex2d(100,600);
   glVertex2d(200,700);
   glVertex2d(300,600);
   glVertex2d(400,700);
   glVertex2d(500,600);
   glVertex2d(600,700);
   glVertex2d(700,600);
   glVertex2d(800,700);
   glVertex2d(800,800);
   glEnd();


}

float angle_earth = 0.0, angle_moon = 0.0;
void moon(float size)
{
    int N = 30;
    float pX, pY;
    glTranslatef((float)glfwGetTime()*40,0,0);
    glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();

}


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160035>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();
        background();
        R();
        H();
        E();
        I();
        S();
        A();

        E2();
        C2();
        H2();
        A2();

        Bintang1();
        Bintang2();
        Bintang3();
        Bintang4();
        Bintang5();
        Bintang6();
        Bintang7();
        list();
        grass();
        moon(50);

    glPopMatrix();
    glPopMatrix();
    glPopMatrix();
    glPopMatrix();



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
