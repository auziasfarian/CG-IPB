


//g++ -Wall -o "rendi" "rendi.cxx" -lglfw3 -lGL -lX11 -lXi -lXrandr -lXxf86vm -lXinerama -lXcursor -lrt -lm -pthread

#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

double stop = 0.0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 768, 0, 768, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);

    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();

}
//glColor3ub(20,42,89);
//glColor3ub(50,188,191);
//glColor3ub(254,155,175);
void Be ()
{
    glBegin(GL_POLYGON);
        glColor3ub(5,5,5);
        glVertex2d( 0 , 0 );
        glVertex2d( 0 , 278 );
        glVertex2d( 398 , 488 );
        glVertex2d( 768 , 283 );
        glVertex2d( 768 , 0 );
    glEnd();
}
void Re ()
{
    glBegin(GL_POLYGON);
        glColor3ub(19,19,19);
        glVertex2d( 0 , 278 );
        glVertex2d( 398 , 488 );
        glVertex2d( 398 , 768 );
        glVertex2d( 0 , 768 );
    glEnd();
}
void Le (){

glBegin(GL_POLYGON);
        glColor3ub(13,13,13);
        glVertex2d( 768 , 768 );        
        glVertex2d( 398 , 768 );
        glVertex2d( 398 , 488 );
        glVertex2d( 768 , 283 );
    glEnd();
}

void K ()
{
    glBegin(GL_POLYGON);
        glColor3ub(30,30,30);
        glVertex2d( 0 , 0 );
        glVertex2d( 0 , 768 );
        glVertex2d( 768 , 768 );
        glVertex2d( 768 , 0 );
    glEnd();
}
void R ()
{
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 82 , 320 );
        glVertex2d( 42 , 300 );
        glVertex2d( 42 , 440 );
        glVertex2d( 82 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 82 , 460 );
        glVertex2d( 122 , 440 );
        glVertex2d( 122 , 400 );
        glVertex2d( 42 , 440 );
    glEnd();
}
void E ()
{
    glBegin(GL_POLYGON);
        glColor3ub(9,34,51);
        glVertex2d( 262 , 320 );
        glVertex2d( 222 , 300 );
        glVertex2d( 142 , 348 );
        glVertex2d( 182 , 368 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 182 , 368 );
        glVertex2d( 182 , 420 );
        glVertex2d( 142 , 440 );
        glVertex2d( 142 , 348 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 182 , 420 );
        glVertex2d( 142 , 440 );
        glVertex2d( 222 , 480 );
        glVertex2d( 222 , 440 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 222 , 440 );
        glVertex2d( 222 , 480 );
        glVertex2d( 302 , 440 );
        glVertex2d( 262 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 302 , 440 );
        glVertex2d( 262 , 420 );
        glVertex2d( 262 , 368 );
        glVertex2d( 302 , 392 );
    glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(1,108,106);
		glVertex2d( 222 , 420 );
		glVertex2d( 246 , 408 );
		glVertex2d( 222 , 396 );
		glVertex2d( 198 , 408 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(9,34,51);
		glVertex2d( 246 , 408 );
		glVertex2d( 246 , 376 );
		glVertex2d( 222 , 364 );
		glVertex2d( 222 , 396 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(9,53,74);
		glVertex2d( 222 , 364 );
		glVertex2d( 198 , 376 );
		glVertex2d( 198 , 408 );
		glVertex2d( 222 , 396 );
	glEnd();
}
void N ()
{
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 358 , 320 );
        glVertex2d( 318 , 340 );
        glVertex2d( 318 , 440 );
        glVertex2d( 358 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 318 , 440 );
        glVertex2d( 358 , 420 );
        glVertex2d( 398 , 440 );
        glVertex2d( 398 , 480 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 398 , 440 );
        glVertex2d( 398 , 480 );
        glVertex2d( 478 , 440 );
        glVertex2d( 438 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 478 , 440 );
        glVertex2d( 438 , 420 );
        glVertex2d( 438 , 320 );
        glVertex2d( 478 , 340 );
    glEnd();
}
void D ()
{
    glBegin(GL_POLYGON);
        glColor3ub(9,34,51);
        glVertex2d( 654 , 348 );
        glVertex2d( 574 , 300 );
        glVertex2d( 574 , 348 );
        glVertex2d( 614 , 368 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,34,51);
        glVertex2d( 574 , 300 );
        glVertex2d( 574 , 348 );
        glVertex2d( 534 , 368 );
        glVertex2d( 494 , 348 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 534 , 368 );
        glVertex2d( 494 , 348 );
        glVertex2d( 494 , 440 );
        glVertex2d( 534 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106);
        glVertex2d( 494 , 440 );
        glVertex2d( 534 , 420 );
        glVertex2d( 574 , 440 );
        glVertex2d( 574 , 480 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(1,108,106 );
        glVertex2d( 574 , 440 );
        glVertex2d( 574 , 480 );
        glVertex2d( 614 , 460 );
        glVertex2d( 614 , 420 );
    glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 654 , 348 );
        glVertex2d( 614 , 368 );
        glVertex2d( 614 , 532 );
        glVertex2d( 654 , 508 );
    glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(1,108,106);
		glVertex2d( 574 , 420 );
		glVertex2d( 598 , 408 );
		glVertex2d( 574 , 396 );
		glVertex2d( 550 , 408 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(9,34,51);
		glVertex2d( 598 , 408 );
		glVertex2d( 598 , 376 );
		glVertex2d( 574 , 364 );
		glVertex2d( 574 , 396 );
	glEnd();
	glBegin(GL_POLYGON);
		glColor3ub(9,53,74);
		glVertex2d( 574 , 364 );
		glVertex2d( 550 , 376 );
		glVertex2d( 550 , 408 );
		glVertex2d( 574 , 396 );
	glEnd();
}
void I ()
{
    glBegin(GL_POLYGON);
        glColor3ub(9,53,74);
        glVertex2d( 678 , 498 );
        glVertex2d( 718 , 470 );
        glVertex2d( 718 , 310 );
        glVertex2d( 678 , 333 );
    glEnd();
}



int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(768, 768, "s", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {	
    	stop = glfwGetTime();
        setup_viewport(window);

        display();
        K();
        if((float)glfwGetTime()>1.00)Be();
        if((float)glfwGetTime()>2.00)Le();
        if((float)glfwGetTime()>3.00)Re();
        if((float)glfwGetTime()>4.00){
        	glPushMatrix();
        	//glScalef((float)glfwGetTime()*0.1,(float)glfwGetTime()*0.1,0);
        	glTranslated(384,384,0);
        	if (stop <= 10) glScalef(stop*0.1,stop*0.1,0);
        	//glRotated((float)glfwGetTime()*10-10,0,0,0);
        	glTranslated(-384,-384,0);
	        R();
	        E();
	        N();
	        D();
	        I();
	        glPopMatrix();
	    }
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
