#include <GLFW/glfw3.h>
#include <bits/stdc++.h>
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_WIDTH 960
#define SCREEN_HEIGHT 560

using namespace std;

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); //Close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting view ports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);

    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, SCREEN_WIDTH, SCREEN_HEIGHT, 0, 1.f, -1.f); // left, right, bottom, top, front, back

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void background()
{
    glBegin(GL_POLYGON);
    glColor3ub(249,243,162);
    glVertex2d(0,0);
    glVertex2d(0,560);
    glVertex2d(960,560);
    glVertex2d(960,0);
    glEnd();
}

void nama()
{
    //Huruf P
    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(102.4,410.8);
    glVertex2d(162.8,445.7);
    glVertex2d(162.8,410.8);
    glVertex2d(193,393.4);
    glVertex2d(193,358.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(162.8,445.7);
    glVertex2d(193,463.1);
    glVertex2d(193,428.3);
    glVertex2d(162.8,410.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(223.2,410.8);
    glVertex2d(193,393.4);
    glVertex2d(193,358.5);
    glVertex2d(283.6,410.8);
    glVertex2d(223.2,445.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(223.2,410.8);
    glVertex2d(223.2,480.6);
    glVertex2d(193,463.1);
    glVertex2d(193,428.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(253.4,498);
    glVertex2d(283.6,480.6);
    glVertex2d(223.2,445.7);
    glVertex2d(223.2,480.6);
    glEnd();

    //Huruf R
    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(223.2,341);
    glVertex2d(283.6,375.9);
    glVertex2d(283.6,341);
    glVertex2d(313.8,323.6);
    glVertex2d(313.8,288.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(283.6,375.9);
    glVertex2d(313.8,393.4);
    glVertex2d(313.8,358.5);
    glVertex2d(283.6,341.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(313.8,393.4);
    glVertex2d(344.1,410.8);
    glVertex2d(344.1,341);
    glVertex2d(313.8,358.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(313.8,323.6);
    glVertex2d(313.8,288.7);
    glVertex2d(374.3,323.6);
    glVertex2d(344.1,341);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(374.3,323.6);
    glVertex2d(374.3,358.5);
    glVertex2d(344.1,375.9);
    glVertex2d(344.1,341);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(344.1,410.8);
    glVertex2d(374.3,428.3);
    glVertex2d(404.5,410.8);
    glVertex2d(344.1,375.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(374.3,358.5);
    glVertex2d(404.5,341.1);
    glVertex2d(404.5,375.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(404.5,375.9);
    glVertex2d(404.5,341.1);
    glVertex2d(464.9,375.9);
    glVertex2d(434.7,393.4);
    glEnd();

    //Huruf A yang pertama
    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(344,271.3);
    glVertex2d(404.5,306.2);
    glVertex2d(404.5,271.3);
    glVertex2d(434.7,253.8);
    glVertex2d(434.7,218.9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(404.5,306.2);
    glVertex2d(404.5,271.3);
    glVertex2d(434.7,288.7);
    glVertex2d(434.7,323.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(434.7,323.6);
    glVertex2d(434.7,288.7);
    glVertex2d(464.9,271.3);
    glVertex2d(464.9,341.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(434.7,218.9);
    glVertex2d(434.7,253.8);
    glVertex2d(555.5,323.6);
    glVertex2d(585.7,306.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(464.9,306.2);
    glVertex2d(464.9,271.3);
    glVertex2d(495.1,288.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(464.9,341.1);
    glVertex2d(464.9,306.2);
    glVertex2d(525.3,341);
    glVertex2d(495.1,358.5);
    glEnd();

    //Huruf N
    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(464.9,201.5);
    glVertex2d(495.1,218.9);
    glVertex2d(495.1,184.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(495.1,218.9);
    glVertex2d(495.1,184.1);
    glVertex2d(525.3,201.5);
    glVertex2d(525.3,236.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(525.3,236.4);
    glVertex2d(525.3,201.5);
    glVertex2d(555.5,184.1);
    glVertex2d(555.5,253.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(555.5,184.1);
    glVertex2d(555.5,218.9);
    glVertex2d(585.7,201.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(555.5,218.9);
    glVertex2d(555.5,253.8);
    glVertex2d(615.9,288.7);
    glVertex2d(646.2,271.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(585.7,201.5);
    glVertex2d(615.9,218.9);
    glVertex2d(615.9,184.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(555.5,149.2);
    glVertex2d(585.7,166.6);
    glVertex2d(585.7,131.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(585.7,166.6);
    glVertex2d(585.7,131.7);
    glVertex2d(736.8,218.9);
    glVertex2d(706.6,236.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(615.9,218.9);
    glVertex2d(615.9,184.1);
    glVertex2d(646.2,201.5);
    glEnd();

    //Huruf A yang kedua
    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(615.9,114.3);
    glVertex2d(676.4,149.2);
    glVertex2d(676.4,114.3);
    glVertex2d(706.6,96.9);
    glVertex2d(706.6,62);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(676.4,149.2);
    glVertex2d(676.4,114.3);
    glVertex2d(706.6,131.7);
    glVertex2d(706.6,166.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(26,188,156);
    glVertex2d(706.6,166.6);
    glVertex2d(706.6,131.7);
    glVertex2d(736.8,114.3);
    glVertex2d(736.8,184.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(706.6,96.9);
    glVertex2d(706.6,62);
    glVertex2d(857.6,149.2);
    glVertex2d(827.4,166.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(736.8,149.2);
    glVertex2d(736.8,114.3);
    glVertex2d(767,131.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(52,73,94);
    glVertex2d(736.8,184.1);
    glVertex2d(736.8,149.2);
    glVertex2d(797.2,184.1);
    glVertex2d(767,201.5);
    glEnd();
}


int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);

    // initialize the GLFW
    if (!glfwInit())
        exit(EXIT_FAILURE);

    // create a windowed mode and its OpenGL context
    window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Nama saya adalah ...", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    // make the window's context current
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    // loop until the user closes window
    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        background();
        nama();

        // swap front and back buffers
        glfwSwapBuffers(window);

        // poll for and process any events
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
