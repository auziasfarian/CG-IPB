#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClearColor(1,1,1,1);
}

void display()
{


}

void krismanti(){

//m

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2f(86.19,268);
glVertex2f(119.71,268);
glVertex2f(97.06,532);
glVertex2f(72,532);

glEnd();
glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2f(76.19,268);
glVertex2f(109.71,268);
glVertex2f(87.06,532);
glVertex2f(62,532);

glEnd();

//

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(107.03,302.08);
glVertex2d(119.71,268);
glVertex2d(174.98,489);
glVertex2d(163.5,530.43);


glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(97.03,302.08);
glVertex2d(109.71,268);
glVertex2d(164.98,489);
glVertex2d(153.5,530.43);

glEnd();


glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(233.69,268);
glVertex2d(267.21,267.85);
glVertex2d(183.43,530.43);
glVertex2d(163.5,530.43);


glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(223.69,268);
glVertex2d(257.21,267.85);
glVertex2d(173.43,530.43);
glVertex2d(153.5,530.43);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);


glVertex2d(245.94,302.08);
glVertex2d(267.08,268);
glVertex2d(279.77,532);
glVertex2d(254.1,532);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(235.94,302.08);
glVertex2d(257.08,268);
glVertex2d(269.77,532);
glVertex2d(244.1,532);

glEnd();



//A

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(371.1,267.95);
glVertex2d(402.8,267.98);
glVertex2d(328.86,531.91);
glVertex2d(301.68,531.88);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(361.1,267.95);
glVertex2d(392.8,267.98);
glVertex2d(318.86,531.91);
glVertex2d(291.68,531.88);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(385.86,298.12);
glVertex2d(402.8,267.98);
glVertex2d(472,532.05);
glVertex2d(443.91,532.05);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(375.86,298.12);
glVertex2d(392.8,267.98);
glVertex2d(462,532.05);
glVertex2d(433.91,532.05);

glEnd();



glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);
glVertex2d(345.54,422.26);
glVertex2d(406.84,422.32);
glVertex2d(414.25,448.96);
glVertex2d(342.08,448.96);

glEnd();


//y
glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(459.28,268.04);
glVertex2d(489.17,268.07);
glVertex2d(550.02,419.71);
glVertex2d(523.45,420.08);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);
glVertex2d(449.28,268.04);
glVertex2d(479.17,268.07);
glVertex2d(540.02,419.71);
glVertex2d(513.45,420.08);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(588.53,268.17);
glVertex2d(618.42,268.2);
glVertex2d(550.02,419.71);
glVertex2d(537.97,395.42);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(578.53,268.17);
glVertex2d(608.42,268.2);
glVertex2d(540.02,419.71);
glVertex2d(527.97,395.42);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(523.45,420.08);
glVertex2d(550.02,419.71);
glVertex2d(549.91,532.13);
glVertex2d(523.34,532.1);

glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(513.45,420.08);
glVertex2d(540.02,419.71);
glVertex2d(539.91,532.13);
glVertex2d(513.34,532.1);

glEnd();

//A
glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(670.97,268.25);
glVertex2d(702.68,268.28);
glVertex2d(628.73,532.21);
glVertex2d(601.55,532.18);


glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(660.97,268.25);
glVertex2d(692.68,268.28);
glVertex2d(618.73,532.21);
glVertex2d(591.55,532.18);

glEnd();


glBegin(GL_POLYGON);
glColor3ub(36, 31, 40);

glVertex2d(686.34,298.42);
glVertex2d(702.68,268.28);
glVertex2d(771.87,532.35);
glVertex2d(743.78,532.32);


glEnd();

glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(676.34,298.42);
glVertex2d(692.68,268.28);
glVertex2d(761.87,532.35);
glVertex2d(733.78,532.32);

glEnd();



glBegin(GL_POLYGON);
glColor3ub(213, 159, 255);

glVertex2d(645.41,422.56);
glVertex2d(706.71,422.62);
glVertex2d(714.12,449.26);
glVertex2d(639.95,449.19);

glEnd();
}
//gambar


void gambar1(){
glBegin(GL_POLYGON);
 glColor3ub(245,255,159);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
      glVertex2f(400+cos(rad)*450,423+sin(rad)*400);
   }
   glEnd();
}
void gambar2(){

 glBegin(GL_POLYGON);
 srand(time(NULL));
 int a=rand()%255,b=rand()%255,c=rand()%255;
 glColor3ub(a,b,c);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
      glVertex2f(400+cos(rad)*400,423+sin(rad)*400);
   }
   glEnd();
}
void gambar3(){
glBegin(GL_POLYGON);
 glColor3ub(245,255,159);
   for (int i=0; i <= 360; i++)
   {

      float rad = i*3.14159/180;
      glVertex2f(400+cos(rad)*350,423+sin(rad)*400);
   }
   glEnd();
}


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Maya Maharani-<G64160021>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        gambar1();
        gambar2();
        gambar3();
        krismanti();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
