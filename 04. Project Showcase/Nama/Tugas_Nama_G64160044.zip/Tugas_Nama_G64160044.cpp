#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <windows.h> //include sound.wav winmm
#include <MMSystem.h>


//keluar suara loh
int clindex=0,buff=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 536, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

static void grid(int x, int y)
{
    int i;
    glColor3f(.2,.2,.2);
    glBegin(GL_LINES);
    for(i=-x; i<=x; i+=10)
    {
        glVertex2f(i,-y);
        glVertex2f(i,y);
    }
    for(i=-y; i<=y; i++)
    {
        glVertex2f(-x,i);
        glVertex2f(x,i);
    }
    glColor3f(0.7,1,0.7);
    glVertex2f(-x,0);
    glVertex2f(x,0);
    glVertex2f(0,-y);
    glVertex2f(0,y);
    glEnd();
}

void circle(float size)
{
    int N = 50;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}

float angle_earth = 0.0, angle_moon = 0.0;

//int colorf[3][3]={{255, 208, 0},{155,155,155},{255, 255, 255}};
int colorf[100][100]={
    {239,83,80},
    {236,64,122}, //pink
    {171,71,188}, //purple
    {126,87,194}, //deep purple
    {92,107,192}, //indigo
    {66,165,245},//blue
    {41,182,246}, //light blue
    {38,198,218}, //cyan
    {38,166,154}, //teal
    {102,187,106}, //green
    {156,204,101}, //light green
    {212,225,87}, //lime
    {255,238,88}, //yellow
    {255,202,40}, //amber
    {255,167,38}, //orange
    {255,112,67}, //deep orange
};

void ketupat_gede()
{
    glBegin(GL_POLYGON);
    glColor3f(0, 0, 0); glVertex3f(186.74, 204.14, 0);
    glColor3f(0.3, 0.3, 0.3); glVertex3f(687.97, 130.77, 0);
    glColor3f(0.3, 0.3, 0.3); glVertex3f(655.68, 295.02, 0);
    glColor3f(0, 0, 0); glVertex3f(149.74, 367.62, 0);
    glEnd();

}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    //Background
    int i=0; int n=100;
    glBegin(GL_QUADS);
    for(i=0; i<101; i++){
    glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);
    }
    glVertex3f(0, 0, 0);
    glVertex3f(0, 536, 0);
    glVertex3f(800, 536, 0);
    glVertex3f(800, 0, 0);
    glEnd();

    //ketupat gede
    ketupat_gede();
    //huruf E
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(186.43, 200.52, 0);
    glVertex3f(210.39, 224.94, 0);
    glVertex3f(258.76, 225.39, 0);
    glVertex3f(258.99, 201.21, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(186.43, 200.52, 0);
    glVertex3f(185.59, 289.21, 0);
    glVertex3f(210.01, 265.25, 0);
    glVertex3f(210.39, 224.99, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(210.01, 265.25, 0);
    glVertex3f(185.59, 289.21, 0);
    glVertex3f(258.15, 289.89, 0);
    glVertex3f(258.38, 265.7, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(210.31, 233, 0);
    glVertex3f(210.08, 257.19, 0);
    glVertex3f(258.46, 257.64, 0);
    glVertex3f(258.68, 233.45, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(153.88, 232.47, 0);
    glVertex3f(177.83, 256.88, 0);
    glVertex3f(185.9, 256.96, 0);
    glVertex3f(186.12, 232.77, 0);
    glEnd();

    //huruf D
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(266.75, 233.53, 0);
    glVertex3f(266.21, 289.96, 0);
    glVertex3f(290.63, 266.01, 0);
    glVertex3f(290.93, 233.76, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(266.21, 289.96, 0);
    glVertex3f(290.63, 266.01, 0);
    glVertex3f(314.82, 266.23, 0);
    glVertex3f(338.77, 290.65, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(315.19, 225.92, 0);
    glVertex3f(314.82, 266.23, 0);
    glVertex3f(338.77, 290.65, 0);
    glVertex3f(339.61, 201.96, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(315.19, 225.92, 0);
    glVertex3f(266.82, 225.47, 0);
    glVertex3f(267.05, 201.28, 0);
    glVertex3f(339.61, 201.96, 0);
    glEnd();

    //huruf N
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(347.82, 185.91, 0);
    glVertex3f(346.84, 290.72, 0);
    glVertex3f(371.02, 290.95, 0);
    glVertex3f(371.33, 258.7, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(371.33, 258.7, 0);
    glVertex3f(419.24, 307.53, 0);
    glVertex3f(395.74, 234.74, 0);
    glVertex3f(347.82, 185.91, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(420.23, 202.72, 0);
    glVertex3f(419.24, 307.53, 0);
    glVertex3f(395.74, 234.74, 0);
    glVertex3f(396.04, 202.49, 0);
    glEnd();

    //huruf O
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(500.85, 203.48, 0);
    glVertex3f(500.02, 292.16, 0);
    glVertex3f(427.46, 291.48, 0);
    glVertex3f(428.29, 202.8, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glColor3f(0.2, 0.2, 0.2); glVertex3f(476.44, 227.44, 0);
    glColor3f(0.2, 0.2, 0.2); glVertex3f(476.06, 267.75, 0);
    glColor3f(0.2, 0.2, 0.2); glVertex3f(451.87, 267.52, 0);
    glColor3f(0.2, 0.2, 0.2); glVertex3f(452.25, 227.21, 0);
    glEnd();

    //huruf u
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(533.1, 203.78, 0);
    glVertex3f(532.49, 268.28, 0);
    glVertex3f(508.08, 292.24, 0);
    glVertex3f(508.91, 203.55, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(556.68, 268.5, 0);
    glVertex3f(580.64, 292.92, 0);
    glVertex3f(508.08, 292.24, 0);
    glVertex3f(532.49, 268.28, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(581.47, 204.23, 0);
    glVertex3f(580.64, 292.92, 0);
    glVertex3f(556.68, 268.5, 0);
    glVertex3f(557.28, 204.01, 0);
    glEnd();

    //huruf R
    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(613.49, 228.72, 0);
    glVertex3f(612.89, 293.22, 0);
    glVertex3f(588.7, 292.99, 0);
    glVertex3f(589.53, 204.31, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(662.09, 204.99, 0);
    glVertex3f(637.68, 228.95, 0);
    glVertex3f(613.49, 228.72, 0);
    glVertex3f(589.53, 204.31, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(637.6, 237.01, 0);
    glVertex3f(661.56, 261.43, 0);
    glVertex3f(613.49, 260.97, 0);
    glVertex3f(613.42, 236.79, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(662.09, 204.99, 0);
    glVertex3f(661.56, 261.43, 0);
    glVertex3f(637.6, 237.01, 0);
    glVertex3f(637.68, 228.95, 0);
    glEnd();

    glBegin(GL_POLYGON);
        for(i=0; i<101; i++){     glColor3ub(colorf[(clindex+1)%15][0+i],colorf[(clindex+1)%15][1+i],colorf[(clindex+1)%15][2+i]);     }
    glVertex3f(645.44, 261.27, 0);
    glVertex3f(661.41, 277.55, 0);
    glVertex3f(661.11, 309.8, 0);
    glVertex3f(613.19, 260.97, 0);
    glEnd();

    //attribut slash
    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(222.61, 70.91, 0);
    glVertex3f(221.76, 71.97, 0);
    glVertex3f(0, 104.04, 0);
    glVertex3f(0, 102.16, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(539.63, 82.23, 0);
    glVertex3f(539.94, 84.07, 0);
    glVertex3f(273.95, 122.53, 0);
    glVertex3f(276.63, 120.69, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(523.47, 96.5, 0);
    glVertex3f(523.78, 98.34, 0);
    glVertex3f(189.77, 146.72, 0);
    glVertex3f(188.62, 145.95, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(338.92, 387.38, 0);
    glVertex3f(339.23, 389.22, 0);
    glVertex3f(5.07, 437.62, 0);
    glVertex3f(4.91, 435.77, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(451.75, 464.69, 0);
    glVertex3f(452.06, 466.53, 0);
    glVertex3f(186.07, 504.99, 0);
    glVertex3f(185.76, 503.15, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0, 0, 0);
    glVertex3f(800, 377.4, 0);
    glVertex3f(800, 379.29, 0);
    glVertex3f(638.44, 402.63, 0);
    glVertex3f(638.28, 400.79, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex3f(663.13, 146.75, 0);
    glVertex3f(663.43, 148.59, 0);
    glVertex3f(441.67, 180.66, 0);
    glVertex3f(441.67, 178.78, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex3f(633.6, 165.5, 0);
    glVertex3f(633.25, 167.31, 0);
    glVertex3f(552.02, 179.99, 0);
    glVertex3f(552.47, 178.17, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex3f(399.15, 310.01, 0);
    glVertex3f(399.45, 311.85, 0);
    glVertex3f(177.69, 343.92, 0);
    glVertex3f(177.69, 342.04, 0);
    glEnd();

    //hiasan kiri atas
    glRotatef((float) glfwGetTime() * 100.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -150.f, 0);
    glColor3f(0.2, 0.2, 0.2);
    circle(25);

    glRotatef((float) glfwGetTime() * -250.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -250.f, 0);
    glColor3f(255, 255, 255);
    circle(15);

    glRotatef((float) glfwGetTime() * 0.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -450.f, 0);
    glColor3f(0.2, 0.2, 0.2);
    circle(120);

    glRotatef((float) glfwGetTime() * -50.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -70.f, 0);
    glColor3f(0.2, 0.2, 0.2);
    circle(10);

    glRotatef((float) glfwGetTime() * 0.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -250.f, 0);
    glColor3f(255, 255, 255);
    circle(50);

    glRotatef((float) glfwGetTime() * -10.f, 0.f, 0.f, 1.f);
    glTranslatef(0, -700.f, 0);
    glColor3f(0.2, 0.2, 0.2);
    circle(200);

    glFlush();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 536, "Endang Nuradi G64160044", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    PlaySound(TEXT("sound.wav"), NULL, SND_FILENAME|SND_LOOP|SND_ASYNC);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%3;

        setup_viewport(window);
        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
