#include <GLFW/glfw3.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    //glOrtho(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your drawing code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

// ini fungsi buat kata nya
void W_penuh(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(19,415);
    glVertex2d(144,415);
    glVertex2d(107,514);
    glVertex2d(52,514);

    glEnd();
}

void Segi_kiri_w(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(36,415);
    glVertex2d(50,415);
    glVertex2d(69,464);
    glVertex2d(62,483);

    glEnd();
}

void Segi_kanan_w(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(90,464);
    glVertex2d(109,415);
    glVertex2d(123,415);
    glVertex2d(97,483);

    glEnd();
}

void Segi_atas_w(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(72,415);
    glVertex2d(87,415);
    glVertex2d(79,436);

    glEnd();
}

void Segi_bawah_w(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(72,515);
    glVertex2d(80,493);
    glVertex2d(87,514);

    glEnd();
}

void A_penuh(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(148,514);
    glVertex2d(148,437);
    glVertex2d(163,415);
    glVertex2d(215,415);
    glVertex2d(231,437);
    glVertex2d(231,514);
    glVertex2d(169,486);
    glVertex2d(169,514);

    glEnd();
}

void Segi_bawah_a(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(148,514);
    glVertex2d(169,514);
    glVertex2d(148,532);

    glEnd();
}

void Kotak_atas_a(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(168,437);
    glVertex2d(210,437);
    glVertex2d(210,464);
    glVertex2d(168,464);

    glEnd();
}

void Kotak_bawah_a(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(168,486);
    glVertex2d(210,486);
    glVertex2d(210,514);
    glVertex2d(168,514);

    glEnd();
}

void R_penuh(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(245,514);
    glVertex2d(245,416);
    glVertex2d(316,416);
    glVertex2d(331,446);
    glVertex2d(331,514);

    glEnd();
}

void Segi_atas_r(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(331,446);
    glVertex2d(331,486);
    glVertex2d(320,469);

    glEnd();
}

void Kotak_atas_r(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(265,438);
    glVertex2d(305,438);
    glVertex2d(310,448);
    glVertex2d(305,459);
    glVertex2d(265,459);

    glEnd();
}

void Kotak_bawah_r(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(265,482);
    glVertex2d(305,482);
    glVertex2d(311,490);
    glVertex2d(311,514);
    glVertex2d(265,514);

    glEnd();
}

void Segi_bawah_r(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(245,514);
    glVertex2d(265,514);
    glVertex2d(245,532);

    glEnd();
}

void D_penuh(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(346,416);
    glVertex2d(414,416);
    glVertex2d(433,465);
    glVertex2d(414,514);
    glVertex2d(346,514);

    glEnd();
}

void Segi_d(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(366,438);
    glVertex2d(400,438);
    glVertex2d(411,465);
    glVertex2d(400,492);
    glVertex2d(366,492);

    glEnd();
}

void I_penuh(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(446,416);
    glVertex2d(467,416);
    glVertex2d(467,514);
    glVertex2d(446,531);

    glEnd();
}

void M_kiri(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(482,416);
    glVertex2d(505,416);
    glVertex2d(502,452);
    glVertex2d(502,514);
    glVertex2d(482,531);

    glEnd();
}

void M_kiri_tengah(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(505,416);
    glVertex2d(502,452);
    glVertex2d(528,502);
    glVertex2d(541,502);
    glVertex2d(535,475);

    glEnd();
}

void M_kanan_tengah(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(535,475);
    glVertex2d(564,416);
    glVertex2d(567,452);
    glVertex2d(541,502);


    glEnd();
}

void M_kanan(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);


    glVertex2d(564,416);
    glVertex2d(587,416);
    glVertex2d(587,514);
    glVertex2d(567,514);
    glVertex2d(567,452);


    glEnd();
}

void A_penuh_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(602,514);
    glVertex2d(602,437);
    glVertex2d(617,415);
    glVertex2d(669,415);
    glVertex2d(684,437);
    glVertex2d(684,514);

    glEnd();
}

void Segi_bawah_a_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(602,514);
    glVertex2d(622,514);
    glVertex2d(602,532);

    glEnd();
}

void Kotak_atas_a_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(622,437);
    glVertex2d(664,437);
    glVertex2d(664,464);
    glVertex2d(622,464);

    glEnd();
}

void Kotak_bawah_a_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

    glVertex2d(622,486);
    glVertex2d(664,486);
    glVertex2d(664,514);
    glVertex2d(622,514);

    glEnd();
}

void N_kiri_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(699,416);
    glVertex2d(714,416);
    glVertex2d(720,457);
    glVertex2d(720,514);
    glVertex2d(699,531);

    glEnd();
}

void N_miring(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(714,416);
    glVertex2d(720,457);
    glVertex2d(768,514);
    glVertex2d(763,475);

    glEnd();
}

void N_kanan_ujung(){

    glBegin(GL_POLYGON);
    glColor3ub(250,90,255);

    glVertex2d(763,416);
    glVertex2d(784,416);
    glVertex2d(784,514);
    glVertex2d(768,514);
    glVertex2d(763,475);

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Wardiman Perdian", NULL, NULL);

    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window)){
        setup_viewport(window);
        display();

        //buat manggil fungsi k
        W_penuh();
        Segi_kiri_w();
        Segi_kanan_w();
        Segi_atas_w();
        Segi_bawah_w();

        A_penuh();
        Segi_bawah_a();
        Kotak_atas_a();
        Kotak_bawah_a();

        R_penuh();
        Segi_atas_r();
        Kotak_atas_r();
        Kotak_bawah_r();
        Segi_bawah_r();

        D_penuh();
        Segi_d();

        I_penuh();

        M_kiri();
        M_kiri_tengah();
        M_kanan_tengah();
        M_kanan();

        A_penuh_ujung();
        Segi_bawah_a_ujung();
        Kotak_atas_a_ujung();
        Kotak_bawah_a_ujung();

        N_kiri_ujung();
        N_miring();
        N_kanan_ujung();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
