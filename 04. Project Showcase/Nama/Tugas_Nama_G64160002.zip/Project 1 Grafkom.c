#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;
int colorf[3][3]={{0,0,0},{88,86,109},{255,255,255}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);

    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 80, 80, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
   glClear(GL_COLOR_BUFFER_BIT);

   glFlush();
}

void Background(){

    //glColor3f(1,1,1);
    glBegin(GL_POLYGON);
    glColor3ub(colorf[clindex%2][0],colorf[(clindex)%2][1],colorf[(clindex)%2][2]);
    glVertex2d(0,0);
    glColor3ub(colorf[clindex%2][0],colorf[(clindex)%2][1],colorf[(clindex)%2][2]);
    glVertex2d(80,0);
    glColor3ub(colorf[clindex%1][0],colorf[(clindex)%1][1],colorf[(clindex)%1][2]);
    glVertex2d(80,80);
    glColor3ub(colorf[clindex%1][0],colorf[(clindex)%1][1],colorf[(clindex)%1][2]);
    glVertex2d(0,80);
    glEnd();
}

void Y(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(22.02,29.32);
    glVertex2d(24.68,29.32);
    glVertex2d(25.56,33.25);
    glVertex2d(24.08,35.96);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(26.31,29.32);
    glVertex2d(28.90,29.32);
    glVertex2d(26.79,35.96);
    glVertex2d(25.36,33.25);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(24.08,35.96);
    glVertex2d(26.79,35.96);
    glVertex2d(26.79,39.70);
    glVertex2d(24.08,39.70);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(25.36,33.25);
    glVertex2d(25.56,33.25);
    glVertex2d(26.79,35.96);
    glVertex2d(24.08,35.96);
    glEnd();
}

void YShad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(23.02,28.32);
    glVertex2d(25.68,28.32);
    glVertex2d(26.56,32.25);
    glVertex2d(25.08,34.96);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(27.31,28.32);
    glVertex2d(29.90,28.32);
    glVertex2d(27.79,34.96);
    glVertex2d(26.36,32.25);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(25.08,34.96);
    glVertex2d(27.79,34.96);
    glVertex2d(27.79,38.70);
    glVertex2d(25.08,38.70);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(26.36,32.25);
    glVertex2d(26.56,32.25);
    glVertex2d(27.79,34.96);
    glVertex2d(25.08,34.96);
    glEnd();
}

void U1(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(29.30,31.13);
    glVertex2d(32.15,31.13);
    glVertex2d(32.15,38.27);
    glVertex2d(29.30,38.27);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(33.04,31.13);
    glVertex2d(35.89,31.13);
    glVertex2d(35.89,38.27);
    glVertex2d(33.04,38.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(29.30,38.27);
    glVertex2d(35.89,38.27);
    glVertex2d(34.60,39.70);
    glVertex2d(30.60,39.70);
    glEnd();

    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(32.15,36.98);
    glVertex2d(33.11,36.98);
    glVertex2d(33.11,38.27);
    glVertex2d(32.15,38.27);
    glEnd();
}

void U1Shad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(30.30,30.13);
    glVertex2d(33.15,30.13);
    glVertex2d(33.15,37.27);
    glVertex2d(30.30,37.27);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(34.04,30.13);
    glVertex2d(36.89,30.13);
    glVertex2d(36.89,37.27);
    glVertex2d(34.04,37.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(30.30,37.27);
    glVertex2d(36.89,37.27);
    glVertex2d(35.60,38.70);
    glVertex2d(31.60,38.70);
    glEnd();

    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(33.15,35.98);
    glVertex2d(34.11,35.98);
    glVertex2d(34.11,37.27);
    glVertex2d(33.15,37.27);
    glEnd();
}

void S(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(40.11,31.13);
    glVertex2d(42.76,31.13);
    glVertex2d(42.76,33.85);
    glVertex2d(40.11,33.85);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(39.36,31.13);
    glVertex2d(40.11,31.13);
    glVertex2d(40.11,32.70);
    glVertex2d(39.36,32.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(38.33,31.13);
    glVertex2d(39.36,31.13);
    glVertex2d(39.36,32.70);
    glVertex2d(36.84,32.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(36.84,32.70);
    glVertex2d(39.36,32.70);
    glVertex2d(39.36,33.85);
    glVertex2d(36.84,33.85);
    glEnd();

    //tengah
    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(36.84,33.85);
    glVertex2d(40.11,36.64);
    glVertex2d(36.84,34.85);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(36.84,33.85);
    glVertex2d(39.36,33.85);
    glVertex2d(42.76,36.64);
    glVertex2d(40.11,36.64);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(39.36,33.85);
    glVertex2d(42.76,35.82);
    glVertex2d(42.76,36.64);
    glEnd();

    //bawah
    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(36.84,36.64);
    glVertex2d(39.29,36.64);
    glVertex2d(39.29,39.70);
    glVertex2d(36.84,39.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(38.41,38.27);
    glVertex2d(40.11,38.27);
    glVertex2d(40.11,39.70);
    glVertex2d(38.41,39.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(40.11,38.27);
    glVertex2d(42.76,38.27);
    glVertex2d(41.33,39.70);
    glVertex2d(38.41,39.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(40.11,36.64);
    glVertex2d(42.76,36.64);
    glVertex2d(42.76,38.27);
    glVertex2d(40.11,38.27);
    glEnd();
}

void SShad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(41.11,30.13);
    glVertex2d(43.76,30.13);
    glVertex2d(43.76,32.85);
    glVertex2d(41.11,32.85);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(1,1,1);
    glVertex2d(40.36,30.13);
    glVertex2d(41.11,30.13);
    glVertex2d(41.11,31.70);
    glVertex2d(40.36,31.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(39.33,30.13);
    glVertex2d(40.36,30.13);
    glVertex2d(40.36,31.70);
    glVertex2d(37.84,31.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(37.84,31.70);
    glVertex2d(40.36,31.70);
    glVertex2d(40.36,32.85);
    glVertex2d(37.84,32.85);
    glEnd();

    //tengah
    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(37.84,32.85);
    glVertex2d(41.11,35.64);
    glVertex2d(37.84,33.85);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(37.84,32.85);
    glVertex2d(40.36,32.85);
    glVertex2d(43.76,35.64);
    glVertex2d(41.11,35.64);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(40.36,32.85);
    glVertex2d(43.76,34.82);
    glVertex2d(43.76,35.64);
    glEnd();

    //bawah
    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(37.84,35.64);
    glVertex2d(40.29,35.64);
    glVertex2d(40.29,38.70);
    glVertex2d(37.84,38.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(39.41,37.27);
    glVertex2d(41.11,37.27);
    glVertex2d(41.11,38.70);
    glVertex2d(39.41,38.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(41.11,37.27);
    glVertex2d(43.76,37.27);
    glVertex2d(42.33,38.70);
    glVertex2d(39.41,38.70);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(41.11,35.64);
    glVertex2d(43.76,35.64);
    glVertex2d(43.76,37.27);
    glVertex2d(41.11,37.27);
    glEnd();
}

void U2(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(43.64,31.13);
    glVertex2d(46.50,31.13);
    glVertex2d(46.50,38.27);
    glVertex2d(43.64,38.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(47.38,31.13);
    glVertex2d(50.24,31.13);
    glVertex2d(50.24,38.27);
    glVertex2d(47.38,38.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(46.50,36.98);
    glVertex2d(50.24,36.98);
    glVertex2d(47.38,38.27);
    glVertex2d(46.50,38.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(43.64,38.27);
    glVertex2d(50.24,38.27);
    glVertex2d(48.83,39.70);
    glVertex2d(45.07,39.70);
    glEnd();
}

void U2Shad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(44.64,30.13);
    glVertex2d(47.50,30.13);
    glVertex2d(47.50,37.27);
    glVertex2d(44.64,37.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(48.38,30.13);
    glVertex2d(51.24,30.13);
    glVertex2d(51.24,37.27);
    glVertex2d(48.38,37.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(47.50,35.98);
    glVertex2d(51.24,35.98);
    glVertex2d(48.38,37.27);
    glVertex2d(47.50,37.27);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(44.64,37.27);
    glVertex2d(51.24,37.27);
    glVertex2d(49.83,38.70);
    glVertex2d(46.07,38.70);
    glEnd();
}

void F(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(51.39,29.32);
    glVertex2d(53.70,29.32);
    glVertex2d(53.70,39.70);
    glVertex2d(51.39,39.70);
    glEnd();

    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(53.70,29.32);
    glVertex2d(54.93,29.32);
    glVertex2d(54.93,31.30);
    glVertex2d(53.70,31.30);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(50.71,32.22);
    glVertex2d(54.60,32.22);
    glVertex2d(54.60,34.00);
    glVertex2d(50.71,34.00);
    glEnd();
}

void FShad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(52.39,28.32);
    glVertex2d(54.70,28.32);
    glVertex2d(54.70,38.70);
    glVertex2d(52.39,38.70);
    glEnd();

    glBegin(GL_POLYGON);
   // glColor3f(1,1,1);
    glVertex2d(54.70,28.32);
    glVertex2d(55.93,28.32);
    glVertex2d(55.93,30.30);
    glVertex2d(54.70,30.30);
    glEnd();

    glBegin(GL_POLYGON);
  //  glColor3f(1,1,1);
    glVertex2d(51.71,31.22);
    glVertex2d(55.60,31.22);
    glVertex2d(55.60,33.00);
    glVertex2d(51.71,33.00);
    glEnd();
}

void circle(float size)
{
    int i, N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}

void circleS1()
    {
        glTranslatef(20,20,0.f);
        glColor3f(0,0,0);
        circle(15);
    }

void Line(){
    glColor3f(0,0,0);
    glBegin(GL_POLYGON);

    glVertex2d(22.02,42.05);
    glVertex2d(54.93,42.05);
    glVertex2d(54.93,43.39);
    glVertex2d(22.02,43.39);
    glEnd();
}

void LineShad(){
    glColor3f(0.2,0.2,0.2);
    glBegin(GL_POLYGON);

    glVertex2d(23.02,41.35);
    glVertex2d(55.93,41.35);
    glVertex2d(55.93,42.69);
    glVertex2d(23.02,42.69);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800 , 800, "Tugas Nama - Yusuf Ibadurrahman Assidiq G64160002", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        setup_viewport(window);
        display();
        Background();
        YShad();
        Y();
        U1Shad();
        U1();
        SShad();
        S();
        U2Shad();
        U2();
        FShad();
        F();
        LineShad();
        Line();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}

