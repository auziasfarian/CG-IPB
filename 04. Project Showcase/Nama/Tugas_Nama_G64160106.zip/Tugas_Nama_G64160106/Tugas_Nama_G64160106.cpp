//latihan bikin nama
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/////warna/////
#define biruLangit 195, 237, 245
#define merahPastel 244, 170, 173
#define maroon 167, 44, 50
#define toscaPastel 185, 239, 226
#define unguPastel 238, 194, 245
#define biruPastel 197, 194, 245
#define putih 255, 255, 255
#define toscaTua 32, 145, 126
#define orenPastel 255, 187, 128
#define maroonTua 91, 0, 0
#define pinkhoho 243, 221, 229
#define ijoMudaPastel 217, 255, 203
#define warnaKulit 255, 216, 189
#define kuninghoho 255, 212, 141

int clindex=0,buff=0;
int colorf[3][3]={{toscaPastel},{warnaKulit},{pinkhoho}};


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 0, -1); //

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your drawing code here, maybe
    /*glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glBegin(GL_TRIANGLES);
    glColor3f(1.f, 0.f, 0.f);
    glVertex3f(-0.6f, -0.4f, 0.f);
    glColor3f(0.f, 1.f, 0.f);
    glVertex3f(0.6f, -0.4f, 0.f);
    glColor3f(0.f, 0.f, 1.f);
    glVertex3f(0.f, 0.6f, 0.f);
    glEnd();*/
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void bground()
{
    glBegin(GL_POLYGON);

    glColor3ub(ijoMudaPastel);

    glVertex2d(0, 0);
    glVertex2d(800, 0);
    glVertex2d(800, 800);
    glVertex2d(0, 800);

    glEnd();

}

void bground2()
{
    glBegin(GL_POLYGON);

    glColor3ub(putih);

    glVertex2d(0, 200);
    glVertex2d(800, 200);
    glVertex2d(800, 600);
    glVertex2d(0, 600);

    glEnd();
}

void lingkaranPojok()
{

 float theta;

    glClear(GL_COLOR);

    glBegin(GL_POLYGON);
    glColor3ub(toscaTua);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(152+130*cos(theta),159+130*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(152+100*cos(theta),159+100*sin(theta));
    }

    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(toscaTua);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(653+130*cos(theta),252+130*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(653+100*cos(theta),252+100*sin(theta));
    }

    glEnd();



     glBegin(GL_POLYGON);
    glColor3ub(toscaTua);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(212+130*cos(theta),597+130*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(212+100*cos(theta),597+100*sin(theta));
    }

    glEnd();
}

void segitiga()

{
    glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(290, 167);
    glVertex2d(346, 326);
    glVertex2d(271, 288);

    glEnd();


    glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(411, 22);
    glVertex2d(481, 31);
    glVertex2d(451, 131);

    glEnd();

    /*glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(214, 392);
    glVertex2d(254, 402);
    glVertex2d(199, 506);

    glEnd();*/

    /*glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(550, 168);
    glVertex2d(595, 458);
    glVertex2d(412, 323);

    glEnd(); */

    glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(424, 435);
    glVertex2d(683, 661);
    glVertex2d(328, 562);

    glEnd();

   /* glBegin(GL_TRIANGLES);

    glColor3ub(biruLangit);

    glVertex2d(294, 613);
    glVertex2d(391, 783);
    glVertex2d(174, 708);

    glEnd(); */
}

void nama()
{
    ///////// M ////////////

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(200, 134);
    glVertex2d(259, 134);
    glVertex2d(259, 255);
    glVertex2d(200, 255);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(259, 134);
    glVertex2d(316, 171);
    glVertex2d(316, 222);
    glVertex2d(259, 184);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(316, 171);
    glVertex2d(371, 134);
    glVertex2d(371, 184);
    glVertex2d(316, 222);


    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(372, 134);
    glVertex2d(432, 134);
    glVertex2d(432, 255);
    glVertex2d(372, 255);

    glEnd();

    //////////// I ////////////////

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(486, 134);
    glVertex2d(545, 134);
    glVertex2d(545, 255);
    glVertex2d(486, 255);

    glEnd();

    /*N*/

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(319, 304);
    glVertex2d(378, 304);
    glVertex2d(378, 424);
    glVertex2d(319, 424);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(378, 304);
    glVertex2d(439, 386);
    glVertex2d(439, 424);
    glVertex2d(378, 342);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(439, 303);
    glVertex2d(498, 303);
    glVertex2d(498, 424);
    glVertex2d(439, 424);

    glEnd();

/*A*/

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(261, 479);
    glVertex2d(273, 479);
    glVertex2d(273, 656);
    glVertex2d(204, 656);

    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(273, 479);
    glVertex2d(335, 479);
    glVertex2d(335, 517);
    glVertex2d(273, 517);


    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(273, 545);
    glVertex2d(335, 545);
    glVertex2d(335, 582);
    glVertex2d(273, 582);


    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(335, 479);
    glVertex2d(347, 479);
    glVertex2d(405, 656);
    glVertex2d(335, 656);


    glEnd();

/*Y*/


    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(424, 465);
    glVertex2d(504, 465);
    glVertex2d(540, 549);
    glVertex2d(506, 549);

    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(577, 465);
    glVertex2d(656, 465);
    glVertex2d(575, 549);
    glVertex2d(506, 549);


    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroon);

    glVertex2d(506, 549);
    glVertex2d(575, 549);
    glVertex2d(575, 648);
    glVertex2d(506, 648);

    glEnd();


}

void namaBelakang()

//x ditambah 25, y dikurang 25
{
    ///////// M ////////////

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(225, 109);
    glVertex2d(284, 109);
    glVertex2d(284, 230);
    glVertex2d(225, 230);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);
//x ditambah 25, y dikurang 2
    glVertex2d(284, 109);
    glVertex2d(341, 146);
    glVertex2d(341, 197);
    glVertex2d(284, 159);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(316, 146);
    glVertex2d(371, 109);
    glVertex2d(396, 109);
    glVertex2d(316, 197);


    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(397, 109);
    glVertex2d(457, 109);
    glVertex2d(457, 230);
    glVertex2d(397, 230);

    glEnd();

    //////////// I ////////////////

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(511, 109);
    glVertex2d(570, 109);
    glVertex2d(570, 230);
    glVertex2d(511, 230);

    glEnd();

    /*N*/

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(344, 279);
    glVertex2d(403, 279);
    glVertex2d(403, 399);
    glVertex2d(344, 399);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(403, 279);
    glVertex2d(464, 361);
    glVertex2d(464, 399);
    glVertex2d(403, 317);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(464, 278);
    glVertex2d(523, 278);
    glVertex2d(523, 399);
    glVertex2d(464, 399);

    glEnd();

/*A*/

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(286, 454);
    glVertex2d(298, 454);
    glVertex2d(298, 631);
    glVertex2d(229, 631);

    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(298, 454);
    glVertex2d(360, 454);
    glVertex2d(360, 492);
    glVertex2d(298, 492);


    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(298, 520);
    glVertex2d(360, 520);
    glVertex2d(360, 557);
    glVertex2d(298, 557);


    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(360, 454);
    glVertex2d(372, 454);
    glVertex2d(430, 631);
    glVertex2d(360, 631);


    glEnd();

/*Y*/


    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(449, 440);
    glVertex2d(529, 440);
    glVertex2d(565, 524);
    glVertex2d(531, 524);

    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(602, 440);
    glVertex2d(681, 440);
    glVertex2d(600, 524);
    glVertex2d(531, 524);


    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(maroonTua);

    glVertex2d(531, 524);
    glVertex2d(600, 524);
    glVertex2d(600, 623);
    glVertex2d(531, 623);

    glEnd();


}

void hiasan()
{
    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(85, 40);
    glVertex2d(142, 40);
    glVertex2d(142, 60);
    glVertex2d(85, 60);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(335, 40);
    glVertex2d(392, 40);
    glVertex2d(392, 60);
    glVertex2d(335, 60);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(210, 40);
    glVertex2d(268, 40);
    glVertex2d(268, 60);
    glVertex2d(210, 60);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(460, 40);
    glVertex2d(517, 40);
    glVertex2d(517, 60);
    glVertex2d(460, 60);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(585, 40);
    glVertex2d(642, 40);
    glVertex2d(642, 60);
    glVertex2d(585, 60);

    glEnd();

    /////////////////////////////////////////////////////////

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(85, 727);
    glVertex2d(142, 727);
    glVertex2d(142, 747);
    glVertex2d(85, 747);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(335, 727);
    glVertex2d(392, 727);
    glVertex2d(392, 747);
    glVertex2d(335, 747);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(210, 727);
    glVertex2d(268, 727);
    glVertex2d(268, 747);
    glVertex2d(210, 747);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(460, 727);
    glVertex2d(517, 727);
    glVertex2d(517, 747);
    glVertex2d(460, 747);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(orenPastel);

    glVertex2d(585, 727);
    glVertex2d(642, 727);
    glVertex2d(642, 747);
    glVertex2d(585, 747);

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - Yasmin Rizky F (Minay) - G64160106", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();

        //////////////////////////////

        bground();

        bground2();

        lingkaranPojok();

        segitiga();

        namaBelakang();

        nama();

        hiasan();


        //////////////////////////////

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
