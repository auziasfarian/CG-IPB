#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <Windows.h>
#define clgrey 0,0,180-colorA*2
#define clblue 0,0,200-colorA
#define cldarkgrey colorA+20,colorA+20,colorA+20
#define clwhite 255-colorA,255-colorA,255-colorA
#define clsilver 120-colorA,120-colorA,120-colorA
int buff=0, colorA=0, colorB=0, buff2=0, buff3=0, moveA=200, moveB=-20,moveC=0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glEnable( GL_BLEND ) ;
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA ) ; // works fine, except cracks
    //glBlendFunc( GL_SRC_ALPHA_SATURATE, GL_ONE ) ; // works only on black background...
    glPolygonMode( GL_FRONT, GL_FILL ) ;
    glEnable( GL_POLYGON_SMOOTH ) ;
    glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST ) ;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void background(){
    glBegin(GL_POLYGON);
    glColor3ub(clwhite);
    glVertex2d(0+moveA,400);
    glVertex2d(400,0+moveA);
    glVertex2d(800-moveA,400);
    glVertex2d(400,800-moveA);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clsilver);
    if(colorB==0){
        glVertex2d(400,0+moveA);
        glVertex2d(800-moveA,400);
        glVertex2d(400,400);
    }
    else{
        glVertex2d(0+moveA,400);
        glVertex2d(400,800-moveA);
        glVertex2d(400,400);
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(400,800-70-moveA);
    glVertex2d(70+moveA,400);
    glVertex2d(400,70+moveA);
    glVertex2d(800-70-moveA,400);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(410,0);
    glVertex2d(390,0);
    glVertex2d(390,800);
    glVertex2d(410,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(0,410);
    glVertex2d(0,390);
    glVertex2d(800,390);
    glVertex2d(800,410);
    glEnd();

    glPushMatrix();
    glTranslated(400,400,0);
    glRotatef((float)glfwGetTime()*10.0f,0.0f,0.0f,0.0f);
    glTranslated(-400, -400, 0);

    glBegin(GL_POLYGON);
    glColor3ub(clwhite);
    glVertex2d(400,300);
    glVertex2d(500,400);
    glVertex2d(400,500);
    glVertex2d(300,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(420,315);
    glVertex2d(380,315);
    glVertex2d(380,485);
    glVertex2d(420,485);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(315,420);
    glVertex2d(315,380);
    glVertex2d(485,380);
    glVertex2d(485,420);
    glEnd();
    glPopMatrix();

}
void display()
{
    if(buff==0&&colorB==0){
        colorA++;

        if(colorA==60){
            colorB=1;
            moveB=-20;
            //Sleep(600);
        }
    }
    if(buff==0&&colorB==1){
        colorA--;

        if(colorA==0){
        colorB=0;
        moveB=20;
            //Sleep(600);
            }
    }
    buff++;
    buff=buff%20;
    if(buff%7==0&&colorB==1){
        moveA++;
    }
    if(buff%7==0&&colorB==0){
        moveA--;
    }
    glPushMatrix();
   // glTranslatef(0, y, z);
    glTranslated(400,400,0);

    glRotatef((float)glfwGetTime()*10.0f,0.0f,0.0f,1.0f);
    glTranslated(-400, -400, 0);
   // glTranslatef(0, -y, -z);
    background();
    glPopMatrix();
// UPPER PART
    //F
    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(37+moveB,264+moveC);
    glVertex2d(179+moveB,264+moveC);
    glVertex2d(179+moveB,305+moveC);
    glVertex2d(78+moveB,305+moveC);
    glVertex2d(78+moveB,310+moveC);
    glVertex2d(37+moveB,269+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);

    glVertex2d(37+moveB,327+moveC);
    glVertex2d(37+moveB,431+moveC);
    glVertex2d(78+moveB,431+moveC);
    glVertex2d(78+moveB,368+moveC);
    glVertex2d(134+moveB,368+moveC);
    glVertex2d(134+moveB,327+moveC);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(37+moveB,288+moveC);
    glVertex2d(83+moveB,333+moveC);
    glVertex2d(37+moveB,327+moveC);
    glEnd();
    //end of F

    //A
    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(247+moveB,313+moveC);
    glVertex2d(177+moveB,431+moveC);
    glVertex2d(224+moveB,431+moveC);
    glVertex2d(271+moveB,353+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(255+moveB,301+moveC);
    glVertex2d(279+moveB,261+moveC);
    glVertex2d(380+moveB,431+moveC);
    glVertex2d(332+moveB,431+moveC);
    glEnd();
    //end of A

    //L
    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(397+moveB,264+moveC);
    glVertex2d(397+moveB,430+moveC);
    glVertex2d(437+moveB,430+moveC);
    glVertex2d(437+moveB,264+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(484+moveB,430+moveC);
    glVertex2d(444+moveB,390+moveC);
    glVertex2d(437+moveB,389+moveC);
    glVertex2d(437+moveB,430+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(462+moveB,389+moveC);
    glVertex2d(503+moveB,430+moveC);
    glVertex2d(511+moveB,430+moveC);
    glVertex2d(511+moveB,389+moveC);
    glEnd();
    //end of L

    //D
    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(535+moveB,264+moveC);
    glVertex2d(535+moveB,311+moveC);
    glVertex2d(576+moveB,353+moveC);
    glVertex2d(576+moveB,306+moveC);
    glVertex2d(617+moveB,306+moveC);
    glVertex2d(617+moveB,264+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(535+moveB,329+moveC);
    glVertex2d(535+moveB,430+moveC);
    glVertex2d(576+moveB,430+moveC);
    glVertex2d(576+moveB,371+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(617+moveB,430+moveC);
    glVertex2d(617+moveB,388+moveC);
    glVertex2d(576+moveB,388+moveC);
    glVertex2d(576+moveB,430+moveC);
    glEnd();

    glBegin(GL_LINES);
    glColor3ub(clgrey);
    for (float i=270; i <= 450; i=i+0.25)
   {
      float rad = i*3.14159/180;
      glVertex2f(610+cos(rad)*83+moveB,347+sin(rad)*83+moveC);
      glVertex2f(610+cos(rad)*41.5+moveB,347+sin(rad)*41.5+moveC);
   }
    glEnd();
    //end of D

    //I
    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(722+moveB,263+moveC);
    glVertex2d(722+moveB,284+moveC);
    glVertex2d(763+moveB,325+moveC);
    glVertex2d(763+moveB,263+moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(clgrey);
    glVertex2d(722+moveB,303+moveC);
    glVertex2d(722+moveB,431+moveC);
    glVertex2d(763+moveB,431+moveC);
    glVertex2d(763+moveB,345+moveC);
    glEnd();
    //end of I
//END OF UPPER PART

//BOTTOM PART
     //F
    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(37-moveB,597-moveC);
    glVertex2d(37-moveB,592-moveC);
    glVertex2d(78-moveB,551-moveC);
    glVertex2d(78-moveB,556-moveC);
    glVertex2d(179-moveB,556-moveC);
    glVertex2d(179-moveB,597-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(37-moveB,430-moveC);
    glVertex2d(37-moveB,573-moveC);
    glVertex2d(78-moveB,534-moveC);
    glVertex2d(78-moveB,430-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(37-moveB,534-moveC);
    glVertex2d(134-moveB,534-moveC);
    glVertex2d(134-moveB,493-moveC);
    glVertex2d(78-moveB,493-moveC);
    glEnd();
    //end of F

    //A
    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(255-moveB,560-moveC);
    glVertex2d(279-moveB,600-moveC);
    glVertex2d(380-moveB,430-moveC);
    glVertex2d(332-moveB,430-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(177-moveB,430-moveC);
    glVertex2d(224-moveB,430-moveC);
    glVertex2d(271-moveB,508-moveC);
    glVertex2d(247-moveB,548-moveC);
    glEnd();
    //end of A

    //L
    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(462-moveB,472-moveC);
    glVertex2d(511-moveB,472-moveC);
    glVertex2d(511-moveB,430-moveC);
    glVertex2d(503-moveB,430-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(397-moveB,430-moveC);
    glVertex2d(397-moveB,472-moveC);
    glVertex2d(444-moveB,472-moveC);
    glVertex2d(484-moveB,430-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(397-moveB,430-moveC);
    glVertex2d(397-moveB,597-moveC);
    glVertex2d(437-moveB,597-moveC);
    glVertex2d(437-moveB,430-moveC);
    glEnd();
    //end of L

    //D
    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(535-moveB,430-moveC);
    glVertex2d(617-moveB,430-moveC);
    glVertex2d(617-moveB,472-moveC);
    glVertex2d(576-moveB,472-moveC);
    glVertex2d(576-moveB,489-moveC);
    glVertex2d(535-moveB,531-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(535-moveB,550-moveC);
    glVertex2d(535-moveB,597-moveC);
    glVertex2d(617-moveB,597-moveC);
    glVertex2d(617-moveB,555-moveC);
    glVertex2d(576-moveB,555-moveC);
    glVertex2d(576-moveB,508-moveC);
    glEnd();

    glBegin(GL_LINES);
    glColor3ub(cldarkgrey);
    for (float i=270; i <= 450; i=i+0.25)
   {
      float rad = i*3.14159/180;
      glVertex2f(610+cos(rad)*83-moveB,513+sin(rad)*83-moveC);
      glVertex2f(610+cos(rad)*41.5-moveB,513+sin(rad)*41.5-moveC);
   }
    glEnd();
    //end of D

    //I
    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(722-moveB,430-moveC);
    glVertex2d(722-moveB,557-moveC);
    glVertex2d(763-moveB,516-moveC);
    glVertex2d(763-moveB,430-moveC);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(cldarkgrey);
    glVertex2d(722-moveB,576-moveC);
    glVertex2d(763-moveB,535-moveC);
    glVertex2d(763-moveB,597-moveC);
    glVertex2d(722-moveB,597-moveC);
    glEnd();
    //end of I
//END OF BOTTOM PART
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160068", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
