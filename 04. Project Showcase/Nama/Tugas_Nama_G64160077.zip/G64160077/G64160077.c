#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

int buff=0, clindex=0;
int i=0,j=0,k=0,a=0,b=0,c=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{

    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void persegi(double x1, double y1, double x2, double y2){
    glBegin(GL_POLYGON);
    glVertex2d(x1,y1);
    glVertex2d(x2,y1);
    glVertex2d(x2,y2);
    glVertex2d(x1,y2);
    glEnd();
}

void A1()
{
    glColor3ub(255,255,255);
    persegi(52,415,148,428);
    persegi(40,428,88,536);
    persegi(112,428,160,536);
    persegi(88,464,112,488);
}

void B()
{
    glColor3ub(255,255,255);
    persegi(184,415,292,536);
    persegi(292,428,304,464);
    persegi(292,488,304,524);
    persegi(232,440,256,464);
    persegi(232,488,256,523);
}

void lubangB()
{
    glColor3ub(0,0,0);
    persegi(232,428,256,464);
    persegi(232,488,256,523);
}

void D()
{
    glColor3ub(255,255,255);
    persegi(328,415,437,536);
    persegi(437,428,449,524);
}

void lubangD()
{
    glColor3ub(0,0,0);
    persegi(376,440,401,512);
}

void U()
{
    glColor3ub(255,255,255);
    persegi(473,415,593,536);
}

void lubangU()
{
    glColor3ub(0,0,0);
    persegi(473,524,485,536);
    persegi(521,415,545,512);
    persegi(581,524,593,536);
}

void L()
{
    glColor3ub(255,255,255);
    persegi(617,415,666,512);
    persegi(617,512,738,536);
}

void A2()
{
    glColor3ub(255,255,255);
    persegi(52,589,148,601);
    persegi(40,601,88,709);
    persegi(112,601,160,709);
    persegi(88,637,112,661);
}

void Z1()
{
    glColor3ub(255,255,255);
    persegi(184,589,304,709);
}

void lubangZ1()
{
    glColor3ub(0,0,0);
    persegi(184,613,256,637);
    persegi(184,637,196,649);

    persegi(292,649,304,661);
    persegi(232,661,304,685);
}

void I()
{
    glColor3ub(255,255,255);
    persegi(328,589,376,709);
}

void Z2()
{
    glColor3ub(255,255,255);
    persegi(401,589,521,709);
}

void lubangZ2()
{
    glColor3ub(0,0,0);
    persegi(401,613,473,637);
    persegi(401,637,413,649);

    persegi(509,649,521,661);
    persegi(449,661,521,685);
}

void selimut()
{

    glColor3ub(136-i,225-j,248-k); //114,195,38(22,30,210)
    persegi(180,172,355,264);
    persegi(199,159,355,172);
}

void selimut2()
{
    glColor3ub(255,255,255);
    persegi(180,264,391,292);
    persegi(355,172,372,265);
    persegi(372,188,391,265);
}

void ranjang()
{
    glColor3ub(137,82,22);
    persegi(180,292,562,322);
    persegi(562,150,592,322);

}

void bantal()
{
    glColor3ub(209,209,209);
    persegi(391,265,562,292);
}

void wajah()
{
    glColor3ub(255,195,130);
    persegi(390,204,442,265);
    persegi(407,188,442,204);
    persegi(424,172,442,188);
    persegi(442,188,460,204);
}

void rambut()
{
    glColor3ub(105,60,0);
    persegi(460,172,509,265);
    persegi(509,172,528,188);
    persegi(509,204,528,265);
}

void display(){
glClear(GL_COLOR_BUFFER_BIT);
     selimut();
    glFlush();
}



int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160077", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        if(a<190){
            a++;i++;k++;
        }

        else if(a>=190){
            i--;j--;k++;
            a++;
            if(a==500){a=0;}
        }
        display();
        A1();
        B();
        lubangB();
        D();
        lubangD();
        U();
        lubangU();
        L();
        A2();
        Z1();
        lubangZ1();
        I();
        Z2();
        lubangZ2();

        selimut2();
        bantal();
        wajah();
        rambut();
        ranjang();



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
