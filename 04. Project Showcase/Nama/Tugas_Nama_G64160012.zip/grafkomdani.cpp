#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT) ;

    glFlush();
}

void bg()
{
    glBegin(GL_POLYGON);

    glColor3ub(255,255,255);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(23,255,255);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();
}

void Rumput()
{
    glBegin(GL_POLYGON);

    glColor3ub(140,255,74);
    glVertex2d(0,675);
    glVertex2d(800,675);
    glColor3ub(0,153,102);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,153,102);
    glVertex2d(0,711);
    glVertex2d(800,711);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

}

/* void Superhero()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(74,280);
    glVertex2d(96,280);
    glVertex2d(96,285);
    glVertex2d(74,285);


    glEnd();
}*/

void Pohon()
{
    glBegin(GL_TRIANGLES);
    glColor3ub(38,145,7);

    glVertex2d(534,605);
    glVertex2d(542,621);
    glVertex2d(525,621);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(38,145,7);

    glVertex2d(529,621);
    glVertex2d(539,621);
    glVertex2d(547,637);
    glVertex2d(521,637);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(38,145,7);

    glVertex2d(525,637);
    glVertex2d(543,637);
    glVertex2d(553,656);
    glVertex2d(514,656);



    glEnd();
//kaki

    glBegin(GL_POLYGON);
    glColor3ub(89,191,46);

    glVertex2d(530,656);
    glVertex2d(537,656);
    glVertex2d(537,676);
    glVertex2d(530,676);





    glEnd();
}

void BrickD()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(21,400);
    glVertex2d(37,400);
    glVertex2d(37,404);
    glVertex2d(21,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(49,400);
    glVertex2d(65,400);
    glVertex2d(65,404);
    glVertex2d(49,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(77,400);
    glVertex2d(94,400);
    glVertex2d(94,404);
    glVertex2d(77,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(105,400);
    glVertex2d(122,400);
    glVertex2d(122,404);
    glVertex2d(105,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(133,430);
    glVertex2d(150,430);
    glVertex2d(150,435);
    glVertex2d(133,435);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(161,460);
    glVertex2d(178,460);
    glVertex2d(178,464);
    glVertex2d(161,464);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(105,610);
    glVertex2d(122,610);
    glVertex2d(122,615);
    glVertex2d(105,615);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(77,640);
    glVertex2d(94,640);
    glVertex2d(94,645);
    glVertex2d(77,645);


    glEnd();
}
void D()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(15,404);
    glVertex2d(128,404);
    glVertex2d(128,435);
    glVertex2d(15,435);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(100,435);
    glVertex2d(156,435);
    glVertex2d(156,464);
    glVertex2d(100,464);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(128,464);
    glVertex2d(184,464);
    glVertex2d(184,615);
    glVertex2d(128,615);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(100,615);
    glVertex2d(156,615);
    glVertex2d(156,645);
    glVertex2d(100,645);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(15,645);
    glVertex2d(128,645);
    glVertex2d(128,675);
    glVertex2d(15,675);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(15,435);
    glVertex2d(71,435);
    glVertex2d(71,645);
    glVertex2d(15,645);

    glEnd();
}

void BrickA()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(277,400);
    glVertex2d(294,400);
    glVertex2d(294,404);
    glVertex2d(277,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(305,400);
    glVertex2d(322,400);
    glVertex2d(322,404);
    glVertex2d(305,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(249,430);
    glVertex2d(265,430);
    glVertex2d(265,435);
    glVertex2d(249,435);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(333,430);
    glVertex2d(350,430);
    glVertex2d(350,435);
    glVertex2d(333,435);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(221,460);
    glVertex2d(237,460);
    glVertex2d(237,464);
    glVertex2d(221,464);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(361,460);
    glVertex2d(378,460);
    glVertex2d(378,464);
    glVertex2d(361,464);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(277,550);
    glVertex2d(294,550);
    glVertex2d(294,555);
    glVertex2d(277,555);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(305,550);
    glVertex2d(322,550);
    glVertex2d(322,555);
    glVertex2d(305,555);


    glEnd();
}

void A()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(271,404);
    glVertex2d(328,404);
    glVertex2d(328,434);
    glVertex2d(271,434);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(243,434);
    glVertex2d(356,434);
    glVertex2d(356,464);
    glVertex2d(243,464);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(215,464);
    glVertex2d(271,464);
    glVertex2d(271,675);
    glVertex2d(215,675);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(328,464);
    glVertex2d(384,464);
    glVertex2d(384,675);
    glVertex2d(328,675);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(271,555);
    glVertex2d(328,555);
    glVertex2d(328,585);
    glVertex2d(271,585);


    glEnd();
}

void BrickN()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(421,400);
    glVertex2d(437,400);
    glVertex2d(437,404);
    glVertex2d(421,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(449,400);
    glVertex2d(465,400);
    glVertex2d(465,404);
    glVertex2d(449,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(561,400);
    glVertex2d(578,400);
    glVertex2d(578,404);
    glVertex2d(561,404);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(477,460);
    glVertex2d(494,460);
    glVertex2d(494,464);
    glVertex2d(477,464);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(505,490);
    glVertex2d(522,490);
    glVertex2d(522,495);
    glVertex2d(505,495);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(533,520);
    glVertex2d(550,520);
    glVertex2d(550,524);
    glVertex2d(533,524);


    glEnd();
}

void N()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(415,404);
    glVertex2d(471,404);
    glVertex2d(471,675);
    glVertex2d(415,675);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(556,404);
    glVertex2d(584,404);
    glVertex2d(584,675);
    glVertex2d(556,675);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(471,464);
    glVertex2d(500,464);
    glVertex2d(500,525);
    glVertex2d(471,525);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(500,495);
    glVertex2d(528,495);
    glVertex2d(528,555);
    glVertex2d(500,555);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(528,524);
    glVertex2d(556,524);
    glVertex2d(556,585);
    glVertex2d(528,585);


    glEnd();
}

void BrickI()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(621,400);
    glVertex2d(637,400);
    glVertex2d(637,405);
    glVertex2d(621,405);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(649,400);
    glVertex2d(665,400);
    glVertex2d(665,405);
    glVertex2d(649,405);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(677,400);
    glVertex2d(694,400);
    glVertex2d(694,405);
    glVertex2d(677,405);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(705,400);
    glVertex2d(722,400);
    glVertex2d(722,405);
    glVertex2d(705,405);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(733,400);
    glVertex2d(750,400);
    glVertex2d(750,405);
    glVertex2d(733,405);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(761,400);
    glVertex2d(778,400);
    glVertex2d(778,405);
    glVertex2d(761,405);


    glEnd();

//kaki

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(621,640);
    glVertex2d(637,640);
    glVertex2d(637,645);
    glVertex2d(621,645);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(649,640);
    glVertex2d(665,640);
    glVertex2d(665,645);
    glVertex2d(649,645);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(733,640);
    glVertex2d(750,640);
    glVertex2d(750,645);
    glVertex2d(733,645);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(761,640);
    glVertex2d(778,640);
    glVertex2d(778,645);
    glVertex2d(761,645);


    glEnd();

}

void I()
{
    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(615,405);
    glVertex2d(784,405);
    glVertex2d(784,435);
    glVertex2d(615,435);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(671,435);
    glVertex2d(728,435);
    glVertex2d(728,645);
    glVertex2d(671,645);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(21,80,255);

    glVertex2d(615,645);
    glVertex2d(784,645);
    glVertex2d(784,675);
    glVertex2d(615,675);


    glEnd();
}

void Sun()
{
    glPushMatrix();
    glTranslated(668,135,0); //bikin muter
    glRotatef((float)glfwGetTime()*25.0f,0.0f,0.0f,1.0f);
    glTranslated(-668,-135,0);

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);

    glVertex2d(593,61);
    glVertex2d(739,61);
    glVertex2d(739,206);
    glVertex2d(593,206);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);

    glVertex2d(639,34);
    glVertex2d(765,107);
    glVertex2d(692,232);
    glVertex2d(567,160);


    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);

    glVertex2d(692,34);
    glVertex2d(765,160);
    glVertex2d(639,232);
    glVertex2d(567,107);


    glEnd();
}


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(8000, 800, "Grid", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        bg(); //Background
        Rumput();
        //Superhero();
        Pohon();
        BrickD(); //Balok Huruf D
        BrickA();
        BrickN();
        BrickI();
        D(); //Huruf D
        A();
        N();
        I();

        Sun();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
