#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int det=0,clindey=0;
int color1[3][3]={{1.0,0.0,1.0},{1.0,0.0,0.0},{0.0,1.0,0.0}};
int color2[3][3]={{1.0,0.0,0.0},{0.0,1.0,0.0},{1.0,0.0,1.0}};
int color3[3][3]={{0.0,1.0,0.0},{1.0,0.0,1.0},{1.0,0.0,0.0}};
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(1, 1, 1, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void setLingkaran(double poX, double poY, double rad){
    double cons=(3.14/100);
    double px,py;
    double posX=poX, posY=poY;
    double radius1=0;
    double radius2=rad;
    glBegin(GL_TRIANGLE_STRIP);
        for(int i=0;i<101;i++){
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px=sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void D(){

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    //luar
    glVertex2d(202,407);
    glVertex2d(202,324);
    glVertex2d(230,324);
    glVertex2d(230,407);

    glEnd();
    setLingkaran(230,366,41);
    glColor3f(1.0,1.0,1.0);

    setLingkaran(230,366,27);
}
void E(){
    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(286,407);
    glVertex2d(286,324);
    glVertex2d(315,324);
    glVertex2d(315,407);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(315,324);
    glVertex2d(369,324);
    glVertex2d(369,340);
    glVertex2d(315,340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(315,357);
    glVertex2d(356,357);
    glVertex2d(356,372);
    glVertex2d(315,372);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(315,391);
    glVertex2d(367,391);
    glVertex2d(367,407);
    glVertex2d(315,407);
    glEnd();
}
void V(){

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(411,407);
    glVertex2d(377,324);
    glVertex2d(403,324);
    glVertex2d(439,407);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(439,407);
    glVertex2d(427,379);
    glVertex2d(454,324);
    glVertex2d(474,324);
    glEnd();
}
void I(){

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(490,407);
    glVertex2d(490,324);
    glVertex2d(514,324);
    glVertex2d(514,407);
    glEnd();
}
void N(){

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(541,407);
    glVertex2d(541,324);
    glVertex2d(567,324);
    glVertex2d(561,351);
    glVertex2d(561,407);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(561,351);
    glVertex2d(567,324);
    glVertex2d(630,407);
    glVertex2d(609,407);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86,0,104);

    glVertex2d(612,407);
    glVertex2d(612,324);
    glVertex2d(630,324);
    glVertex2d(630,407);
    glEnd();
}
void garis1(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,1.0,1.0);

    glVertex2d(70,434);
    glVertex2d(70,423);
    glVertex2d(327,423);
    glVertex2d(327,434);
    glEnd();
}
void garis2(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,1.0,1.0);

    glVertex2d(466,308);
    glVertex2d(466,296);
    glVertex2d(738,296);
    glVertex2d(738,308);
    glEnd();
}
void poli1(){

    glBegin(GL_POLYGON);
    glColor3f(color1[clindey%3][0],color1[clindey%3][1],color1[clindey%3][2]);

    glVertex2d(130,365);
    glVertex2d(82,365);
    glVertex2d(58,324);
    glVertex2d(82,281);
    glVertex2d(130,281);
    glVertex2d(154,324);
    glEnd();
}
void poli2(){

    glBegin(GL_POLYGON);
    glColor3f(color2[clindey%3][0],color2[clindey%3][1],color2[clindey%3][2]);


    glVertex2d(196,313);
    glVertex2d(155,313);
    glVertex2d(133,280);
    glVertex2d(153,244);
    glVertex2d(193,244);
    glVertex2d(216,280);
    glEnd();
}
void poli3(){

    glBegin(GL_POLYGON);
    glColor3f(color3[clindey%3][0],color3[clindey%3][1],color3[clindey%3][2]);

    glVertex2d(130,276);
    glVertex2d(82,276);
    glVertex2d(58,235);
    glVertex2d(82,194);
    glVertex2d(130,194);
    glVertex2d(154,235);
    glEnd();
}
void bingkai1(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,0.0,1.0);

    glVertex2d(32,782);
    glVertex2d(19,782);
    glVertex2d(19,24);
    glVertex2d(32,24);
    glEnd();
}
void bingkai2(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,0.0,1.0);

    glVertex2d(32,39);
    glVertex2d(32,24);
    glVertex2d(768,24);
    glVertex2d(768,39);
    glEnd();
}
void bingkai3(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,0.0,1.0);

    glVertex2d(768,782);
    glVertex2d(781,782);
    glVertex2d(781,24);
    glVertex2d(768,24);
    glEnd();
}
void bingkai4(){

    glBegin(GL_POLYGON);
    glColor3f(0.0,0.0,1.0);

    glVertex2d(768,782);
    glVertex2d(768,767);
    glVertex2d(32,767);
    glVertex2d(32,782);
    glEnd();
}
void jalan(){
    glBegin(GL_POLYGON);
    glColor3f(0.3244,0.3111,0.2711);

    glVertex2d(32,770);
    glVertex2d(32,732);
    glVertex2d(768,732);
    glVertex2d(768,770);
    glEnd();
}
void gj1(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(137,755);
    glVertex2d(137,747);
    glVertex2d(53,747);
    glVertex2d(53,755);
    glEnd();
}
void gj2(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(300,755);
    glVertex2d(300,747);
    glVertex2d(216,747);
    glVertex2d(216,755);
    glEnd();
}
void gj3(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(468,755);
    glVertex2d(468,747);
    glVertex2d(384,747);
    glVertex2d(384,755);
    glEnd();
}
void gj4(){
    glBegin(GL_POLYGON);
    glColor3f(1.0,1.0,1.0);

    glVertex2d(655,755);
    glVertex2d(655,747);
    glVertex2d(571,747);
    glVertex2d(571,755);
    glEnd();
}
void rumput(){
    glBegin(GL_POLYGON);
    glColor3f(0.5111,0.8489,0.3022);

    glVertex2d(31,733);
    glVertex2d(31,718);
    glVertex2d(769,718);
    glVertex2d(769,733);
    glEnd();
}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Devin", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(det==0){
            clindey++;
        }
        det++;
        det=det%100;
        setup_viewport(window);
        D();
        E();
        V();
        I();
        N();
        garis1();
        garis2();
        poli1();
        poli2();
        poli3();
        bingkai1();
        bingkai2();
        bingkai3();
        bingkai4();
        jalan();
        gj1();
        gj2();
        gj3();
        gj4();
        rumput();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
