#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define putih 255,255,255
#define birumuda 111,214,233
#define birutua 54,75,161
#define pink 237,34,144
#define coklat 128,64,0
#define marun 128,0,0
#define merah 238,37,36
#define hijau 27,159,73


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods){
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window){
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);

    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 600, 600, 0, 0, -1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display(){
    // your drawing code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);

    //background
    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(0, 0);
    glColor3ub(putih);
    glVertex2d(0,600);
    glColor3ub(putih);
    glVertex2d(600, 600);
    glColor3ub(birumuda);
    glVertex2d(600, 0);
    glEnd();

    glFlush();
}

void persegi1(){
    glBegin(GL_POLYGON);
    glColor3ub(hijau);
    glVertex2d(23, 584);
    glVertex2d(23, 383);
    glVertex2d(575, 383);
    glVertex2d(575, 584);
    glEnd();
}

void persegi2(){
    glBegin(GL_POLYGON);
    glColor3ub(merah);
    glVertex2d(113, 230);
    glVertex2d(484, 230);
    glVertex2d(575, 383);
    glVertex2d(204, 383);
    glEnd();
}

void segitiga(){
    glBegin(GL_TRIANGLES);
    glColor3ub(coklat);
    glVertex2d(23, 383);
    glVertex2d(113,230);
    glVertex2d(204, 383);
    glEnd();
}

void segitiga1(){
    glBegin(GL_TRIANGLES);
    glColor3ub(139,69,19);
    glVertex2d(52, 383);
    glVertex2d(128,253);
    glVertex2d(204, 383);
    glEnd();
}
/*
void lingkaran(double poX, double poY, double rad){
    double cons=(3.14/100)*2;
    double px, py;
    double posX=poX, posY=poY;
    double radius1=0;
    double radius2=rad;
    glColor3ub(merah);
    glBegin(GL_TRIANGLE_STRIP);
        for (int i=0; i<=100; i++){
            px=sin(1*cons)*radius1+posX;
            px=cos(1*cons)*radius1+posY;
            glVertex2f(px*10,py*10);
            px=sin(1*cons)*radius2+posX;
            px=cos(1*cons)*radius2+posY;
            glVertex2f(px*10,py*10);
        }
    glEnd();
}
*/
void L1(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(53,548);
    glColor3ub(birutua);
    glVertex2d(53,436);
    glColor3ub(birumuda);
    glVertex2d(103,436);
    glColor3ub(birumuda);
    glVertex2d(103,519);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(103,519);
    glColor3ub(birumuda);
    glVertex2d(146,519);
    glColor3ub(birumuda);
    glVertex2d(146,548);
    glColor3ub(birutua);
    glVertex2d(53,548);
    glEnd();
}

void L2(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(230,548);
    glColor3ub(birutua);
    glVertex2d(230,436);
    glColor3ub(birumuda);
    glVertex2d(279,436);
    glColor3ub(birumuda);
    glVertex2d(279,519);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(279,519);
    glColor3ub(birumuda);
    glVertex2d(323,519);
    glColor3ub(birumuda);
    glVertex2d(323,548);
    glColor3ub(birutua);
    glVertex2d(230,548);
    glEnd();
}

void I1(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(159,548);
    glColor3ub(birutua);
    glVertex2d(159,436);
    glColor3ub(birumuda);
    glVertex2d(208,436);
    glColor3ub(birumuda);
    glVertex2d(208,548);
    glEnd();
}

void I2(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(335,548);
    glColor3ub(birutua);
    glVertex2d(335,436);
    glColor3ub(birumuda);
    glVertex2d(385,436);
    glColor3ub(birumuda);
    glVertex2d(385,548);
    glEnd();
}

void H(){
    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(406,548);
    glColor3ub(birutua);
    glVertex2d(406,436);
    glColor3ub(birumuda);
    glVertex2d(456,436);
    glColor3ub(birumuda);
    glVertex2d(456,548);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(birumuda);
    glVertex2d(456,477);
    glColor3ub(birumuda);
    glVertex2d(481,477);
    glColor3ub(birumuda);
    glVertex2d(481,506);
    glColor3ub(birutua);
    glVertex2d(406,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(birutua);
    glVertex2d(481,548);
    glColor3ub(birutua);
    glVertex2d(481,436);
    glColor3ub(birumuda);
    glVertex2d(530,436);
    glColor3ub(birumuda);
    glVertex2d(530,548);
    glEnd();
}

int main(void){
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(600, 600, "Tugas Nama", NULL, NULL);

    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    while (!glfwWindowShouldClose(window)){
        setup_viewport(window);

        display();
        persegi1();
        persegi2();
        segitiga();
        segitiga1();


        //panggil fungsi nama
        L1();
        I1();
        L2();
        I2();
        H();
        //lingkaran(600,0,100);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
