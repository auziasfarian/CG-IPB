#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
const double PI = 3.141592653589793;

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{

if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}



int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(640, 480, "G64160037 - Putri Ardi - Tugas Nama", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
float radius;
int i;
float ratio, x_tengah, y_tengah, jumlah_titik,m,l;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();

glEnable(GL_BLEND);
glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

glOrtho(-ratio, ratio, -1.f, 1.f, 1.f, -1.f);           // kemiringan bidang
glColor3f(1.f, 0.f, 0.f);           //warna merah
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
glRotatef((float) glfwGetTime() * 0.f, 0.f, 0.f, 1.f); //ntuk perputaran object


//Background
glBegin(GL_POLYGON);
glColor4ub(247, 158, 176, 255);
glVertex3f(-1.4f, 1.f, 0.f);
glVertex3f(1.4f, 1.f, 0.f);
glVertex3f(1.4f, -1.f, 0.f);
glVertex3f(-1.4f, -1.f, 0.f);
glEnd();


glBegin(GL_TRIANGLES);
glColor4ub(0, 209, 216, 250);
glVertex3f(-0.1f, -1.f, 0.f);
glVertex3f(1.4f, -1.f, 0.f);
glVertex3f(1.4f, 0.2f, 0.f);
glEnd();

for(m=1.4; m>=-0.2; m=m-0.02){
    for(l=0.3; l>=-1; l=l-0.02){
        glBegin(GL_POINTS);
        glPointSize(0.1f);
        glColor4ub(0, 0, 0, 1000);
        glVertex3f(m, l, 0.f);
        glVertex3f((m-0.01), l, 0.f);
        glVertex3f((m-0.01), (l-0.01), 0.f);
        glVertex3f(m, (l-0.01), 0.f);
        glEnd();
    }
}

glBegin(GL_TRIANGLES);
glColor4ub(247, 158, 176, 250);
glVertex3f(-0.25f, 0.4f, 0.f);
glVertex3f(-0.25f, -1.f, 0.f);
glVertex3f(1.4f, 0.3f, 0.f);
glEnd();

glBegin(GL_TRIANGLES);
glColor4ub(0, 209, 216, 250);
glVertex3f(0.06f, -1.f, 0.f);
glVertex3f(1.4f, -1.f, 0.f);
glVertex3f(1.4f, 0.08f, 0.f);
glEnd();


//Buletan
glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);              //warna biru

    radius = 2;
    jumlah_titik = 370;
    x_tengah = 95;
    y_tengah = 5;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

glBegin(GL_POLYGON);
glColor4ub(9, 156, 229, 250);              //warna biru

    radius = 2;
    jumlah_titik = 370;
    x_tengah = 80;
    y_tengah = -3;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();


glBegin(GL_POLYGON);
glColor4ub(64, 83, 229, 250);              //warna biru

    radius = 5;
    jumlah_titik = 500;
    x_tengah = 90;
    y_tengah = 85;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

glBegin(GL_POLYGON);
glColor4ub(247, 158, 176, 255);              //warna biru

    radius = 4;
    jumlah_titik = 500;
    x_tengah = 90;
    y_tengah = 85;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

//Segi empat
glBegin(GL_POLYGON);
glColor4ub(226, 81, 160, 250);
glVertex3f(-1.18f, 1.f, 0.f);
glVertex3f(-1.15f, 1.f, 0.f);
glVertex3f(-1.15f, 0.85f, 0.f);
glVertex3f(-1.18f, 0.85f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(247, 158, 176, 255);
glVertex3f(-1.17f, 1.f, 0.f);
glVertex3f(-1.16f, 1.f, 0.f);
glVertex3f(-1.16f, 0.86f, 0.f);
glVertex3f(-1.17f, 0.86f, 0.f);
glEnd();


for(m=-50; m>=-78; m=m-7){
for(l=-75; l>=-103; l=l-7){
glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);              //warna biru
    radius = 1.1;
    jumlah_titik = 370;
    x_tengah = l;
    y_tengah = m;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();}}

glPushMatrix();
glRotatef((float) glfwGetTime() * 100.f, 0.f, 10.f, 0.f);
//bulet bulet
glBegin(GL_POLYGON);
glColor4ub(216, 91, 91, 180);              //warna biru
    radius = 3.5;
    jumlah_titik = 470;
    x_tengah = -25;
    y_tengah = -40;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 250);              //warna biru
    radius = 2;
    jumlah_titik = 470;
    x_tengah = -35;
    y_tengah = -20;
    for(i=50; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef((float) glfwGetTime() * 200.f, -0.9f, -0.13f, 0.f);
//Z
glBegin(GL_POLYGON);
glColor4ub(76, 69, 73, 250);
glVertex3f(-0.9f, -0.13f, 0.f);
glVertex3f(-0.92f, -0.1f, 0.f);
glVertex3f(-0.99f, -0.17f, 0.f);
glVertex3f(-0.97f, -0.2f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(76, 69, 73, 250);
glVertex3f(-0.9f, -0.13f, 0.f);
glVertex3f(-0.87f, -0.1f, 0.f);
glVertex3f(-0.96f, -0.01f, 0.f);
glVertex3f(-0.99f, -0.04f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(76, 69, 73, 250);
glVertex3f(-0.93f, -0.29f, 0.f);
glVertex3f(-0.9f, -0.26f, 0.f);
glVertex3f(-0.99f, -0.17f, 0.f);
glVertex3f(-1.02f, -0.2f, 0.f);
glEnd();

//Z bayangan
glBegin(GL_POLYGON);
glColor4ub(0, 209, 216, 250);
glVertex3f(-0.92f, -0.13f, 0.f);
glVertex3f(-0.94f, -0.1f, 0.f);
glVertex3f(-1.01f, -0.17f, 0.f);
glVertex3f(-0.99f, -0.2f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(0, 209, 216, 250);
glVertex3f(-0.92f, -0.13f, 0.f);
glVertex3f(-0.89f, -0.1f, 0.f);
glVertex3f(-0.98f, -0.01f, 0.f);
glVertex3f(-1.01f, -0.04f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(0, 209, 216, 250);
glVertex3f(-0.95f, -0.29f, 0.f);
glVertex3f(-0.92f, -0.26f, 0.f);
glVertex3f(-1.01f, -0.17f, 0.f);
glVertex3f(-1.04f, -0.2f, 0.f);
glEnd();
glPopMatrix();

glRotatef((float) glfwGetTime() * 50.f, 0.f, 10.f, 0.f);
//LOVE
glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.f, 0.3f, 0.f);
glVertex3f(1.03f, 0.33f, 0.f);
glVertex3f(1.06f, 0.29f, 0.f);
glVertex3f(1.06f, 0.24f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.06f, 0.24f, 0.f);
glVertex3f(1.06f, 0.29f, 0.f);
glVertex3f(1.09f, 0.33f, 0.f);
glVertex3f(1.12f, 0.3f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.f, 0.4f, 0.f);
glVertex3f(1.03f, 0.43f, 0.f);
glVertex3f(1.06f, 0.39f, 0.f);
glVertex3f(1.06f, 0.34f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.06f, 0.34f, 0.f);
glVertex3f(1.06f, 0.39f, 0.f);
glVertex3f(1.09f, 0.43f, 0.f);
glVertex3f(1.12f, 0.4f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.f, 0.5f, 0.f);
glVertex3f(1.03f, 0.53f, 0.f);
glVertex3f(1.06f, 0.49f, 0.f);
glVertex3f(1.06f, 0.44f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.06f, 0.44f, 0.f);
glVertex3f(1.06f, 0.49f, 0.f);
glVertex3f(1.09f, 0.53f, 0.f);
glVertex3f(1.12f, 0.5f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.f, 0.6f, 0.f);
glVertex3f(1.03f, 0.63f, 0.f);
glVertex3f(1.06f, 0.59f, 0.f);
glVertex3f(1.06f, 0.54f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.06f, 0.54f, 0.f);
glVertex3f(1.06f, 0.59f, 0.f);
glVertex3f(1.09f, 0.63f, 0.f);
glVertex3f(1.12f, 0.6f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.f, 0.7f, 0.f);
glVertex3f(1.03f, 0.73f, 0.f);
glVertex3f(1.06f, 0.69f, 0.f);
glVertex3f(1.06f, 0.64f, 0.f);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(255, 255, 255, 255);
glVertex3f(1.06f, 0.64f, 0.f);
glVertex3f(1.06f, 0.69f, 0.f);
glVertex3f(1.09f, 0.73f, 0.f);
glVertex3f(1.12f, 0.7f, 0.f);
glEnd();


//P garis kiri
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biruush
glVertex3f(-1.115f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.99f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-1.115f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-1.115f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.99f, 0.7f, 0.f);
glEnd();

//P lengkung
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19;
    jumlah_titik = 348;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.2;
    jumlah_titik = 345;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.4;
    jumlah_titik = 344;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.6;
    jumlah_titik = 340;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.55*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.8;
    jumlah_titik = 338;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20;
    jumlah_titik = 338;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20.2;
    jumlah_titik = 338;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20.4;
    jumlah_titik = 335;
    x_tengah = -95;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

//P garis kanan
glBegin(GL_POLYGON);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.99f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.32f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.97f, 0.045f, 0.f);

glEnd();
glBegin(GL_TRIANGLES);

glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.32f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.97f, 0.045f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.97f, 0.3f, 0.f);
glEnd();

//P lengkung dalam
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru

    radius = 7.5;
    jumlah_titik = 370;
    x_tengah = -95;
    y_tengah = 50;
    for(i=185; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

//P daris dalam lengkung
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.435f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.57f, 0.f);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.435f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.99f, 0.563f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.97f, 0.5715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.97f, 0.425f, 0.f);

glEnd();


//P bayangan atas
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-1.115f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-1.09f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.7f, 0.f);
glEnd();
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.96f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-1.09f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.7f, 0.f);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.99f, 0.684f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.96f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.96f, 0.715f, 0.f);
glEnd();


//U garis kiri
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.715f, 0.19f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.715f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.585f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.585f, 0.25f, 0.f);
glEnd();
//U garis kanan dalam
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.43f, 0.21f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.43f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.19f, 0.f);
glEnd();
//U lengkung dalam
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 7.9;
    jumlah_titik = 366;
    x_tengah = -50.54;
    y_tengah = 22.5;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.9505*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 7.8;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 7.95;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.48*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.1;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.49*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.3;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.48*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.5;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.4*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.7;
    jumlah_titik = 300;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.35*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.9;
    jumlah_titik = 250;
    x_tengah = -49.02;
    y_tengah = 22.7;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.15*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 10;
    jumlah_titik = 300;
    x_tengah = -48.19;
    y_tengah =24;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.25*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 7.6;
    jumlah_titik = 366;
    x_tengah = -50.54;
    y_tengah = 22.5;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.5505*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 7.7;
    jumlah_titik = 366;
    x_tengah = -50.54;
    y_tengah = 22.5;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.5505*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();


//U lengkung luar
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 21;
    jumlah_titik = 360;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 21.2;
    jumlah_titik = 245;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 21.4;
    jumlah_titik = 240;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 21.6;
    jumlah_titik = 235;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 21.8;
    jumlah_titik = 235;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 22;
    jumlah_titik = 233;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 22.2;
    jumlah_titik = 230;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 22.4;
    jumlah_titik = 220;
    x_tengah = -50.595;
    y_tengah = 23;
    for(i=196; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.95*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 8.4;
    jumlah_titik = 219;
    x_tengah = -45.595;
    y_tengah = 10.5;
    for(i=186; i<=jumlah_titik; i++)
    {
        float sudut=i*(1.69*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();


//U bayangan kiri atas
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.72f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.695f, 0.717f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.59f, 0.7f, 0.f);
glEnd();

glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.57f, 0.717f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.695f, 0.717f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.59f, 0.7f, 0.f);
glEnd();

//U bayangan kiri dalam
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.565f, 0.717f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.585f, 0.19f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.585f, 0.7f, 0.f);
glEnd();

glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.565f, 0.717f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.585f, 0.19f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.565f, 0.19f, 0.f);
glEnd();

//U bayangan kanan atas
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.43f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.4f, 0.715f, 0.f);
glEnd();

glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.28f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.4f, 0.715f, 0.f);
glEnd();

//U kanan bayangan luar
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.28f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.19f, 0.f);
glEnd();

glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.28f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.28f, 0.19f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.3f, 0.19f, 0.f);
glEnd();


//T garis
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.105f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.02f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.105f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.105f, 0.6f, 0.f);
glColor4ub(0, 51, 181, 180);
glVertex3f(-0.245f, 0.6f, 0.f);
glColor4ub(0, 51, 181, 180);
glVertex3f(-0.245f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);
glVertex3f(0.16f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);
glVertex3f(0.16f, 0.6f, 0.f);
glColor4ub(0, 51, 181, 180);
glVertex3f(0.02f, 0.6f, 0.f);
glEnd();


//T bayangan vertikal
glBegin(GL_POLYGON);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.02f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.02f, 0.6f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.04f, 0.045f, 0.f);

glEnd();
glBegin(GL_TRIANGLES);

glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.02f, 0.6f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.04f, 0.045f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.04f, 0.6f, 0.f);
glEnd();

//T bayangan samping atas
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.16f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.18f, 0.715f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.18f, 0.615f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.16f, 0.6f, 0.f);
glEnd();

//T bayangan horizontal
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(-0.245f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.21f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.16f, 0.7f, 0.f);
glEnd();
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.18f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(-0.21f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.16f, 0.7f, 0.f);
glEnd();



//R garis kiri
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.215f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.215f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.34f, 0.684f, 0.f);
glEnd();
//R lengkung luar
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19;
    jumlah_titik = 348;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.2;
    jumlah_titik = 345;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.4;
    jumlah_titik = 344;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.57*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.6;
    jumlah_titik = 340;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.55*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 19.8;
    jumlah_titik = 338;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20;
    jumlah_titik = 338;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20.2;
    jumlah_titik = 338;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
    radius = 20.4;
    jumlah_titik = 335;
    x_tengah = 38;
    y_tengah = 50;
    for(i=195; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.53*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

//R garis miring
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.215f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.34f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.18f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.46f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.58f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.35f, 0.31f, 0.f);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.58f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.35f, 0.31f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.373f, 0.31f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.58f, 0.058f, 0.f);

glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.34f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.18f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.36f, 0.045f, 0.f);

glEnd();
glBegin(GL_TRIANGLES);

glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.18f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.36f, 0.045f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.36f, 0.16f, 0.f);
glEnd();

//R lengkung dalam
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru

    radius = 7.5;
    jumlah_titik = 370;
    x_tengah = 38;
    y_tengah = 50;
    for(i=185; i<=jumlah_titik; i++)
    {
        float sudut=i*(2.67*PI/jumlah_titik);
        float x=x_tengah+radius*cos(sudut);
        float y=y_tengah+radius*sin(sudut);
        glVertex2f(x/100,y/100);
    }
glEnd();

//R garis dalam
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.435f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.57f, 0.f);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.435f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.34f, 0.563f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.36f, 0.5715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.36f, 0.425f, 0.f);

glEnd();


//R bayangan atas
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.215f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.24f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.7f, 0.f);
glEnd();
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.37f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.24f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.7f, 0.f);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.34f, 0.684f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.37f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.37f, 0.715f, 0.f);
glEnd();


//I
glBegin(GL_LINE_STRIP);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.615f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.74f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.615f, 0.03f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.615f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.74f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glEnd();

//I bayangan samping
glBegin(GL_POLYGON);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.74f, 0.03f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.76f, 0.045f, 0.f);

glEnd();
glBegin(GL_TRIANGLES);

glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.76f, 0.045f, 0.f);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.76f, 0.72f, 0.f);
glEnd();

//I bayangan atas
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.615f, 0.7f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.635f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glEnd();
glBegin(GL_TRIANGLES);
glColor4ub(0, 243, 251, 250);           //warna putih
glVertex3f(0.76f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.635f, 0.715f, 0.f);
glColor4ub(0, 51, 181, 180);              //warna biru
glVertex3f(0.74f, 0.7f, 0.f);
glEnd();




glfwSwapBuffers(window);
glfwPollEvents();

}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
