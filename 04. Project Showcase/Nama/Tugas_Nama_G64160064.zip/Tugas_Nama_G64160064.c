#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


int clindex=0;int buff=0;int clindex2=0;int buff2=0;
int colorf[3][3]={{225,225,2},{225,2,2},{2,2,225}};
int color2[3][3]={{100,100,115},{120,120,135},{140,140,140}};
double animationInterval = 0.05; float gerak = 0; float angle =0.0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void animate(){
if(gerak<=49)
gerak += 1;
else gerak = 0;
}
void display()
{
 glClear(GL_COLOR_BUFFER_BIT);

 glFlush();   // your code here, maybe
 glPushMatrix();
    glTranslatef(0,gerak,0);
    bg();
    glPopMatrix();

}
void BG(){

    glBegin(GL_POLYGON);

   glColor3ub(255,255,255);

               glVertex2d(0,0);
        glVertex2d(0,800);
        glVertex2d(800,800);
        glVertex2d(800,0);

    glEnd();
}
void bg()
{


    int i=0; int j = 0;



while (i!=800){
        glBegin(GL_POLYGON);

glColor3ub(color2[clindex2%3][2],color2[clindex2%3][0],color2[clindex2%3][2]);
        glVertex2d(0,i);
        glVertex2d(0,i+15);
        glVertex2d(800,i+15);
        glVertex2d(800,i);

        i=i+50;
        glEnd();
}

}



void A()
{
    glBegin(GL_POLYGON);

    glColor3ub(colorf[clindex%3][0],colorf[clindex%3][1],colorf[clindex%3][2]);

        glVertex2d(148,152);
        glVertex2d(215,301);
        glVertex2d(184,301);
        glVertex2d(173,279);
        glVertex2d(148,279);
        glVertex2d(148,256);
        glVertex2d(162,256);
        glVertex2d(148,217);
        glVertex2d(119,217);

    glEnd();



    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

        glVertex2d(148,217);
        glVertex2d(148,256);
        glVertex2d(162,256);



    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

        glVertex2d(148,313);
        glVertex2d(215,461);
        glVertex2d(184,461);
        glVertex2d(173,439);
        glVertex2d(91,439);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

        glVertex2d(148,383);
        glVertex2d(135,413);
        glVertex2d(162,413);


    glEnd();



     glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

        glVertex2d(148,472);
        glVertex2d(215,620);
        glVertex2d(184,620);
        glVertex2d(173,598);
        glVertex2d(124,598);
        glVertex2d(114,620);
        glVertex2d(82,620);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,0,0);

        glVertex2d(148,542);
        glVertex2d(135,572);
        glVertex2d(162,572);


    glEnd();
}

void LingkaranR(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<101;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void R()//segitiga bawah
{

    glBegin(GL_POLYGON);

   glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

        glVertex2d(297,249);
        glVertex2d(297,301);
        glVertex2d(334,301);
        glVertex2d(301,249);

    glEnd();

 glBegin(GL_POLYGON);

  glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

        glVertex2d(227,182);
        glVertex2d(227,155);
        glVertex2d(297,159);
        glVertex2d(297,182);

    glEnd();


     glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

        glVertex2d(227,315);
        glVertex2d(280,315);
        glVertex2d(280,394);
        glVertex2d(227,394);

    glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

        glVertex2d(301,408);
        glVertex2d(301,461);
        glVertex2d(334,461);

    glEnd();




     glBegin(GL_POLYGON);

 glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

        glVertex2d(227,475);
        glVertex2d(260,479);
        glVertex2d(260,567);
        glVertex2d(334,620);
        glVertex2d(298,620);
        glVertex2d(257,556);
        glVertex2d(257,620);
        glVertex2d(227,620);

    glEnd();

 glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        LingkaranR(260,523,44);


    glColor3b(0,0,0);
        LingkaranR(260,523,20);


     glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        LingkaranR(275,355,39);


    glColor3b(0,0,0);
        LingkaranR(275,355,21);


}


void I()
{
    glBegin(GL_POLYGON);

    glColor3ub(colorf[clindex%3][0],colorf[clindex%3][1],colorf[clindex%3][2]);

        glVertex2d(346,155);
        glVertex2d(376,155);
        glVertex2d(376,191);
        glVertex2d(346,191);


    glEnd();

     glBegin(GL_POLYGON);

    glColor3ub(colorf[clindex%3][0],colorf[clindex%3][1],colorf[clindex%3][2]);

        glVertex2d(683,155);
        glVertex2d(713,155);
        glVertex2d(713,193);
        glVertex2d(683,193);

    glEnd();

    glBegin(GL_POLYGON);

   glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

        glVertex2d(346,315);
        glVertex2d(376,315);
        glVertex2d(376,412);
        glVertex2d(346,412);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

        glVertex2d(683,315);
        glVertex2d(713,315);
        glVertex2d(713,414);
        glVertex2d(683,414);

    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

        glVertex2d(346,473);
        glVertex2d(376,473);
        glVertex2d(376,620);
        glVertex2d(346,620);

    glEnd();

       glBegin(GL_POLYGON);
      glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

        glVertex2d(683,473);
        glVertex2d(713,473);
        glVertex2d(713,620);
        glVertex2d(683,620);

    glEnd();
}

void N()
{
        glBegin(GL_POLYGON);

  glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

        glVertex2d(548,152);
        glVertex2d(612,213);
        glVertex2d(576,213);
        glVertex2d(576,301);
        glVertex2d(548,301);


    glEnd();

    glBegin(GL_POLYGON);

     glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

        glVertex2d(637,154);
        glVertex2d(666,154);
        glVertex2d(666,304);
        glVertex2d(637,275);


    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);


        glVertex2d(548,313);
        glVertex2d(640,406);
        glVertex2d(605,406);
        glVertex2d(577,380);
        glVertex2d(577,461);
        glVertex2d(548,461);


    glEnd();


     glBegin(GL_POLYGON);

     glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);


        glVertex2d(637,315);
        glVertex2d(666,315);
        glVertex2d(666,464);
        glVertex2d(640,439);


    glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

        glVertex2d(548,471);
        glVertex2d(637,555);
        glVertex2d(637,471);
        glVertex2d(666,474);
        glVertex2d(666,623);
        glVertex2d(576,538);
        glVertex2d(576,620);
        glVertex2d(548,620);

    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);

        glVertex2d(548,471);
        glVertex2d(637,555);
        glVertex2d(637,471);

    glEnd();
    }


void LingkaranQ(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<202;i++)
        {
            px = cos(i*cons)*radius1+posX;
            py = sin(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = cos(i*cons)*radius2+posX;
            py = sin(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void Lingkaranseto(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<122;i++)
        {
            px = cos(i*cons)*radius1+posX;
            py = sin(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = cos(i*cons)*radius2+posX;
            py = sin(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void Lingkaranseto2(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<90;i++)
        {
            px = cos(i*cons)*radius1+posX;
            py = sin(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = cos(i*cons)*radius2+posX;
            py = sin(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}


void O(){

//BAris 3
   glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        LingkaranQ(462,547,80);

    glColor3b(0,0,0);
        LingkaranQ(462,547,45);
//baris 2
 glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        LingkaranQ(462,382,80);

    glColor3b(0,0,0);
        LingkaranQ(462,382,45);
//baris 3
glColor3ub(0,0,0);
        Lingkaranseto2(462,382,80);

    glColor3b(0,0,0);
        Lingkaranseto2(462,382,45);



//baris 1
 glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
        LingkaranQ(462,220,80);

    glColor3b(0,0,0);
        LingkaranQ(462,220,45);

//baris 1
glColor3ub(0,0,0);
        Lingkaranseto(462,220,80);

   // glColor3b(0,0,0);

}

void animate2(){
angle -=6;
}

void animateO(){
    glRotatef(angle, 0.f, 0.f, 1.f);
 glColor3f(1.f, 0.f, 0.f);
Lingkaranseto(462,220,45);
}


int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160064>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
int ticks =0;
int ticks2 =0;


    while (!glfwWindowShouldClose(window))
    {

        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%135;
        if(buff2==0){
            clindex2++;
        }
        buff2++;
        buff2=buff2%75;
        setup_viewport(window);


double currentTime = glfwGetTime();
while (currentTime / animationInterval > ticks) {

animate();
 ticks++;
 currentTime = glfwGetTime();
 }


    display();
    N();O();A();I();R();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
