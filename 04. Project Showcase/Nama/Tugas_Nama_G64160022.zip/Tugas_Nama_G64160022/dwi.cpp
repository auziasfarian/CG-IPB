#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

int clindex=0,buff=0;
int colorf[3][3]={{39,102,160},{30,28,124},{82,78,234}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);//(0,800,0,800)
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
void kotak(){
    glBegin(GL_POLYGON);
    glColor3ub(117,28,181);
    glVertex2d(800,800);
    glColor3ub(177,79,247);
    glVertex2d(0,800);
    glColor3ub(198,139,239);
    glVertex2d(0,0);
    //glColor3ub(242,164,61);
    glVertex2d(800,0);
    glEnd();
}

/*void kotak(){
    glBegin(GL_POLYGON);
    glColor3ub(90,63,55);
    glVertex2d(0,0);
    glColor3ub(44,119,68);
    glVertex2d(400,0);
    glVertex2d(400,400);
    glVertex2d(0,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(241,242,181);
    glVertex2d(800,400);
    glColor3ub(19,80,88);
    glVertex2d(400,400);
    glVertex2d(400,0);
    glVertex2d(800,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(29,67,80);
    glVertex2d(800,800);
    glColor3ub(164,57,49);
    glVertex2d(400,800);
    glVertex2d(400,400);
    glVertex2d(800,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(29,67,80);
    glVertex2d(400,800);
    glColor3ub(164,57,49);
    glVertex2d(0,800);
    glVertex2d(0,400);
    glVertex2d(400,400);
    glEnd();
}*/
void kotak1() {
    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(118,478);
    glColor3ub(39,102,160);
    glVertex2d(80,488);
    glVertex2d(118,438);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(163,494);
    glColor3ub(39,102,160);
    glVertex2d(125,482);
    glVertex2d(127,442);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(209,488);
    glColor3ub(39,102,160);
    glVertex2d(170,497);
    glVertex2d(209,448);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(255,511);
    glColor3ub(39,102,160);
    glVertex2d(217,500);
    glVertex2d(219,460);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(288,478);
    glColor3ub(39,102,160);
    glVertex2d(250,488);
    glVertex2d(288,438);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(334,503);
    glColor3ub(39,102,160);
    glVertex2d(296,492);
    glVertex2d(298,452);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(368,470);
    glColor3ub(39,102,160);
    glVertex2d(329,478);
    glVertex2d(368,430);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(377,452);
    glColor3ub(39,102,160);
    glVertex2d(375,492);
    glVertex2d(377,452);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(413,503);
    glColor3ub(39,102,160);
    glVertex2d(375,492);
    glVertex2d(377,452);
    glEnd();

}

void kotak2() {
    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(686,223);
    glColor3ub(39,102,160);
    glVertex2d(648,212);
    glVertex2d(650,172);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(637,190);
    glColor3ub(39,102,160);
    glVertex2d(599,199);
    glVertex2d(637,150);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(609,229);
    glColor3ub(39,102,160);
    glVertex2d(571,217);
    glVertex2d(573,178);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(564,195);
    glColor3ub(39,102,160);
    glVertex2d(526,204);
    glVertex2d(564,155);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(518,205);
    glColor3ub(39,102,160);
    glVertex2d(481,194);
    glVertex2d(482,154);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(473,209);
    glColor3ub(39,102,160);
    glVertex2d(435,219);
    glVertex2d(473,170);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(437,196);
    glColor3ub(39,102,160);
    glVertex2d(400,184);
    glVertex2d(401,145);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(388,200);
    glColor3ub(39,102,160);
    glVertex2d(350,209);
    glVertex2d(388,160);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(413,503);
    glColor3ub(39,102,160);
    glVertex2d(375,492);
    glVertex2d(377,452);
    glEnd();

}

void kotak3() {
    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(230,52);
    glColor3ub(39,102,160);
    glVertex2d(20,52);
    glVertex2d(20,25);
    glVertex2d(230,25);
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(230,52);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(20,52);
    glVertex2d(20,25);
    glVertex2d(230,25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(47,246);
    glColor3ub(39,102,160);
    glVertex2d(20,246);
    glVertex2d(20,52);
    glVertex2d(47,52);
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(20,52);
    glVertex2d(47,246);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(20,52);
    glVertex2d(20,246);
    glVertex2d(20,52);
    glVertex2d(47,52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(779,782);
    glColor3ub(39,102,160);
    glVertex2d(568,782);
    glVertex2d(568,754);
    glVertex2d(779,754);
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(779,782);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(568,782);
    glVertex2d(568,754);
    glVertex2d(779,754);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(779,754);
    glColor3ub(39,102,160);
    glVertex2d(751,754);
    glVertex2d(751,560);
    glVertex2d(779,560);
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(779,754);
    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(751,754);
    glVertex2d(751,560);
    glVertex2d(779,560);
    glEnd();

}

void S (){
    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(155,291);
    glColor3ub(14,17,16);
    glVertex2d(141,291);
    glColor3ub(39,51,46);
    glVertex2d(141,247);
    glColor3ub(104,98,91);
    glVertex2d(155,246);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(141,247);
    glColor3ub(14,17,16);
    glVertex2d(105,247);
    glColor3ub(39,51,46);
    glVertex2d(103,232);
    glColor3ub(104,98,91);
    glVertex2d(144,232);
    glVertex2d(152,236);
    glVertex2d(155,246);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(105,247);
    glColor3ub(14,17,16);
    glVertex2d(105,288);
    glColor3ub(39,51,46);
    glVertex2d(91,285);
    glColor3ub(104,98,91);
    glVertex2d(91,246);
    glVertex2d(94,236);
    glVertex2d(103,232);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(105,288);
    glColor3ub(14,17,16);
    glVertex2d(150,353);
    glColor3ub(39,51,46);
    glVertex2d(155,367);
    glColor3ub(104,98,91);
    glVertex2d(141,365);
    glVertex2d(96,300);
    glVertex2d(91,285);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    //glVertex2d(112,353);
    glVertex2d(155,367);
    glColor3ub(14,17,16);
    glVertex2d(155,412);
    glColor3ub(39,51,46);
    glVertex2d(152,422);
    glColor3ub(104,98,91);
    glVertex2d(144,426);
    glVertex2d(141,411);
    glVertex2d(141,365);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(155,412);
    glColor3ub(14,17,16);
    glVertex2d(152,422);
    glColor3ub(39,51,46);
    glVertex2d(144,426);
    glColor3ub(104,98,91);
    glVertex2d(103,426);
    glVertex2d(94,422);
    glVertex2d(91,412);
    glVertex2d(105,411);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(103,426);
    glColor3ub(14,17,16);
    glVertex2d(94,422);
    glColor3ub(39,51,46);
    glVertex2d(91,412);
    glColor3ub(104,98,91);
    glVertex2d(91,363);
    glVertex2d(105,363);
    glVertex2d(105,411);
    glEnd();
}
void A (){
    glBegin(GL_POLYGON);
    glColor3ub(31,127,79);
    glVertex2d(262,434);
    glVertex2d(163,434);
    glVertex2d(174,386);
    glVertex2d(212,224);
    glVertex2d(236,343);
    glVertex2d(262,434);
    //glVertex2d(242,245);
    glEnd();
}

void F(){
    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(293,413);
    glColor3ub(14,17,16);
    glVertex2d(274,413);
     glColor3ub(104,98,91);
    glVertex2d(274,219);
    glColor3ub(160,99,24);
    glVertex2d(293,234);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(341,234);
    glColor3ub(14,17,16);
    glVertex2d(293,234);
    glColor3ub(104,98,91);
    glVertex2d(274,219);
    glColor3ub(160,99,24);
    glVertex2d(341,219);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(337,323);
    glColor3ub(14,17,16);
    glVertex2d(293,323);
    glColor3ub(104,98,91);
    glVertex2d(293,307);
    glColor3ub(160,99,24);
    glVertex2d(337,307);
    glEnd();
}

void I(){
    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(383,426);
    glColor3ub(14,17,16);
    glVertex2d(364,426);
    glColor3ub(39,51,46);
    glVertex2d(364,232);
    glColor3ub(104,98,91);
    glVertex2d(383,232);
    glEnd();
}

void R(){
    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(420,438);
    glColor3ub(14,17,16);
    glVertex2d(405,438);
    glColor3ub(38,198,118);
    glVertex2d(405,244);
    glVertex2d(420,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(405,244);
    glColor3ub(14,17,16);
    glVertex2d(460,244);
    glColor3ub(66,79,73);
    glVertex2d(468,248);
    glVertex2d(471,257);
    glVertex2d(457,259);
    glVertex2d(420,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(468,248);
    glColor3ub(14,17,16);
    glVertex2d(471,257);
    glColor3ub(66,79,73);
    glVertex2d(471,331);
    glVertex2d(455,345);
    glVertex2d(457,330);
    glVertex2d(457,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(471,331);
    glColor3ub(14,17,16);
    glVertex2d(455,345);
    glVertex2d(451,345);
    glColor3ub(66,79,73);
    glVertex2d(446,345);
    glVertex2d(457,330);
    glVertex2d(431,330);
    //glVertex2d(446,345);
    glVertex2d(429,334);
    glVertex2d(446,345);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,28,124);
    glVertex2d(446,345);
    glColor3ub(14,17,16);
    glVertex2d(429,334);
    glColor3ub(66,79,73);
    glVertex2d(459,438);
    glVertex2d(474,438);
    glEnd();
}

void A1 (){
    glBegin(GL_POLYGON);
    glColor3ub(29,145,98);
    glVertex2d(598,434);
    glVertex2d(482,434);
    glVertex2d(545,239);
    //glVertex2d(533,242);
    glEnd();

   /* glBegin(GL_POLYGON);
    glColor3ub(35,165,112);
    glVertex2d(533,242);
    glVertex2d(561,437);
    glVertex2d(547,437);
    glVertex2d(525,273);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(48,198,137);
    glVertex2d(541,394);
    glVertex2d(539,378);
    glVertex2d(511,378);
    glVertex2d(509,394);
    glEnd();*/

}

void H(){
    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(633,434);
    glColor3ub(14,17,16);
    glVertex2d(618,434);
    glColor3ub(39,51,46);
    glVertex2d(618,240);
    glColor3ub(104,98,91);
    glVertex2d(633,240);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(672,341);
    glColor3ub(14,17,16);
    glVertex2d(633,341);
    glColor3ub(39,51,46);
    glVertex2d(633,325);
    glColor3ub(104,98,91);
    glVertex2d(672,325);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,43,27);
    glVertex2d(686,434);
    glColor3ub(14,17,16);
    glVertex2d(672,434);
    glColor3ub(39,51,46);
    glVertex2d(672,240);
    glColor3ub(104,98,91);
    glVertex2d(686,240);
    glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160022", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        setup_viewport(window);

        display();

        kotak();
        kotak1();
        kotak2();
        kotak3();
        S();
        A();
        F();
        I();
        R();
        A1();
        H();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
