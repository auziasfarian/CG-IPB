#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key

}
    //color
    double nol = 0, resetx=60, resety=-18;
    int trigger = 0,i;

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
void warna(){

 if(trigger%2==0){
            nol+=0.25;}
        else{
            nol-=0.5;
        }
        if(nol==255 || nol == 0){
        trigger++;
        }


}
void bulad()
{
     glBegin(GL_POLYGON);
        glColor3ub(-nol,-nol,-nol);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(142+cos(rad)*54.5+nol-resetx,574.53+sin(rad)*54.5+nol-resety);
           }
        glEnd();
}
void wow()
{
    int i=0; int n=100;
    glBegin(GL_QUADS);
    for(i=0; i<101; i++){
    glColor3ub(nol,-nol,nol*34);
    }
    glVertex3f(0, 0, 0);
    glVertex3f(0, 800, 0);
    glVertex3f(800, 800, 0);
    glVertex3f(800, 0, 0);
    glEnd();


}
void blkng()
{
    glBegin(GL_POLYGON);
    glColor3ub(148,203,234);
    glVertex2d(0,0+nol);
    glColor3ub(nol,255,nol*3);
    glVertex2d(400,0+nol);
    glColor3ub(61,155,165);
    glVertex2d(400,400+nol);
   glColor3ub(nol,255,nol*3);
    glVertex2d(0,400+nol);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(161,217,226);
    glVertex2d(400,400-nol);
    glColor3ub(0,nol+244,nol*32);
    glVertex2d(800,400-nol);
    glColor3ub(0,nol+244,nol*32);
    glVertex2d(800,800-nol);
    glColor3ub(0,nol+244,nol*32);
    glVertex2d(400,800-nol);
    glEnd();

}


void kotak1()
{
   glBegin(GL_POLYGON);
    glColor3ub(16,82,105);
    glVertex2d(81,502);
    glColor3ub(nol,255,nol*3);
    glVertex2d(81,260);
    glColor3ub(0,nol+244,nol*32);
    glVertex2d(659,260);
    glColor3ub(nol,255,nol*3);
    glVertex2d(659,502);
    glEnd();
glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(16,309);
    glVertex2d(146,309);
    glVertex2d(146,201);
    glVertex2d(16,201);
glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(603,471);
    glVertex2d(722,471);
    glVertex2d(722,568);
    glVertex2d(603,568);
    glEnd();

}

void garis()
{
    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2d(62.5,201);
    glVertex2d(63,83.5);
    glVertex2d(700,83.13);
    glVertex2d(700.32,471);
    glEnd();
}
void F()
{

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(88.9+nol,329.33);
    glVertex2d(190.97+nol,317.58);
    glVertex2d(184.12+nol,345.19);
    glVertex2d(144.23+nol,348.55);
    glVertex2d(112.34+nol,342.97);
  glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(190.97+nol,317.58);
    glVertex2d(199.5+nol,377.3);
    glVertex2d(184.12+nol,345.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(88.9+nol,437.52);
    glVertex2d(104.08+nol,425.28);
    glVertex2d(155.25+nol,433.49);
    glVertex2d(168.81+nol,444.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(104.08+nol,425.28);
    glVertex2d(112.34+nol,342.97);
    glVertex2d(149+nol,375.5);
    glVertex2d(147.66+nol,397.18);
    glVertex2d(155.25+nol,433.49);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(112.34+nol,342.97);
    glVertex2d(144.23+nol,348.55);
    glVertex2d(149+nol,375.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(149+nol,375.5);
    glVertex2d(166.06+nol,366.54);
    glVertex2d(171.7+nol,398.83);
    glVertex2d(147.66+nol,397.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(236,0,140);
    glVertex2d(166.06+nol,366.54);
    glVertex2d(171.7+nol,398.83);
    glVertex2d(186+nol,423.06);
    glVertex2d(173.24+nol,354.22);
glEnd();
}

void A()
{

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(183.24+nol-resetx,484.9+nol-resety);
    glVertex2d(197.79+nol-resetx,471.95+nol-resety);
    glVertex2d(233.31+nol-resetx,472.32+nol-resety);
    glVertex2d(241.8+nol-resetx,481.02+nol-resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(197.79+nol-resetx,471.95+nol-resety);
    glVertex2d(218.88+nol-resetx,380.21+nol-resety);
    glVertex2d(237.26+nol-resetx,432.71+nol-resety);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(218.88+nol-resetx,380.21+nol-resety);
    glVertex2d(246.47+nol-resetx,394.92+nol-resety);
    glVertex2d(237.26+nol-resetx,432.71+nol-resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(197.79+nol-resetx,471.95+nol-resety);
    glVertex2d(237.26+nol-resetx,432.71+nol-resety);
    glVertex2d(239.57+nol-resetx,452.54+nol-resety);
    glVertex2d(233.31+nol-resetx,472.32+nol-resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(218.88+nol-resetx,380.21+nol-resety);
    glVertex2d(246.47+nol-resetx,394.92+nol-resety);
    glVertex2d(263.71+nol-resetx,383.12+nol-resety);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(218.88+nol-resetx,380.21+nol-resety);
    glVertex2d(208.36+nol-resetx,371.24+nol-resety);
    glVertex2d(280.78+nol-resetx,375.95+nol-resety);
    glVertex2d(263.71+nol-resetx,383.12+nol-resety);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(246.47+nol-resetx,394.92+nol-resety);
    glVertex2d(263.71+nol-resetx,383.12+nol-resety);
    glVertex2d(291.42+nol-resetx,466.73+nol-resety);
    glVertex2d(263.07+nol-resetx,468.23+nol-resety);
    glVertex2d(259.59+nol-resetx,451.07+nol-resety);
    glVertex2d(254.32+nol-resetx,425.92+nol-resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(237.26+nol-resetx,432.71+nol-resety);
    glVertex2d(254.32+nol-resetx,425.92+nol-resety);
    glVertex2d(259.59+nol-resetx,451.07+nol-resety);
    glVertex2d(239.57+nol-resetx,452.54+nol-resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,30,45);
    glVertex2d(263.07+nol-resetx,468.23+nol-resety);
    glVertex2d(291.42+nol-resetx,466.73+nol-resety);
    glVertex2d(303.03+nol-resetx,471.4+nol-resety);
    glVertex2d(248.79+nol-resetx,490.99+nol-resety);
    glEnd();

}

void K()
{
    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(289.64+nol+resetx,397.62+nol+resety);
    glVertex2d(300.2+nol+resetx,386.69+nol+resety);
    glVertex2d(338.78+nol+resetx,392.19+nol+resety);
    glVertex2d(348.63+nol+resetx,406.9+nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(300.2+nol+resetx,386.69+nol+resety);
    glVertex2d(305.77+nol+resetx,297.32+nol+resety);
    glVertex2d(328.35+nol+resetx,293.29+nol+resety);
    glVertex2d(332.27+nol+resetx,328.12+nol+resety);
    glVertex2d(332.39+nol+resetx,348.49+nol+resety);
    glVertex2d(338.78+nol+resetx,392.19+nol+resety);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(294.34+nol+resetx,287.05+nol+resety);
    glVertex2d(341.54+nol+resetx,279+nol+resety);
    glVertex2d(328.35+nol+resetx,293.29+nol+resety);
    glVertex2d(305.77+nol+resetx,297.32+nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(352.97+nol+resetx,293.62+nol+resety);
    glVertex2d(390.15+nol+resetx,285.9+nol+resety);
    glVertex2d(347.17+nol+resetx,283.68+nol+resety);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(332.27+nol+resetx,328.12+nol+resety);
    glVertex2d(352.97+nol+resetx,293.62+nol+resety);
    glVertex2d(390.15+nol+resetx,285.9+nol+resety);
    glVertex2d(359.66+nol+resetx,320.24+nol+resety);
    glVertex2d(335.44+nol+resetx,347.67+nol+resety);
    glVertex2d(332.39+nol+resetx,348.49+nol+resety);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(335.44+nol+resetx,347.67+nol+resety);
    glVertex2d(359.66+nol+resetx,320.24+nol+resety);
    glVertex2d(400+nol+resetx,403.37+nol+resety);
    glVertex2d(362.65+nol+resetx,386.86+nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(57,181,74);
    glVertex2d(362.65+nol+resetx,386.86+nol+resety);
    glVertex2d(400+nol+resetx,403.37+nol+resety);
    glVertex2d(353.32+nol+resetx,395.4+nol+resety);
    glEnd();
}

void H()
{
    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(395.67-nol+resetx,493.8-nol+resety);
    glVertex2d(403.59-nol+resetx,486.34-nol+resety);
    glVertex2d(435.56-nol+resetx,490.83-nol+resety);
    glVertex2d(444.11-nol+resetx,498.37-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(403.59-nol+resetx,486.34-nol+resety);
    glVertex2d(410.26-nol+resetx,394.63-nol+resety);
    glVertex2d(430.89-nol+resetx,390.67-nol+resety);
    glVertex2d(433.68-nol+resetx,426.24-nol+resety);
    glVertex2d(435.56-nol+resetx,457.47-nol+resety);
    glVertex2d(435.56-nol+resetx,490.83-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(410.26-nol+resetx,394.63-nol+resety);
    glVertex2d(396.81-nol+resetx,389.15-nol+resety);
    glVertex2d(439.44-nol+resetx,381-nol+resety);
    glVertex2d(430.89-nol+resetx,390.67-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(433.68-nol+resetx,426.24-nol+resety);
    glVertex2d(448.55-nol+resetx,433.63-nol+resety);
    glVertex2d(451.69-nol+resetx,454.19-nol+resety);
    glVertex2d(435.56-nol+resetx,457.47-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(448.55-nol+resetx,433.63-nol+resety);
    glVertex2d(452.37-nol+resetx,393.49-nol+resety);
    glVertex2d(484.8-nol+resetx,396.61-nol+resety);
    glVertex2d(489.36-nol+resetx,480.85-nol+resety);
    glVertex2d(450.72-nol+resetx,483.45-nol+resety);
    glVertex2d(451.69-nol+resetx,454.19-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(452.37-nol+resetx,393.49-nol+resety);
    glVertex2d(445.13-nol+resetx,384.28-nol+resety);
    glVertex2d(499.5-nol+resetx,386.48-nol+resety);
    glVertex2d(484.8-nol+resetx,396.61-nol+resety);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,94,60);
    glVertex2d(450.72-nol+resetx,483.45-nol+resety);
    glVertex2d(489.36-nol+resetx,480.85-nol+resety);
    glVertex2d(499.28-nol+resetx,489.15-nol+resety);
    glVertex2d(441.89-nol+resetx,491.97-nol+resety);
    glEnd();

}

void R()
{
    glBegin(GL_POLYGON);
    glColor3ub(-nol,-nol,-nol);
    glVertex2d(491.06,376.57);
    glVertex2d(499.89,369.33);
    glVertex2d(529.55,369.48);
    glVertex2d(543.23,384.37);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
    glVertex2d(499.89,369.33);
    glVertex2d(510.12,288.74);
    glVertex2d(532.02,296.08);
    glVertex2d(529.22,321.58);
    glVertex2d(528.15,343.18);
    glVertex2d(529.55,369.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,242,0);
     glVertex2d(529.22,321.58);
     glVertex2d(537.52,324.58);
     glVertex2d(558.79,344.68);
     glVertex2d(534.19,344.46);
     glVertex2d(528.15,343.18);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(-nol,-nol,-nol);
     glVertex2d(557.1,378.82);
     glVertex2d(534.19,344.46);
     glVertex2d(558.79,344.68);
     glVertex2d(593.64,373.91);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(255,242,0);
     glVertex2d(557.1,378.82);
     glVertex2d(593.64,373.91);
     glVertex2d(551.99,389.89);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(-nol,-nol,-nol);
     glVertex2d(510.12,288.74);
     glVertex2d(490.75,278.34);
     glVertex2d(538.3,272.56);
     glVertex2d(547.65,271.56);
     glVertex2d(554.58,271.33);
     glVertex2d(582.92,280.95);
     glVertex2d(592.22,308.13);
     glVertex2d(541.42,303.68);
     glVertex2d(532.02,296.08);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(255,242,0);
     glVertex2d(541.42,303.68);
     glVertex2d(544.3,313.32);
     glVertex2d(583.57,332.17);
     glVertex2d(592.22,308.13);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(255,242,0);
     glVertex2d(537.52,324.58);
     glVertex2d(544.3,313.32);
     glVertex2d(583.57,332.17);
     glVertex2d(558.79,344.68);
     glEnd();



}

void I()
{
    glBegin(GL_POLYGON);
    glColor3ub(35,31,32);
    glVertex2d(593.67-nol,469.26);
    glVertex2d(604.65-nol,458.46);
    glVertex2d(642.43-nol,447.1);
    glVertex2d(659-nol,460.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(35,31,32);
    glVertex2d(604.65-nol,458.46);
    glVertex2d(609.93-nol,380.07);
    glVertex2d(631.61-nol,377.34);
    glVertex2d(642.43-nol,447.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(35,31,32);
    glVertex2d(609.93-nol,380.07);
    glVertex2d(591.22-nol,361.21);
    glVertex2d(655.54-nol,368.29);
    glVertex2d(631.61-nol,377.34);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(255,0,0);
    glVertex2d(593.67-nol,469.26);
     glColor3ub(0,nol+244,nol*32);
    glVertex2d(593.67-nol,469.26);
     glColor3ub(nol,231,nol*2);
    glVertex2d(604.65-nol,458.46);
    glColor3ub(-nol,-nol,-nol);
    glVertex2d(642.43-nol,447.1);
    glColor3ub(nol,255,nol*3);
    glVertex2d(659-nol,460.92);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(255,0,0);
    glVertex2d(609.93-nol,380.07);
    glColor3ub(0,nol+244,nol*32);
    glVertex2d(591.22-nol,361.21);
    glColor3ub(nol,231,nol*2);
    glVertex2d(655.54-nol,368.29);
    glColor3ub(nol,255,nol*3);
    glVertex2d(631.61-nol,377.34);
    glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "s", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        wow();
        bulad();
        blkng();
        garis();
        warna();
        kotak1();
        F();
        A();
        K();
        H();
        R();
        I();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
