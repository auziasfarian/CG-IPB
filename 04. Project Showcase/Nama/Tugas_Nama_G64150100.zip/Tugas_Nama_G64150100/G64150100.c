#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void lingkaran(float radius, float jumlah_titik, float x_tengah, float y_tengah)
{
    glBegin(GL_POLYGON);
    int i;
    for(i=0; i<=360; i++){
        //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
        float sudut = i*(2*3.14/jumlah_titik);
        float x = x_tengah+radius*cos(sudut);
        float y = y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}

void display()
{
        int i;
    //Background
            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(0.0f,0.0f);
            glVertex2f(800.0f,0.0f);
            glColor3ub(221,173,173);
            glVertex2f(800.0f,800.0f);
            glVertex2f(0.0f,800.0f);
            glEnd();

        // A Kiei

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(203.67f,303.f);
            glVertex2f(160.f,423.36f);
            glColor3ub(221,173,173);
            glVertex2f(182.85f,423.36f);
            glVertex2f(213.71f,334.59f);
            glEnd();

        // A Kanan

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(224.33f,303.f);
            glVertex2f(268.f,423.36f);
            glColor3ub(221,173,173);
            glVertex2f(244.57f,423.36f);
            glVertex2f(213.71f,334.59f);
            glEnd();

        // A atas

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(203.67f,303.f);
            glVertex2f(224.33f,303.f);
            glColor3ub(221,173,173);
            glVertex2f(213.71f,334.59f);
            glEnd();

        // A Tengah

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(213.71f,334.59f);
            glVertex2f(192.17f,396.56f);
            glColor3ub(221,173,173);
            glVertex2f(235.25f,396.56f);
            glEnd();

        // I

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(552.64f,307.f);
            glVertex2f(552.64f,426.f);
            glColor3ub(255,255,255);
            glVertex2f(579.f,426.f);
            glVertex2f(579.f,307.f);
            glEnd();

        // 1 tengah

            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(579.f,307.f);
            glVertex2f(552.64f,375.34f);
            glVertex2f(579.f,426.f);

            glEnd();

        // D

            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(419.51f,310.f);
            glVertex2f(419.51f,419.f);
            glColor3ub(221,173,173);
            glVertex2f(439.26f,397.36f);
            glVertex2f(439.26f,331.64f);
            glEnd();

        // D atas
            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(419.51f,310.f);
            glVertex2f(439.26f,331.64f);
            glVertex2f(475.2f,314.81f);
            glEnd();

        // D samping

            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(439.26f,331.64f);
            glVertex2f(475.2f,314.81f);
            glVertex2f(493.42f,331.64f);
            glEnd();

        // D samping bawah

            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(493.32f,331.64f);
            glVertex2f(501.91f,357.6f);
            glVertex2f(481.31f,359.41f);
            glVertex2f(439.26f,331.64f);
            glEnd();

        // D bawah

            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(501.91f,357.6f);
            glVertex2f(478.19f,412.47f);
            glVertex2f(439.26f,397.36f);
            glVertex2f(481.31f,359.41f);
            glEnd();

        // D bawah banger

         glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(478.19f,412.47f);
            glVertex2f(439.26f,397.36f);
            glVertex2f(419.51f,419.f);
            glEnd();

        // D tambahn
            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(493.3f,397.36f);
            glVertex2f(479.74f,377.65f);
            glVertex2f(439.26f,397.36f);
            glEnd();

        // R
            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(297.f,307.f);
            glVertex2f(297.f,422.f);
            glVertex2f(318.38f,422.f);
            glVertex2f(318.38f,329.83f);
            glEnd();


        // R atas
            glBegin(GL_POLYGON);
            glColor3ub(255,255,255);
            glVertex2f(297.f,307.f);
            glVertex2f(341.43f,307.f);
            glVertex2f(318.38f,329.83f);
            glEnd();

        // R Samoing

            glBegin(GL_POLYGON);
            glColor3ub(221,173,173);
            glVertex2f(369.75f,318.66f);
            glVertex2f(341.43f,307.f);
            glVertex2f(318.38f,329.83f);
            glEnd();


}
int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Tugas Nama - G64150100", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800,0,1.f,-1.f);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
