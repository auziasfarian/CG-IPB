#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void error_callback(int error, const char* description){
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods){
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void huruf_B(float x_trans, float y_trans){
    int i, x = 10, y = 10;
    glColor3f(2.5, 1.75, 0.5);
    /* Garis Luar */
    //1
    glBegin(GL_POLYGON);
        glVertex2f(36.23+x_trans, 288.46+y_trans);
        glVertex2f(140.76+x_trans, 288.46+y_trans);
        glVertex2f(139.22+x_trans, 293.69+y_trans);
        glVertex2f(40.12+x_trans, 293.79+y_trans);
    glEnd();
    //2
    glBegin(GL_POLYGON);
        glVertex2f(36.23+x_trans, 288.46+y_trans);
        glVertex2f(40.12+x_trans, 293.79+y_trans);
        glVertex2f(40.12+x_trans, 331.66+y_trans);
        glVertex2f(36.06+x_trans, 337.11+y_trans);
    glEnd();
    //3
    glBegin(GL_POLYGON);
        glVertex2f(140.76+x_trans, 288.46+y_trans);
        glVertex2f(139.22+x_trans, 293.69+y_trans);
        glVertex2f(163.87+x_trans, 325.02+y_trans);
        glVertex2f(168.05+x_trans, 322.94+y_trans);
    glEnd();
    //4
    glBegin(GL_POLYGON);
        glVertex2f(40.12+x_trans, 331.66+y_trans);
        glVertex2f(36.06+x_trans, 337.11+y_trans);
        glVertex2f(46.18+x_trans, 337.11+y_trans);
        glVertex2f(50.05+x_trans, 331.87+y_trans);
    glEnd();
    //5
    glBegin(GL_POLYGON);
        glVertex2f(163.87+x_trans, 325.02+y_trans);
        glVertex2f(168.05+x_trans, 322.94+y_trans);
        glVertex2f(168.05+x_trans, 378.37+y_trans);
        glVertex2f(163.93+x_trans, 376.83+y_trans);
    glEnd();
    //6
    glBegin(GL_POLYGON);
        glVertex2f(46.06+x_trans, 337.11+y_trans);
        glVertex2f(50.05+x_trans, 331.87+y_trans);
        glVertex2f(50.05+x_trans, 460.56+y_trans);
        glVertex2f(46.06+x_trans, 455.66+y_trans);
    glEnd();
    //7
    glBegin(GL_POLYGON);
        glVertex2f(168.05+x_trans, 378.37+y_trans);
        glVertex2f(163.93+x_trans, 376.83+y_trans);
        glVertex2f(151.33+x_trans, 392.84+y_trans);
        glVertex2f(156.91+x_trans, 392.53+y_trans);
    glEnd();
    //8
    glBegin(GL_POLYGON);
        glVertex2f(151.33+x_trans, 392.84+y_trans);
        glVertex2f(156.91+x_trans, 392.53+y_trans);
        glVertex2f(168.05+x_trans, 406.7+y_trans);
        glVertex2f(163.93+x_trans, 408.88+y_trans);
    glEnd();
    //9
    glBegin(GL_POLYGON);
        glVertex2f(46.06+x_trans, 455.66+y_trans);
        glVertex2f(50.05+x_trans, 460.56+y_trans);
        glVertex2f(40.16+x_trans, 460.58+y_trans);
        glVertex2f(36+x_trans, 455.66+y_trans);
    glEnd();
    //10
    glBegin(GL_POLYGON);
        glVertex2f(168.05+x_trans, 406.7+y_trans);
        glVertex2f(163.93+x_trans, 408.88+y_trans);
        glVertex2f(163.93+x_trans, 467.21+y_trans);
        glVertex2f(168.05+x_trans, 469.51+y_trans);
    glEnd();
    //11
    glBegin(GL_POLYGON);
        glVertex2f(40.16+x_trans, 460.58+y_trans);
        glVertex2f(36+x_trans, 455.66+y_trans);
        glVertex2f(36+x_trans, 504+y_trans);
        glVertex2f(40.12+x_trans, 498.76+y_trans);
    glEnd();
    //12
    glBegin(GL_POLYGON);
        glVertex2f(163.93+x_trans, 467.21+y_trans);
        glVertex2f(168.05+x_trans, 469.51+y_trans);
        glVertex2f(140.92+x_trans, 504+y_trans);
        glVertex2f(139.22+x_trans, 498.76+y_trans);
    glEnd();
    //13
    glBegin(GL_POLYGON);
        glVertex2f(140.92+x_trans, 504+y_trans);
        glVertex2f(139.22+x_trans, 498.76+y_trans);
        glVertex2f(40.12+x_trans, 498.76+y_trans);
        glVertex2f(36+x_trans, 504+y_trans);
    glEnd();

    /* Isian dalam (clockwise) */
    glBegin(GL_POLYGON);
        glVertex2f(45.45+x_trans, 300.46+y_trans);
        glVertex2f(136.31+x_trans, 300.46+y_trans);
        glVertex2f(120.33+x_trans, 325.11+y_trans);
        glVertex2f(45.45+x_trans, 325.11+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(136.31+x_trans, 300.46+y_trans);
        glVertex2f(120.33+x_trans, 325.11+y_trans);
        glVertex2f(130.74+x_trans, 338.34+y_trans);
        glVertex2f(158.55+x_trans, 328.73+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(130.74+x_trans, 338.34+y_trans);
        glVertex2f(158.55+x_trans, 328.73+y_trans);
        glVertex2f(158.6+x_trans, 372.78+y_trans);
        glVertex2f(130.74+x_trans, 366.97+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(158.6+x_trans, 372.78+y_trans);
        glVertex2f(130.74+x_trans, 366.97+y_trans);
        glVertex2f(120.34+x_trans, 380.22+y_trans);
        glVertex2f(143.34+x_trans, 392.22+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(120.34+x_trans, 380.22+y_trans);
        glVertex2f(143.34+x_trans, 392.22+y_trans);
        glVertex2f(120.36+x_trans, 404.89+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(120.34+x_trans, 380.22+y_trans);
        glVertex2f(120.36+x_trans, 404.89+y_trans);
        glVertex2f(82.55+x_trans, 404.85+y_trans);
        glVertex2f(82.55+x_trans, 380.22+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(143.34+x_trans, 392.22+y_trans);
        glVertex2f(120.36+x_trans, 404.89+y_trans);
        glVertex2f(130.74+x_trans, 418.09+y_trans);
        glVertex2f(158.51+x_trans, 411.5+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(130.74+x_trans, 418.09+y_trans);
        glVertex2f(158.51+x_trans, 411.5+y_trans);
        glVertex2f(158.6+x_trans, 463.6+y_trans);
        glVertex2f(130.74+x_trans, 454.12+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(158.6+x_trans, 463.6+y_trans);
        glVertex2f(130.74+x_trans, 454.12+y_trans);
        glVertex2f(120.32+x_trans, 467.36+y_trans);
        glVertex2f(136.61+x_trans, 491.99+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(120.32+x_trans, 467.36+y_trans);
        glVertex2f(136.61+x_trans, 491.99+y_trans);
        glVertex2f(45.45+x_trans, 491.99+y_trans);
        glVertex2f(45.45+x_trans, 467.36+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(55.38+x_trans, 467.33+y_trans);
        glVertex2f(83.49+x_trans, 467.33+y_trans);
        glVertex2f(83.49+x_trans, 325.17+y_trans);
        glVertex2f(55.38+x_trans, 325.17+y_trans);
    glEnd();
    /* Garis dalam (clockwise, atas lalu bawah) */
    //atas
    glBegin(GL_POLYGON);
        glVertex2f(88.61+x_trans, 331.87+y_trans);
        glVertex2f(116.93+x_trans, 331.87+y_trans);
        glVertex2f(115.92+x_trans, 337.11+y_trans);
        glVertex2f(92.73+x_trans, 337.11+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(116.93+x_trans, 331.87+y_trans);
        glVertex2f(115.92+x_trans, 337.11+y_trans);
        glVertex2f(121.53+x_trans, 344.21+y_trans);
        glVertex2f(125.65+x_trans, 342.96+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(121.53+x_trans, 344.21+y_trans);
        glVertex2f(125.65+x_trans, 342.96+y_trans);
        glVertex2f(125.65+x_trans, 362.48+y_trans);
        glVertex2f(121.53+x_trans, 361.03+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(125.65+x_trans, 362.48+y_trans);
        glVertex2f(121.53+x_trans, 361.03+y_trans);
        glVertex2f(115.97+x_trans, 368.19+y_trans);
        glVertex2f(117.03+x_trans, 373.31+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(115.97+x_trans, 368.19+y_trans);
        glVertex2f(117.03+x_trans, 373.31+y_trans);
        glVertex2f(88.58+x_trans, 373.31+y_trans);
        glVertex2f(92.7+x_trans, 368.19+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(115.97+x_trans, 368.19+y_trans);
        glVertex2f(117.03+x_trans, 373.31+y_trans);
        glVertex2f(88.58+x_trans, 373.31+y_trans);
        glVertex2f(92.7+x_trans, 368.19+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(88.61+x_trans, 331.87+y_trans);
        glVertex2f(92.73+x_trans, 337.11+y_trans);
        glVertex2f(92.73+x_trans, 368.21+y_trans);
        glVertex2f(88.61+x_trans, 373.44+y_trans);
    glEnd();
    //bawah
    glBegin(GL_POLYGON);
        glVertex2f(88.61+x_trans, 411.87+y_trans);
        glVertex2f(116.93+x_trans, 411.87+y_trans);
        glVertex2f(115.92+x_trans, 418.18+y_trans);
        glVertex2f(92.73+x_trans, 418.18+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(116.93+x_trans, 411.87+y_trans);
        glVertex2f(115.92+x_trans, 418.18+y_trans);
        glVertex2f(121.53+x_trans, 426.75+y_trans);
        glVertex2f(125.65+x_trans, 425.14+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(121.53+x_trans, 426.75+y_trans);
        glVertex2f(125.65+x_trans, 425.24+y_trans);
        glVertex2f(125.65+x_trans, 448.78+y_trans);
        glVertex2f(121.53+x_trans, 447.15+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(125.65+x_trans, 448.78+y_trans);
        glVertex2f(121.53+x_trans, 447.15+y_trans);
        glVertex2f(115.97+x_trans, 455.67+y_trans);
        glVertex2f(117.03+x_trans, 461.84+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(115.97+x_trans, 455.67+y_trans);
        glVertex2f(117.03+x_trans, 461.84+y_trans);
        glVertex2f(88.58+x_trans, 462+y_trans);
        glVertex2f(92.7+x_trans, 455.69+y_trans);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(88.61+x_trans, 411.87+y_trans);
        glVertex2f(92.73+x_trans, 418.18+y_trans);
        glVertex2f(92.73+x_trans, 455.69+y_trans);
        glVertex2f(88.61+x_trans, 462+y_trans);
    glEnd();
}

void huruf_O(){
    //garis luar (clockwise)
    glBegin(GL_POLYGON);
        glVertex2f(210.63, 288.57);
        glVertex2f(212.08, 293.82);
        glVertex2f(283.74, 293.82);
        glVertex2f(285.35, 288.57);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(283.74, 293.82);
        glVertex2f(285.35, 288.57);
        glVertex2f(312.39, 322.82);
        glVertex2f(308.37, 325.1);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(312.39, 322.82);
        glVertex2f(308.37, 325.1);
        glVertex2f(308.37, 467.66);
        glVertex2f(312.39, 469.54);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(308.37, 467.66);
        glVertex2f(312.39, 469.54);
        glVertex2f(285.35, 504);
        glVertex2f(284.14, 498.46);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(285.35, 504);
        glVertex2f(284.14, 498.46);
        glVertex2f(212.13, 498.46);
        glVertex2f(210.7, 504);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(212.13, 498.46);
        glVertex2f(210.7, 504);
        glVertex2f(183.62, 469.57);
        glVertex2f(187.94, 467.64);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(183.62, 469.57);
        glVertex2f(187.94, 467.64);
        glVertex2f(187.94, 324.48);
        glVertex2f(183.62, 323.01);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(187.94, 324.48);
        glVertex2f(183.62, 323.01);
        glVertex2f(210.63, 288.57);
        glVertex2f(212.08, 293.82);
    glEnd();
    //isian dalam
    glBegin(GL_POLYGON);
        glVertex2f(215.33, 300.46);
        glVertex2f(280.99, 300.46);
        glVertex2f(264.38, 325.1);
        glVertex2f(231.32, 325.1);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(280.99, 300.46);
        glVertex2f(264.38, 325.1);
        glVertex2f(275.1, 338.55);
        glVertex2f(303.28, 328.81);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(275.1, 338.55);
        glVertex2f(303.28, 328.81);
        glVertex2f(303.28, 463.76);
        glVertex2f(275.1, 454.07);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(303.28, 463.76);
        glVertex2f(275.1, 454.07);
        glVertex2f(264.84, 467.25);
        glVertex2f(281.14, 491.8);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(264.84, 467.25);
        glVertex2f(281.14, 491.8);
        glVertex2f(215.26, 491.91);
        glVertex2f(231.31, 467.35);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(231.31, 467.35);
        glVertex2f(215.26, 491.91);
        glVertex2f(193.03, 463.66);
        glVertex2f(220.9, 454.12);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(193.03, 463.66);
        glVertex2f(220.9, 454.12);
        glVertex2f(220.9, 338.46);
        glVertex2f(193.03, 329.02);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(215.33, 300.46);
        glVertex2f(231.32, 325.1);
        glVertex2f(220.9, 338.46);
        glVertex2f(193.03, 329.02);
    glEnd();
    //garis dalam
    glBegin(GL_POLYGON);
        glVertex2f(234.34, 331.72);
        glVertex2f(261.6, 331.56);
        glVertex2f(260.35, 337.11);
        glVertex2f(235.31, 337.27);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(261.6, 331.56);
        glVertex2f(260.35, 337.11);
        glVertex2f(265.66, 343.79);
        glVertex2f(270.08, 342.34);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(265.66, 343.79);
        glVertex2f(270.08, 342.34);
        glVertex2f(270.08, 450.1);
        glVertex2f(265.66, 448.93);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(270.08, 450.1);
        glVertex2f(265.66, 448.93);
        glVertex2f(260.43, 455.6);
        glVertex2f(261.64, 460.84);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(260.43, 455.6);
        glVertex2f(261.64, 460.84);
        glVertex2f(234.42, 460.84);
        glVertex2f(235.68, 455.6);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(234.42, 460.84);
        glVertex2f(235.68, 455.6);
        glVertex2f(230.11, 448.57);
        glVertex2f(225.99, 450.11);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(230.11, 448.57);
        glVertex2f(225.99, 450.11);
        glVertex2f(225.99, 342.31);
        glVertex2f(230.11, 343.84);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(230.14, 343.84);
        glVertex2f(226.01, 342.31);
        glVertex2f(234.34, 331.72);
        glVertex2f(235.31, 337.27);
    glEnd();
}

void huruf_Y(){
    //garis luar
    float diff_1 = 89.2;
    glBegin(GL_POLYGON);
        glVertex2f(612.83, 288.5);
        glVertex2f(679.53, 288.48);
        glVertex2f(676.06, 293.69);
        glVertex2f(616.25, 293.73);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(612.83+diff_1, 288.5);
        glVertex2f(679.53+diff_1, 288.48);
        glVertex2f(676.06+diff_1, 293.69);
        glVertex2f(616.25+diff_1, 293.73);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(612.83, 288.5);
        glVertex2f(616.25, 293.73);
        glVertex2f(616.25, 331.85);
        glVertex2f(612.83, 337.09);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(612.83+diff_1, 288.5);
        glVertex2f(616.25+diff_1, 293.73);
        glVertex2f(616.25+diff_1, 331.85);
        glVertex2f(702.03, 331.81);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(679.53, 288.48);
        glVertex2f(676.06, 293.69);
        glVertex2f(676.06, 331.87);
        glVertex2f(679.53, 331.81);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(766.93, 288.46);
        glVertex2f(763.45, 293.69);
        glVertex2f(763.45, 331.87);
        glVertex2f(766.93, 337.11);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(616.25, 331.87);
        glVertex2f(627.49, 331.87);
        glVertex2f(625.97, 337.11);
        glVertex2f(612.83, 337.09);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(616.25, 331.87);
        glVertex2f(627.49, 331.87);
        glVertex2f(625.97, 337.11);
        glVertex2f(612.83, 337.09);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(763.48, 331.87);
        glVertex2f(766.89, 337.11);
        glVertex2f(755.48, 337.11);
        glVertex2f(754.27, 331.87);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(679.53, 331.87);
        glVertex2f(670.29, 331.87);
        glVertex2f(673.72, 337.11);
        glVertex2f(679.53, 337.11);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(711.68, 331.87);
        glVertex2f(702.03, 331.87);
        glVertex2f(702.03, 337.11);
        glVertex2f(708.25, 337.11);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(711.68, 331.87);
        glVertex2f(702.03, 331.87);
        glVertex2f(702.03, 337.11);
        glVertex2f(708.25, 337.11);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(678.34, 337.13);
        glVertex2f(690.94, 356.13);
        glVertex2f(690.94, 363.51);
        glVertex2f(673.72, 337.13);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(690.94, 356.13);
        glVertex2f(690.94, 363.51);
        glVertex2f(708.25, 337.13);
        glVertex2f(703.63, 337.13);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(627.49, 331.87);
        glVertex2f(625.97, 337.11);
        glVertex2f(671.5, 406.72);
        glVertex2f(674.89, 404.51);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(754.24, 331.92);
        glVertex2f(755.46, 337.14);
        glVertex2f(710.07, 406.76);
        glVertex2f(706.66, 404.54);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(671.5, 406.72);
        glVertex2f(674.89, 404.51);
        glVertex2f(674.91, 460.58);
        glVertex2f(671.5, 455.66);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(706.66, 404.54);
        glVertex2f(710.07, 406.76);
        glVertex2f(710.07, 455.66);
        glVertex2f(706.66, 460.5);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(663.29, 455.66);
        glVertex2f(671.46, 455.66);
        glVertex2f(674.91, 460.58);
        glVertex2f(666.47, 460.63);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(710.08, 455.66);
        glVertex2f(718.51, 455.66);
        glVertex2f(715.29, 460.58);
        glVertex2f(706.66, 460.5);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(663.29, 455.66);
        glVertex2f(666.47, 460.63);
        glVertex2f(666.47, 499.07);
        glVertex2f(663.29, 503.9);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(718.51, 455.66);
        glVertex2f(715.29, 460.61);
        glVertex2f(715.29, 499.07);
        glVertex2f(718.51, 504);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(666.51, 499.07);
        glVertex2f(663.26, 503.9);
        glVertex2f(718.48, 504);
        glVertex2f(715.24, 499.07);
    glEnd();

    /* Isian dalam */
    glBegin(GL_POLYGON);
        glVertex2f(620.67, 300.46);
        glVertex2f(671.7, 300.46);
        glVertex2f(671.7, 325.1);
        glVertex2f(620.67, 325.1);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(709.87, 300.46);
        glVertex2f(759.29, 300.46);
        glVertex2f(759.29, 325.1);
        glVertex2f(709.87, 325.1);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(670.89, 467.36);
        glVertex2f(710.87 ,467.36);
        glVertex2f(710.87, 495.45);
        glVertex2f(670.89, 495.45);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(690.83, 373.1);
        glVertex2f(702.48, 401.71); //
        glVertex2f(702.48, 467.36);
        glVertex2f(679.33, 467.36);
        glVertex2f(679.33, 401.77); //
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(690.83, 373.1);
        glVertex2f(702.48, 401.71);
        glVertex2f(752.82, 325.17);
        glVertex2f(722.08, 325.17);
    glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(690.83, 373.1);
        glVertex2f(679.33, 401.77);
        glVertex2f(629.15, 325.17);
        glVertex2f(659.49, 325.17);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "G64160091_NAME", NULL, NULL);
    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window)){
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800, 0, -4, 4);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        //Huruf-huruf
        huruf_B(0, 0);
        huruf_O();
        huruf_B(290.49, 0);
        huruf_B(433.14, 0);
        huruf_Y();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

