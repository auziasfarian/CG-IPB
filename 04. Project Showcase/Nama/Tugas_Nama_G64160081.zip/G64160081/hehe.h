#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>

void a1(){
	glBegin(GL_POLYGON);
	glVertex2f(135, 392);
	glVertex2f(191, 261);
	glVertex2f(203, 261);
	glVertex2f(154, 392);
	glEnd();	

}

void akses_aa(){
	glBegin(GL_POLYGON);
	glVertex2f(135 + 356, 392);
	glVertex2f(123 + 356, 395);
	glVertex2f(123 + 356, 400);
	glVertex2f(167 + 356, 400);
	glVertex2f(167 + 356, 395);
	glVertex2f(154 + 356, 392);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(218 + 356, 392);
	glVertex2f(204 + 356, 395);
	glVertex2f(204 + 356, 400);
	glVertex2f(265 + 356, 400);
	glVertex2f(265 + 356, 395);
	glVertex2f(250 + 356, 390);
	glEnd();
	
}

void akses_a(){
	glBegin(GL_POLYGON);
	glVertex2f(135, 392);
	glVertex2f(123, 395);
	glVertex2f(123, 400);
	glVertex2f(167, 400);
	glVertex2f(167, 395);
	glVertex2f(154, 392);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(218, 392);
	glVertex2f(204, 395);
	glVertex2f(204, 400);
	glVertex2f(265, 400);
	glVertex2f(265, 395);
	glVertex2f(250, 390);
	glEnd();
	
}

void a2(){
	glBegin(GL_POLYGON);
	glVertex2f(180, 288);
	glVertex2f(192, 292);
	glVertex2f(202, 261);
	glVertex2f(253, 391);
	glVertex2f(218, 391);
	glEnd();

}

void a3(){
	glBegin(GL_POLYGON);
	glVertex2f(165, 358);
	glVertex2f(215, 358);
	glVertex2f(210, 347);
	glVertex2f(164, 347);
	glEnd();
}

void aa1(){
	glBegin(GL_POLYGON);
	glVertex2f(135 + 356, 392);
	glVertex2f(191 + 356, 261);
	glVertex2f(203 + 356, 261);
	glVertex2f(154 + 356, 392);
	glEnd();	

}

void aa2(){
	glBegin(GL_POLYGON);
	glVertex2f(180 + 356, 288);
	glVertex2f(192 + 356, 292);
	glVertex2f(202 + 356, 261);
	glVertex2f(253 + 356, 391);
	glVertex2f(218 + 356, 391);
	glEnd();

}

void aa3(){
	glBegin(GL_POLYGON);
	glVertex2f(165 + 356, 358);
	glVertex2f(215 + 356, 358);
	glVertex2f(210 + 356, 347);
	glVertex2f(164 + 356, 347);
	glEnd();
}

void l1(){
	glBegin(GL_POLYGON);
	glVertex2f(289, 263);
	glVertex2f(319, 263);
	glVertex2f(319, 400);
	glVertex2f(289, 400);

	glEnd();
	
}
void l2(){
	glBegin(GL_POLYGON);
	glVertex2f(289, 391);
	glVertex2f(376, 391);
	glVertex2f(376, 400);
	glVertex2f(289, 400);
	glEnd();
}
void akses_f(){
	glBegin(GL_POLYGON);
	glVertex2f(404, 391);
	glVertex2f(390, 396);
	glVertex2f(390, 400);
	glVertex2f(452, 400);
	glVertex2f(452, 396);
	glVertex2f(434, 391);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(405, 272);
	glVertex2f(390, 267);
	glVertex2f(390, 263);
	glVertex2f(405, 263);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(471, 272);
	glVertex2f(481, 296);
	glVertex2f(490, 263);
	glVertex2f(471, 263);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(472, 310);
	glVertex2f(460, 327);
	glVertex2f(460, 337);
	glVertex2f(460+12, 337 + 17);
	glEnd();

	glBegin(GL_POLYGON);
	glEnd();
	
}
void f1(){
	glBegin(GL_POLYGON);
	glVertex2f(404, 263);
	glVertex2f(471, 263);
	glVertex2f(471, 273);
	glVertex2f(404, 273);
	glEnd();
}

void f2(){
	glBegin(GL_POLYGON);
	glVertex2f(404, 263);
	glVertex2f(433,263);
	glVertex2f(433, 400);
	glVertex2f(404, 400);
	glEnd();
}

void f3(){
	glBegin(GL_POLYGON);
	glVertex2f(404, 328);
	glVertex2f(471, 328);
	glVertex2f(471, 336);
	glVertex2f(404, 336);
	glEnd();
}


void a(){
	a1();
	a2();
	a3();
	akses_a();
}

void akses_l(){
	glBegin(GL_POLYGON);
	glVertex2f(289, 273);
	glVertex2f(274, 267);
	glVertex2f(274, 263);
	glVertex2f(334, 263);
	glVertex2f(334, 267);
	glVertex2f(320, 273);
	glEnd();	

	glBegin(GL_POLYGON);
	glVertex2f(290, 389);
	glVertex2f(274, 396);
	glVertex2f(274, 396);
	glVertex2f(274, 401);
	glVertex2f(274, 401);
	glVertex2f(319, 401);	
	glVertex2f(319, 391);
	glEnd();	

	glBegin(GL_POLYGON);
	glVertex2f(375, 362);
	glVertex2f(375, 400);
	glVertex2f(358, 390);
	glVertex2f(371, 392);

	glEnd();	
}

void l(){
	l1();
	l2();
	akses_l();
}


void f(){
	f1();	
	f2();	
	f3();	
	akses_f();
};

void aa(){
	aa1();
	aa2();
	aa3();
	akses_aa();
}

void n1(){
	glBegin(GL_POLYGON);
	glVertex2f(640, 400);
	glVertex2f(652, 400);
	glVertex2f(652, 263);
	glVertex2f(640, 263);
	glEnd();
}

void n2(){
	glBegin(GL_POLYGON);
	glVertex2f(652, 294);
	glVertex2f(737, 400);
	glVertex2f(737, 356);
	glVertex2f(663, 263);
	glVertex2f(652, 263);
	glEnd();
}

void n3(){
	glBegin(GL_POLYGON);
	glVertex2f(736, 263);
	glVertex2f(736, 400);
	glVertex2f(749, 400);
	glVertex2f(749, 263);
	glEnd();
}

void akses_n(){
	glBegin(GL_POLYGON);
	glVertex2f(640, 391);
	glVertex2f(623, 395);
	glVertex2f(623, 400);
	glVertex2f(668, 400);
	glVertex2f(668, 395);
	glVertex2f(653, 391);
	glEnd();

	
	glBegin(GL_POLYGON);
	glVertex2f(623, 263);
	glVertex2f(640, 263);
	glVertex2f(640, 273);
	glVertex2f(623, 268);
	glEnd();


	glBegin(GL_POLYGON);
	glVertex2f(640, 391);
	glVertex2f(623, 395);
	glVertex2f(623, 400);
	glVertex2f(668, 400);
	glVertex2f(668, 395);
	glVertex2f(653, 391);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(736, 272);
	glVertex2f(722, 268);
	glVertex2f(722, 263);
	glVertex2f(765, 263);
	glVertex2f(765, 267);
	glVertex2f(749, 272);
	glEnd();


}

void n(){
	n1();
	n2();
	n3();
	akses_n();
};


