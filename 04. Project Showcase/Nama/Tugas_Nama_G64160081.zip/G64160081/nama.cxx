#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
// import some fancy function
#include <bits/stdc++.h>

// compile option
// g++ -Wall -o "nama" "nama.cxx" -lglfw3 -lGL -lX11 -lXi -lXrandr -lXxf86vm -lXinerama -lXcursor -lrt -lm -pthread
// main name library
#include "hehe.h"
#define color cl1, cl2, cl3

// init
unsigned long long hehe = 1;
long long m = 0;
long long kiri = 124, kanan = 765;
long long bawah = 400, atas = 265;
long long posx = 0, posy = 0;
long long incx = 3, incy = 3;

long long cl1 = 0x22;
long long cl2 = 0x22;
long long cl3 = 0x33;

long long inccl1 =  0xaa/0x22;;
long long inccl2 =  0xcc/0x22;;
long long inccl3 =  0xff/0x33;;
long long anu = 0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    
    glDisable( GL_DEPTH_TEST ); // here for illustrative purposes, depth test is initially DISABLED (key!)
    float r = 0x22 * 1.0 / 256;
    float g = 0x22 * 1.0 / 256;
    float b = 0x33 * 1.0 / 256;
    // background
    glClearColor(r, g,  b,0.0f);

    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1000, 1000, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


void movement(){
    
    glColor3ub(color);
    if(cl1 < 0x22 + 5){
        inccl1 =  0xaa/0x22;
        inccl2 =  0xcc/0x22;
        inccl3 =  0xff/0x33;
    }

    else if(cl1 > 0xaa - 5){
        inccl1 =  -0xaa/0x22;
        inccl2 =  -0xcc/0x22;
        inccl3 =  -0xff/0x33;
    }
    if(anu % 5 == 0){
        cl1 += inccl1; 
        cl2 += inccl2; 
        cl3 += inccl3; 
    }

   if(kanan + posx > 960 + 10){
        incx = -3;
    }
    if(kiri  + posx < 45 ){
        incx = 3;
    }
    if(bawah + posy > 1000){    
        incy = -3;
    }
    if(atas + posy < 0 ){
        incy = 3;
    }
    posx += incx;
    posy += incy;
    anu  += 1;
    glTranslatef(posx, posy, 0);       

    // buat ngedebug
    // printf("%d %d %d %d\n", posx + kanan, posx - kiri, bawah + posy, posy - atas);
    
}

void pinkanan(){
    glBegin(GL_POLYGON);
    glVertex2f(960, 293);
    glVertex2f(960, 387);
    glVertex2f(965, 387);
    glVertex2f(965, 293);
    glEnd();

}

void pinkiri(){
    glBegin(GL_POLYGON);
    glVertex2f(40, 293);
    glVertex2f(40, 387);
    glVertex2f(45, 387);
    glVertex2f(45, 293);
    glEnd();

}


long long pkanan = 0, pkiri = 0;
int done = 0;
long long barx = 0, bary = 0;
// # define vector<pair<int, int >>::iterator vit
int kotak[1000000][2];
long long isikotak = 0;
long long buff_map = 0;
void addsomefancy(){
    // mau bikin bfs cuman bingung
    int pil = rand() % 4;
    int x, y;
    
    for (int i = 0; i < isikotak; ++i)
    {
        x = kotak[i][0];
        y = kotak[i][1];
        glBegin(GL_POLYGON);           
        glVertex2f(x, y);
        glVertex2f(x, y+40);
        glVertex2f(x+40, y+40);
        glVertex2f(x+40, y);
        glEnd();
    }

    buff_map++;
    if(buff_map  % 10 == 0){
        if     (pil == 0 && barx < 1000) {;barx += 40; kotak[isikotak][0] = barx;kotak[isikotak][1] = bary;; isikotak++;}
        else if(pil == 1 && barx > 0   ) {;barx -= 40; kotak[isikotak][0] = barx;kotak[isikotak][1] = bary;; isikotak++;}
        else if(pil == 2 && bary < 1000) {;bary += 40; kotak[isikotak][0] = barx;kotak[isikotak][1] = bary;; isikotak++;}
        else if(pil == 3 && bary > 0   ) {;bary -= 40; kotak[isikotak][0] = barx;kotak[isikotak][1] = bary;; isikotak++;}
    }
    glColor3ub(0xaa - 0x20, 0xcc- 0x20, 0xff- 0x20);
    x = kotak[isikotak - 1][0];
    y = kotak[isikotak - 1][1];
    glBegin(GL_POLYGON);           
    glVertex2f(x, y);
    glVertex2f(x, y+40);
    glVertex2f(x+40, y+40);
    glVertex2f(x+40, y);
    glEnd();
    
};


void display()
{
    glColor3ub(0xaa - 10, 0xcc - 10, 0xff - 10);
    addsomefancy();
    glPushMatrix();
    movement();        
    a();
    l();
    f();
    aa();
    n();
    glPopMatrix();

    glColor3ub(0xaa, 0xcc, 0xff);
    
    glPushMatrix();
    // not implemented. takut ga keburu. jadi disubmit duluan
    // niatnya mau bikin semacem game ping pong
    // if(incx > 0){
        // searching
        // if(pkanan != posy + incy){
            // pkanan += incy * 3;
        // }
    // }
    glTranslatef(0, posy + incy, 0);
    pinkanan();
    glPopMatrix();

    glPushMatrix();
    // if(incx < 0) pkiri = posy + incy;
    
    glTranslatef(0, posy + incy, 0);
    pinkiri();
    glPopMatrix();


        
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(700, 700, "Tugas Nama_G64160081", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
	
    while (!glfwWindowShouldClose(window))
    {
		
		setup_viewport(window);

        display();
		
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}

