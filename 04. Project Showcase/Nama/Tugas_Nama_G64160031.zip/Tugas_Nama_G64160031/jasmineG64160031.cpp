#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void j (){

    glBegin(GL_POLYGON);
    glColor3f(1.0, 0.67, 0.96);
    glVertex2d(63, 153);
    glVertex2d(110, 153);
    glVertex2d(110, 188);
    glVertex2d(63, 188);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.89, 0.66, 0.87);
    glVertex2d(110, 153);
    glVertex2d(143, 188);
    glVertex2d(110, 188);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.67, 0.13, 0.7);
    glVertex2d(110, 188);
    glVertex2d(143, 188);
    glVertex2d(143, 305);
    glVertex2d(110, 305);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.9, 0.58, 0.93);
    glVertex2d(110, 305);
    glVertex2d(143, 305);
    glVertex2d(110, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.91, 0.4, 0.86);
    glVertex2d(110, 305);
    glVertex2d(110, 340);
    glVertex2d(63, 340);
    glVertex2d(63, 305);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(1.0, 0.67, 0.96);
    glVertex2d(63, 305);
    glVertex2d(63, 340);
    glVertex2d(30, 305);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.89, 0.66, 0.87);
    glVertex2d(30, 270);
    glVertex2d(63, 305);
    glVertex2d(30, 305);
    glEnd();
}

void a (){
    glBegin(GL_POLYGON);
    glColor3f(0.93, 0.52, 0.22);
    glVertex2d(148, 340);
    glVertex2d(205, 153);
    glVertex2d(262, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.94, 0.9, 0.19);
    glVertex2d(188, 340);
    glVertex2d(225, 218);
    glVertex2d(262, 340);
    glEnd();
}

void s (){
    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(267, 189);
    glVertex2d(300, 153);
    glVertex2d(300, 189);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.2, 0.69, 0.93);
    glVertex2d(300, 153);
    glVertex2d(346, 153);
    glVertex2d(346, 189);
    glVertex2d(300, 189);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(346, 153);
    glVertex2d(379, 189);
    glVertex2d(346, 189);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.51, 0.89, 0.96);
    glVertex2d(267, 189);
    glVertex2d(300, 189);
    glVertex2d(300, 224);
    glVertex2d(267, 224);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(267, 224);
    glVertex2d(300, 224);
    glVertex2d(300, 259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.2, 0.69, 0.93);
    glVertex2d(300, 224);
    glVertex2d(346, 224);
    glVertex2d(346, 259);
    glVertex2d(300, 259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(346, 224);
    glVertex2d(379, 259);
    glVertex2d(346, 259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.51, 0.89, 0.96);
    glVertex2d(346, 259);
    glVertex2d(379, 259);
    glVertex2d(379, 305);
    glVertex2d(346, 305);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(346, 305);
    glVertex2d(379, 305);
    glVertex2d(346, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.2, 0.69, 0.93);
    glVertex2d(300, 305);
    glVertex2d(346, 305);
    glVertex2d(346, 340);
    glVertex2d(300, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.31, 0.41);
    glVertex2d(267, 340);
    glVertex2d(300, 305);
    glVertex2d(300, 340);
    glEnd();
}

void m (){
    glBegin(GL_POLYGON);
    glColor3f(0.78, 0.06, 0.1);
    glVertex2d(384, 153);
    glVertex2d(441, 239);
    glVertex2d(384, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.78, 0.06, 0.1);
    glVertex2d(498, 153);
    glVertex2d(498, 340);
    glVertex2d(441, 239);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.96, 0.52, 0.54);
    glVertex2d(384, 153);
    glVertex2d(441, 186);
    glVertex2d(441, 304);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.96, 0.52, 0.54);
    glVertex2d(441, 186);
    glVertex2d(498, 153);
    glVertex2d(441, 304);
    glEnd();

}

void i (){

    glBegin(GL_POLYGON);
    glColor3f(0.14, 0.88, 0.59);
    glVertex2d(503, 153);
    glVertex2d(539, 153);
    glVertex2d(539, 321);
    glVertex2d(503, 321);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.11, 0.45, 0.34);
    glVertex2d(503, 340);
    glVertex2d(521, 321);
    glVertex2d(539, 340);
    glEnd();
}

void n (){

    glBegin(GL_POLYGON);
    glColor3f(0.67, 0.29, 0.0);
    glVertex2d(544, 153);
    glVertex2d(588, 153);
    glVertex2d(588, 340);
    glVertex2d(544, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.92, 0.72, 0.22);
    glVertex2d(544, 153);
    glVertex2d(658, 153);
    glVertex2d(658, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.67, 0.29, 0.0);
    glVertex2d(588, 153);
    glVertex2d(630, 153);
    glVertex2d(630, 220);
    glEnd();
}

void e (){

    glBegin(GL_POLYGON);
    glColor3f(0.5, 0.5, 0.86);
    glVertex2d(663, 228);
    glVertex2d(767, 228);
    glVertex2d(767, 264);
    glVertex2d(663, 264);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.58, 0.95, 0.98);
    glVertex2d(750, 246);
    glVertex2d(767, 228);
    glVertex2d(767, 264);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.17, 0.17, 0.7);
    glVertex2d(663, 153);
    glVertex2d(693, 153);
    glVertex2d(693, 340);
    glVertex2d(663, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.5, 0.5, 0.86);
    glVertex2d(663, 153);
    glVertex2d(767, 153);
    glVertex2d(767, 190);
    glVertex2d(663, 190);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.58, 0.95, 0.98);
    glVertex2d(750, 171);
    glVertex2d(767, 153);
    glVertex2d(767, 190);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.5, 0.5, 0.86);
    glVertex2d(663, 306);
    glVertex2d(767, 306);
    glVertex2d(767, 340);
    glVertex2d(663, 340);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.58, 0.95, 0.98);
    glVertex2d(750, 324);
    glVertex2d(767, 306);
    glVertex2d(767, 340);
    glEnd();
}
int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "Jasmine", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
//glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
 j();
 a();
 s();
 m();
 i();
 n();
 e();
glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
