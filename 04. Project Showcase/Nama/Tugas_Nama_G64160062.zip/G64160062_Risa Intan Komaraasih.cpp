#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

float DETIK = 0.0;
float DETIK2 = 0.0;

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void nama(){


    glColor3ub(0,43,84);
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(0, 1000);
    glVertex2d(1200, 1000);
    glVertex2d(1200, 0);
    glEnd();

    //3 garis di atas
    glBegin(GL_POLYGON);
    glColor3ub(179+80*DETIK, 142+80*DETIK, 80+80*DETIK);
    glVertex2f(608,63);
    glVertex2f(608,34);
    glVertex2f(800,34);
    glVertex2f(800,63);
    glEnd();
    glBegin(GL_POLYGON);
     glColor3ub(179+100*DETIK, 142+100*DETIK, 80+100*DETIK);
    glVertex2f(513,136);
    glVertex2f(513,107);
    glVertex2f(800,107);
    glVertex2f(800,136);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(179+120*DETIK, 142+120*DETIK, 80+120*DETIK);
    glVertex2f(416,211);
    glVertex2f(416,180);
    glVertex2f(800,180);
    glVertex2f(800,211);
    glEnd();


//I
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(114,475.02);
    glVertex2f(113.99,447);
    glVertex2f(181,447);
    glVertex2f(181.01,475);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(130,447);
    glVertex2f(129.98,382);
    glVertex2f(165,382);
    glVertex2f(165.03,447);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(114,382);
    glVertex2f(113.99,354);
    glVertex2f(165,353.99);
    glVertex2f(165,382);
    glEnd();

    glBegin(GL_POLYGON);
    for(int i=0;i<=360;i++){
         glColor3ub(179, 142, 80+350*DETIK);
        float x=i*3.14159/180;
        glVertex2f(147+17.92*cos(x),318+17.92*sin(x));
    }
    glEnd();

//A
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(448.76,440.14);
    glVertex2f(479.66,314.69);
    glVertex2f(509.68,314.69);
    glVertex2f(541.35,440.14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,43,84);
    glVertex2f(465.04,440.14);
    glVertex2f(474.56,402.86);
    glVertex2f(515.33,402.86);
    glVertex2f(523.75,440.14);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(435.07,460.73);
    glVertex2f(435.07,440.14);
    glVertex2f(479.65,440.14);
    glVertex2f(479.65,460.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(509.67,460.73);
    glVertex2f(509.67,440.14);
    glVertex2f(554.01,440.14);
    glVertex2f(554.01,460.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(509.67,460.73);
    glVertex2f(509.67,440.14);
    glVertex2f(554.01,440.14);
    glVertex2f(554.01,460.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(465.99,314.69);
    glVertex2f(465.99,296.11);
    glVertex2f(523.83,296.11);
    glVertex2f(523.83,314.69);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0,43,84);
    glVertex2f(478.78,383.57);
    glVertex2f(494.46,314.69);
    glVertex2f(511.06,383.57);
    glEnd();

//T
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(379.01,469.68);
    glVertex2f(379.01,353);
    glVertex2f(419.01,353);
    glVertex2f(419.01,469.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(359,391);
    glVertex2f(358.99,353);
    glVertex2f(439,352.99);
    glVertex2f(439.01,391);
    glEnd();

//Ntipis
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(561,474);
    glVertex2f(561,296);
    glVertex2f(673,296);
    glVertex2f(673,474);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(0,43,84);
    glVertex2f(582.13,295);
    glVertex2f(657.59,295);
    glVertex2f(657.59,448);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,43,84);
    glVertex2f(577.04,474);
    glVertex2f(577.04,320);
    glVertex2f(653.32,474);
    glEnd();


//Ntebal
    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(204,477);
    glVertex2f(204,301);
    glVertex2f(337,301);
    glVertex2f(337,477);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(0,43,84);
    glVertex2f(256.37,301);
    glVertex2f(305,301);
    glVertex2f(305,391.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,43,84);
    glVertex2f(236.02,477);
    glVertex2f(236,372.3);
    glVertex2f(292.73,477);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(192,477);
    glVertex2f(192,433);
    glVertex2f(248,433);
    glVertex2f(248,477);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(295,342);
    glVertex2f(295,301);
    glVertex2f(349,301);
    glVertex2f(349,343);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(192,343);
    glVertex2f(192,301);
    glVertex2f(203.97,301);
    glVertex2f(203.97,343);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(0,506);
    glVertex2f(0,474);
    glVertex2f(800,474);
    glVertex2f(800,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(179,142,80);
    glVertex2f(0,283);
    glVertex2f(0,257);
    glVertex2f(800,257);
    glVertex2f(800,283);
    glEnd();

    //3 garis dibawah
    glBegin(GL_POLYGON);
    glColor3ub(179+80*DETIK, 142+80*DETIK, 80+80*DETIK);
    glVertex2f(0,578);
    glVertex2f(0,550);
    glVertex2f(416,550);
    glVertex2f(416,578);
    glEnd();
    glBegin(GL_POLYGON);
     glColor3ub(179+100*DETIK, 142+100*DETIK, 80+100*DETIK);
    glVertex2f(0,645);
    glVertex2f(0,618);
    glVertex2f(313,618);
    glVertex2f(313,645);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(179+120*DETIK, 142+120*DETIK, 80+120*DETIK);
    glVertex2f(0,714);
    glVertex2f(0,685);
    glVertex2f(221,685);
    glVertex2f(221,714);
    glEnd();
}




int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "G64160062", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();

DETIK = glfwGetTime();
DETIK2 = sin(DETIK);

nama();

glfwSwapBuffers(window);
glfwPollEvents();
}


glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
