#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);


    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(0,0);
    glColor3ub(255,255,255);
    glVertex2d(800,0);
    glColor3ub(255,255,255);
    glVertex2d(800,800);
    glColor3ub(255,255,255);
    glVertex2d(0,800);
    glEnd();


    glFlush();
}

void Bakeger() {
  glBegin(GL_POLYGON);

  glColor3ub(238,98,57);
  glVertex2d(0,0);
  glVertex2d(100,0);
  glVertex2d(100,800);
  glVertex2d(0,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(250,193,95);
  glVertex2d(100,0);
  glVertex2d(200,0);
  glVertex2d(200,800);
  glVertex2d(100,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(150,203,122);
  glVertex2d(200,0);
  glVertex2d(300,0);
  glVertex2d(300,800);
  glVertex2d(200,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(87,144,105);
  glVertex2d(300,0);
  glVertex2d(400,0);
  glVertex2d(400,800);
  glVertex2d(300,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(82,188,204);
  glVertex2d(400,0);
  glVertex2d(500,0);
  glVertex2d(500,800);
  glVertex2d(400,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(23,41,60);
  glVertex2d(500,0);
  glVertex2d(600,0);
  glVertex2d(600,800);
  glVertex2d(500,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(238,98,57);
  glVertex2d(600,0);
  glVertex2d(700,0);
  glVertex2d(700,800);
  glVertex2d(600,800);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(250,193,95);
  glVertex2d(700,0);
  glVertex2d(800,0);
  glVertex2d(800,800);
  glVertex2d(700,800);

  glEnd();

}

//abu 103 103 103

void H() {
  glBegin(GL_POLYGON);

  glColor3ub(255,255,255);
  glVertex2d(89.05,465.48);
  glVertex2d(142.82,465.48);
  glVertex2d(142.82,615.88);
  glVertex2d(89.05,615.88);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
  glVertex2d(142.82,520.57);
  glVertex2d(170.45,520.57);
  glVertex2d(170.45,559.99);
  glVertex2d(142.82,559.99);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
  glVertex2d(170.45,465.48);
  glVertex2d(224.08,465.48);
  glVertex2d(224.08,615.88);
  glVertex2d(170.45,615.88);
  glEnd();


}

void H2() {
  glBegin(GL_POLYGON);

  glColor3ub(103,103,103);
  glVertex2d(89.05-13,465.48-10);
  glVertex2d(142.82-13,465.48-10);
  glVertex2d(142.82-13,615.88-10);
  glVertex2d(89.05-13,615.88-10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(103,103,103);
  glVertex2d(142.82-13,520.57-10);
  glVertex2d(170.45-13,520.57-10);
  glVertex2d(170.45-13,559.99-10);
  glVertex2d(142.82-13,559.99-10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(103,103,103);
  glVertex2d(170.45-13,465.48-10);
  glVertex2d(224.08-13,465.48-10);
  glVertex2d(224.08-13,615.88-10);
  glVertex2d(170.45-13,615.88-10);
  glEnd();


}

void A() {
  glBegin(GL_POLYGON);

  glColor3ub(255,255,255);

  glVertex2d(323.25,433.17);
  glVertex2d(399.98,433.17);
  glVertex2d(441.19,583.56);
  glVertex2d(387.3,583.56);
  glVertex2d(380.26,557.94);
  glVertex2d(341.18,557.94);
  glVertex2d(334.25,583.56);
  glVertex2d(279.83,583.56);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(103,103,103);

  glVertex2d(360.85,485.91);
  glVertex2d(370.67,522.65);
  glVertex2d(350.77,522.65);

  glEnd();


}

void A2() {
  glBegin(GL_POLYGON);

  glColor3ub(103,103,103);

  glVertex2d(323.25-13,433.17-10);
  glVertex2d(399.98-13,433.17-10);
  glVertex2d(441.19-13,583.56-10);
  glVertex2d(387.3-13,583.56-10);
  glVertex2d(380.26-13,557.94-10);
  glVertex2d(341.18-13,557.94-10);
  glVertex2d(334.25-13,583.56-10);
  glVertex2d(279.83-13,583.56-10);

  glEnd();



}


void N() {
  glBegin(GL_POLYGON);
  glColor3ub(255,255,255);

  glVertex2d(483.86,483.64);
  glVertex2d(522.26,483.64);
  glVertex2d(550.84,533.89);
  glVertex2d(550.84,483.64);
  glVertex2d(604.57,483.64);
  glVertex2d(604.57,635);
  glVertex2d(563.74,635);
  glVertex2d(537.63,588.43);
  glVertex2d(537.63,634.04);
  glVertex2d(483.86,634.04);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(23,41,60);
  glVertex2d(522.26,483.64);
  glVertex2d(550.84,483.64);
  glVertex2d(550.84,533.89);
  glEnd();

}

void N2() {
  glBegin(GL_POLYGON);
  glColor3ub(103,103,103);

  glVertex2d(483.86-13,483.64-10);
  glVertex2d(522.26-13,483.64-10);
  glVertex2d(550.84-13,533.89-10);
  glVertex2d(550.84-13,483.64-10);
  glVertex2d(604.57-13,483.64-10);
  glVertex2d(604.57-13,635-10);
  glVertex2d(563.74-13,635-10);
  glVertex2d(537.63-13,588.43-10);
  glVertex2d(537.63-13,634.04-10);
  glVertex2d(483.86-13,634.04-10);
  glEnd();

  glBegin(GL_POLYGON);
  glColor3ub(23,41,60);
  glVertex2d(522.26-13,483.64-10);
  glVertex2d(550.84-13,483.64-10);
  glVertex2d(550.84-13,533.89-10);
  glEnd();

}

void I(){
  glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
  glVertex2d(669.5,433.17);
  glVertex2d(723.24,433.17);
  glVertex2d(723.24,583.56);
  glVertex2d(669.5,583.56);

  glEnd();
}

void I2(){
  glBegin(GL_POLYGON);
  glColor3ub(103,103,103-10);
  glVertex2d(669.5-13,433.17-10);
  glVertex2d(723.24-13,433.17-10);
  glVertex2d(723.24-13,583.56-10);
  glVertex2d(669.5-13,583.56-10);

  glEnd();
}

void lingkaran(double poX,double poY,double rad){
  double cons=(3.14/100)*2;
  double px,py;
  double posX=poX,posY=poY;
  double radius1=0;
  double radius2=rad;
  glColor3ub(255,255,255);
  glBegin(GL_TRIANGLE_STRIP);
     for(int i=0;i<100;i++){
        px=sin(i*cons)*radius1+posX;
        py=cos(i*cons)*radius1+posY;
        glVertex2f(px*10,py*10);
        px=sin(i*cons)*radius2+posX;
        py=cos(i*cons)*radius2+posY;
        glVertex2f(px*10,py*10);
     }

  glEnd();
}
//mulai dari sini bukan nama

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Nama - <G64160001>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        Bakeger();
        H2();
        H();
        A2();
        A();
        I2();
        I();
        N2();
        N();
        lingkaran(339,217,150);



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
