#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "G64160073", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 0, 800, -1.f, 1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
//glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);

void rectA(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 142+q);
    glVertex2f(31+p, 142+q);
    glVertex2f(31+p, q);
    glEnd();
}

void rectB(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 142+q);
    glVertex2f(28+p, 142+q);
    glVertex2f(28+p, q);
    glEnd();
}

void rectC(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 25+q);
    glVertex2f(65+p, 25+q);
    glVertex2f(65+p, q);
    glEnd();
}

void rectD(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 26+q);
    glVertex2f(63+p, 26+q);
    glVertex2f(63+p, q);
    glEnd();
}

void triA(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 10+q);
    glVertex2f(10+p, q);
    glEnd();
}

void triB(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, 10+q);
    glVertex2f(p-10, q);
    glEnd();
}

void triC(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, q-10);
    glVertex2f(p-10, q);
    glEnd();
}

void triD(float p, float q) {
    glBegin(GL_POLYGON);
    glColor3ub(255, 102, 153);
    glVertex2f(p, q);
    glVertex2f(p, q-10);
    glVertex2f(10+p, q);
    glEnd();
}

// bg
glBegin(GL_POLYGON);
glColor3ub(153, 255, 153);
glVertex2f(0, 0);
glVertex2f(0, 800);
glVertex2f(800, 800);
glVertex2f(800, 0);
glEnd();

// huruf H
rectA(138, 329);
rectC(169,389);
rectA(234,329);
triA(169, 414);
triB(234, 414);
triC(234, 389);
triD(169, 389);

// huruf I
rectA(293,329);
triC(293, 471);
triD(324, 471);
triA(324, 329);
triB(293, 329);

// huruf L
rectA(353, 329);
triA(384, 355);
triB(447, 355);
rectD(384, 329);

// huruf M
// sisi tegak
rectB(467, 329);
rectB(580, 329);
triB(467,329);
triA(494, 329);
triB(580, 329);
triA(606, 329);
// sisi kelok
glBegin(GL_POLYGON);
glColor3ub(255, 102, 153);
glVertex2f(537, 386);
glVertex2f(583, 474);
glVertex2f(580, 415);
glVertex2f(547, 354);
glVertex2f(527, 354);
glVertex2f(494, 414);
glVertex2f(491, 473);
glEnd();

// huruf I
rectA(636,329);
triC(636, 471);
triD(667, 471);
triA(667, 329);
triB(636, 329);

// bulet 1/4 kiri
glBegin(GL_POLYGON);
glColor3ub(97,230,230);
for (int i=0; i <= 360; i++)
{
  float rad = i*3.14159/180;
  glVertex2f(0+cos(rad)*100,0+sin(rad)*100);
}
glEnd();

// bulet 1/4 kanan
glBegin(GL_POLYGON);
glColor3ub(97,230,230);
for (int i=0; i <= 360; i++)
{
  float rad = i*3.14159/180;
  glVertex2f(800+cos(rad)*100,0+sin(rad)*100);
}
glEnd();

glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
