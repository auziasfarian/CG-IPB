#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define putih 255, 255, 255
#define maroon 237, 29, 36

double gerak=0, pindah=0;
static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "G64160030",NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);

int buff=0, blink=0, status=0, pending=0, stat=1, kedip=0;

while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glDisable( GL_DEPTH_TEST ); // here for illustrative purposes, depth test is initially DISABLED (key!)

glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();


void hurufGAtas(double poX, double poY, double rad1, double rad2) {
    double cons=(3.14/100)*2;// setengah lingkaran, kalo mau full, kali 2 aja consnya
    double px,py;
    double posX=poX, posY=poY; // titik tengah
    double radius1=rad1; //jari-jari dalam
    double radius2=rad2; // jari jari luar
    glBegin(GL_TRIANGLE_STRIP);
        for(int i=25;i<=75;i++) // maenin batesan loopingnya buat rotate, coba aja :)
        {
            px=sin(i*cons)*radius1+posX;
            py=cos(i*cons)*radius1+posY;
            glVertex2f(px*10,py*10);
            px=sin(i*cons)*radius2+posX;
            py=cos(i*cons)*radius2+posY;
            glVertex2f(px*10,py*10);
        }
    glEnd();
}

void hurufGBawah(double poX, double poY, double rad1, double rad2) {
    double cons=(3.14/100)*2;// setengah lingkaran, kalo mau full, kali 2 aja consnya
    double px,py;
    double posX=poX, posY=poY; // titik tengah
    double radius1=rad1; //jari-jari dalam
    double radius2=rad2; // jari jari luar
    glBegin(GL_TRIANGLE_STRIP);
        for(int i=-25;i<=25;i++) // maenin batesan loopingnya buat rotate, coba aja :)
        {
            px=sin(i*cons)*radius1+posX;
            py=cos(i*cons)*radius1+posY;
            glVertex2f(px*10,py*10);
            px=sin(i*cons)*radius2+posX;
            py=cos(i*cons)*radius2+posY;
            glVertex2f(px*10,py*10);
        }
    glEnd();
}

if(buff==0){
    if(status%2==0) blink++;
    else blink--;
}

buff++;
buff=buff%5;

blink = blink%117;
if(blink==117 || blink==0){
    status++;
}

if(pending==0){
    if(stat%2==0) kedip++;
    else kedip--;
}

pending++;
pending=pending%5;

kedip = kedip%117;
if(kedip==117 || kedip==0){
    stat++;
}

// background main
glBegin(GL_POLYGON);
glColor3ub(maroon);
glVertex2f(0, 800);
glColor3ub(maroon);
glVertex2f(0, 0);
glColor3ub(maroon);
glVertex2f(800, 0);
glColor3ub(maroon);
glVertex2f(800, 800);
glEnd();

// background bawah
glBegin(GL_TRIANGLES);
glColor3ub(kedip, kedip, kedip);
glVertex2f(0, 800);
glColor3ub(kedip, kedip, kedip);
glVertex2f(400, 400);
glColor3ub(kedip, kedip, kedip);
glVertex2f(800, 800);
glEnd();

// background kiri
glBegin(GL_TRIANGLES);
glColor3ub(237, blink, blink);
glVertex2f(0, 800);
glColor3ub(237, blink, blink);
glVertex2f(400, 400);
glColor3ub(237, blink, blink);
glVertex2f(0, 0);
glEnd();

// background atas
glBegin(GL_TRIANGLES);
glColor3ub(kedip, kedip, kedip);
glVertex2f(0, 0);
glColor3ub(kedip, kedip, kedip);
glVertex2f(400, 400);
glColor3ub(kedip, kedip, kedip);
glVertex2f(800, 0);
glEnd();

// background kanan
glBegin(GL_TRIANGLES);
glColor3ub(237, blink, blink);
glVertex2f(800, 0);
glColor3ub(237, blink, blink);
glVertex2f(400, 400);
glColor3ub(237, blink, blink);
glVertex2f(800, 800);
glEnd();

// huruf I
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(178, 521);
glColor3ub(putih);
glVertex2f(178, 249);
glColor3ub(putih);
glVertex2f(216, 249);
glColor3ub(putih);
glVertex2f(216, 521);
glEnd();

// huruf Y
// sayap kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(259, 426);
glColor3ub(putih);
glVertex2f(223, 249);
glColor3ub(putih);
glVertex2f(261, 249);
glColor3ub(putih);
glVertex2f(280, 357);
glEnd();

// sayap kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(259, 426);
glColor3ub(putih);
glVertex2f(297, 249);
glColor3ub(putih);
glVertex2f(332, 249);
glColor3ub(putih);
glVertex2f(296, 426);
glEnd();


// kaki
// sayap kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(259, 521);
glColor3ub(putih);
glVertex2f(259, 426);
glColor3ub(putih);
glVertex2f(296, 426);
glColor3ub(putih);
glVertex2f(296, 521);
glEnd();

// huruf A
// kaki kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(319, 521);
glColor3ub(putih);
glVertex2f(353, 248);
glColor3ub(putih);
glVertex2f(370, 324);
glColor3ub(putih);
glVertex2f(351, 521);
glEnd();

//kaki kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(389, 521);
glColor3ub(putih);
glVertex2f(353, 248);
glColor3ub(putih);
glVertex2f(391, 248);
glColor3ub(putih);
glVertex2f(426, 521);
glEnd();

//garis horizontal
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(356, 470);
glColor3ub(putih);
glVertex2f(360, 427);
glColor3ub(putih);
glVertex2f(380, 427);
glColor3ub(putih);
glVertex2f(384, 470);
glEnd();

// huruf N
// kaki kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(434, 521);
glColor3ub(putih);
glVertex2f(434, 249);
glColor3ub(putih);
glVertex2f(473, 249);
glColor3ub(putih);
glVertex2f(463, 521);
glEnd();

// kaki kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(502, 521);
glColor3ub(putih);
glVertex2f(504, 249);
glColor3ub(putih);
glVertex2f(533, 249);
glColor3ub(putih);
glVertex2f(533, 521);
glEnd();

// garis miring
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(502, 521);
glColor3ub(putih);
glVertex2f(463, 355);
glColor3ub(putih);
glVertex2f(473, 249);
glColor3ub(putih);
glVertex2f(504, 397);
glEnd();

// huruf G
    hurufGAtas(59.472, 29.725, 2, 5);
    hurufGBawah(59.472, 47.067, 2, 5);

// garis kanan atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(616,345);
glColor3ub(putih);
glVertex2f(616,297);
glColor3ub(putih);
glVertex2f(645,297);
glColor3ub(putih);
glVertex2f(645,345);
glEnd();

// garis kanan bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(616,524);
glColor3ub(putih);
glVertex2f(616,385);
glColor3ub(putih);
glVertex2f(645,385);
glColor3ub(putih);
glVertex2f(645,524);
glEnd();

// garis strip
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(603,415);
glColor3ub(putih);
glVertex2f(603,385);
glColor3ub(putih);
glVertex2f(645,385);
glColor3ub(putih);
glVertex2f(645,415);
glEnd();

//// setengah lingkaran atas
//glBegin(GL_POLYGON);
// glColor3ub(putih);
//   for (int i=180; i <= 360; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(586+cos(rad)*45,347+sin(rad)*100);
//   }
//   glEnd();
//
//// bolongan setengah lingkaran atas
//glBegin(GL_POLYGON);
// glColor3ub(237, blink, blink);
//   for (int i=180; i <= 360; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(586+cos(rad)*15,347+sin(rad)*57);
//   }
//   glEnd();
//
//// setengah lingkaran bawah
//glBegin(GL_POLYGON);
// glColor3ub(putih);
//   for (int i=0; i <= 180; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(581+cos(rad)*40,425+sin(rad)*100);
//   }
//   glEnd();

//glBegin(GL_POLYGON);
// glColor3ub(putih);
//   for (int i=0; i <= 180; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(586+cos(rad)*40,487+sin(rad)*40);
//   }
//   glEnd();

//// bolongan setengah lingkaran bawah
//glBegin(GL_POLYGON);
// glColor3ub(237, blink, blink);
//   for (int i=0; i <= 180; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(586+cos(rad)*15,420+sin(rad)*70);
//   }
//   glEnd();
//glBegin(GL_POLYGON);
// glColor3ub(237,29,36);
//   for (int i=0; i <= 180; i++)
//   {
//
//      float rad = i*3.14159/180;
//      glVertex2f(586+cos(rad)*15,487+sin(rad)*15);
//   }
//   glEnd();

// garis kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(545,478);
glColor3ub(putih);
glVertex2f(545,297);
glColor3ub(putih);
glVertex2f(575,297);
glColor3ub(putih);
glVertex2f(575,478);
glEnd();

// garis kanan
//glBegin(GL_POLYGON);
//glColor3ub(putih);
//glVertex2f(600,428);
//glColor3ub(putih);
//glVertex2f(600,393);
//glColor3ub(putih);
//glVertex2f(651,393);
//glColor3ub(putih);
//glVertex2f(651,428);
//glEnd();

// border
// border kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(118+gerak, 561);
glColor3ub(putih);
glVertex2f(118+gerak, 199);
glColor3ub(putih);
glVertex2f(128+gerak, 199);
glColor3ub(putih);
glVertex2f(128+gerak, 561);
glEnd();

gerak++;
if(gerak==574){gerak=0;}

// border kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(692-pindah, 571);
glColor3ub(putih);
glVertex2f(692-pindah, 189);
glColor3ub(putih);
glVertex2f(702-pindah, 189);
glColor3ub(putih);
glVertex2f(702-pindah, 571);
glEnd();

pindah++;
if(pindah==574){pindah=0;}

// border atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(118, 199);
glColor3ub(putih);
glVertex2f(118, 189);
glColor3ub(putih);
glVertex2f(692, 189);
glColor3ub(putih);
glVertex2f(692, 199);
glEnd();

// border bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(118, 561);
glColor3ub(putih);
glVertex2f(118, 571);
glColor3ub(putih);
glVertex2f(692, 571);
glColor3ub(putih);
glVertex2f(692, 561);
glEnd();

// huruf W
// sayap kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(188, 636);
glColor3ub(putih);
glVertex2f(182, 599);
glColor3ub(putih);
glVertex2f(186, 599);
glColor3ub(putih);
glVertex2f(192, 636);
glEnd();

// body kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(190, 628);
glColor3ub(putih);
glVertex2f(195, 599);
glColor3ub(putih);
glVertex2f(198, 599);
glColor3ub(putih);
glVertex2f(192, 636);
glEnd();

// body kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(202, 636);
glColor3ub(putih);
glVertex2f(195, 599);
glColor3ub(putih);
glVertex2f(198, 599);
glColor3ub(putih);
glVertex2f(205, 636);
glEnd();

// sayap kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(202, 636);
glColor3ub(putih);
glVertex2f(207, 599);
glColor3ub(putih);
glVertex2f(211, 599);
glColor3ub(putih);
glVertex2f(205, 636);
glEnd();

// huruf I
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(273, 636);
glColor3ub(putih);
glVertex2f(273, 599);
glColor3ub(putih);
glVertex2f(277, 599);
glColor3ub(putih);
glVertex2f(277, 636);
glEnd();

// huruf B
// garis kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(362, 636);
glColor3ub(putih);
glVertex2f(362, 599);
glColor3ub(putih);
glVertex2f(366, 599);
glColor3ub(putih);
glVertex2f(366, 636);
glEnd();

// garis atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(366, 602);
glColor3ub(putih);
glVertex2f(366, 599);
glColor3ub(putih);
glVertex2f(377, 599);
glColor3ub(putih);
glVertex2f(376, 602);
glEnd();

// garis kanan atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(376, 613);
glColor3ub(putih);
glVertex2f(376, 602);
glColor3ub(putih);
glVertex2f(380, 601);
glColor3ub(putih);
glVertex2f(380, 612);
glEnd();

// garis kanan bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(376, 633);
glColor3ub(putih);
glVertex2f(376, 620);
glColor3ub(putih);
glVertex2f(380, 620);
glColor3ub(putih);
glVertex2f(380, 633);
glEnd();

// garis tengah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(366, 618);
glColor3ub(putih);
glVertex2f(366, 615);
glColor3ub(putih);
glVertex2f(372, 615);
glColor3ub(putih);
glVertex2f(372, 618);
glEnd();

// lengkungan atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(372, 615);
glColor3ub(putih);
glVertex2f(376, 613);
glColor3ub(putih);
glVertex2f(380, 612);
glColor3ub(putih);
glVertex2f(375, 616);
glEnd();

// lengkungan bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(376, 620);
glColor3ub(putih);
glVertex2f(372, 618);
glColor3ub(putih);
glVertex2f(372, 615);
glColor3ub(putih);
glVertex2f(380, 620);
glEnd();

// garis bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(366,636);
glColor3ub(putih);
glVertex2f(366,633);
glColor3ub(putih);
glVertex2f(376,633);
glColor3ub(putih);
glVertex2f(376,636);
glEnd();

// huruf O
// garis kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(451,636);
glColor3ub(putih);
glVertex2f(451,599);
glColor3ub(putih);
glVertex2f(455,599);
glColor3ub(putih);
glVertex2f(455,636);
glEnd();

// garis atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(455,602);
glColor3ub(putih);
glVertex2f(455,599);
glColor3ub(putih);
glVertex2f(466,599);
glColor3ub(putih);
glVertex2f(466,602);
glEnd();

// garis kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(466,636);
glColor3ub(putih);
glVertex2f(466,599);
glColor3ub(putih);
glVertex2f(470,599);
glColor3ub(putih);
glVertex2f(470,636);
glEnd();


// garis bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(455,636);
glColor3ub(putih);
glVertex2f(455,633);
glColor3ub(putih);
glVertex2f(466,633);
glColor3ub(putih);
glVertex2f(466,636);
glEnd();

// huruf W 2
// sayap kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(545,636);
glColor3ub(putih);
glVertex2f(539,599);
glColor3ub(putih);
glVertex2f(543,599);
glColor3ub(putih);
glVertex2f(549,636);
glEnd();

// body kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(547,628);
glColor3ub(putih);
glVertex2f(552,599);
glColor3ub(putih);
glVertex2f(555,599);
glColor3ub(putih);
glVertex2f(549,636);
glEnd();

// body kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(559,636);
glColor3ub(putih);
glVertex2f(552,599);
glColor3ub(putih);
glVertex2f(555,599);
glColor3ub(putih);
glVertex2f(562,636);
glEnd();

// sayap kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(559,636);
glColor3ub(putih);
glVertex2f(564,599);
glColor3ub(putih);
glVertex2f(568,599);
glColor3ub(putih);
glVertex2f(562,636);
glEnd();

// huruf ) 2
// garis kiri
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(629,636);
glColor3ub(putih);
glVertex2f(629,599);
glColor3ub(putih);
glVertex2f(633,599);
glColor3ub(putih);
glVertex2f(633,636);
glEnd();

// garis atas
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(633,602);
glColor3ub(putih);
glVertex2f(633,599);
glColor3ub(putih);
glVertex2f(644,599);
glColor3ub(putih);
glVertex2f(644,602);
glEnd();

// garis kanan
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(644,636);
glColor3ub(putih);
glVertex2f(644,599);
glColor3ub(putih);
glVertex2f(648,599);
glColor3ub(putih);
glVertex2f(648,636);
glEnd();

// garis bawah
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(633,636);
glColor3ub(putih);
glVertex2f(633,633);
glColor3ub(putih);
glVertex2f(644,633);
glColor3ub(putih);
glVertex2f(644,636);
glEnd();


//exit
glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}

