#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1200, 600, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void circle(float size, float x, float y, int z)
{
    float m, n, o;
    m = x;
    n = y;
    o = z;
    int N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*o*3.14 / N);
        pY = cos(i*o*3.14 / N);
        glVertex2f(pX * size + m, pY * size + n); // ngatur posisi lingkaran disini
    }
    glEnd();
}

void display()
{
    // your drawing code here, maybe
    // BG
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2f(0,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(0,600);
    glEnd();

    glPushMatrix();
    glTranslatef(0,100,0);
    // R
    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(30,250);
    glVertex2f(55,250);
    glVertex2f(55,375);
    glVertex2f(30,375);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(30,308);
    glVertex2f(48,290);
    glVertex2f(118,360);
    glVertex2f(100,378);
    glEnd();

    glColor3ub(253,124,4);
    circle(40,70,290,2);

    glColor3ub(255,255,255);
    circle(15,70,290,2);

    // E
    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(150,250);
    glVertex2f(220,250);
    glVertex2f(220,270);
    glVertex2f(150,270);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(150,300);
    glVertex2f(210,300);
    glVertex2f(210,320);
    glVertex2f(150,320);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(150,355);
    glVertex2f(220,355);
    glVertex2f(220,375);
    glVertex2f(150,375);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(150,250);
    glVertex2f(175,250);
    glVertex2f(175,375);
    glVertex2f(150,375);
    glEnd();

    // Z
    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(250,250);
    glVertex2f(320,250);
    glVertex2f(320,270);
    glVertex2f(250,270);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(250,355);
    glVertex2f(320,355);
    glVertex2f(320,375);
    glVertex2f(250,375);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(295,270);
    glVertex2f(320,270);
    glVertex2f(275,355);
    glVertex2f(250,355);
    glEnd();

    // A
    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(400,250);
    glVertex2f(450,375);
    glVertex2f(350,375);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(400,300);
    glVertex2f(420,350);
    glVertex2f(380,350);
    glEnd();
    glPopMatrix();

    // 1
    glBegin(GL_POLYGON);
    glColor3ub(255,152,0);
    glVertex2f(470,425);
    glVertex2f(435,315);
    glVertex2f(725,600);
    glVertex2f(640,600);
    glEnd();

    // 2
    glBegin(GL_POLYGON);
    glColor3ub(244,44,43);
    glVertex2f(350,215);
    glVertex2f(350,100);
    glVertex2f(850,600);
    glVertex2f(740,600);
    glEnd();

    //3
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(210,0);
    glVertex2f(310,0);
    glVertex2f(670,360);
    glVertex2f(680,470);
    glEnd();

    // 4
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(650,370);
    glColor3ub(255,152,2);
    glVertex2f(740,410);
    glColor3ub(255,204,0);
    glVertex2f(760,480);
    glEnd();

    // 5
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(450,20);
    glColor3ub(255,152,2);
    glVertex2f(570,60);
    glColor3ub(255,204,0);
    glVertex2f(580,145);
    glEnd();

    // 6
    glBegin(GL_POLYGON);
    glColor3ub(255,84,2);
    glVertex2f(630,190);
    glColor3ub(255,152,2);
    glVertex2f(600,60);
    glColor3ub(255,204,0);
    glVertex2f(860,320);
    glColor3ub(255,204,0);
    glVertex2f(860,420);
    glEnd();

    // 7
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(380,0);
    glColor3ub(255,51,51);
    glVertex2f(400,0);
    glColor3ub(204,0,0);
    glVertex2f(860,460);
    glColor3ub(204,0,0);
    glVertex2f(840,460);
    glEnd();

    // 8
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(860,490);
    glColor3ub(255,51,51);
    glVertex2f(880,490);
    glColor3ub(204,0,0);
    glVertex2f(1000,600);
    glColor3ub(204,0,0);
    glVertex2f(980,600);
    glEnd();

    // 9
    glBegin(GL_POLYGON);
    glColor3ub(255,51,51);
    glVertex2f(380,25);
    glColor3ub(255,51,51);
    glVertex2f(385,25);
    glColor3ub(204,0,0);
    glVertex2f(945,580);
    glColor3ub(204,0,0);
    glVertex2f(940,580);
    glEnd();

    for(int i=0;i<6;i++){
        for(int j=0;j<6-i;j++){
            glColor3ub(0,193,198);
            circle(5,30+(i*20),30+(j*20),2);
        }
    }

    for(int i=0;i<3;i++){
        for(int j=0;j<6;j++){
            glBegin(GL_POLYGON);
            glColor3ub(0,193,198);
            glVertex2f(70+(j*40),530+(i*25));
            glVertex2f(90+(j*40),510+(i*25));
            glVertex2f(110+(j*40),530+(i*25));
            glEnd();
        }
    }

    glPushMatrix();
    glTranslatef(25,25,0);
    // E
    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(775,90);
    glVertex2f(845,90);
    glVertex2f(845,110);
    glVertex2f(775,110);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(775,145);
    glVertex2f(835,145);
    glVertex2f(835,165);
    glVertex2f(775,165);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(775,200);
    glVertex2f(845,200);
    glVertex2f(845,220);
    glVertex2f(775,220);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(775,90);
    glVertex2f(800,90);
    glVertex2f(800,220);
    glVertex2f(775,220);
    glEnd();

    // R
    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(875,90);
    glVertex2f(900,90);
    glVertex2f(900,220);
    glVertex2f(875,220);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(875,145);
    glVertex2f(895,130);
    glVertex2f(965,205);
    glVertex2f(950,220);
    glEnd();

    glColor3ub(253,124,4);
    circle(40,915,130,2);

    glColor3ub(255,255,255);
    circle(15,915,130,2);

    // B
    glColor3ub(253,124,4);
    circle(38,1020,125,2);

    glColor3ub(255,255,255);
    circle(15,1020,125,2);

    glColor3ub(253,124,4);
    circle(38,1020,185,2);

    glColor3ub(255,255,255);
    circle(15,1020,185,2);

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(980,90);
    glVertex2f(1005,90);
    glVertex2f(1005,220);
    glVertex2f(980,220);
    glEnd();

     // E
    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(1075,90);
    glVertex2f(1145,90);
    glVertex2f(1145,110);
    glVertex2f(1075,110);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(1075,145);
    glVertex2f(1135,145);
    glVertex2f(1135,165);
    glVertex2f(1075,165);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(253,124,4);
    glVertex2f(1075,200);
    glVertex2f(1145,200);
    glVertex2f(1145,220);
    glVertex2f(1075,220);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,42,4);
    glVertex2f(1075,90);
    glVertex2f(1100,90);
    glVertex2f(1100,220);
    glVertex2f(1075,220);
    glEnd();
    glPopMatrix();

    for(int i=0;i<6;i++){
        for(int j=6;j>6-i;j--){
            glColor3ub(0,193,198);
            circle(5,1050+(i*20),450+(j*20),2);
        }
    }

    for(int i=0;i<3;i++){
        for(int j=0;j<6;j++){
            glBegin(GL_POLYGON);
            glColor3ub(0,193,198);
            glVertex2f(880+(j*40),40+(i*25));
            glVertex2f(900+(j*40),20+(i*25));
            glVertex2f(920+(j*40),40+(i*25));
            glEnd();
        }
    }

    glPushMatrix();
    glRotatef((float) glfwGetTime() * 100.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(241,95,116);
    glVertex2f(100,150);
    glVertex2f(150,150);
    glVertex2f(150,200);
    glVertex2f(100,200);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glRotatef((float) glfwGetTime() * 75.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(100,250,116);
    glVertex2f(100,150);
    glVertex2f(150,150);
    glVertex2f(150,200);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(253,124,4);
    circle(50,0,250,2);

    glRotatef((float) glfwGetTime() * 60.f, 0.f, 0.f, 1.f);
    glColor3ub(138,210,222);
    circle(30,0,250,2);

    glRotatef((float) glfwGetTime() * 60.f, 0.f, 0.f, 1.f);
    glColor3ub(135,135,135);
    circle(15,0,250,2);
    glPopMatrix();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(255,0,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();

    glPushMatrix();
    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(255,255,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();

    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(0,255,0);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();

    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(0,255,255);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();

    glTranslatef((float) glfwGetTime() * 500.f, 0.f, 0.f);
    glColor3ub(0,0,255);
    glBegin(GL_POLYGON);
    glVertex2f(-300,0);
    glVertex2f(1200,0);
    glVertex2f(1200,600);
    glVertex2f(-300,600);
    glEnd();
    glPopMatrix();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1200, 600, "Reza eRBe", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
