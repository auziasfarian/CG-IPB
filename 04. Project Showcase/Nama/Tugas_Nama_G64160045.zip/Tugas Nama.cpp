#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#define PHI 3.14159

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void circle(float r)
{
    glBegin(GL_POLYGON);
    glColor3ub(244, 226, 66);
    float x, y;
    for(float i=0; i<3;i += 0.03){
        x = cos(i*PHI)*r;
        y = sin(i*PHI)*r;
        glVertex2d(x, y);
    }
    glEnd();
}

void F(){
    glBegin(GL_POLYGON);
    glColor3ub(244, 226, 66);
    glPushMatrix();

    glVertex2d(195, 160);
    glVertex2d(265, 145);
    glVertex2d(265, 170);
    glVertex2d(195, 185);
    glPopMatrix();
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244, 226, 66);
    glPushMatrix();
    glVertex2d(230, 172);
    glVertex2d(230, 268);
    glVertex2d(205, 268);
    glVertex2d(205, 180);
    glPopMatrix();
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244, 226, 66);
    glPushMatrix();
    glVertex2d(225, 197);
    glVertex2d(255, 190);
    glVertex2d(255, 210);
    glVertex2d(225, 215);
    glPopMatrix();
    glEnd();
}

void a(){
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glPushMatrix();
    glVertex2d(325, 178);
    glVertex2d(325, 255);
    glVertex2d(300, 255);
    glVertex2d(300, 190);
    glPopMatrix();
    glEnd();

    glTranslatef(300, 225, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x, y;
    for(int i=-35; i<25; i++){
        x = i;
        y = sqrt(1225 - x*x);
        glVertex2d(x, y);
    }
    glVertex2d(x, y-30);
    glPopMatrix();
    glEnd();

    glLoadIdentity();
    glTranslatef(300, 220, 0);
    glColor3ub(0, 0, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x1, y1;
    for(int i=-12; i<=12; i++){
        x1 = i;
        y1 = sqrt(1 - x1*x1/144.0)*20;
        glVertex2d(x1, y1);
    }
    glPopMatrix();
    glEnd();
}

void d(){
    glLoadIdentity();
    glColor3ub(244, 226, 66);
    glBegin(GL_POLYGON);
    glPushMatrix();
    glVertex2d(382, 140);
    glVertex2d(382, 255);
    glVertex2d(360, 255);
    glVertex2d(360, 145);
    glPopMatrix();
    glEnd();
    glTranslatef(361, 225, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x, y;
    for(int i=-37; i<25; i++){
        x = i;
        y = sqrt(1369 - x*x);
        glVertex2d(x, y);
    }
    glVertex2d(x, y-30);
    glPopMatrix();
    glEnd();

    glLoadIdentity();
    glTranslatef(361, 220, 0);
    glColor3ub(0, 0, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x1, y1;
    for(int i=-12; i<=12; i++){
        x1 = i;
        y1 = sqrt(1 - x1*x1/144.0)*20;
        glVertex2d(x1, y1);
    }
    glPopMatrix();
    glEnd();
}

void i(){
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glColor3ub(244, 226, 66);
    glPushMatrix();
    glVertex2d(408, 180);
    glVertex2d(408, 263);
    glVertex2d(385, 263);
    glVertex2d(385, 190);
    glPopMatrix();
    glEnd();
    glTranslatef(396, 165, 0);
    circle(14);
}

void l(){
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glPushMatrix();
    glVertex2d(438, 146);
    glVertex2d(438, 267);
    glVertex2d(415, 267);
    glVertex2d(415, 160);
    glPopMatrix();
    glEnd();
}

void a2(){
    glLoadIdentity();
    glTranslatef(170, 0, 0);
    glBegin(GL_POLYGON);
    glPushMatrix();
    glColor3ub(244, 226, 66);
    glVertex2d(325, 178);
    glVertex2d(325, 255);
    glVertex2d(300, 255);
    glVertex2d(300, 190);
    glPopMatrix();
    glEnd();

    glTranslatef(300, 225, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x, y;
    for(int i=-35; i<25; i++){
        x = i;
        y = sqrt(1225 - x*x);
        glVertex2d(x, y);
    }
    glVertex2d(x, y-30);
    glPopMatrix();
    glEnd();

    glLoadIdentity();
    glTranslatef(470, 220, 0);
    glColor3ub(0, 0, 0);
    glRotatef(90,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x1, y1;
    for(int i=-12; i<=12; i++){
        x1 = i;
        y1 = sqrt(1 - x1*x1/144.0)*20;
        glVertex2d(x1, y1);
    }
    glPopMatrix();
    glEnd();

}

void h(){
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glPushMatrix();
    glColor3ub(244, 226, 66);
    glVertex2d(496, 145);
    glVertex2d(523, 141);
    glVertex2d(528, 247);
    glVertex2d(504, 251);
    glPopMatrix();
    glEnd();

    // ellipse equation
    glLoadIdentity();
    glTranslatef(540, 250, 0);
    glRotatef(180,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x, y;
    for(int i=-35; i<=35; i++){
        x = i;
        y = sqrt(1 - x*x/1225.0)*70;
        glVertex2d(x, y);
    }
    glPopMatrix();
    glEnd();

    glLoadIdentity();
    glColor3ub(0, 0, 0);
    glTranslatef(540, 250, 0);
    glRotatef(180,0,0,1);
    glBegin(GL_POLYGON);
    glPushMatrix();
    int x1, y1;
    for(int i=-15; i<=15; i++){
        x1 = i;
        y1 = sqrt(1 - x1*x1/225.0)*40;
        glVertex2d(x1, y1);
    }
    glPopMatrix();
    glEnd();
}

void grid(int x, int y)
{
    int i;
    glLoadIdentity();
    glColor3ub(255,255,255);
    glBegin(GL_LINES);
    for(i=0; i<=x; i+=65)
    {
        glVertex2f(i,0);
        glVertex2f(i,y);
    }
    for(i=0; i<=y; i+=65)
    {
        glVertex2f(0,i);
        glVertex2f(x,i);
    }
    glEnd();
}

void block1(int x, int y_pos){
    glLoadIdentity();
    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex2d(x+15, 15+y_pos*65);
    glVertex2d(x+50, 15+y_pos*65);
    glVertex2d(x+50, 50+y_pos*65);
    glVertex2d(x+15, 50+y_pos*65);
    glEnd();
}

void movF(int x){
        block1(x, 0); block1(x-65, 0); block1(x+65, 0); block1(x+130, 0);
        block1(x-65, 1);
        block1(x, 2); block1(x-65, 2); block1(x+65, 2);
        block1(x-65, 3);
        block1(x-65, 4);
        block1(x-65, 5);
}

void movA(int x){
        block1(x, 0);
        block1(x-65, 1); block1(x+65, 1);
        block1(x, 2); block1(x-65, 2); block1(x+65, 2); block1(x+130, 2); block1(x-130, 2);
        block1(x-130, 3); block1(x+130, 3);
        block1(x-130, 4); block1(x+130, 4);
        block1(x-130, 5); block1(x+130, 5);
}

void movD(int x){
        block1(x, 0); block1(x-65, 0); block1(x+65, 0);
        block1(x-65, 1); block1(x+130, 1);
        block1(x-65, 2); block1(x+130, 2);
        block1(x-65, 3); block1(x+130, 3);
        block1(x-65, 4); block1(x+130, 4);
        block1(x, 5); block1(x-65, 5); block1(x+65, 5);
}

void movI(int x){
        block1(x, 0); block1(x-65, 0); block1(x+65, 0);
        block1(x, 1);
        block1(x, 2);
        block1(x, 3);
        block1(x, 4);
        block1(x, 5); block1(x-65, 5); block1(x+65, 5);
}

void movL(int x){
        block1(x, 0);
        block1(x, 1);
        block1(x, 2);
        block1(x, 3);
        block1(x, 4);
        block1(x, 5); block1(x+130, 5); block1(x+65, 5); block1(x+195, 5);
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 400, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int main(void)
{
    int x=0, trig = 'F'; // untuk panel gerak
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(960, 480, "Tugas Grafkom Nama - Fadilah Agung Nugraha - G64160045", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        // Block animation here
        if(trig == 'F'){
            movF(x);
            if (65 * 14 == x){x = -195; trig = 'A';}
        } else if (trig == 'A'){
            movA(x);
            if (65 * 14 == x){x = -195; trig = 'D';}
        } else if (trig == 'D'){
            movD(x);
            if (65 * 14 == x){x = -195; trig = 'I';}
        } else if (trig == 'I'){
            movI(x);
            if (65 * 14 == x){x = -195; trig = 'L';}
        } else {
            movL(x);
            if (65 * 14 == x){x = -195; trig = 'F';}
        }
        x += 65;
        //grid(800, 400);
        F(); a(); d(); i(); l();
        a2(); h();
        usleep(100000);
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
