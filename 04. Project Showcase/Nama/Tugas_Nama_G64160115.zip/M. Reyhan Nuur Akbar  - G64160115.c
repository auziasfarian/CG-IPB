#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0;
int buff=0;
int colorf[2][3]={{0,0,0},{255,255,255}};
int color1[3][3]={{0,0,0},{255,255,255},{220,203,24}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);// your code here, maybe
    glFlush();
}

void R(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(68,210);
    glVertex2d(112,210);
    glVertex2d(122,223);
    glVertex2d(114,232);
    glVertex2d(105,238);
    glVertex2d(80,238);
    glVertex2d(80,252);
    glVertex2d(68,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(114,232);
    glVertex2d(122,240);
    glVertex2d(122,252);
    glVertex2d(109,262);
    glVertex2d(109,242);
    glVertex2d(105,238);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%2][0],colorf[(clindex+1)%2][1],colorf[(clindex+1)%2][2]);
    glVertex2d(80,219);
    glVertex2d(105,219);
    glVertex2d(108,224);
    glVertex2d(105,228);
    glVertex2d(80,228);

    glEnd();
}

void E(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(130,210);
    glVertex2d(143,219);
    glVertex2d(143,243);
    glVertex2d(130,252);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(130,210);
    glVertex2d(143,219);
    glVertex2d(172,219);
    glVertex2d(181,210);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(143,227);
    glVertex2d(175,227);
    glVertex2d(166,235);
    glVertex2d(143,235);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(143,243);
    glVertex2d(180,243);
    glVertex2d(170,252);
    glVertex2d(130,252);
    glEnd();
}

void Y(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(214,223);
    glVertex2d(221,232);
    glVertex2d(221,252);
    glVertex2d(208,259);
    glVertex2d(208,232);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(185,210);
    glVertex2d(201,210);
    glVertex2d(214,223);
    glVertex2d(208,232);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(214,223);
    glVertex2d(228,210);
    glVertex2d(243,210);
    glVertex2d(221,232);
    glEnd();
}

void H(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(249,210);
    glVertex2d(262,210);
    glVertex2d(262,252);
    glVertex2d(249,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(262,227);
    glVertex2d(287,227);
    glVertex2d(287,235);
    glVertex2d(262,235);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(287,210);
    glVertex2d(300,210);
    glVertex2d(300,252);
    glVertex2d(287,252);
    glEnd();
}

void A(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(309,219);
    glVertex2d(319,210);
    glVertex2d(322,219);
    glVertex2d(322,252);
    glVertex2d(309,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(319,210);
    glVertex2d(351,210);
    glVertex2d(348,219);
    glVertex2d(322,219);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(348,219);
    glVertex2d(351,210);
    glVertex2d(361,219);
    glVertex2d(361,252);
    glVertex2d(348,252);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(322,230);
    glVertex2d(348,230);
    glVertex2d(348,240);
    glVertex2d(322,240);
    glEnd();
}

void N(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(370,210);
    glVertex2d(379,210);
    glVertex2d(383,227);
    glVertex2d(383,252);
    glVertex2d(370,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(413,252);
    glVertex2d(410,235);
    glVertex2d(410,210);
    glVertex2d(423,210);
    glVertex2d(423,252);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(379,210);
    glVertex2d(383,227);
    glVertex2d(413,252);
    glVertex2d(410,235);
    glEnd();
}

void cg(){

    glBegin(GL_POLYGON);
    glColor3ub(color1[(clindex)%3][0],color1[(clindex)%3][1],color1[(clindex)%3][2]);
    glVertex2d(790,455);
    glVertex2d(772,455);
    glVertex2d(772,472);
    glVertex2d(790,472);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color1[(clindex+1)%3][0],color1[(clindex+1)%3][1],color1[(clindex+1)%3][2]);
    glVertex2d(772,486);
    glVertex2d(790,486);
    glVertex2d(790,503);
    glVertex2d(772,503);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(color1[(clindex+2)%3][0],color1[(clindex+2)%3][1],color1[(clindex+2)%3][2]);
    glVertex2d(757,455);
    glVertex2d(757,472);
    glVertex2d(738,472);
    glVertex2d(738,455);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(738,516);
    glVertex2d(757,516);
    glVertex2d(757,533);
    glVertex2d(738,533);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(705,486);
    glVertex2d(723,486);
    glVertex2d(723,503);
    glVertex2d(705,503);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(705,516);
    glVertex2d(723,516);
    glVertex2d(723,533);
    glVertex2d(705,533);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(705,546);
    glVertex2d(723,546);
    glVertex2d(723,563);
    glVertex2d(705,563);
    glEnd();
    //left
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(637,447);
    glVertex2d(656,447);
    glVertex2d(656,464);
    glVertex2d(637,464);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(637,477);
    glVertex2d(656,477);
    glVertex2d(656,494);
    glVertex2d(637,494);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(637,508);
    glVertex2d(656,508);
    glVertex2d(656,525);
    glVertex2d(637,525);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(637,538);
    glVertex2d(656,538);
    glVertex2d(656,555);
    glVertex2d(637,555);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(603,417);
    glVertex2d(622,417);
    glVertex2d(622,434);
    glVertex2d(603,434);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(603,477);
    glVertex2d(622,477);
    glVertex2d(622,494);
    glVertex2d(603,494);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(603,538);
    glVertex2d(622,538);
    glVertex2d(622,555);
    glVertex2d(603,555);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(566,447);
    glVertex2d(585,447);
    glVertex2d(585,464);
    glVertex2d(566,464);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(566,477);
    glVertex2d(585,477);
    glVertex2d(585,494);
    glVertex2d(566,494);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(566,568);
    glVertex2d(585,568);
    glVertex2d(585,585);
    glVertex2d(566,585);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(533,417);
    glVertex2d(552,417);
    glVertex2d(552,434);
    glVertex2d(533,434);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(533,538);
    glVertex2d(552,538);
    glVertex2d(552,555);
    glVertex2d(533,555);
    glEnd();
    //left-middle
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(495,552);
    glVertex2d(514,552);
    glVertex2d(514,569);
    glVertex2d(495,569);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(495,582);
    glVertex2d(514,582);
    glVertex2d(514,599);
    glVertex2d(495,599);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(495,613);
    glVertex2d(514,613);
    glVertex2d(514,630);
    glVertex2d(495,630);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(462,552);
    glVertex2d(480,552);
    glVertex2d(480,569);
    glVertex2d(462,569);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(462,613);
    glVertex2d(480,613);
    glVertex2d(480,630);
    glVertex2d(462,630);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(428,582);
    glVertex2d(447,582);
    glVertex2d(447,599);
    glVertex2d(428,599);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(428,613);
    glVertex2d(447,613);
    glVertex2d(447,630);
    glVertex2d(428,630);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(428,643);
    glVertex2d(447,643);
    glVertex2d(447,660);
    glVertex2d(428,660);
    glEnd();
    //right-middle
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(361,517);
    glVertex2d(380,517);
    glVertex2d(380,534);
    glVertex2d(361,534);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(361,547);
    glVertex2d(380,547);
    glVertex2d(380,564);
    glVertex2d(361,564);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(361,577);
    glVertex2d(380,577);
    glVertex2d(380,594);
    glVertex2d(361,594);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(361,607);
    glVertex2d(380,607);
    glVertex2d(380,624);
    glVertex2d(361,624);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(361,637);
    glVertex2d(380,637);
    glVertex2d(380,654);
    glVertex2d(361,654);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(326,517);
    glVertex2d(345,517);
    glVertex2d(345,534);
    glVertex2d(326,534);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(326,577);
    glVertex2d(345,577);
    glVertex2d(345,594);
    glVertex2d(326,594);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(326,637);
    glVertex2d(345,637);
    glVertex2d(345,654);
    glVertex2d(326,654);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(326,667);
    glVertex2d(345,667);
    glVertex2d(345,684);
    glVertex2d(326,684);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(290,547);
    glVertex2d(308,547);
    glVertex2d(308,564);
    glVertex2d(290,564);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(290,577);
    glVertex2d(308,577);
    glVertex2d(308,594);
    glVertex2d(290,594);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(290,667);
    glVertex2d(308,667);
    glVertex2d(308,684);
    glVertex2d(290,684);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(256,517);
    glVertex2d(275,517);
    glVertex2d(275,534);
    glVertex2d(256,534);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(256,637);
    glVertex2d(275,637);
    glVertex2d(275,654);
    glVertex2d(256,654);
    glEnd();


}

void gg(){

    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex2d(672,441);
    glVertex2d(800,441);
    glVertex2d(800,800);
    glVertex2d(672,800);
    glEnd();
    //left
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex2d(508,537);
    glVertex2d(508,405);
    glVertex2d(672,405);
    glVertex2d(672,800);
    glVertex2d(520,800);
    glEnd();
    //left-middle
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex2d(399,537);
    glVertex2d(520,537);
    glVertex2d(520,800);
    glVertex2d(399,800);
    glVertex2d(399,537);
    glEnd();
    //right-middle
    glBegin(GL_LINE_STRIP);
    glColor3ub(255,255,255);
    glVertex2d(235,504);
    glVertex2d(399,504);
    glVertex2d(399,800);
    glVertex2d(235,800);
    glVertex2d(235,504);
    glEnd();
    //right
}

void brc(){

    glBegin(GL_TRIANGLE_FAN);
    float r=230, t=100, xmid=235,ymid=237;
    for(int i=1;i<=t;i++){
        float sudut=i*(2*3.14/t);
        float x= xmid+r*cos(sudut);
        float y= ymid+r*sin(sudut);
        glColor3ub(colorf[(clindex+1)%2][0],colorf[(clindex+1)%2][1],colorf[(clindex+1)%2][2]);
        glVertex2f(x, y);
    }
    glEnd();
}

void cl(){

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(110,432);
    glVertex2d(400,74);
    glColor3ub(colorf[(clindex+1)%2][0],colorf[(clindex+1)%2][1],colorf[(clindex+1)%2][2]);
    glVertex2d(800,441);
    glVertex2d(733,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(800,440);
    glVertex2d(800,800);
    glVertex2d(673,800);
    glVertex2d(673,440);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(521,537);
    glVertex2d(520,800);
    glVertex2d(671,800);
    glVertex2d(671,405);
    glVertex2d(507,405);
    glVertex2d(507,537);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(399,537);
    glVertex2d(520,537);
    glVertex2d(520,800);
    glVertex2d(399,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(234,504);
    glVertex2d(397,504);
    glVertex2d(397,800);
    glVertex2d(234,800);
    glEnd();

}

void bt(){

    glBegin(GL_POINT);
    glColor3ub(255,255,255);
    glVertex2d(775,107);
    //glVertex2d(769,315);
    //glVertex2d(741,158);
    //glVertex2d(741,192);
    //glVertex2d(745,251);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas M. Reyhan Nuur Akbar - <G64160115>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%1000;

        setup_viewport(window);

        display();
        cl();
        brc();
        R();
        E();
        Y();
        H();
        A();
        N();

        //brc();
        cg();
        gg();
        //bt();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
