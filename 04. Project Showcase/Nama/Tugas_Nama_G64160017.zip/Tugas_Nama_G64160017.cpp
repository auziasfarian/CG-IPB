#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800,0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
//Matriks Warna
int clindex=0,buff=0;
int colorf[3][3]={{70,163,203},{229,232,237},{255,216,32}};

//setengah lingkaran sebelah kanan
void halfcircle(float posisiX,float posisiY,float jari2){
    float X, Y;
	glBegin(GL_POLYGON);
		for(int i=0; i<=500; i++){
			X=sin(i*2*3.14/1000)*jari2+posisiX;
			Y=cos(i*2*3.14/1000)*jari2+posisiY;
			glVertex2f(X, Y);
		}
	glEnd();
}
//setengah lingkaran sebelah kiri
void revhalfcircle(float posisiX,float posisiY,float jari2){
    float X, Y;
	glBegin(GL_POLYGON);
		for(int i=0; i<=500; i++){
			X=-sin(i*2*3.14/1000)*jari2+posisiX;
			Y=-cos(i*2*3.14/1000)*jari2+posisiY;
			glVertex2f(X, Y);
		}
	glEnd();
}
//buat segi empat
void kotak(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4){
    glBegin(GL_QUADS);
        glVertex2f(x1,y1); //kiri atas
        glVertex2f(x2,y2);   //kiri bawah
        glVertex2f(x3,y3);    //kanan bawah
        glVertex2f(x4,y4);  //kanan atas
    glEnd();
}
//NAMA NORMAN
void norman(int warna1,int warna2,int warna3){
    //huruf N
    glColor3ub(warna1,warna2,warna3);
    kotak(204,247,204,329,225,329,225,247);
    kotak(218,247,251,329,274,329,238,247);
    kotak(263,247,263,329,284,329,284,247);
    //huruf O
    kotak(298,265,298,312,320,312,320,265);
    kotak(349,265,349,312,371,312,371,265);
    kotak(314,247,314,269,355,269,355,247);
    kotak(314,307,314,329,355,329,355,307);
    revhalfcircle(314,263,15);
    revhalfcircle(314,313,15);
    halfcircle(355,313,15);
    halfcircle(355,263,15);
    //huruf R
    kotak(386,247,386,329,408,329,408,247);
    kotak(408,247,408,265,436,265,436,247);
    kotak(408,285,408,303,436,303,436,285);
    kotak(420,303,435,329,450,329,434,297);
    kotak(428,265,428,285,452,285,452,265);
    halfcircle(436,263,15);
    halfcircle(436,281,15);
    //huruf M
    kotak(371,370,371,452,393,452,393,370);
    kotak(386,370,410,452,432,452,404,370);
    kotak(437,370,413,450,432,452,454,370);
    kotak(447,370,447,452,469,452,469,370);
    //huruf A
    kotak(503,370,479,452,503,452,523,370);
    kotak(506,421,506,439,533,439,533,421);
    kotak(518,370,536,452,561,452,536,370);
    //huruf N
    kotak(571,370,571,452,591,452,591,370);
    kotak(584,370,617,452,640,452,604,370);
    kotak(630,370,630,452,650,452,650,370);
}
//NORMAN KELAPKELIP
void nfdkelip(){

    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
     //huruf N
    kotak(204,247,204,329,225,329,225,247);
    kotak(218,247,251,329,274,329,238,247);
    kotak(263,247,263,329,284,329,284,247);
    //huruf O
    kotak(298,265,298,312,320,312,320,265);
    kotak(349,265,349,312,371,312,371,265);
    kotak(314,247,314,269,355,269,355,247);
    kotak(314,307,314,329,355,329,355,307);
    revhalfcircle(314,263,15);
    revhalfcircle(314,313,15);
    halfcircle(355,313,15);
    halfcircle(355,263,15);
    //huruf R
    kotak(386,247,386,329,408,329,408,247);
    kotak(408,247,408,265,436,265,436,247);
    kotak(408,285,408,303,436,303,436,285);
    kotak(420,303,435,329,450,329,434,297);
    kotak(428,265,428,285,452,285,452,265);
    halfcircle(436,263,15);
    halfcircle(436,281,15);
    //huruf M
    kotak(371,370,371,452,393,452,393,370);
    kotak(386,370,410,452,432,452,404,370);
    kotak(437,370,413,450,432,452,454,370);
    kotak(447,370,447,452,469,452,469,370);
    //huruf A
    kotak(503,370,479,452,503,452,523,370);
    kotak(506,421,506,439,533,439,533,421);
    kotak(518,370,536,452,561,452,536,370);
    //huruf N
    kotak(571,370,571,452,591,452,591,370);
    kotak(584,370,617,452,640,452,604,370);
    kotak(630,370,630,452,650,452,650,370);
}
void display()
{
    //background level 0
    glColor3d(0,0,0);
    glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(1,767);
        glVertex2d(1,800);
        glVertex2d(800,800);
        glVertex2d(800,305);
    glEnd();
    glColor3d(1,1,1);
    kotak(0,0,1,767,800,305,800,0);

    //background level 1
    glRotatef((float) glfwGetTime() * -55.f, 0.f, 0.f, 0.f);
    glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(0,85);
        glVertex2d(0,165);
        glVertex2d(228,34);
        glVertex2d(228,0);
        glVertex2d(149,0);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(1,0,0);
        glVertex2d(0,176);
        glVertex2d(0,666);
        glVertex2d(713,248);
        glVertex2d(713,0);
        glVertex2d(307,0);
    glEnd();

    //poligon merah bawah
    kotak(94,606,414,791,414,739,138,580);
    kotak(414,739,414,791,780,580,735,555);
    kotak(414,739,414,791,780,580,735,555);
    kotak(735,555,780,580,780,307,735,343);
    glBegin(GL_POLYGON);
        glColor3d(1,1,1);
        glVertex2d(414,45);
        glVertex2d(733,229);
        glVertex2d(800,229);
        glVertex2d(800,0);
        glVertex2d(494,0);
    glEnd();
    glRotatef((float) glfwGetTime() * 55.f, 0.f, 0.f, 0.f);

    //segienam merah
    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);
        glVertex2d(129,532);
        glVertex2d(414,696);
        glVertex2d(699,532);
        glVertex2d(699,203);
        glVertex2d(414,39);
        glVertex2d(129,203);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(1,1,1);
        glVertex2d(141,525);
        glVertex2d(414,683);
        glVertex2d(688,525);
        glVertex2d(688,210);
        glVertex2d(414,52);
        glVertex2d(141,210);
    glEnd();
    glRotatef((float) glfwGetTime() * 55.f, 0.f, 0.f, 0.f);

    //segienam merah
    glBegin(GL_POLYGON);
        glColor3ub(200,0,0);
        glVertex2d(129,532);
        glVertex2d(414,696);
        glVertex2d(699,532);
        glVertex2d(699,203);
        glVertex2d(414,39);
        glVertex2d(129,203);
    glEnd();
    glBegin(GL_POLYGON);
        glColor3d(1,1,1);
        glVertex2d(141,525);
        glVertex2d(414,683);
        glVertex2d(688,525);
        glVertex2d(688,210);
        glVertex2d(414,52);
        glVertex2d(141,210);
    glEnd();
    norman(200,0,0);
    glRotatef((float) glfwGetTime() * 55.f, 0.f, 0.f, 0.f);
    nfdkelip();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(600, 600, "Norman Firmansyah Destiawan G64160017", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
