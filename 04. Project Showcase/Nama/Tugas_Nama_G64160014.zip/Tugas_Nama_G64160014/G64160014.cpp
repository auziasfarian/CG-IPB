#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;
int color[3][3]={{244,176,176},{175,104,104},{140,49,49}};
int colors[3][3]={{156,255,203},{121,219,165},{125,178,147}};

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
void S(){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(122,152);
    glVertex2d(0,152);
    glVertex2d(0,21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(29,21);
    glVertex2d(275,21);
    glVertex2d(157,152);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(189,152);
    glVertex2d(311,21);
    glVertex2d(438,152);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(363,21);
    glVertex2d(493,152);
    glVertex2d(610,21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(533,152);
    glVertex2d(655,21);
    glVertex2d(782,152);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(701,21);
    glVertex2d(800,21);
    glVertex2d(800,120);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(800,779);
    glVertex2d(800,670);
    glVertex2d(695,779);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(663,779);
    glVertex2d(781,656);
    glVertex2d(535,656);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(489,656);
    glVertex2d(616,779);
    glVertex2d(367,779);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(198,656);
    glVertex2d(444,656);
    glVertex2d(326,779);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(284,779);
    glVertex2d(158,656);
    glVertex2d(38,779);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(115,656);
    glVertex2d(0,779);
    glVertex2d(0,656);
    glEnd();
}

void S2(){
    glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(0,47);
    glVertex2d(88,139);
    glVertex2d(0,139);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(66,33);
    glVertex2d(240,33);
    glVertex2d(158,125);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(225,139);
    glVertex2d(311,47);
    glVertex2d(402,139);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(403,33);
    glVertex2d(577,33);
    glVertex2d(493,125);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(575,139);
    glVertex2d(655,47);
    glVertex2d(751,139);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(737,33);
    glVertex2d(800,93);
    glVertex2d(800,33);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(800,697);
    glVertex2d(800,761);
    glVertex2d(736,761);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(571,674);
    glVertex2d(663,761);
    glVertex2d(745,674);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(490,674);
    glVertex2d(580,761);
    glVertex2d(408,761);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(408,674);
    glVertex2d(326,761);
    glVertex2d(234,674);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(color[clindex%3][0],color[(clindex)%3][1],color[(clindex)%3][2]);
    glVertex2d(249,764);
    glVertex2d(158,674);
    glVertex2d(73,761);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(colors[clindex%3][0],colors[(clindex)%3][1],colors[(clindex)%3][2]);
    glVertex2d(0,758);
    glVertex2d(79,674);
    glVertex2d(0,673);
    glEnd();
}
void K(){
    glBegin(GL_POLYGON);
    glColor3ub(247,245,178);
    glVertex2d(0,0);
    glVertex2d(0,800);
    glVertex2d(800,800);
    glVertex2d(800,0);
    glEnd();
}

void K2(){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(127,192);
    glVertex2d(127,593);
    glVertex2d(667,593);
    glVertex2d(667,192);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(247,245,178);
    glVertex2d(143,209);
    glVertex2d(648,209);
    glVertex2d(648,574);
    glVertex2d(143,574);
    glEnd();
}

void W(){
    glBegin(GL_POLYGON);
    glColor3ub(195,131,204);
    glVertex2d(70,301);
    glVertex2d(105,435);
    glVertex2d(115,415);
    glVertex2d(89,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(188,94,204);
    glVertex2d(105,435);
    glVertex2d(115,415);
    glVertex2d(115,415);
    glVertex2d(123,435);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(211,50,234);
    glVertex2d(115,415);
    glVertex2d(123,435);
    glVertex2d(153,321);
    glVertex2d(144,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(152,26,170);
    glVertex2d(144,301);
    glVertex2d(162,301);
    glVertex2d(188,415);
    glVertex2d(179,435);
    glVertex2d(152,321);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,142,237);
    glVertex2d(189,415);
    glVertex2d(197,435);
    glVertex2d(235,301);
    glVertex2d(217,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,80,239);
    glVertex2d(179,435);
    glVertex2d(188,415);
    glVertex2d(189,415);
    glVertex2d(197,435);
    glEnd();
}
void A1(){
    glBegin(GL_POLYGON);
    glColor3ub(160, 207, 239);
    glVertex2d(284,435);
    glVertex2d(302,435);
    glVertex2d(316,393);
    glVertex2d(320,379);
    glVertex2d(340,316);
    glVertex2d(330,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(3,206,252);
    glVertex2d(330,301);
    glVertex2d(351,301);
    glVertex2d(340.53,316.5);
    glVertex2d(340.13,316.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96,187,239);
    glVertex2d(320,379);
    glVertex2d(360,379);
    glVertex2d(364,393);
    glVertex2d(316,393);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(11,153,216);
    glVertex2d(378,435);
    glVertex2d(397,435);
    glVertex2d(351,301);
    glVertex2d(340,316);
    glVertex2d(360,379);
    glVertex2d(364,393);
    glEnd();
}
void F(){
    glBegin(GL_POLYGON);
    glColor3ub(154,232,197);
    glVertex2d(470,435);
    glVertex2d(487,435);
    glVertex2d(487,374);
    glVertex2d(487,360);
    glVertex2d(487,315);
    glVertex2d(470,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(83,242,166);
    glVertex2d(470,301);
    glVertex2d(487,315);
    glVertex2d(543,315);
    glVertex2d(543,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(101,219,160);
    glVertex2d(487,374);
    glVertex2d(538,374);
    glVertex2d(538,360);
    glVertex2d(487,360);
    glEnd();
}
void A2(){
    glBegin(GL_POLYGON);
    glColor3ub(242,167,173);
    glVertex2d(616,435);
    glVertex2d(634,435);
    glVertex2d(648,393);
    glVertex2d(651,379);
    glVertex2d(671,316);
    glVertex2d(662,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,146,152);
    glVertex2d(662,301);
    glVertex2d(683,301);
    glVertex2d(672,316);
    glVertex2d(671,316);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,119,129);
    glVertex2d(651,379);
    glVertex2d(692,379);
    glVertex2d(696,393);
    glVertex2d(648,393);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(216,50,63);
    glVertex2d(683,301);
    glVertex2d(729,435);
    glVertex2d(710,435);
    glVertex2d(696,393);
    glVertex2d(692,379);
    glVertex2d(671,316);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Grid", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
         if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();

        K();
        K2();
        S();
        S2();
        W();
        A1();
        F();
        A2();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
