#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

#define PUTIH 242,244,248
#define ABU_G 81,87,94
#define ABU_T 202,204,210
#define Batas_atas 439.306
#define Batas_bawah 502.84
#define SKIN 249,227,202

#define drawOneLine(x1,y1,x2,y2)  glBegin(GL_LINES);  \
   glVertex2f ((x1),(y1)); glVertex2f ((x2),(y2)); glEnd();

int clindex=0,buff=0,
    clindex1=0,buff1=0,
    clindex2=0,buff2=0,
    clindex3=0,buff3=0,
    clindex4=0,buff4=0,
    clindex5=0,buff5=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClearColor(0.949, 0.957, 0.972, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    glClearColor(0.949, 0.957, 0.972, 0);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 700, 700, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void displaybackground() {

    if(buff1==0)clindex1++; buff1++; buff1=buff1%643;
    if(buff2==0)clindex2++; buff2++; buff2=buff2%725;
    if(buff3==0)clindex3++; buff3++; buff3=buff3%982;
    if(buff4==0)clindex4++; buff4++; buff4=buff4%429;
    if(buff5==0)clindex5++; buff5++; buff5=buff5%400;

    int colorf1[2][3]={{ABU_T},{ABU_G}};
    int colorf2[2][3]={{ABU_G},{ABU_T}};

    //background
    glBegin(GL_POLYGON);
        glColor3ub(38, 132, 209);
        glVertex2d(19.61, 19.61);
        glVertex2d(680.44, 19.61);
        glVertex2d(680.44, 680.44);
        glVertex2d(19.61, 680.44);
    glEnd();

    //square1
    glBegin(GL_POLYGON);
        glColor4ub(ABU_T,102);
        glVertex2d(183.538, 127.504);
        glVertex2d(338.359, 127.504);
        glVertex2d(338.359, 302.423);
        glVertex2d(183.538, 302.423);
    glEnd();

    //square2
    glBegin(GL_POLYGON);
        glColor4ub(colorf1[clindex2%2][0],colorf1[clindex2%2][1],colorf1[clindex2%2][2],61);
        glVertex2d(387.238, 67.005);
        glVertex2d(619.853, 67.005);
        glVertex2d(619.853, 313.816);
        glVertex2d(387.238, 313.816);
    glEnd();

    //square3
    glBegin(GL_POLYGON);
        glColor4ub(ABU_G,0.19*255);
        glVertex2d(297.414, 274.17);
        glVertex2d(464.374, 274.17);
        glVertex2d(464.374, 451.335);
        glVertex2d(297.414, 451.335);
    glEnd();

    //square4
    glBegin(GL_POLYGON);
        glColor4ub(colorf1[clindex4%2][0],colorf1[clindex4%2][1],colorf1[clindex4%2][2],0.22*255);
        glVertex2d(358.379, 377.629);
        glVertex2d(577.765, 377.629);
        glVertex2d(577.765, 621.226);
        glVertex2d(358.379, 621.226);
    glEnd();

    //square5
    glBegin(GL_POLYGON);
        glColor4ub(ABU_G,0.19*255);
        glVertex2d(121.393, 524.171);
        glVertex2d(412.971, 524.171);
        glVertex2d(412.971, 606.205);
        glVertex2d(121.393, 606.205);
    glEnd();

    //shadow
    glBegin(GL_POLYGON);
        glColor4ub(0,0,0,50);
        glVertex2d(504.898, 420.553);
        glVertex2d(593.629, 420.553);
        glVertex2d(593.629, 450.943);
        glVertex2d(504.898, 450.943);
    glEnd();


}

void displayfauzi() {
    //f1 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(202, 204, 210);
        glVertex2d(76.481, 355.566);
        glVertex2d(104.959, 373.085);
        glVertex2d(105.074, 419.225);
        glVertex2d(76.481, 419.225);
    glEnd();

    //f2 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(76.481, 355.566);
        glVertex2d(104.959, 373.085);
        glVertex2d(132.475, 373.085);
        glVertex2d(132.475, 355.566);
    glEnd();

    //f3 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(132.475, 390.648);
        glVertex2d(132.475, 402.502);
        glVertex2d(105.018, 402.502);
        glVertex2d(105.018, 390.648);
    glEnd();

    //--------------------------------

    //a1 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(81, 87, 94);
        glVertex2d(177.518, 356.892);
        glVertex2d(167.301, 420.502);
        glVertex2d(146.402, 420.502);
    glEnd();

    //a2 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(177.518, 356.892);
        glVertex2d(167.301, 420.502);
        glVertex2d(206.226, 420.502);
    glEnd();

    //--------------------------------

    //U1 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(216.997, 356.892);
        glVertex2d(245.532, 356.892);
        glVertex2d(245.532, 420.502);
        glVertex2d(216.997, 420.502);
    glEnd();

    //U2 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(260.308, 356.892);
        glVertex2d(274.414, 356.892);
        glVertex2d(274.414, 420.502);
        glVertex2d(260.308, 420.502);
    glEnd();

    //U3 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(260.308, 420.502);
        glVertex2d(245.532, 420.502);
        glVertex2d(245.532, 388.716);
        glVertex2d(260.308, 388.716);
    glEnd();

    //--------------------------------

    //z1 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(290.239, 356.933);
        glVertex2d(347.703, 356.933);
        glVertex2d(347.703, 368.568);
        glVertex2d(290.239, 368.568);
    glEnd();

    //z2 fauzi
    glBegin(GL_TRIANGLES);
        glColor3ub(ABU_G);
        glVertex2d(347.703, 385.89);
        glVertex2d(290.212, 420.502);
        glVertex2d(347.703, 368.568);
    glEnd();

    //Z3 fauzi
    glBegin(GL_TRIANGLES);
        glColor3ub(PUTIH);
        glVertex2d(347.703, 385.89);
        glVertex2d(290.212, 420.502);
        glVertex2d(347.703, 420.502);
    glEnd();

    //--------------------------------

    //i2 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(379.822, 356.933);
        glVertex2d(363.489, 420.502);
        glVertex2d(392.197, 420.502);
        glVertex2d(392.197, 356.933);
    glEnd();

    //i1 fauzi
    glBegin(GL_POLYGON);
        glColor3ub(ABU_T);
        glVertex2d(381.667, 356.933);
        glVertex2d(363.489, 420.502);
        glVertex2d(363.489, 356.933);
    glEnd();


}

void displaytitik() {

    if(buff==0)clindex++;
        buff++;
        buff=buff%500;

    int colorf[2][3]={{237,144,81},{198,77,68}};

    //titik utama
    glBegin(GL_POLYGON);
        glColor3ub(colorf[(clindex+2)%2][0],colorf[(clindex+2)%2][1],colorf[(clindex+2)%2][2]);
        glVertex2d(392.197, 315.407);
        glVertex2d(392.197, 344.116);
        glVertex2d(363.489, 344.116);
        glVertex2d(363.489, 315.407);
    glEnd();

    //titik kedua
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(369.635, 344.116);
        glVertex2d(386.051, 344.116);
        glVertex2d(377.978, 325.188);
    glEnd();

    //cahaya1
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(295.407, 325.658);
        glVertex2d(350.114, 325.658);
        glVertex2d(350.114, 330.713);
        glVertex2d(295.407, 330.713);
    glEnd();

    //cahaya2
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(458.041, 325.658);
        glVertex2d(406.302, 325.658);
        glVertex2d(406.302, 330.713);
        glVertex2d(458.041, 330.713);
    glEnd();

    //cahaya3
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(323.565, 270.767);
        glVertex2d(351.477, 309.324);
        glVertex2d(355.383, 306.152);
        glVertex2d(327.473, 267.593);
    glEnd();

    //cahaya4
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(436.729, 270.767);
        glVertex2d(406.232, 309.324);
        glVertex2d(402.365, 306.152);
        glVertex2d(432.862, 267.593);
    glEnd();

    //cahaya5
    glBegin(GL_POLYGON);
        glColor3ub(255,201,68);
        glVertex2d(376.698, 248.864);
        glVertex2d(381.663, 248.864);
        glVertex2d(381.663, 301.558);
        glVertex2d(376.698, 301.558);
    glEnd();

}

void displayfern() {
    //f1 fern
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(76.481, 439.318);
        glVertex2d(104.959, 456.837);
        glVertex2d(105.074, 502.976);
        glVertex2d(76.481, 502.976);
    glEnd();

    //f2 fern
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(76.481, 439.318);
        glVertex2d(104.959, 456.837);
        glVertex2d(132.475, 456.837);
        glVertex2d(132.475, 439.31);
    glEnd();

    //f3 fern
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(132.475, 474.4);
        glVertex2d(132.475, 486.254);
        glVertex2d(105.018, 486.254);
        glVertex2d(105.018, 474.4);
    glEnd();

    //e1 fern
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(145.389, 502.84);
        glVertex2d(202.806, 502.84);
        glVertex2d(202.806, 491.395);
        glVertex2d(145.389, 491.395);
    glEnd();

    //e2 fern
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(145.389, 491.395);
        glVertex2d(145.389, 439.306);
        glVertex2d(202.806, 439.306);
    glEnd();

    //e3 fern
    glBegin(GL_POLYGON);
        glColor3ub(ABU_T);
        glVertex2d(145.389, 491.395);
        glVertex2d(145.389, 473.924);
        glVertex2d(202.806, 439.306);
    glEnd();

    //r1 fern
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(217.104, 502.84);
        glVertex2d(245.361, 439.306);
        glVertex2d(217.447, 439.306);
    glEnd();

    //r2 fern
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(217.104, 502.84);
        glVertex2d(245.361, 439.306);
        glVertex2d(273.961, 439.306);
        glVertex2d(248.625, 473.12 );
        glVertex2d(273.961, 502.84);
    glEnd();

    //n1 fern
    glBegin(GL_POLYGON);
        glVertex2d(308.488, 502.84);
        glVertex2d(290.229, 439.306);
        glVertex2d(290.229, 502.84);
    glEnd();

    //n2 fern
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(308.488, 502.84);
        glVertex2d(290.229, 439.306);
        glVertex2d(347.646, 502.84);
    glEnd();

    //n3 fern
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(347.646, Batas_bawah);
        glVertex2d(333.54, 487.337);
        glVertex2d(333.54, Batas_atas);
        glVertex2d(347.646, Batas_atas);
    glEnd();

}

void displayanda() {
    //a1 anda
    glBegin(GL_POLYGON);
        glColor3ub(81, 87, 94);
        glVertex2d(388.059, Batas_atas);
        glVertex2d(377.843, Batas_bawah);
        glVertex2d(356.944 , Batas_bawah);
    glEnd();

    //a2 anda
    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 248);
        glVertex2d(388.059, Batas_atas);
        glVertex2d(377.843, Batas_bawah);
        glVertex2d(416.768, Batas_bawah);
    glEnd();

    //-----------------------------------

    //n1 anda
    glBegin(GL_POLYGON);
        glColor3ub(ABU_T);
        glVertex2d(447.009, 502.84);
        glVertex2d(428.75, 439.306);
        glVertex2d(428.75, 502.84);
    glEnd();

    //n2 anda
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(447.009, 502.84);
        glVertex2d(428.75, 439.306);
        glVertex2d(486.167, 502.84);
    glEnd();

    //n3 anda
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(486.167, Batas_bawah);
        glVertex2d(472.061, 487.337);
        glVertex2d(472.061, Batas_atas);
        glVertex2d(486.167, Batas_atas);
    glEnd();

    //-----------------------------------

    //d1 anda
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(518.577, 492.313);
        glVertex2d(498.201, Batas_atas);
        glVertex2d(498.201, Batas_bawah);
    glEnd();

    //d2 anda
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(518.577, 492.313);
        glVertex2d(498.201, Batas_atas);
        glVertex2d(557.652, 471.121);
    glEnd();


    //-----------------------------------

    //a1 anda B
    glBegin(GL_POLYGON);
        glColor3ub(ABU_T);
        glVertex2d(592.37, Batas_atas);
        glVertex2d(582.154, Batas_bawah);
        glVertex2d(561.255, Batas_bawah);
    glEnd();

    //a2 anda B
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(592.37, Batas_atas);
        glVertex2d(582.154, Batas_bawah);
        glVertex2d(621.079, Batas_bawah);
    glEnd();

    //-----------------------------------

    //garis1
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(76.481, 573.685);
        glVertex2d(76.481, 593.241);
        glVertex2d(621.079, 593.241);
        glVertex2d(621.079, 573.685);
    glEnd();

    //garis2
    glBegin(GL_POLYGON);
        glColor3ub(ABU_T);
        glVertex2d(76.481, 573.685);
        glVertex2d(76.481, 593.241);
        glVertex2d(410, 593.241);
    glEnd();

}

void displayavatar_head() {
    //neck
    glBegin(GL_POLYGON);
        glColor3ub(SKIN);
        glVertex2d(541.926,288.823);
        glVertex2d(558.313,288.823);
        glVertex2d(558.313 ,278.251 );
        glVertex2d(541.926,278.251);
    glEnd();

    //head1
    glBegin(GL_POLYGON);
        glColor3ub(SKIN);
        glVertex2d(527.196,282.285);
        glVertex2d(572.835,282.285);
        glVertex2d(586.335,258.83);
        glVertex2d(514.917,259.06 );
    glEnd();

    //head2
    glBegin(GL_POLYGON);
        glColor3ub(SKIN);
        glVertex2d(586.335,259.06);
        glVertex2d(514.917,259.06 );
        glVertex2d(514.917,233.658 );
        glVertex2d(586.335,233.658);
    glEnd();

    //hat-top
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(543.854,196.233);
        glVertex2d(552.048,196.233);
        glVertex2d(550.864,206.443);
        glVertex2d(544.79,206.443);
    glEnd();

    //hat1
    glBegin(GL_POLYGON);
        glColor3ub(202,204,210);
        glVertex2d(513.291,233.658);
        glVertex2d(518.173,215.072);
        glVertex2d(533.705,204.573);
        glVertex2d(576.478,207.139);
        glVertex2d(591.84,233.658);
    glEnd();

    //hat2
    glBegin(GL_POLYGON);
        glColor3ub(202,204,210);
        glVertex2d(576.478,207.139);
        glVertex2d(591.84,233.658);
        glVertex2d(598.258,216.937);
    glEnd();

    //eye1
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(525.702,246.14);
        glVertex2d(541.306,246.14);
        glVertex2d(541.306,266.129);
        glVertex2d(525.702,266.129);
    glEnd();

    //eyeball1
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(530.709,246.14);
        glVertex2d(536.3,246.14);
        glVertex2d(536.3,264.275);
        glVertex2d(530.709,264.275);
    glEnd();

    //eye2
    glBegin(GL_POLYGON);
        glColor3ub(PUTIH);
        glVertex2d(559.173,246.14);
        glVertex2d(574.778,246.14);
        glVertex2d(574.778,266.129);
        glVertex2d(559.173,266.129);
    glEnd();

    //eyeball2
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(564.18,246.14);
        glVertex2d(569.771,246.14);
        glVertex2d(569.771,264.275);
        glVertex2d(564.18,264.275);
    glEnd();

    //glasses-frame
    glLineWidth(2.5);
    glColor3ub(234,126,101);
    drawOneLine(511.843, 243.532, 522.218, 244.286); //left
    drawOneLine(544.388, 244.286, 556.489, 243.532); //right
    drawOneLine(578.66, 244.286, 591.605, 244.286); //middle

    //glasses-left
    glColor3ub(154,159,173);
    drawOneLine(522.218, 244.286, 544.388, 244.286);
    drawOneLine(544.388, 244.286, 544.388, 268.515);
    drawOneLine(544.388, 268.515, 522.218, 268.515);
    drawOneLine(522.218, 268.515, 522.218, 244.286);

    //glasses-right
    drawOneLine(556.489, 244.286, 578.66, 244.286);
    drawOneLine(578.66, 244.286, 578.66, 268.515);
    drawOneLine(578.66, 268.515, 556.489, 268.515);
    drawOneLine(556.489, 268.515, 556.489, 244.286);

    //hair1
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(513.291,233.658);
        glVertex2d(509.632,246.524);
        glVertex2d(518.621,238.777);
        glVertex2d(519.555,249.48);
        glVertex2d(526.714,233.658);
    glEnd();

    //hair2
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(589.029,233.658);
        glVertex2d(592.917,246.524);
        glVertex2d(583.53,238.777);
        glVertex2d(582.567,249.48);
        glVertex2d(575.181,233.658);
    glEnd();
}

void displayavatar_body() {
    //shirt_white
    glBegin(GL_POLYGON);
        glColor3ub(232,233,234);
        glVertex2d(522.437,287.955);
        glVertex2d(577.605,287.955);
        glVertex2d(577.605,359.693);
        glVertex2d(522.437,359.693);
    glEnd();

    //shirt_gray
    glBegin(GL_POLYGON);
        glColor3ub(202,204,210);
        glVertex2d(522.437,317.37);
        glVertex2d(577.605,317.37);
        glVertex2d(577.605,331.886);
        glVertex2d(522.437,331.886);
    glEnd();

    //shirt_black
    glBegin(GL_POLYGON);
        glColor3ub(ABU_G);
        glVertex2d(522.437,303.074);
        glVertex2d(577.605,303.074);
        glVertex2d(577.605,317.37);
        glVertex2d(522.437,317.37);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2d(577.605,359.693);
        glVertex2d(522.437,359.693);
        glVertex2d(522.437,345.396);
        glVertex2d(577.605,345.396);
    glEnd();

    //torso-right
    glBegin(GL_POLYGON);
        glColor3ub(114,114,114);
        glVertex2d(577.605,287.955);
        glVertex2d(595.388,356.279);
        glVertex2d(582.531,360.569);
        glVertex2d(577.605,344.327);
    glEnd();

    //torso-left
    glBegin(GL_POLYGON);
        glColor3ub(114,114,114);
        glVertex2d(522.437,287.955);
        glVertex2d(522.437,303.074);
        glVertex2d(494.746,290.491);
        glVertex2d(502.833,279.75);
    glEnd();

    //trousers
    glBegin(GL_POLYGON);
        glColor3ub(201,158,129);
        glVertex2d(570.638,423.89);
        glVertex2d(570.638,359.693);
        glVertex2d(529.25,359.693);
        glVertex2d(529.25,423.89);
    glEnd();

    //shoes
    glBegin(GL_POLYGON);
        glColor3ub(114,114,114);
        glVertex2d(576.076,423.89);
        glVertex2d(523.75,423.89);
        glVertex2d(518.085,435.748);
        glVertex2d(581.952,435.748);
    glEnd();

    //trousers border
    glBegin(GL_POLYGON);
        glColor3ub(38,132,209);
        glVertex2d(549.263,371.5);
        glVertex2d(550.625,371.5);
        glVertex2d(550.625,435.748);
        glVertex2d(549.263,435.748);
    glEnd();
/*
    //arm1
    glBegin(GL_POLYGON);
        glColor3ub(114,114,114);
        glVertex2d(503.97,289.675);
        glVertex2d(501.801,250.458);
        glVertex2d(492.403,251.986);
        glVertex2d(494.502,290.383);
    glEnd();
    glBegin(GL_POLYGON); //palm
        glColor3ub(SKIN);
        glVertex2d(501.801,250.458);
        glVertex2d(492.403,251.986);
        glVertex2d(492.172,241.896);
        glVertex2d(500.55,239.708);
    glEnd();
    glBegin(GL_POLYGON); //thumb
        glColor3ub(SKIN);
        glVertex2d(501.801,250.458);
        glVertex2d(501.531,248.137);
        glVertex2d(505.089,246.482);
        glVertex2d(505.751,248.71);
    glEnd();
*/
    //arm2
    glBegin(GL_POLYGON);
        glColor3ub(114,114,114);
        glVertex2d(502.833,279.75);
        glVertex2d(484.613,250.979);
        glVertex2d(476.694,256.266);
        glVertex2d(494.746,290.491);
    glEnd();
    glBegin(GL_POLYGON); //palm
        glColor3ub(SKIN);
        glVertex2d(476.747,256.462);
        glVertex2d(472.301,247.179);
        glVertex2d(479.019,241.715);
        glVertex2d(484.613,250.979);
    glEnd();
    glBegin(GL_POLYGON); //thumb
        glColor3ub(SKIN);
        glVertex2d(484.613,250.979);
        glVertex2d(487.483,247.752);
        glVertex2d(485.958,245.998);
        glVertex2d(483.406,248.979);
    glEnd();
}

int main(void)
{
    glfwInit();

    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    glfwWindowHint(GLFW_SAMPLES, 4);
    window = glfwCreateWindow(900, 900, "MY NAME IS...", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        glEnable (GL_BLEND); glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        setup_viewport(window);
        displaybackground();
        displayfauzi();
        displaytitik();
        displayfern();
        displayanda();
        displayavatar_head();
        displayavatar_body();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
}
