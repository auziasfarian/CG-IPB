#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
    double nol = 0, resetx=10, resety=0;
    int trigger = 0,i;
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void warna(){

 if(trigger%2==0){
            nol+=0.5;}
        else{
            nol-=0.25;
        }
        if(nol==200 || nol == 0){
        trigger++;
        }


}



void blkng()
{
    glBegin(GL_POLYGON);
    glColor3ub(148,203,234);
    glVertex2d(0,0+nol);
    glColor3ub(221,172,nol*221);
    glVertex2d(400,0+nol);
    glColor3ub(219,196,158);
    glVertex2d(0,400+nol);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(148,203,nol*151);
    glVertex2d(400,0+nol);
    glColor3ub(183,111,221);
    glVertex2d(800,0+nol);
    glColor3ub(194,255,214);
    glColor3ub(218,221,111);
    glVertex2d(800,400+nol);
    glEnd();


glBegin(GL_POLYGON);
    glColor3ub(219,113,179);
    glVertex2d(400,400-nol);
    glColor3ub(148,203,nol*151);
    glColor3ub(157,224,173);
    glVertex2d(800,800-nol);
    glVertex2d(400,800-nol);
    glEnd();




     glBegin(GL_POLYGON);
    glColor3ub(221,158,168);
    glVertex2d(400,400-nol);
    glColor3ub(219,113,179);
    glVertex2d(400,800-nol);
    glColor3ub(148,203,234);
    glVertex2d(0,800-nol);
    glEnd();

     glBegin(GL_LINE_LOOP);
          glColor3ub(i+nol,i*2+nol,i*3+nol);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(400+cos(rad)*350,400+sin(rad)*350);
           }
        glEnd();

  glBegin(GL_LINE_LOOP);
    glColor3ub(221,158,nol*70);
    glVertex2d(5,5-nol);
    glColor3ub(219,113,nol*190);
    glVertex2d(795,5-nol);
    glColor3ub(148,203,nol*209);
    glVertex2d(795,795-nol);
    glColor3ub(221,158,nol*89);
    glVertex2d(5,795-nol);
    glEnd();


}


void D()
{
    glBegin(GL_POLYGON);
    glColor3ub(234,155,nol*85);
    glVertex2d(123-nol,324);
    glColor3ub(191,112,17);
    glVertex2d(174-nol,324);
    glVertex2d(224-nol,339);
    glVertex2d(241-nol,374);
    glVertex2d(223-nol,410);
    glColor3ub(36,40,86);
    glVertex2d(177-nol,424);
    glVertex2d(123-nol,424);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(110-nol,330);
    glVertex2d(123-nol,324);
    glVertex2d(123-nol,424);
    glVertex2d(110-nol,412);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(148,203,234 );
    glVertex2d(164-nol,347);
    glVertex2d(192-nol,355);
    glVertex2d(198-nol,373);
    glVertex2d(191-nol,393);
    glVertex2d(174-nol,401);
    glVertex2d(164-nol,401);
    glEnd();
}

void W(){
    glBegin(GL_POLYGON);
    glColor3ub(247,114,202);
    glVertex2d(248,324+nol);

    glVertex2d(283,424+nol);

    glVertex2d(319,424+nol);

    glVertex2d(286,324+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(234,78,197);
    glVertex2d(283,424+nol);
    glColor3b(103,87,221);
    glVertex2d(323,324+nol);
    glVertex2d(355,324+nol);
    glVertex2d(319,424+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(232,5,189);
    glVertex2d(323,324+nol);
    glVertex2d(355,324+nol);
    glVertex2d(389,424+nol);
    glVertex2d(355,424+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(193,6,167);
    glVertex2d(355,424+nol);
    glColor3b(103,87,221);
    glVertex2d(389,424+nol);

    glVertex2d(424,324+nol);
    glVertex2d(393,324+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(235,319+nol);
    glVertex2d(248,324+nol);
    glVertex2d(283,424+nol);
    glVertex2d(270,414+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(248,324+nol);
    glVertex2d(235,319+nol);
    glVertex2d(276,319+nol);
    glVertex2d(286,324+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(302,369+nol);
    glVertex2d(305,382+nol);
    glVertex2d(323,324+nol);
    glVertex2d(317,319+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(323,324+nol);
    glVertex2d(317,319+nol);
    glVertex2d(345,319+nol);
    glVertex2d(355,324+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(370,368+nol);
    glVertex2d(374,382+nol);
    glVertex2d(393,324+nol);
    glVertex2d(385,319+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(385,319+nol);
    glVertex2d(393,324+nol);
    glVertex2d(424,324+nol);
    glVertex2d(415,319+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(355,423+nol);
    glVertex2d(345,418+nol);
    glVertex2d(332,382+nol);
    glVertex2d(336,369+nol);
    glEnd();
}

void I()
{
    glBegin(GL_POLYGON);
    glColor3ub(160,19,127);
    glVertex2d(437,324-nol);
    glVertex2d(477,324-nol);
    glColor3ub(149,219,155);
    glVertex2d(477,424-nol);
    glVertex2d(437,424-nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(433,319-nol);
    glVertex2d(437,324-nol);
    glVertex2d(437,423-nol);
    glVertex2d(432,418-nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(477,324-nol);
    glVertex2d(437,324-nol);
    glVertex2d(433,319-nol);
    glVertex2d(469,319-nol);
    glEnd();


}


void K()
{
    glBegin(GL_POLYGON);
    glColor3ub(145,3,118);
    glVertex2d(501,324+nol);
    glVertex2d(501,424+nol);
    glColor3ub(219,173,149);
    glVertex2d(539,424+nol);
    glVertex2d(539,324+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,0,101);
    glVertex2d(539,365+nol);
    glVertex2d(575,324+nol);

    glVertex2d(612,324+nol);
    glColor3ub(165,219,149);
    glVertex2d(539,401+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,0,101);
    glVertex2d(579,358+nol);
    glVertex2d(620,424+nol);
    glVertex2d(576,424+nol);
    glColor3ub(165,219,149);
    glVertex2d(553,386+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(501,424+nol);
    glVertex2d(492,418+nol);
    glVertex2d(492,319+nol);
    glVertex2d(501,324+nol);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(539,324+nol);
    glVertex2d(501,324+nol);
    glVertex2d(492,319+nol);
    glVertex2d(532,319+nol);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(579,324+nol);
    glVertex2d(539,367+nol);
    glVertex2d(539,351+nol);
    glVertex2d(570,317+nol);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(612,324+nol);
    glVertex2d(575,324+nol);
    glVertex2d(570,317+nol);
    glVertex2d(605,317+nol);
    glEnd();

}
void A()
{
    glBegin(GL_POLYGON);
    glColor3ub(102,14,77);
    glVertex2d(620+nol,424);
    glVertex2d(661+nol,324);
    glVertex2d(704+nol,324);
    glVertex2d(653+nol,424);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(76,15,59);
    glVertex2d(661+nol,324);
    glVertex2d(704+nol,324);
    glVertex2d(745+nol,424);
    glVertex2d(704+nol,424);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,0,101);
    glVertex2d(661+nol,324);
    glVertex2d(701+nol,324);
    glColor3ub(219,149,167);
    glVertex2d(745+nol,424);
    glVertex2d(704+nol,424);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,0,101);
    glVertex2d(668+nol,385);
    glVertex2d(689+nol,385);
    glVertex2d(689+nol,385);
    glVertex2d(696+nol,404);
    glVertex2d(661+nol,404);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(655+nol,315);
    glVertex2d(661+nol,324);
    glVertex2d(620+nol,424);
    glVertex2d(618+nol,407);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(661+nol,324);
    glVertex2d(655+nol,315);
    glVertex2d(698+nol,315);
     glVertex2d(704+nol,324);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3b(100,100,120);
    glVertex2d(704+nol,424);
    glVertex2d(698+nol,421);
    glVertex2d(692+nol,404);
    glVertex2d(696+nol,404);
    glEnd();
}



int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Dwika Ayu N- <G64160116>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);



    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        blkng();
        D();
        W();
        I();
        K();
        A();
        warna();



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
