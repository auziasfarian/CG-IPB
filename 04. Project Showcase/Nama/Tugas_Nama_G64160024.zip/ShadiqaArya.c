#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define xmin -10
#define xmax 10
#define ymin -10
#define ymax 10


int c;
int pink;

static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}


static void grid(int x, int y)
{
    int i;
    glColor3f(.2,.2,.2);
    glBegin(GL_LINES);
    for(i=-x; i<=x; i++)
    {
        glVertex2f(i,-y);
        glVertex2f(i,y);
    }
    for(i=-y; i<=y; i++)
    {
        glVertex2f(-x,i);
        glVertex2f(x,i);
    }
    glColor3f(0.7,1,0.7);
    glVertex2f(-x,0);
    glVertex2f(x,0);
    glVertex2f(0,-y);
    glVertex2f(0,y);
    glEnd();
}





int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Shadiqa", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    int hehe=0,buff=0;
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width * 10 / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 800, 800, 0, 1, -1);
        //glOrtho(-ratio, ratio, ymin, ymax, 1, -1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        //display();
 c=c%13;
if(c==0){
pink=-15;
}
else {pink=0;}
c++;


        //S
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=-30; i <=170 ; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*70+pink,442.5+sin(rad)*70);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*50+pink,442.5+sin(rad)*50);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(146.52+pink,300.39);
//glColor3ub(255, 153, 153);
        glVertex2f(213.09+pink,424.69);
//glColor3ub(255, 153, 153);
        glVertex2f(230.72+pink,415.24);
//glColor3ub(255, 153, 153);
        glVertex2f(164.15+pink,290.95);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=155; i <= 345; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*45+pink,282+sin(rad)*45);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*25+pink,282+sin(rad)*25);
        }
        glEnd();

        //h
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(260+pink,322);
//glColor3ub(255, 153, 153);
        glVertex2f(260+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(280+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(280+pink,322);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*50+pink,457+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*30+pink,457+sin(rad)*30);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(339.56+pink,448);
//glColor3ub(255, 153, 153);
        glVertex2f(339.56+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56+pink,448);
        glEnd();


        //a
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(430+cos(rad)*50+pink,459+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(430+cos(rad)*30+pink,459+sin(rad)*30);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(460+pink,406);
//glColor3ub(255, 153, 153);
        glVertex2f(460+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(480+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(480+pink,406);
        glEnd();

        //d
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(550+cos(rad)*50+pink,459+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(550+cos(rad)*30+pink,459+sin(rad)*30);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(580+pink,353);
//glColor3ub(255, 153, 153);
        glVertex2f(580+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(600+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(600+pink,353);
        glEnd();




        //garis
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620+pink,491);
//glColor3ub(255, 153, 153);
        glVertex2f(620+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(720+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(720+pink,491);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620+pink,457);
//glColor3ub(255, 153, 153);
        glVertex2f(620+pink,477);
//glColor3ub(255, 153, 153);
        glVertex2f(690+pink,477);
//glColor3ub(255, 153, 153);
        glVertex2f(690+pink,457);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620+pink,444);
//glColor3ub(255, 153, 153);
        glVertex2f(620+pink,424);
//glColor3ub(255, 153, 153);
        glVertex2f(660+pink,424);
//glColor3ub(255, 153, 153);
        glVertex2f(660+pink,444);
        glEnd();



        //geser
         //S
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=-30; i <=170 ; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*70,442.5+sin(rad)*70);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*50,442.5+sin(rad)*50);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(146.52,300.39);
//glColor3ub(255, 153, 153);
        glVertex2f(213.09,424.69);
//glColor3ub(255, 153, 153);
        glVertex2f(230.72,415.24);
//glColor3ub(255, 153, 153);
        glVertex2f(164.15,290.95);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=155; i <= 345; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*45,282+sin(rad)*45);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*25,282+sin(rad)*25);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=-30; i <=170 ; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*70+pink,442.5+sin(rad)*70);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(165.5+cos(rad)*50+pink,442.5+sin(rad)*50);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(146.52+pink,300.39);
//glColor3ub(255, 153, 153);
        glVertex2f(213.09+pink,424.69);
//glColor3ub(255, 153, 153);
        glVertex2f(230.72+pink,415.24);
//glColor3ub(255, 153, 153);
        glVertex2f(164.15+pink,290.95);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=155; i <= 345; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*45+pink,282+sin(rad)*45);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(187+cos(rad)*25,282+sin(rad)*25);
        }
        glEnd();
        //h



        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(339.56,448);
//glColor3ub(255, 153, 153);
        glVertex2f(339.56,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56,448);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*50,457+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*30,457+sin(rad)*30);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*50+pink,457+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=180; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(309.8+cos(rad)*30+pink,457+sin(rad)*30);
        }
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(339.56+pink,448);
//glColor3ub(255, 153, 153);
        glVertex2f(339.56+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56+pink,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56+pink,448);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(339.56,448);
//glColor3ub(255, 153, 153);
        glVertex2f(339.56,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56,511);
//glColor3ub(255, 153, 153);
        glVertex2f(359.56,448);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(260,322);
//glColor3ub(255, 153, 153);
        glVertex2f(260,511);
//glColor3ub(255, 153, 153);
        glVertex2f(280,511);
//glColor3ub(255, 153, 153);
        glVertex2f(280,322);
        glEnd();

        //a
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(430+cos(rad)*50,459+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(430+cos(rad)*30,459+sin(rad)*30);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(460,406);
//glColor3ub(255, 153, 153);
        glVertex2f(460,511);
//glColor3ub(255, 153, 153);
        glVertex2f(480,511);
//glColor3ub(255, 153, 153);
        glVertex2f(480,406);
        glEnd();

        //d
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(550+cos(rad)*50,459+sin(rad)*50);
        }
        glEnd();
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        for (int i=0; i <= 360; i++)
        {
        float rad = i*3.14159/180;
        glVertex2f(550+cos(rad)*30,459+sin(rad)*30);
        }
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(580,353);
//glColor3ub(255, 153, 153);
        glVertex2f(580,511);
//glColor3ub(255, 153, 153);
        glVertex2f(600,511);
//glColor3ub(255, 153, 153);
        glVertex2f(600,353);
        glEnd();




        //garis
        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620,491);
//glColor3ub(255, 153, 153);
        glVertex2f(620,511);
//glColor3ub(255, 153, 153);
        glVertex2f(720,511);
//glColor3ub(255, 153, 153);
        glVertex2f(720,491);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620,457);
//glColor3ub(255, 153, 153);
        glVertex2f(620,477);
//glColor3ub(255, 153, 153);
        glVertex2f(690,477);
//glColor3ub(255, 153, 153);
        glVertex2f(690,457);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(255,255,255);
        glVertex2f(620,444);
//glColor3ub(255, 153, 153);
        glVertex2f(620,424);
//glColor3ub(255, 153, 153);
        glVertex2f(660,424);
//glColor3ub(255, 153, 153);
        glVertex2f(660,444);
        glEnd();



        glfwSwapBuffers(window);
        glfwPollEvents();


    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
