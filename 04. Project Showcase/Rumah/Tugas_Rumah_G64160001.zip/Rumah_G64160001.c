#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define xmin -10
#define xmax 10
#define ymin -10
#define ymax 10


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);


    glBegin(GL_POLYGON);
    glColor3ub(250,238,73);
    glVertex2d(0,0);
    glColor3ub(252,175,33);
    glVertex2d(800,0);
    glColor3ub(255,255,255);
    glVertex2d(800,800);
    glColor3ub(255,255,255);
    glVertex2d(0,800);
    glEnd();


    glFlush();
}

void tanah() {
  glBegin(GL_POLYGON);

  glColor3ub(140,198,63);
  glVertex2d(0,500);
  glVertex2d(800,500);
  glVertex2d(800,800);
  glVertex2d(0,800);

  glEnd();
}

  //pindahin pohoj
void pohon() {
  glBegin(GL_POLYGON);

  glColor3ub(18,148,71);
  glVertex2d(733.208-700,362.471);
  glVertex2d(696.585-700,429.293);
  glVertex2d(709.881-700,428.722);
  glVertex2d(687.139-700,471.218);
  glVertex2d(703.466-700,470.503);
  glVertex2d(681.54-700,511.564);
  glVertex2d(694.369-700,509.563);
  glVertex2d(675.94-700,544.049);
  glVertex2d(693.202-700,543.187);
  glVertex2d(675.125-700,576.243);
  glVertex2d(694.369-700,575.38);
  glVertex2d(684.923-700,592.983);
  glVertex2d(704.75-700,591.982);
  glVertex2d(699.034-700,603.715);
  glVertex2d(729.241+3-700,601.565);
  glVertex2d(733.208-700,632.473);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(9,105,57);
  glVertex2d(733.208-700,362.471);
  glVertex2d(773.213-700,425.715);
  glVertex2d(759.913-700,426.286);
  glVertex2d(784.523-700,466.639);
  glVertex2d(768.194-700,467.353);
  glVertex2d(791.873-700,506.271);
  glVertex2d(779.043-700,505.556);
  glVertex2d(798.984-700,538.179);
  glVertex2d(781.728-700,539.041);
  glVertex2d(800-700,570.229);
  glVertex2d(781.96-700,571.234);
  glVertex2d(792.223-700,587.832);
  glVertex2d(772.51-700,588.833);
  glVertex2d(778.693-700,599.992);
  glVertex2d(748.486-700,600.707);
  glVertex2d(749.185-700,631.614);
  glVertex2d(733.208-700,632.473);
  glEnd();
}

void satu() {
  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(463.477,319.054);
  glVertex2d(670.356,253.736);
  glVertex2d(670.356,585.55);
  glVertex2d(463.477,544.497);

  glEnd();
}

void dua() {
  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(670.356,253.736);
  glVertex2d(738.446,356.254);
  glVertex2d(738.446,548.102);
  glVertex2d(670.09,602.937);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(670.09,602.937);
  glVertex2d(487.913,753.639);
  glVertex2d(487.913,705.239);
  glVertex2d(670.356,585.55);

  glEnd();
}
void tiga() {
  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(529.783,328.012);
  glVertex2d(624.916,299.521);
  glVertex2d(624.916,323.657);
  glVertex2d(558.884,341.822);
  glVertex2d(558.336,438.618);
  glVertex2d(529.783,433.141);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(558.336,342.821);
  glVertex2d(624.916,328.261);
  glVertex2d(624.916,449.192);
  glVertex2d(558.336,438.618);

  glEnd();

    glBegin(GL_POLYGON);

  glColor3ub(11,78,100);
  glVertex2d(557.648,341.201);
  glVertex2d(625.054,323.657);
  glVertex2d(624.505,344.682);
  glVertex2d(558.06,360.112);


  glEnd();
}
void empat() {
  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(293.792,345.928);
  glVertex2d(523.88,407.016);
  glVertex2d(523.88,459.646+2);
  glVertex2d(293.792,487.139);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(511.659,417.591);
  glVertex2d(626.979,436.133);
  glVertex2d(626.979,578.584);
  glVertex2d(511.935,643.654);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(364.629,438.618);
  glVertex2d(511.659,417.591);
  glVertex2d(511.935,643.654);
  glVertex2d(457.71,631.335);
  glVertex2d(384.399,611.431);
  glVertex2d(364.629,607.076);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(384.399,455.412);
  glVertex2d(421.743,452.802);
  glVertex2d(419.27,603.716);
  glVertex2d(384.399,611.431);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(419.27,603.716);
  glVertex2d(457.71,612.052);
  glVertex2d(457.71,630.217);
  glVertex2d(381.931,611.057);

  glEnd();

    glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(413.505,453.423);
  glVertex2d(457.71,450.19);
  glVertex2d(457.71,612.052);
  glVertex2d(413.916,604.714);

  glEnd();
}

void lima() {
  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(109.012,408.015);
  glVertex2d(293.792,345.928);
  glVertex2d(293.792,485.025);
  glVertex2d(109.012,485.025);
  glEnd();
}
void enam() {
  glBegin(GL_POLYGON);

  glColor3ub(181,203,155);
  glVertex2d(626.979+3,578.584-1);
  glVertex2d(666.928+3.5,586.549-1);
  glVertex2d(487.913,705.239);
  glVertex2d(142.51,577.964);
  glVertex2d(211.291,568.01);
  glVertex2d(507.679,642.784);
  glEnd();
}
void tujuh() {
  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(214.857,605.087);
  glVertex2d(486.811,705.239);
  glVertex2d(486.811,753.639);
  glVertex2d(214.857,634.571);
  glEnd();
}

void lapan() {
  glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(306.836,484.652+1);
  glVertex2d(364.905,477.186+2);
  glVertex2d(364.905,587.667-3);
  glVertex2d(306.836,592.769);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(11,78,100);
  glVertex2d(294.895,485.025);
  glVertex2d(310.681,485.273);
  glVertex2d(310.681,593.142);
  glVertex2d(293.934,588.911);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(11,78,100);
  glVertex2d(278.558,485.025);
  glVertex2d(294.895,485.025);
  glVertex2d(297.093,590.153);
  glVertex2d(278.97,585.177);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(210.052,485.025);
  glVertex2d(285.01,485.025);
  glVertex2d(285.01,587.543);
  glVertex2d(210.052,568.01);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(11,78,100);
  glVertex2d(192.619,485.025);
  glVertex2d(210.052,485.025);
  glVertex2d(210.052,568.01);
  glVertex2d(192.619,570.745);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(181,203,155);
  glVertex2d(17.724-5,596.004-3);
  glVertex2d(141.414+10-5,578.088-5);
  glVertex2d(220.211+10,606.702);
  glVertex2d(96.11,635.566);
  glVertex2d(167.633,687.571);
  glVertex2d(147.864,691.801);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(17.175,482.912+2);
  glVertex2d(192.619,485.025);
  glVertex2d(192.619,572.365);
  glVertex2d(17.175,596.004);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(0.84,484.026+2);
  glVertex2d(17.175,482.912+2);
  glVertex2d(17.175,596.004);
  glVertex2d(0.84,583.437);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(249,205,224);
  glVertex2d(0.84,583.437);
  glVertex2d(147.864,691.801);
  glVertex2d(147.864,737.462);
  glVertex2d(0.84,603.467);
  glEnd();

  //tangga

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(147.864,691.801);
  glVertex2d(164.753,688.197);
  glVertex2d(164.753,733.232);
  glVertex2d(147.864,737.462);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(181,203,155);
  glVertex2d(108.189,644.4);
  glVertex2d(219.662,616.904);
  glVertex2d(247.254,628.228);
  glVertex2d(127.684,658.582);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(96.11,635.566);
  glVertex2d(220.211,606.702);
  glVertex2d(220.211,617.773);
  glVertex2d(109.287,645.146);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(127.684,658.582);
  glVertex2d(247.254,628.228);
  glVertex2d(247.254,638.555);
  glVertex2d(138.808,667.789);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(181,203,155);
  glVertex2d(138.808,667.789);
  glVertex2d(248.22,638.555);
  glVertex2d(268.948,645.519);
  glVertex2d(153.497,679.114);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(153.497,679.114);
  glVertex2d(268.948,645.519);
  glVertex2d(268.948,658.086);
  glVertex2d(165.576,688.942);

  glEnd();

  //jendela
  glBegin(GL_POLYGON);

  glColor3ub(6,75,88);
  glVertex2d(682.024,375.542);
  glVertex2d(732.682,412.738);
  glVertex2d(732.682,437.997);
  glVertex2d(682.024,411.619);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(682.024,385.864);
  glVertex2d(724.996,415.477);
  glVertex2d(725.133,433.767);
  glVertex2d(682.024,411.619);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(11,78,100);
  glVertex2d(707.559,476.564);
  glVertex2d(800,476.564);
  glVertex2d(800,579.331);
  glVertex2d(707.559,570.745);

  glEnd();

  //jendela depan

  glBegin(GL_POLYGON);

  glColor3ub(124,88,116);
  glVertex2d(119.998,422.69);
  glVertex2d(224.056,389.1);
  glVertex2d(224.056,457.902);
  glVertex2d(119.998,469.6);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(32,37,87);
  glVertex2d(132.214,432.274);
  glVertex2d(224.056,406.395);
  glVertex2d(224.056,457.902);
  glVertex2d(132.214,468.355);

  glEnd();

  //pohon

  glBegin(GL_POLYGON);

  glColor3ub(18,148,71);
  glVertex2d(733.208,362.471);
  glVertex2d(696.585,429.293);
  glVertex2d(709.881,428.722);
  glVertex2d(687.139,471.218);
  glVertex2d(703.466,470.503);
  glVertex2d(681.54,511.564);
  glVertex2d(694.369,509.563);
  glVertex2d(675.94,544.049);
  glVertex2d(693.202,543.187);
  glVertex2d(675.125,576.243);
  glVertex2d(694.369,575.38);
  glVertex2d(684.923,592.983);
  glVertex2d(704.75,591.982);
  glVertex2d(699.034,603.715);
  glVertex2d(729.241+3,601.565);
  glVertex2d(733.208,632.473);

  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(9,105,57);
  glVertex2d(733.208,362.471);
  glVertex2d(773.213,425.715);
  glVertex2d(759.913,426.286);
  glVertex2d(784.523,466.639);
  glVertex2d(768.194,467.353);
  glVertex2d(791.873,506.271);
  glVertex2d(779.043,505.556);
  glVertex2d(798.984,538.179);
  glVertex2d(781.728,539.041);
  glVertex2d(800,570.229);
  glVertex2d(781.96,571.234);
  glVertex2d(792.223,587.832);
  glVertex2d(772.51,588.833);
  glVertex2d(778.693,599.992);
  glVertex2d(748.486,600.707);
  glVertex2d(749.185,631.614);
  glVertex2d(733.208,632.473);
  glEnd();

  glBegin(GL_POLYGON);

  glColor3ub(94,40,13);
  glVertex2d(666.639,639.336);
  glVertex2d(758.572,654.108);
  glVertex2d(659.39,761.012);
  glVertex2d(563.582,730.257);

  glEnd();





  //bintang
  //glBegin(GL_POLYGON);

  //glColor3ub(255,255,255);
  //glVertex2d(369.344,216.311);
  //glVertex2d(390.151,232.624);
  //glVertex2d(410.041,216.311);
  //glVertex2d(400.013,240.012);
  //glVertex2d(422.607,252.807);
  //glVertex2d(395.602,251.18);
  //glVertex2d(389.692,275.408);
  //glVertex2d(383.035,250.652);
  //glVertex2d(356.735,252.807);
  //glVertex2d(379.663,239.176);

  //glEnd();


}

void lingkaran(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
    glColor3ub(242,234,85);
        for(i=0; i<360;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}




int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Runah - <G64160001>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        tanah();
        pohon();
        satu();
        dua();
        enam();
        tiga();
        empat();
        lima();
        tujuh();
        lapan();




        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
