#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

const double PI = 3.141592653589793;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,800,0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void bg (){
    glBegin(GL_POLYGON);
    glColor4ub(255,248,255,180);
    glVertex2d(0,0);
    glColor4ub(255,248,255,180);
    glVertex2d(800,0);
    glColor4ub(255,248,16,90);
    glVertex2d(800,400);
    glVertex2d(0,400);
    glEnd();}

void grass (){
    glBegin(GL_POLYGON);
    glColor3ub(138,212,1);
    glVertex2d(406,125);
    glVertex2d(801,362);
    glVertex2d(800,800);
    glVertex2d(0,800);
    glVertex2d(0,370);
    glEnd();
}

void build (){
    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(359,515);
    glVertex2d(359,530);
    glVertex2d(260,470);
    glVertex2d(260,456);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(477,487);
    glVertex2d(477,502);
    glVertex2d(335,416);
    glVertex2d(335,402);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(372,424);
    glVertex2d(372,439);
    glVertex2d(231,353);
    glVertex2d(231,339);
    glEnd();

    //dinding
    glBegin(GL_POLYGON);
    glColor3ub(255,124,118);
    glVertex2d(476,398);
    glVertex2d(477,494);
    glVertex2d(231,344);
    glVertex2d(232,249);
    glEnd();

    //jendela2
    glBegin(GL_POLYGON);
    glColor3ub(122,36,28);
    glVertex2d(284,309);
    glVertex2d(284,361);
    glVertex2d(244,337);
    glVertex2d(244,285);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(283,309);
    glVertex2d(283,359);
    glVertex2d(245,336);
    glVertex2d(245,287);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(46,171,227);
    glVertex2d(279,312);
    glVertex2d(279,352);
    glVertex2d(249,333);
    glVertex2d(249,294);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(279,328);
    glVertex2d(279,331);
    glVertex2d(249,311);
    glVertex2d(249,309);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(266,304);
    glVertex2d(266,344);
    glVertex2d(262,342);
    glVertex2d(262,302);
    glEnd();

    //dinding
    glBegin(GL_POLYGON);
    glColor3ub(221,109,104);
    glVertex2d(549,280);
    glVertex2d(618,303);
    glVertex2d(618,408);
    glVertex2d(477,494);
    glVertex2d(476,398);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(221,109,104);
    glVertex2d(441,385);
    glVertex2d(440,472);
    glVertex2d(359,521);
    glVertex2d(359,435);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,124,118);
    glVertex2d(359,435);
    glVertex2d(359,521);
    glVertex2d(260,461);
    glVertex2d(260,375);
    glVertex2d(310,348);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,189,189);
    glVertex2d(231,253);
    glVertex2d(236,260);
    glVertex2d(236,347);
    glVertex2d(231,344);
    glEnd();

    //atap
    glBegin(GL_POLYGON);
    glColor3ub(103,67,45);
    glVertex2d(301,121);
    glVertex2d(547,271);
    glVertex2d(456,409);
    glVertex2d(211,259);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(103,67,45);
    glVertex2d(392,149);
    glVertex2d(638,299);
    glVertex2d(547,271);
    glVertex2d(301,121);
    glEnd();

    //tiang
    glBegin(GL_POLYGON);
    glColor3ub(219,189,189);
    glVertex2d(547,271);
    glVertex2d(638,299);
    glVertex2d(632,307);
    glVertex2d(551,285);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,189,189);
    glVertex2d(468,411);
    glVertex2d(456,409);
    glVertex2d(547,271);
    glVertex2d(551,285);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,189,189);
    glVertex2d(618,408);
    glVertex2d(618,416);
    glVertex2d(477,502);
    glVertex2d(477,494);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,189,189);
    glVertex2d(441,472);
    glVertex2d(441,480);
    glVertex2d(359,530);
    glVertex2d(359,521);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(310,332);
    glVertex2d(372,443);
    glVertex2d(362,449);
    glVertex2d(307,350);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(310,332);
    glVertex2d(307,350);
    glVertex2d(254,379);
    glVertex2d(248,368);
    glEnd();

    //pintu
    glBegin(GL_POLYGON);
    glColor3ub(122,36,28);
    glVertex2d(538,371);
    glVertex2d(538,459);
    glVertex2d(497,483);
    glVertex2d(497,396);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(536,374);
    glVertex2d(536,458);
    glVertex2d(499,481);
    glVertex2d(499,397);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(168,171,173);
    glVertex2d(531,427);
    glVertex2d(531,457);
    glVertex2d(520,464);
    glVertex2d(520,434);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(530,430);
    glVertex2d(530,456);
    glVertex2d(521,462);
    glVertex2d(521,435);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(168,171,173);
    glVertex2d(515,437);
    glVertex2d(515,467);
    glVertex2d(504,473);
    glVertex2d(504,444);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(514,439);
    glVertex2d(514,466);
    glVertex2d(505,471);
    glVertex2d(505,445);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(168,171,173);
    glVertex2d(531,386);
    glVertex2d(531,420);
    glVertex2d(504,436);
    glVertex2d(504,402);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(46,171,227);
    glVertex2d(530,388);
    glVertex2d(530,418);
    glVertex2d(505,434);
    glVertex2d(505,401);
    glEnd();

    //jendela1
    glBegin(GL_POLYGON);
    glColor3ub(122,36,28);
    glVertex2d(611,321);
    glVertex2d(611,392);
    glVertex2d(556,425);
    glVertex2d(556,355);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(609,324);
    glVertex2d(609,391);
    glVertex2d(558,422);
    glVertex2d(558,356);
    glEnd();

    for (int i=0;i<2;i++){
    glBegin(GL_POLYGON);
    glColor4ub(46,171,227,180);
    glVertex2d(604-(i*23),334+(i*14));
    glVertex2d(604-(i*23),354+(i*14));
    glVertex2d(586-(i*23),365+(i*14));
    glVertex2d(586-(i*23),345+(i*14));
    glEnd();

    glBegin(GL_POLYGON);
    glColor4ub(46,171,227,180);
    glVertex2d(604-(i*23),357+(i*14));
    glVertex2d(604-(i*23),388+(i*14));
    glVertex2d(586-(i*23),399+(i*14));
    glVertex2d(586-(i*23),369+(i*14));
    glEnd();}



    //alas pintu
    glBegin(GL_POLYGON);
    glColor3ub(204,180,180);
    glVertex2d(552,469);
    glVertex2d(587,491);
    glVertex2d(542,519);
    glVertex2d(506,497);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204,180,180);
    glVertex2d(544,453);
    glVertex2d(554,460);
    glVertex2d(503,491);
    glVertex2d(493,484);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,158,158);
    glVertex2d(554,460);
    glVertex2d(554,468);
    glVertex2d(503,499);
    glVertex2d(503,491);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(503,491);
    glVertex2d(503,499);
    glVertex2d(493,492);
    glVertex2d(493,484);
    glEnd();

    //pintu garasi
    glBegin(GL_POLYGON);
    glColor3ub(122,36,28);
    glVertex2d(341,429);
    glVertex2d(341,519);
    glVertex2d(271,477);
    glVertex2d(271,386);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,212,212);
    glVertex2d(345,424);
    glVertex2d(345,431);
    glVertex2d(268,385);
    glVertex2d(268,377);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4ub(230,231,232,180);
    glVertex2d(338,427);
    glVertex2d(338,518);
    glColor4ub(188,190,192,180);
    glVertex2d(273,478);
    glVertex2d(273,386);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,165,165);
    glVertex2d(341,519);
    glVertex2d(318,533);
    glVertex2d(249,491);
    glVertex2d(271,477);
    glEnd();
}

void garis(){
    glBegin(GL_POLYGON);
    glColor3ub(135,92,68);
    glVertex2d(220,245);
    glVertex2d(466,394);
    glVertex2d(465,396);
    glVertex2d(219,247);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(81,53,37);
    glVertex2d(219,247);
    glVertex2d(465,396);
    glVertex2d(464,397);
    glVertex2d(218,248);
    glEnd();
}

void kolam(){
    glBegin(GL_POLYGON);
    glColor3ub(124,80,55);
    glVertex2d(442,254);
    glVertex2d(442,400);
    glVertex2d(372,443);
    glVertex2d(310,332);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(171,173,176);
    glVertex2d(110,372);
    glVertex2d(110,431);
    glVertex2d(28,381);
    glVertex2d(28,378);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(212,216,219);
    glVertex2d(110,372);
    glVertex2d(215,364);
    glVertex2d(215,366);
    glVertex2d(110,431);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237,244,249);
    glVertex2d(133,313);
    glVertex2d(215,364);
    glVertex2d(110,429);
    glVertex2d(28,378);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4ub(0,234,255,180);
    glVertex2d(201,364);
    glVertex2d(110,420);
    glColor4ub(0,187,255,180);
    glVertex2d(42,378);
    glVertex2d(133,322);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(171,173,176);
    glVertex2d(133,322);
    glVertex2d(133,324);
    glVertex2d(43,379);
    glVertex2d(42,378);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(212,216,219);
    glVertex2d(201,364);
    glVertex2d(200,365);
    glVertex2d(133,324);
    glVertex2d(133,322);
    glEnd();
}

void kursi(){
    glBegin(GL_POLYGON);
    glColor3ub(220,26,34);
    glVertex2d(181,401);
    glVertex2d(200,413);
    glVertex2d(162,436);
    glVertex2d(143,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,26,34); //merah terang
    glVertex2d(192,377);
    glVertex2d(211,388);
    glVertex2d(200,412);
    glVertex2d(182,400);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,26,34);
    glVertex2d(182,400);
    glVertex2d(200,412);
    glVertex2d(200,413);
    glVertex2d(181,401);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(211,388);
    glVertex2d(213,389);
    glVertex2d(202,414);
    glVertex2d(200,412);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24); //merah gelap
    glVertex2d(200,412);
    glVertex2d(202,414);
    glVertex2d(200,413);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(200,413);
    glVertex2d(202,414);
    glVertex2d(162,439);
    glVertex2d(162,436);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(144,14,18);
    glVertex2d(162,436);
    glVertex2d(162,439);
    glVertex2d(143,427);
    glVertex2d(143,425);
    glEnd();

//kaki
    glBegin(GL_POLYGON);
    glColor3ub(231,234,234);
    glVertex2f(161.4,443.35);
    glVertex2f(160.44,443.95);
    glVertex2f(153.83,436.92);
    glVertex2f(154.79,436.32);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,130,131);
    glVertex2f(160.44,443.95);
    glVertex2f(160.44,444.81);
    glVertex2f(150.27,433.99);
    glVertex2f(150.49,433.37);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,187,188); //gak muncul
    glVertex2f(162.57,440.37);
    glVertex2f(162.55,446.04);
    glVertex2f(161.6,446.64);
    glVertex2f(161.61,440.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,130,131); //gak muncul
    glVertex2f(161.61,440.97);
    glVertex2f(161.6,446.64);
    glVertex2f(160.44,445.92);
    glVertex2f(160.45,440.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,130,131);
    glVertex2f(151.87,435.69);
    glVertex2f(152.85,436.73);
    glVertex2f(145.43,435.34);
    glVertex2f(154.79,434.49);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,130,131);
    glVertex2f(144.28,430.15);
    glVertex2f(145.44,430.87);
    glVertex2f(145.42,436.54);
    glVertex2f(144.27,435.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(119,123,125); //putih gelap
    glVertex2d(162,439);
    glVertex2d(162,442);
    glVertex2d(143,430);
    glVertex2d(143,427);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155,161,163);
    glVertex2d(202,414);
    glVertex2d(203,416);
    glVertex2d(162,442);
    glVertex2d(162,439);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155,161,163);
    glVertex2d(213,389);
    glVertex2d(215,389);
    glVertex2d(203,416);
    glVertex2d(202,414);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(194,377);
    glVertex2d(213,389);
    glVertex2d(211,388);
    glVertex2d(192,377);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,187,188); //gak muncul
    glVertex2f(201.72,415.51);
    glVertex2f(201.7,421.18);
    glVertex2f(200.74,421.78);
    glVertex2f(201.76,416.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,130,131); //gak muncul
    glVertex2f(201.76,416.11);
    glVertex2f(200.74,421.78);
    glVertex2f(199.59,421.06);
    glVertex2f(199.6,415.39);
    glEnd();
}

void kgaris(){
    glBegin(GL_POLYGON);
    glColor3ub(229,236,241);
    glVertex2d(149,421);
    glVertex2d(168,433);
    glVertex2d(165,435);
    glVertex2d(146,423);
    glEnd();
}

void kgaris1(){
    glBegin(GL_POLYGON);
    glColor3ub(229,236,241);
    glVertex2d(184,395);
    glVertex2d(203,406);
    glVertex2d(201,410);
    glVertex2d(183,398);
    glEnd();
}

void circle(float X, float Y, float r){
    glBegin(GL_POLYGON);
    glColor4ub(46,171,227,180); //biru
    //glRotatef((float) glfwGetTime() * 0.f, 90.f, 90.f, 1.f);
    for (int i=0; i<=360;i++){
        float rad = i*3.14159/180;
        glVertex2f(X+cos(rad)*r,+Y+sin(rad)*r);
    }
    glEnd();
}

void circle2(float X, float Y, float r){
    glBegin(GL_POLYGON);
    glColor3ub(108,32,25); //coklat
    for (int i=0; i<=360;i++){
        float rad = i*3.14159/180;
        glVertex2f(X+cos(rad)*r,+Y+sin(rad)*r);
    }
    glEnd();
}

void DrawEllipse(float radiusX, float radiusY)
{
   int i;
   float DEG2RAD = 3.14159/180.0;
   glTranslatef(100.5f,100.5f,0.f);
   glBegin(GL_POLYGON);

   for(i=0;i<360;i++)
   {
      float rad = i*DEG2RAD;
      glVertex2f(cos(rad)*radiusX,
                  sin(rad)*radiusY);
   }

   glEnd();
}
void pagar(){
    for(int i=0;i<4;i++){
    glBegin(GL_POLYGON);
    glColor3ub(240,244,247);
    glVertex2d(2+i*12,443+i*7);
    glVertex2d(6+i*12,440+i*7);
    glVertex2d(10+i*12,448+i*7);
    glVertex2d(10+i*12,489+i*7);
    glVertex2d(2+i*12,484+i*7);
    glEnd();}

    for(int i=0;i<2;i++){
    glBegin(GL_POLYGON);
    glColor3ub(202,216,219);
    glVertex2d(0,453+i*20);
    glVertex2d(48,482+i*20);
    glVertex2d(48,487+i*20);
    glVertex2d(0,457+i*20);
    glEnd();}
}

void pagar2(){
    for(int i=0;i<4;i++){
    glBegin(GL_POLYGON);
    glColor3ub(240,244,247);
    glVertex2d(529+i*12,757-i*7);
    glVertex2d(533+i*12,749-i*7);
    glVertex2d(537+i*12,752-i*7);
    glVertex2d(537+i*12,794-i*7);
    glVertex2d(529+i*12,800-i*7);
    glEnd();}

    for(int i=0;i<2;i++){
    glBegin(GL_POLYGON);
    glColor3ub(202,216,219);
    glVertex2d(526,770+i*20);
    glVertex2d(573,740+i*20);
    glVertex2d(573,745+i*20);
    glVertex2d(526,775+i*20);
    glEnd();}
}

void road(){
    glBegin(GL_POLYGON);
    glColor3ub(124,124,124);
    glVertex2d(800,655);
    glVertex2d(800,800);
    glVertex2d(580,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124,124,124);
    glVertex2d(0,545);
    glVertex2d(0,800);
    glVertex2d(440,800);
    glEnd();
}

void ayunan(){
    //tali
    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(464,535);
    glVertex2d(465,535);
    glVertex2d(465,575);
    glVertex2d(464,575);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(453,541);
    glVertex2d(454,535);
    glVertex2d(454,578);
    glVertex2d(453,578);
    glEnd();

    //tempat duduk
    glBegin(GL_POLYGON);
    glColor3ub(240,231,216);
    glVertex2d(468,566);
    glVertex2d(468,573);
    glVertex2d(453,582);
    glVertex2d(453,575);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(240,231,216);
    glVertex2d(468,573);
    glVertex2d(474,577);
    glVertex2d(460,586);
    glVertex2d(453,582);
    glEnd();

    //tiang
    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(476,530);
    glVertex2d(476,606);
    glVertex2d(472,604);
    glVertex2d(472,530);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(479,524);
    glVertex2d(479,604);
    glVertex2d(476,606);
    glVertex2d(476,530);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(479,524);
    glVertex2d(476,530);
    glVertex2d(446,549);
    glVertex2d(442,546);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251,5,15);
    glVertex2d(442,546);
    glVertex2d(446,549);
    glVertex2d(446,624);
    glVertex2d(442,626);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,0,7);
    glVertex2d(439,544);
    glVertex2d(442,546);
    glVertex2d(442,626);
    glVertex2d(439,624);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(254,111,106);
    glVertex2d(475,522);
    glVertex2d(479,524);
    glVertex2d(442,546);
    glVertex2d(439,544);
    glEnd();
}
void tree(){
    glBegin(GL_POLYGON);
    glColor3ub(60,29,0);
    glVertex2d(757,407);
    glVertex2d(750,481);
    glVertex2d(749,484);
    glVertex2d(747,486);
    glVertex2d(742,487);
    glVertex2d(737,487);
    glVertex2d(733,485);
    glVertex2d(730,481);
    glVertex2d(730,467);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,95,6);
    glVertex2d(767,443);
    glVertex2d(772,450);
    glVertex2d(773,453);
    glVertex2d(772,457);
    glVertex2d(770,463);
    glVertex2d(764,468);
    glVertex2d(756,473);
    glVertex2d(748,474);
    glVertex2d(731,474);
    glVertex2d(721,471);
    glVertex2d(714,467);
    glVertex2d(709,463);
    glVertex2d(707,456);
    glVertex2d(708,451);
    glVertex2d(711,445);
    glVertex2d(713,443);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(93,131,0);
    glVertex2d(761,422);
    glVertex2d(768,431);
    glVertex2d(769,437);
    glVertex2d(767,443);
    glVertex2d(760,449);
    glVertex2d(751,452);
    glVertex2d(740,454);
    glVertex2d(728,453);
    glVertex2d(719,448);
    glVertex2d(713,443);
    glVertex2d(711,437);
    glVertex2d(712,431);
    glVertex2d(726,411);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(122,168,0);
    glVertex2d(740,382);
    glVertex2d(762,411);
    glVertex2d(761,422);
    glVertex2d(756,426);
    glVertex2d(749,429);
    glVertex2d(740,430);
    glVertex2d(731,429);
    glVertex2d(723,425);
    glVertex2d(718,419);
    glVertex2d(716,415);
    glVertex2d(718,410);
    glEnd();
}

int main(void)
{
    float radius;
    int i, j=0,k=0;
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Rumah - G64160026", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        bg();
        grass();
        build();
        garis();
        glPushMatrix();
        glTranslated(19,-29,0);
        garis();
        glTranslated(16,-24,0);
        garis();
        glTranslated(17,-26,0);
        garis();
        glTranslated(18,-27,0);
        garis();
        glTranslated(50,-8,0);
        garis();
        glTranslated(34,10,0);
        garis();
        glPopMatrix();
        kolam();
        //DrawEllipse(14,18);
        circle2(307.52,381.96,12.84); //jendela coklat
        circle(307.52,381.96,11); //jendela kaca

        glBegin(GL_POLYGON);
        glColor3ub(229,236,241);
        glVertex2d(184,395);
        glVertex2d(203,406);
        glVertex2d(201,410);
        glVertex2d(183,398);
        glEnd();

        kursi();
        for(i=0;i<6;i++){
        glPushMatrix();
        glTranslated(i*6,i*(-4),0);
        kgaris();
        glPopMatrix();}
        for(i=0;i<3;i++){
        glPushMatrix();
        glTranslated(i*3,i*(-7),0);
        kgaris1();
        glPopMatrix();}
        glPushMatrix();
        glTranslated(27,20,0);
        kursi();
        glPopMatrix();
        for(i=0;i<6;i++){
        glPushMatrix();
        glTranslated(i*6+27,i*(-4)+20,0);
        kgaris();
        glPopMatrix();
        }
        for(i=0;i<3;i++){
        glPushMatrix();
        glTranslated(i*3+27,i*(-7)+20,0);
        kgaris1();
        glPopMatrix();}

        road();
        for(i=0;i<10;i++){
            glPushMatrix();
            glTranslated(i*51,i*30,0);
            pagar();
            glPopMatrix();
        }
        glPushMatrix();
        glTranslated((-10),(-25),0);
        pagar2();
        for(i=0;i<5&&i!=3;i++){
            glTranslated(53,(-34),0);
            pagar2();
        }
        glTranslated(2*53,2*(-34),0);
        pagar2();
        glPopMatrix();
        ayunan();

        tree();
        glPushMatrix();
            glTranslated(-200,100,0);
            tree();
            glPopMatrix();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}

