#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,800,800,0,-1.f,1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void box(float x, float y, float xe, float ye){
    glBegin(GL_POLYGON);
        glVertex2f(x,y);
        glVertex2f(x,ye);
        glVertex2f(xe,ye);
        glVertex2f(xe,y);
    glEnd();
}

void circle(float r, float x, float y){
    glBegin(GL_POLYGON);
        for (int i=0; i <= 360; i++){
            glVertex2f(x+cos(i)*r, y+sin(i)*r);
        }
   glEnd();
}

void triangle(float ax, float ay, float bx, float by, float cx, float cy){
    glBegin(GL_POLYGON);
        glVertex2d(ax,ay);
        glVertex2d(bx,by);
        glVertex2d(cx,cy);
    glEnd();
}

void display()
{
    // your drawing code here, maybe
    //background
    glColor3ub(0,162,232);
    box(0,0,800,800);
    glColor3ub(128,64,0);
    box(0,575,800,800);

    glColor3ub(218,218,218);
    box(121,335,677,639);

    glColor3ub(56,58,73);
    box(94,563,707,582);
    box(77,335,718,342);
    box(121,264,677,336);
    triangle(214,335,580,335,397,197);

    glColor3ub(163,167,168);
    box(94,342,702,348);
    box(139,391,327,488);
    box(473,390,659,486);
    triangle(226,335,571,335,397,205);

    glColor3ub(172,154,135);
    box(341,383,454,542);

    glColor3ub(84,85,91);
    for(int i = 0; i < 4; i++)
        box(354,270+(i*8),445,275+(i*8));
    for(int i = 0; i < 4; i++)
        box(300,542+(18*i),498,552+(18*i));

    glColor3ub(252,247,228);
    for(int i = 0; i < 4; i++)
        box(302,560+(18*i),494,570+(18*i));

    glColor3ub(227,207,111);
    box(425,464,437,473);
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Rumah Impian", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
