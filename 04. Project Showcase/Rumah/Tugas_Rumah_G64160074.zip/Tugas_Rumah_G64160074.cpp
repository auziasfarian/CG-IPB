#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description) {
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void display() {
    glColor3ub(19,24,98);
    glBegin(GL_POLYGON);
    glVertex2f(0, 0);
    glVertex2f(0, 500);
    glVertex2f(500, 500);
    glVertex2f(500, 0);
    glEnd();

    //land
    glPushMatrix();
        glColor3ub(140, 173, 81);
        glBegin(GL_POLYGON);
        glVertex2f(23.03, 224.21);
        glVertex2f(154.95, 148.55);
        glVertex2f(480.4, 311.9);
        glVertex2f(328.04, 400.45);
        glEnd();

        glColor3ub(127, 158, 72);
        glBegin(GL_POLYGON);
        glVertex2f(328.04, 400.45);
        glVertex2f(480.4, 311.9);
        glVertex2f(480.39, 316.42);
        glVertex2f(328.02, 404.97);
        glEnd();

        glColor3ub(95, 117, 56);
        glBegin(GL_POLYGON);
        glVertex2f(23.03, 224.21);
        glVertex2f(328.04, 400.45);
        glVertex2f(328.02, 404.97);
        glVertex2f(23.02, 230.18);
        glEnd();
    glPopMatrix();

    //home1
    glPushMatrix();
        glColor3ub(25, 114, 158);
        glBegin(GL_POLYGON);
        glVertex2f(70.17, 144.24);
        glVertex2f(145.05, 187.47);
        glVertex2f(144.86, 254.03);
        glVertex2f(69.98, 210.8);
        glEnd();

        glColor3ub(14, 70, 102);
        glBegin(GL_POLYGON);
        glVertex2f(80.84, 179.54);
        glVertex2f(126.9, 206.13);
        glVertex2f(126.79, 243.55);
        glVertex2f(80.73, 216.96);
        glEnd();

        glColor3ub(14, 70, 102);
        glBegin(GL_POLYGON);
        glVertex2f(81.44, 179.19);
        glVertex2f(127.5, 205.78);
        glVertex2f(126.9, 206.13);
        glVertex2f(80.84, 179.54);
        glEnd();

        glColor3ub(14, 70, 102);
        glBegin(GL_POLYGON);
        glVertex2f(126.9, 206.13);
        glVertex2f(127.5, 205.78);
        glVertex2f(127.4, 243.2);
        glVertex2f(126.79, 243.55);
        glEnd();

        glColor3ub(109, 117, 121);
        glBegin(GL_POLYGON);
        glVertex2f(79.92, 178.98);
        glVertex2f(81.74, 182.13);
        glVertex2f(81.64, 217.48);
        glVertex2f(79.82, 216.43);
        glEnd();

        glColor3ub(146, 146, 146);
        glBegin(GL_POLYGON);
        glVertex2f(81.74, 182.13);
        glVertex2f(82.35, 181.78);
        glVertex2f(82.25, 217.13);
        glVertex2f(81.64, 217.48);
        glEnd();

        glColor3ub(109, 117, 121);
        glBegin(GL_POLYGON);
        glVertex2f(79.92, 178.98);
        glVertex2f(127.81, 206.63);
        glVertex2f(125.98, 207.67);
        glVertex2f(81.74, 182.13);
        glEnd();

        glColor3ub(109, 117, 121);
        glBegin(GL_POLYGON);
        glVertex2f(125.98, 207.67);
        glVertex2f(127.81, 206.63);
        glVertex2f(127.71, 244.08);
        glVertex2f(125.88, 243.02);
        glEnd();

        glColor3ub(155, 156, 158);
        glBegin(GL_POLYGON);
        glVertex2f(80.53, 178.63);
        glVertex2f(128.42, 206.28);
        glVertex2f(127.81, 206.63);
        glVertex2f(79.92, 178.98);
        glEnd();

        glColor3ub(146, 146, 146);
        glBegin(GL_POLYGON);
        glVertex2f(127.81, 206.63);
        glVertex2f(128.42, 206.28);
        glVertex2f(128.31, 243.73);
        glVertex2f(127.71, 244.08);
        glEnd();

        glColor3ub(136, 135, 134);
        glBegin(GL_POLYGON);
        glVertex2f(143.39, 100.22);
        glVertex2f(220.17, 144.55);
        glVertex2f(141.55, 190.24);
        glVertex2f(64.77, 145.91);
        glEnd();

        glColor3ub(96, 95, 95);
        glBegin(GL_POLYGON);
        glVertex2f(64.77, 145.91);
        glVertex2f(141.55, 190.24);
        glVertex2f(141.54, 192.48);
        glVertex2f(64.76, 148.15);
        glEnd();

        glColor3ub(136, 135, 134);
        glBegin(GL_POLYGON);
        glVertex2f(141.55, 190.24);
        glVertex2f(220.17, 144.55);
        glVertex2f(220.16, 146.79);
        glVertex2f(141.54, 192.48);
        glEnd();

        glColor3ub(82, 124, 175);
        glBegin(GL_POLYGON);
        glVertex2f(145.19, 168.09);
        glVertex2f(169.46, 154.78);
        glVertex2f(193.58, 196.03);
        glVertex2f(193.34, 282.07);
        glVertex2f(144.94, 254.13);
        glEnd();

        glColor3ub(32, 101, 148);
        glBegin(GL_POLYGON);
        glVertex2f(150.09, 213.06);
        glVertex2f(182.2, 231.6);
        glVertex2f(182.2, 276.13);
        glVertex2f(150.09, 257.59);
        glEnd();

        glColor3ub(32, 101, 148);
        glBegin(GL_POLYGON);
        glVertex2f(150.19, 177.4);
        glVertex2f(182.3, 195.94);
        glVertex2f(182.2, 276.13);
        glVertex2f(150.09, 257.59);
        glEnd();

        glColor3ub(160, 161, 161);
        glBegin(GL_POLYGON);
        glVertex2f(151.69, 179.77);
        glVertex2f(180.79, 196.57);
        glVertex2f(180.73, 217.8);
        glVertex2f(151.63, 201);
        glEnd();

        for(int i = 0; i < 3; i++){
            glColor3ub(118, 145, 153);
            glBegin(GL_POLYGON);
            glVertex2f(153.51 + i * 9.09, 182.93 + i * 5.25);
            glVertex2f(160.78 + i * 9.09, 187.12 + i * 5.25);
            glVertex2f(160.78 + i * 9.09, 204.15 + i * 5.25);
            glVertex2f(153.46 + i * 9.09, 199.96 + i * 5.25);
            glEnd();
        }

        glColor3ub(145, 156, 158);
        glBegin(GL_POLYGON);
        glVertex2f(148.05, 207.67);
        glVertex2f(184.47, 228.7);
        glVertex2f(184.46, 232.9);
        glVertex2f(148.04, 211.87);
        glEnd();

        glColor3ub(205, 220, 224);
        glBegin(GL_POLYGON);
        glVertex2f(148.65, 207.32);
        glVertex2f(150.71, 208.51);
        glVertex2f(150.1, 208.86);
        glVertex2f(148.05, 207.67);
        glEnd();

        glColor3ub(205, 220, 224);
        glBegin(GL_POLYGON);
        glVertex2f(182.82, 227.05);
        glVertex2f(185.08, 228.35);
        glVertex2f(184.47, 228.7);
        glVertex2f(182.21, 227.4);
        glEnd();

        glColor3ub(205, 220, 224);
        glBegin(GL_POLYGON);
        glVertex2f(184.47, 228.7);
        glVertex2f(185.08, 228.35);
        glVertex2f(185.06, 232.55);
        glVertex2f(184.46, 232.9);
        glEnd();

        glColor3ub(81, 173, 205);
        glBegin(GL_POLYGON);
        glVertex2f(150.8, 177.05);
        glVertex2f(182.91, 195.59);
        glVertex2f(182.3, 195.94);
        glVertex2f(150.19, 177.4);
        glEnd();

        glColor3ub(74, 159, 187);
        glBegin(GL_POLYGON);
        glVertex2f(182.3, 195.94);
        glVertex2f(182.91, 195.59);
        glVertex2f(182.82, 227.05);
        glVertex2f(182.21, 227.4);
        glEnd();

        glColor3ub(74, 159, 187);
        glBegin(GL_POLYGON);
        glVertex2f(182.2, 231.6);
        glVertex2f(182.81, 231.24);
        glVertex2f(182.68, 275.78);
        glVertex2f(182.08, 276.13);
        glEnd();

        for(int i = 0; i < 2; i++){
            glColor3ub(14, 70, 102);
            glBegin(GL_POLYGON);
            glVertex2f(152.5 + i * 13.61, 225.07 + i * 7.86);
            glVertex2f(166.11 + i * 13.61, 232.93 + i * 7.86);
            glVertex2f(166.02 + i * 13.61, 266.86 + i * 7.86);
            glVertex2f(152.4 + i * 13.61, 259 + i * 7.86);
            glEnd();
        }

        for(int i = 0; i < 2; i++){
            glColor3ub(118, 145, 153);
            glBegin(GL_POLYGON);
            glVertex2f(155.53 + i * 13.62, 230.33 + i * 7.86);
            glVertex2f(163.06 + i * 13.62, 234.68 + i * 7.86);
            glVertex2f(162.99 + i * 13.62, 261.6 + i * 7.86);
            glVertex2f(155.45 + i * 13.62, 257.25 + i * 7.86);
            glEnd();
        }

        glColor3ub(83, 82, 82);
        glBegin(GL_POLYGON);
        glVertex2f(136.24, 170.69);
        glVertex2f(214.86, 125);
        glVertex2f(244.96, 109.09);
        glVertex2f(166.34, 154.78);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(136.24, 170.69);
        glVertex2f(166.34, 154.78);
        glVertex2f(166.33, 157.69);
        glVertex2f(137.5, 172.93);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(166.34, 154.78);
        glVertex2f(196.23, 205.3);
        glVertex2f(194.96, 206.08);
        glVertex2f(166.33, 157.69);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(166.34, 154.78);
        glVertex2f(196.23, 205.3);
        glVertex2f(194.96, 206.08);
        glVertex2f(166.33, 157.69);
        glEnd();

        glColor3ub(133, 132, 131);
        glBegin(GL_POLYGON);
        glVertex2f(166.34, 154.78);
        glVertex2f(244.96, 109.09);
        glVertex2f(274.85, 159.61);
        glVertex2f(196.23, 205.3);
        glEnd();
    glPopMatrix();

    //home2
    glPushMatrix();
        glColor3ub(122, 159, 196);
        glBegin(GL_POLYGON);
        glVertex2f(193.62, 189.83);
        glVertex2f(248.41, 221.46);
        glVertex2f(293.77, 247.65);
        glVertex2f(193.36, 281.84);
        glEnd();

        glColor3ub(122, 159, 196);
        glBegin(GL_POLYGON);
        glVertex2f(248.41, 221.46);
        glVertex2f(271.18, 203.3);
        glVertex2f(293.77, 247.65);
        glVertex2f(293.59, 339.71);
        glVertex2f(193.36, 281.84);
        glEnd();

        glColor3ub(112, 171, 224);
        glBegin(GL_POLYGON);
        glVertex2f(293.77, 247.65);
        glVertex2f(384.49, 194.93);
        glVertex2f(384.3, 286.99);
        glVertex2f(293.59, 339.71);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(248.37, 221.52);
        glVertex2f(293.9, 247.81);
        glVertex2f(291.93, 248.92);
        glVertex2f(250.33, 224.9);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(248.37, 221.52);
        glVertex2f(250.33, 224.9);
        glVertex2f(250.08, 312.42);
        glVertex2f(248.11, 313.53);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(291.93, 248.92);
        glVertex2f(293.9, 247.81);
        glVertex2f(293.64, 339.82);
        glVertex2f(291.69, 336.44);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(249.3, 259.85);
        glVertex2f(292.78, 284.95);
        glVertex2f(292.76, 291.95);
        glVertex2f(249.28, 266.84);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(253.58, 269.32);
        glVertex2f(256.08, 270.76);
        glVertex2f(255.94, 318.05);
        glVertex2f(253.44, 316.61);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(285.86, 287.96);
        glVertex2f(288.36, 289.4);
        glVertex2f(288.23, 336.69);
        glVertex2f(285.73, 335.25);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(250.08, 312.42);
        glVertex2f(263.56, 320.2);
        glVertex2f(263.56, 322.45);
        glVertex2f(248.11, 313.53);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(278.88, 329.05);
        glVertex2f(291.69, 336.44);
        glVertex2f(293.64, 339.82);
        glVertex2f(278.87, 331.29);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(263.65, 289.65);
        glVertex2f(278.96, 298.49);
        glVertex2f(278.87, 331.29);
        glVertex2f(263.56, 322.62);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(262.74, 278.17);
        glVertex2f(279.95, 288.11);
        glVertex2f(279.95, 288.61);
        glVertex2f(262.74, 278.67);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(263.68, 279.22);
        glVertex2f(279.01, 288.07);
        glVertex2f(278.99, 295.36);
        glVertex2f(263.66, 286.52);
        glEnd();

        glColor3ub(105, 125, 132);
        glBegin(GL_POLYGON);
        glVertex2f(265.78, 281.23);
        glVertex2f(276.91, 287.66);
        glVertex2f(276.9, 293.34);
        glVertex2f(265.76, 286.92);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(270.82, 283.8);
        glVertex2f(271.87, 284.4);
        glVertex2f(271.85, 290.66);
        glVertex2f(270.8, 290.06);
        glEnd();

        glColor3ub(136, 135, 134);
        glBegin(GL_POLYGON);
        glVertex2f(285.14, 129.54);
        glVertex2f(345.21, 164.21);
        glVertex2f(248.01, 220.7);
        glVertex2f(187.95, 186.02);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(187.95, 186.02);
        glVertex2f(248.01, 220.7);
        glVertex2f(248.66, 223.69);
        glVertex2f(187.94, 188.52);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(248.01, 220.7);
        glVertex2f(270.24, 202.97);
        glVertex2f(270.23, 206.48);
        glVertex2f(248.66, 223.69);
        glEnd();

        glColor3ub(86, 85, 85);
        glBegin(GL_POLYGON);
        glVertex2f(270.24, 202.97);
        glVertex2f(295.68, 252.91);
        glVertex2f(294.18, 253.49);
        glVertex2f(270.23, 206.48);
        glEnd();

        glColor3ub(133, 132, 131);
        glBegin(GL_POLYGON);
        glVertex2f(270.24, 202.97);
        glVertex2f(367.44, 146.49);
        glVertex2f(392.87, 196.42);
        glVertex2f(295.68, 252.91);
        glEnd();

        for(int i = 0; i < 2; i++){
            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(203.57 + i * 21.75, 212.5 + i * 12.56);
            glVertex2f(217.87 + i * 21.75, 220.75 + i * 12.56);
            glVertex2f(217.81 + i * 21.75, 241.08 + i * 12.56);
            glVertex2f(203.51 + i * 21.75, 232.82 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(202.69 + i * 21.75, 211.19 + i * 12.56);
            glVertex2f(218.75 + i * 21.75, 220.46 + i * 12.56);
            glVertex2f(218.75 + i * 21.75, 221.26 + i * 12.56);
            glVertex2f(202.69 + i * 21.75, 211.99 + i * 12.56);
            glEnd();

            glColor3ub(105, 125, 132);
            glBegin(GL_POLYGON);
            glVertex2f(205.52 + i * 21.75, 215.88 + i * 12.56);
            glVertex2f(215.91 + i * 21.75, 221.88 + i * 12.56);
            glVertex2f(215.86 + i * 21.75, 237.7 + i * 12.56);
            glVertex2f(205.47 + i * 21.75, 231.7 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(210.23 + i * 21.75, 217.09 + i * 12.56);
            glVertex2f(211.2 + i * 21.75, 217.65 + i * 12.56);
            glVertex2f(211.15 + i * 21.75, 236.1 + i * 12.56);
            glVertex2f(210.18 + i * 21.75, 235.54 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(204.51 + i * 21.75, 222.66 + i * 12.56);
            glVertex2f(216.86 + i * 21.75, 229.79 + i * 12.56);
            glVertex2f(216.86 + i * 21.75, 230.92 + i * 12.56);
            glVertex2f(204.51 + i * 21.75, 223.79 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(202.58 + i * 21.75, 249 + i * 12.56);
            glVertex2f(218.64 + i * 21.75, 258.27 + i * 12.56);
            glVertex2f(218.64 + i * 21.75, 259.08 + i * 12.56);
            glVertex2f(202.58 + i * 21.75, 249.8 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(203.46 + i * 21.75, 250.31 + i * 12.56);
            glVertex2f(217.76 + i * 21.75, 258.57 + i * 12.56);
            glVertex2f(217.7 + i * 21.75, 278.88 + i * 12.56);
            glVertex2f(203.4 + i * 21.75, 270.63 + i * 12.56);
            glEnd();

            glColor3ub(105, 125, 132);
            glBegin(GL_POLYGON);
            glVertex2f(205.41 + i * 21.75, 253.69 + i * 12.56);
            glVertex2f(215.8 + i * 21.75, 259.68 + i * 12.56);
            glVertex2f(215.75 + i * 21.75, 275.51 + i * 12.56);
            glVertex2f(205.36 + i * 21.75, 269.51 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(210.12 + i * 21.75, 256.4 + i * 12.56);
            glVertex2f(211.09 + i * 21.75, 256.97 + i * 12.56);
            glVertex2f(211.05 + i * 21.75, 272.79 + i * 12.56);
            glVertex2f(210.07 + i * 21.75, 272.23 + i * 12.56);
            glEnd();

            glColor3ub(150, 150, 150);
            glBegin(GL_POLYGON);
            glVertex2f(205.39 + i * 21.75, 261.04 + i * 12.56);
            glVertex2f(215.78 + i * 21.75, 267.04 + i * 12.56);
            glVertex2f(215.77 + i * 21.75, 268.16 + i * 12.56);
            glVertex2f(205.38 + i * 21.75, 262.16 + i * 12.56);
            glEnd();
        }

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(203.57 + 60.39, 212.5 + 26.41);
        glVertex2f(217.87 + 60.39, 220.75 + 26.41);
        glVertex2f(217.81 + 60.39, 241.08 + 26.41);
        glVertex2f(203.51 + 60.39, 232.82 + 26.41);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(202.69 + 60.39, 211.19 + 26.41);
        glVertex2f(218.75 + 60.39, 220.46 + 26.41);
        glVertex2f(218.75 + 60.39, 221.26 + 26.41);
        glVertex2f(202.69 + 60.39, 211.99 + 26.41);
        glEnd();

        glColor3ub(105, 125, 132);
        glBegin(GL_POLYGON);
        glVertex2f(205.52 + 60.39, 215.88 + 26.41);
        glVertex2f(215.91 + 60.39, 221.88 + 26.41);
        glVertex2f(215.86 + 60.39, 237.7 + 26.41);
        glVertex2f(205.47 + 60.39, 231.7 + 26.41);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(210.23 + 60.39, 217.09 + 26.41);
        glVertex2f(211.2 + 60.39, 217.65 + 26.41);
        glVertex2f(211.15 + 60.39, 236.1 + 26.41);
        glVertex2f(210.18 + 60.39, 235.54 + 26.41);
        glEnd();

        glColor3ub(150, 150, 150);
        glBegin(GL_POLYGON);
        glVertex2f(204.51 + 60.39, 222.66 + 26.41);
        glVertex2f(216.86 + 60.39, 229.79 + 26.41);
        glVertex2f(216.86 + 60.39, 230.92 + 26.41);
        glVertex2f(204.51 + 60.39, 223.79 + 26.41);
        glEnd();

        glColor3ub(150, 134, 70);
        glBegin(GL_POLYGON);
        glVertex2f(264.95, 291.91);
        glVertex2f(277.66, 299.24);
        glVertex2f(277.57, 329.22);
        glVertex2f(264.86, 321.88);
        glEnd();

        for(int i = 0; i < 2; i++){
            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(299.28 + i * 21.76, 262.21 + i * -11.76);
            glVertex2f(315.34 + i * 21.76, 252.94 + i * -11.76);
            glVertex2f(315.35 + i * 21.76, 253.74 + i * -11.76);
            glVertex2f(299.29 + i * 21.76, 263.01 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(300.17 + i * 21.76, 262.5 + i * -11.76);
            glVertex2f(314.47 + i * 21.76, 254.24 + i * -11.76);
            glVertex2f(314.53 + i * 21.76, 274.56 + i * -11.76);
            glVertex2f(300.22 + i * 21.76, 282.82 + i * -11.76);
            glEnd();

            glColor3ub(141, 166, 178);
            glBegin(GL_POLYGON);
            glVertex2f(302.13 + i * 21.76, 263.62 + i * -11.76);
            glVertex2f(312.52 + i * 21.76, 257.62 + i * -11.76);
            glVertex2f(312.56 + i * 21.76, 273.44 + i * -11.76);
            glVertex2f(302.17 + i * 21.76, 279.44 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(306.83 + i * 21.76, 259.4 + i * -11.76);
            glVertex2f(307.81 + i * 21.76, 258.83 + i * -11.76);
            glVertex2f(307.86 + i * 21.76, 277.29 + i * -11.76);
            glVertex2f(306.88 + i * 21.76, 277.85 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(301.17 + i * 21.76, 271.54 + i * -11.76);
            glVertex2f(313.52 + i * 21.76, 264.41 + i * -11.76);
            glVertex2f(313.52 + i * 21.76, 265.53 + i * -11.76);
            glVertex2f(301.17 + i * 21.76, 272.66 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(299.39 + i * 21.76, 300.01 + i * -11.76);
            glVertex2f(315.45 + i * 21.76, 290.74 + i * -11.76);
            glVertex2f(315.45 + i * 21.76, 291.54 + i * -11.76);
            glVertex2f(299.39 + i * 21.76, 300.82 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(300.27 + i * 21.76, 300.31 + i * -11.76);
            glVertex2f(314.58 + i * 21.76, 292.05 + i * -11.76);
            glVertex2f(314.64 + i * 21.76, 312.37 + i * -11.76);
            glVertex2f(300.33 + i * 21.76, 320.63 + i * -11.76);
            glEnd();

            glColor3ub(141, 166, 178);
            glBegin(GL_POLYGON);
            glVertex2f(302.24 + i * 21.76, 301.43 + i * -11.76);
            glVertex2f(312.52 + i * 21.76, 295.43 + i * -11.76);
            glVertex2f(312.67 + i * 21.76, 311.26 + i * -11.76);
            glVertex2f(302.28 + i * 21.76, 317.26 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(306.94 + i * 21.76, 298.71 + i * -11.76);
            glVertex2f(307.92 + i * 21.76, 298.14 + i * -11.76);
            glVertex2f(307.97 + i * 21.76, 313.97 + i * -11.76);
            glVertex2f(306.99 + i * 21.76, 314.54 + i * -11.76);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(302.26 + i * 21.76, 308.78 + i * -11.76);
            glVertex2f(312.65 + i * 21.76, 302.78 + i * -11.76);
            glVertex2f(312.65 + i * 21.76, 303.91 + i * -11.76);
            glVertex2f(302.26 + i * 21.76, 309.9 + i * -11.76);
            glEnd();
        }

        glColor3ub(122, 159, 196);
        glBegin(GL_POLYGON);
        glVertex2f(346.15, 265.48);
        glVertex2f(372.61, 280.85);
        glVertex2f(372.73, 324.72);
        glVertex2f(346.27, 309.34);
        glEnd();

        glColor3ub(112, 171, 224);
        glBegin(GL_POLYGON);
        glVertex2f(372.61, 280.85);
        glVertex2f(391.64, 248.35);
        glVertex2f(410.78, 258.81);
        glVertex2f(410.91, 302.68);
        glVertex2f(372.73, 324.72);
        glEnd();

        glColor3ub(136, 135, 134);
        glBegin(GL_POLYGON);
        glVertex2f(363.23, 230.5);
        glVertex2f(391.69, 245.88);
        glVertex2f(367.58, 287.31);
        glVertex2f(341.12, 271.93);
        glEnd();

        glColor3ub(83, 82, 82);
        glBegin(GL_POLYGON);
        glVertex2f(367.58, 287.31);
        glVertex2f(391.69, 245.88);
        glVertex2f(391.7, 248.46);
        glVertex2f(368.7, 287.97);
        glEnd();

        glColor3ub(83, 82, 82);
        glBegin(GL_POLYGON);
        glVertex2f(391.69, 245.88);
        glVertex2f(415.96, 259.38);
        glVertex2f(414.83, 261.33);
        glVertex2f(391.7, 248.46);
        glEnd();

        glColor3ub(83, 82, 82);
        glBegin(GL_POLYGON);
        glVertex2f(365.23, 230.5);
        glVertex2f(389.5, 244);
        glVertex2f(415.96, 259.38);
        glVertex2f(391.69, 245.88);
        glEnd();

        for(int i = 0; i < 2; i++){
            glColor3ub(203, 203, 203); //window
            glBegin(GL_POLYGON);
            glVertex2f(375.57 + i * 17.76, 292.36 + i * -10.25);
            glVertex2f(388.68 + i * 17.76, 284.79 + i * -10.25);
            glVertex2f(388.69 + i * 17.76, 285.45 + i * -10.25);
            glVertex2f(375.57 + i * 17.76, 293.02 + i * -10.25);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(376.29 + i * 17.76, 292.61 + i * -10.25);
            glVertex2f(387.97 + i * 17.76, 285.86 + i * -10.25);
            glVertex2f(388.01 + i * 17.76, 302.46 + i * -10.25);
            glVertex2f(376.33 + i * 17.76, 309.2 + i * -10.25);
            glEnd();

            glColor3ub(141, 166, 178);
            glBegin(GL_POLYGON);
            glVertex2f(377.89 + i * 17.76, 293.52 + i * -10.25);
            glVertex2f(386.38 + i * 17.76, 288.62 + i * -10.25);
            glVertex2f(386.41 + i * 17.76, 301.55 + i * -10.25);
            glVertex2f(377.93 + i * 17.76, 306.45 + i * -10.25);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(381.73 + i * 17.76, 290.07 + i * -10.25);
            glVertex2f(382.53 + i * 17.76, 289.61 + i * -10.25);
            glVertex2f(382.57 + i * 17.76, 304.68 + i * -10.25);
            glVertex2f(381.77 + i * 17.76, 305.14 + i * -10.25);
            glEnd();

            glColor3ub(203, 203, 203);
            glBegin(GL_POLYGON);
            glVertex2f(377.11 + i * 17.76, 299.98 + i * -10.25);
            glVertex2f(387.19 + i * 17.76, 294.16 + i * -10.25);
            glVertex2f(387.2 + i * 17.76, 295.08 + i * -10.25);
            glVertex2f(377.11 + i * 17.76, 300.9 + i * -10.25);
            glEnd();
        }
    glPopMatrix();

    //decos
    glPushMatrix();
        glColor3ub(204, 170, 125);
        glBegin(GL_POLYGON);
        glVertex2f(125.72, 275.6);
        glVertex2f(148.87, 261.93);
        glVertex2f(174.24, 276.58);
        glVertex2f(150.72, 290.04);
        glEnd();

        glColor3ub(204, 170, 125);
        glBegin(GL_POLYGON);
        glVertex2f(231.97, 337.57);
        glVertex2f(255.12, 323.9);
        glVertex2f(280.49, 338.55);
        glVertex2f(256.97, 352);
        glEnd();

        glColor3ub(63, 61, 61);
        glBegin(GL_POLYGON);
        glVertex2f(46.65, 237.38);
        glVertex2f(79.82, 216.43);
        glVertex2f(127.71, 244.08);
        glVertex2f(95.14, 265.01);
        glEnd();

        glColor3ub(237, 244, 249);
        glBegin(GL_POLYGON);
        glVertex2f(299.67, 342.2);
        glVertex2f(346.17, 315.18);
        glVertex2f(382.57, 336.2);
        glVertex2f(336.07, 363.22);
        glEnd();

        glColor3ub(0, 235, 255);
        glBegin(GL_POLYGON);
        glVertex2f(306.42, 342.55);
        glVertex2f(346.17, 319.45);
        glVertex2f(375.82, 336.56);
        glVertex2f(336.07, 359.67);
        glEnd();

        glColor3ub(171, 173, 176);
        glBegin(GL_POLYGON);
        glVertex2f(305.8, 342.19);
        glVertex2f(346.17, 318.73);
        glVertex2f(346.17, 319.45);
        glVertex2f(306.42, 342.55);
        glEnd();

        glColor3ub(212, 216, 219);
        glBegin(GL_POLYGON);
        glVertex2f(346.17, 318.73);
        glVertex2f(376.44, 336.21);
        glVertex2f(375.82, 336.56);
        glVertex2f(346.17, 319.45);
        glEnd();

        glColor3ub(212, 216, 219);
        glBegin(GL_POLYGON);
        glVertex2f(336.07, 363.22);
        glVertex2f(382.57, 336.2);
        glVertex2f(382.57, 337.22);
        glVertex2f(336.07, 364.24);
        glEnd();

        glColor3ub(171, 173, 176);
        glBegin(GL_POLYGON);
        glVertex2f(299.67, 342.2);
        glVertex2f(336.07, 363.22);
        glVertex2f(336.07, 364.24);
        glVertex2f(299.67, 343.23);
        glEnd();

    glPopMatrix();


    /*
        glColor3ub();
        glBegin(GL_POLYGON);
        glVertex2f();
        glVertex2f();
        glVertex2f();
        glVertex2f();
        glEnd();
    */
}

int main(void) {
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(600, 600, "House - G64160074 - Alif Hilmi Akbar", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width * 10 / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        glOrtho(0, 500, 500, 0, 1, -1);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
