#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1366, 768, 0, 1.0f, -1.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    //background biru
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_POLYGON);
    glColor3ub(92,137,187);
    glVertex2d(0,0);
    glVertex2d(1366,0);
    glVertex2d(1366,768);
    glVertex2d(0,1366);
    glEnd();
    glFlush();
}

void dinding(){

    glBegin(GL_POLYGON);
    glColor3ub(218,216,219);
    glVertex2d(320.05,457.16);
    glVertex2d(996.42,290.75);
    glVertex2d(1256.6,496.96);
    glVertex2d(1210.54,501.21);
    glVertex2d(443.82,496.96);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(139,80,64);
    glVertex2d(317.22,445.35);
    glVertex2d(317.22,456.21);
    glVertex2d(996.42,290.75);
    glVertex2d(996.42,277.64);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(112,60,49);
    glVertex2d(996.42,277.64);
    glVertex2d(996.42,290.75);
    glVertex2d(1256.6,496.96);
    glVertex2d(1256.6,486.8);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,80,64);
    glVertex2d(964.41,243.04);
    glVertex2d(996.42,277.64);
    glVertex2d(317.22,445.35);
    glVertex2d(733.29,305.99);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(112,60,49);
    glVertex2d(1256.6,486.8);
    glVertex2d(996.42,277.64);
    glVertex2d(964.41,243.04);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(209,188,161);
    glVertex2d(995,338.58);
    glVertex2d(995,458.22);
    glVertex2d(1094.56,755.6);
    glVertex2d(1211.24,755.6);
    glVertex2d(1210.43,489.87);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(254,225,193);
    glVertex2d(422.68,460.23);
    glVertex2d(422.68,582.82);
    glVertex2d(995,512.31);
    glVertex2d(995,338.58);
    glEnd();


        glBegin(GL_POLYGON);
    glColor3ub(254,225,193);
    glVertex2d(522.48,593.45);
    glVertex2d(522.48,755.6);
    glVertex2d(896.98,755.6);
    glVertex2d(896.98,551.52);
    glEnd();


            glBegin(GL_POLYGON);
    glColor3ub(187,171,148);
    glVertex2d(896.98,551.52);
    glVertex2d(896.98,636.79);
    glVertex2d(995.71,631.12);
    glVertex2d(995.71,579.98);
    glEnd();

            glBegin(GL_POLYGON);
    glColor3ub(254,225,193);
    glVertex2d(1009.53,581.05);
    glVertex2d(1009.53,747.92);
    glVertex2d(1094.56,747.92);
    glVertex2d(1093.97,575.61);
    glEnd();



             glBegin(GL_POLYGON);
    glColor3ub(254,225,193);
    glVertex2d(1009.53,581.05);
    glVertex2d(1009.53,747.92);
    glVertex2d(1094.56,747.92);
    glVertex2d(1093.97,575.61);
    glEnd();



            glBegin(GL_POLYGON);
    glColor3ub(113,80,71);
    glVertex2d(896.98,551.52);
    glVertex2d(994.06,512.31);
    glVertex2d(1146.53,572.07);
    glVertex2d(1001.85,581.75);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(254,225,193);
    glVertex2d(967.25,523.41);
    glVertex2d(967.25,641.04);
    glVertex2d(995.71,641.04);
    glVertex2d(995.71,519.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(209,188,161);
    glVertex2d(995.71,519.16);
    glVertex2d(995.71,641.04);
    glVertex2d(1012.72,641.04);
    glVertex2d(1012.72,526.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(195,139,124);
    glVertex2d(253.8,506.29);
    glVertex2d(443.82,472.51);
    glVertex2d(443.82,755.6);
    glVertex2d(253.8,755.6);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(153,111,95);
    glVertex2d(443.82,472.51);
    glVertex2d(443.82,658.17);
    glVertex2d(532.99,652.38);
    glVertex2d(532.99,487.04);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(166,93,76);
    glVertex2d(253.8,496.96);
    glVertex2d(253.8,506.29);
    glVertex2d(444.18,472.51);
    glVertex2d(444.18,463.18);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(107,58,43);
    glVertex2d(444.18,463.18);
    glVertex2d(444.18,472.51);
    glVertex2d(532.99,494.24);
    glVertex2d(532.99,487.04);
glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(221,191,180);
    glVertex2d(431.42,667.02);
    glVertex2d(661.01,653.68);
    glVertex2d(661.01,755.6);
    glVertex2d(431.42,755.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,153,142);
    glVertex2d(661.01,653.68);
    glVertex2d(676.01,653.44);
    glVertex2d(676.01,755.6);
    glVertex2d(661.01,755.6);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(221,191,180);
    glVertex2d(778.64,643.64);
    glVertex2d(778.64,755.6);
    glVertex2d(995.71,755.6);
    glVertex2d(995.71,631.12);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,153,142);
    glVertex2d(995.71,631.12);
    glVertex2d(995.71,755.6);
    glVertex2d(1040,755.6);
    glVertex2d(1040,641.16);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(170,92,72);
    glVertex2d(777.46,633.84);
    glVertex2d(777.46,643.64);
    glVertex2d(995.71,631.12);
    glVertex2d(995.71,620.14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(131,73,59);
    glVertex2d(661.13,644.23);
    glVertex2d(661.01,653.68);
    glVertex2d(676.01,653.44);
    glVertex2d(676.25,644.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(131,73,59);
    glVertex2d(995.71,620.14);
    glVertex2d(995.71,631.12);
    glVertex2d(1040,641.16);
    glVertex2d(1040.35,629.59);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(195,139,124);
    glVertex2d(453.15,516.8);
    glVertex2d(453.15,578.33);
    glVertex2d(994.06,512.31);
    glVertex2d(994.06,425.03);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(162,116,103);
    glVertex2d(994.06,425.03);
    glVertex2d(994.06,512.31);
    glVertex2d(1146.53,572.07);
    glVertex2d(1146.53,508.77);
    glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(113,80,71);
    glVertex2d(453.15,578.33);
    glVertex2d(521.77,593.45);
    glVertex2d(896.98,551.52);
    glVertex2d(994.06,512.31);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(154,110,99);
    glVertex2d(1040,739.89);
    glVertex2d(1087.12,739.89);
    glVertex2d(1086.41,747.92);
    glVertex2d(1040,747.92);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(154,110,99);
    glVertex2d(1040,747.92);
    glVertex2d(1094.56,747.92);
    glVertex2d(1094.56,755.6);
    glVertex2d(1040,755.6);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(88,76,64);
    glVertex2d(177.98,755.6);
    glVertex2d(177.98,767.41);
    glVertex2d(1346.71,767.41);
    glVertex2d(1346.71,755.6);
glEnd();
}

void pohon() {
glBegin(GL_POLYGON);
    glColor3ub(51,117,75);
    glVertex2d(1303.48,615.41);
    glVertex2d(1279.27,611.87);
    glVertex2d(1228.61,343.66);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(51,117,75);
    glVertex2d(1228.61,343.66);
    glVertex2d(1301.24,700.56);
    glVertex2d(1228.61,714.38);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,133,85);
    glVertex2d(1228.61,341.66);
    glVertex2d(1152.67,615.66);
    glVertex2d(1177.94,613.41);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,133,85);
    glVertex2d(1228.61,341.66);
    glVertex2d(1156.09,693.96);
    glVertex2d(1172.27,708.96);
    glVertex2d(1228.61,712.38);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(51,117,75);
    glVertex2d(1342.22,714.85);
    glVertex2d(1296.28,488.81);
    glVertex2d(1296.28,723.59);
glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(96,84,38);
    glVertex2d(1212.54,708.6);
    glVertex2d(1228.61,708.6);
    glVertex2d(1228.61,750.52);
    glVertex2d(1212.9,750.52);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(77,67,30);
    glVertex2d(1228.61,708.6);
    glVertex2d(1243.6,708.95);
    glVertex2d(1244.08,748.87);
    glVertex2d(1228.61,748.4);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96,84,38);
    glVertex2d(1286.12,719.93);
    glVertex2d(1296.28,719.93);
    glVertex2d(1296.28,746.39);
    glVertex2d(1286.24,746.39);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(77,67,30);
    glVertex2d(1296.28,719.93);
    glVertex2d(1305.73,720.17);
    glVertex2d(1306.08,745.44);
    glVertex2d(1296.28,745.09);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,134,86);
    glVertex2d(1278.21,743.91);
    glVertex2d(1277.62,756.9);
    glVertex2d(1314.35,756.9);
    glVertex2d(1314.35,743.91);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,134,86);
    glVertex2d(1199.2,746.51);
    glVertex2d(1199.2,756);
    glVertex2d(1257.19,756);
    glVertex2d(1257.19,746.51);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,133,85);
    glVertex2d(1296.28,491);
    glVertex2d(1248.09,660.33);
    glVertex2d(1264.15,658.83);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(57,133,85);
    glVertex2d(1296.28,491);
    glVertex2d(1250.34,708.6);
    glVertex2d(1260.49,717.93);
    glVertex2d(1296.28,720);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(51,117,75);
    glVertex2d(1328.28,658.64);
    glVertex2d(1343.64,660.88);
    glVertex2d(1296.28,488.81);
glEnd();


}

void jendela() {

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1051.69,595.93);
    glVertex2d(1051.69,720.76);
    glVertex2d(1086.53,720.76);
    glVertex2d(1086.53,588.96);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(273.4,554.12);
    glVertex2d(298.44,551.4);
    glVertex2d(298.09,731.51);
    glVertex2d(273.4,731.51);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(309.42,549.63);
    glVertex2d(334.46,546.8);
    glVertex2d(334.11,732.22);
    glVertex2d(309.42,732.22);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(715.69,410.63);
    glVertex2d(846.43,383.34);
    glVertex2d(846.19,450.07);
    glVertex2d(715.69,471.57);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(551.41,447.95);
    glVertex2d(661.48,424.92);
    glVertex2d(661.25,481.13);
    glVertex2d(551.41,499.2);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(835,567.34);
    glVertex2d(880.5,563);
    glVertex2d(880.5,626.63);
    glVertex2d(835,630);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(603,592.56);
    glVertex2d(640,589);
    glVertex2d(640,641.23);
    glVertex2d(603,644);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(550,596.56);
    glVertex2d(587,593);
    glVertex2d(587,645.23);
    glVertex2d(550,648);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(607.92,597.11);
    glVertex2d(634.49,594.74);
    glVertex2d(634.49,641.63);
    glVertex2d(607.92,643.01);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(554.92,601.11);
    glVertex2d(581.49,598.74);
    glVertex2d(581.49,645.63);
    glVertex2d(554.92,647.01);
glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(721.48,414.64);
    glVertex2d(773.33,404.72);
    glVertex2d(773.33,464.12);
    glVertex2d(721.48,470.5);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(778.64,403.89);
    glVertex2d(778.64,461.53);
    glVertex2d(841.23,450.9);
    glVertex2d(841.23,390.9);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(556.37,451.25);
    glVertex2d(599.95,442.87);
    glVertex2d(599.95,491.17);
    glVertex2d(556.37,498.26);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(604.44,442.16);
    glVertex2d(604.44,490.7);
    glVertex2d(657.11,481.84);
    glVertex2d(657.11,431.29);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(1055.47,598.17);
    glVertex2d(1082.75,594.39);
    glVertex2d(1082.75,716.15);
    glVertex2d(1055.47,716.15);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(277.18,557.43);
    glVertex2d(294.66,555.54);
    glVertex2d(294.31,727.73);
    glVertex2d(277.18,727.73);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(313.2,553.06);
    glVertex2d(330.68,551.05);
    glVertex2d(330.33,728.32);
    glVertex2d(313.2,728.32);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(148,196,234);
    glVertex2d(841.05,572.88);
    glVertex2d(873.73,569.99);
    glVertex2d(873.73,627.11);
    glVertex2d(841.05,628.79);
glEnd();

}

void pagar(){


glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(476.18,583.05);
    glVertex2d(484.69,583.05);
    glVertex2d(483.98,659.58);
    glVertex2d(476.18,660.17);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(490,582.58);
    glVertex2d(497.8,582.58);
    glVertex2d(497.8,658.05);
    glVertex2d(490,658.64);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(504.17,580.34);
    glVertex2d(512.68,580.34);
    glVertex2d(511.97,657.22);
    glVertex2d(504.17,657.81);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(518.82,578.92);
    glVertex2d(527.2,578.92);
    glVertex2d(526.49,655.69);
    glVertex2d(518.82,656.28);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(533.82,577.5);
    glVertex2d(542.2,577.5);
    glVertex2d(541.49,654.86);
    glVertex2d(533.82,655.57);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(547.99,576.2);
    glVertex2d(556.37,576.2);
    glVertex2d(555.67,652.85);
    glVertex2d(547.99,653.59);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(563.34,574.79);
    glVertex2d(571.73,574.79);
    glVertex2d(571.02,652.85);
    glVertex2d(563.34,653.56);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(579.05,573.25);
    glVertex2d(587.43,573.25);
    glVertex2d(586.73,650.96);
    glVertex2d(579.05,651.55);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(593.93,571.95);
    glVertex2d(602.43,571.95);
    glVertex2d(601.73,649.78);
    glVertex2d(593.93,650.37);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(610.82,570.3);
    glVertex2d(619.32,570.3);
    glVertex2d(618.61,649.78);
    glVertex2d(610.82,650.37);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(628.18,568.76);
    glVertex2d(636.57,568.76);
    glVertex2d(635.86,649.66);
    glVertex2d(628.18,650.37);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(147,123,119);
    glVertex2d(643.89,567.23);
    glVertex2d(652.27,567.23);
    glVertex2d(651.56,645.77);
    glVertex2d(643.89,646.47);
glEnd();

        glBegin(GL_POLYGON);
    glColor3ub(170,92,72);
    glVertex2d(431.42,658.99);
    glVertex2d(431.42,667.02);
    glVertex2d(661.01,653.68);
    glVertex2d(661.13,644.23);
    glEnd();
}


void pintu() {
glBegin(GL_POLYGON);
    glColor3ub(155,119,105);
    glVertex2d(966.69,583.32);
    glVertex2d(966.69,621.97);
    glVertex2d(932,623.92);
    glVertex2d(932,575);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(937.83,581.36);
    glVertex2d(966.69,588.21);
    glVertex2d(966.69,621.97);
    glVertex2d(937.83,623.92);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(124,165,195);
    glVertex2d(947,597.75);
    glVertex2d(961,600.2);
    glVertex2d(961,622);
    glVertex2d(947,623);
glEnd();




}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1366, 768, "Tugas Nama - <G64160001>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

     while (!glfwWindowShouldClose(window))
    {

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

        setup_viewport(window);

        display();
        dinding();
        pohon();
        jendela();
        pagar();
        pintu();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    exit(EXIT_SUCCESS);
}

