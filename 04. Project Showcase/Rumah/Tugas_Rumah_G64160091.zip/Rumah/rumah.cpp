#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void error_callback(int error, const char* description){
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods){
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}
void langit(){
    glColor3ub(35,181,226);
    glBegin(GL_POLYGON);
        glVertex2f(0, 0);
        glVertex2f(600, 0);
        glVertex2f(600, 416);
        glVertex2f(0, 416);
    glEnd();
}
void rumput(){
    glColor3ub(171,208,62);
    glBegin(GL_POLYGON);
        glVertex2f(92.5, 254.5);
        glVertex2f(0, 306.5);
        glVertex2f(0, 416);
        glVertex2f(600, 416);
        glVertex2f(600, 291.5);
        glVertex2f(512.5, 258.5);
    glEnd();
}
void tembok_coklat1(){
    glColor3ub(244,234,217);
    glBegin(GL_POLYGON);
        glVertex2f(92.5, 168.5);
        glVertex2f(92.5, 243.5);
        glVertex2f(302.5, 348.5);
        glVertex2f(302.5, 260.08);
        glVertex2f(197.57, 113.61);
    glEnd();
}
void tembok_coklat2(){
    glColor3ub(235,222,198);
    glBegin(GL_POLYGON);
        glVertex2f(302.5, 348.5);
        glVertex2f(302.5, 260.08);
        glVertex2f(511.5, 183.9);
        glVertex2f(511.5, 245.5);
    glEnd();
}
void tembok_abu(){
    glColor3ub(109,110,112);
    glBegin(GL_POLYGON);
        glVertex2f(92.5, 243.5);
        glVertex2f(92.5, 267.5);
        glVertex2f(302.5, 374.5);
        glVertex2f(302.5, 348.5);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(302.5, 374.5);
        glVertex2f(302.5, 348.5);
        glVertex2f(511.5, 245.5);
        glVertex2f(511.5, 267.5);
    glEnd();
}
void kusen_pintu(){
    glColor3ub(165,88,65);
    glBegin(GL_POLYGON);
        glVertex2f(168.5, 208.5);
        glVertex2f(208.5, 226.5);
        glVertex2f(208.5, 326.5);
        glVertex2f(168.5, 306.5);
    glEnd();
}
void hiasan_pintu(int xtr, int ytr){
    glColor3ub(255,204,3);
    glBegin(GL_POLYGON);
        glVertex2f(175.5+xtr, 219.5+ytr);
        glVertex2f(186.5+xtr, 224.5+ytr);
        glVertex2f(186.5+xtr, 247.5+ytr);
        glVertex2f(175.5+xtr, 242.5+ytr);
    glEnd();
}
void jendela1(int xtr, int ytr){
    glColor3ub(190, 102, 61);
    glBegin(GL_POLYGON);
        glVertex2f(103.5+xtr, 183.5+ytr);
        glVertex2f(151.5+xtr, 205.5+ytr);
        glVertex2f(151.5+xtr, 250.5+ytr);
        glVertex2f(103.5+xtr, 227.5+ytr);
    glEnd();

    glColor3ub(199,234,251);
    glBegin(GL_POLYGON);
        glVertex2f(106.5+xtr, 187.5+ytr);
        glVertex2f(148.5+xtr, 207.5+ytr);
        glVertex2f(148.5+xtr, 246.5+ytr);
        glVertex2f(106.5+xtr, 226.54+ytr);
    glEnd();
}
void jendela2(int xtr, int ytr){
    glColor3ub(190, 102, 61);
    glBegin(GL_POLYGON);
        glVertex2f(333.5+xtr, 262.5+ytr);
        glVertex2f(381.5+xtr, 240.5+ytr);
        glVertex2f(381.5+xtr, 284.5+ytr);
        glVertex2f(333.5+xtr, 307.5+ytr);
    glEnd();

    glColor3ub(199,234,251);
    glBegin(GL_POLYGON);
        glVertex2f(337.5+xtr, 263.5+ytr);
        glVertex2f(379.5+xtr, 243.5+ytr);
        glVertex2f(379.5+xtr, 282.54+ytr);
        glVertex2f(337.5+xtr, 302.5+ytr);
    glEnd();
}
void bayangan(){
    glColor3ub(210,183,137);
    glBegin(GL_POLYGON);
        glVertex2f(92.5, 168.5);
        glVertex2f(197.5, 113.5);
        glVertex2f(187.5, 99.5);
        glVertex2f(92.5, 152.5);
    glEnd();
}
void genteng_dalam(){
    glColor3ub(166, 51, 47);
    glBegin(GL_POLYGON);
        glVertex2f(64.5, 153.5);
        glVertex2f(92.5, 152.5);
        glVertex2f(187.5, 99.5);
        glVertex2f(181.5, 82.5);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(187.5, 99.5);
        glVertex2f(314.5, 276.5);
        glVertex2f(181.5, 82.5);
    glEnd();
}
void genteng_luar(){
    glColor3ub(212, 60, 45);
    glBegin(GL_POLYGON);
        glVertex2f(314.5, 276.5);
        glVertex2f(181.5, 82.5);
        glVertex2f(392.5, 22.5);
        glVertex2f(531.5, 174.5);
    glEnd();
}
void display(){
    langit();
    rumput();
    tembok_coklat1();
    tembok_coklat2();
    tembok_abu();
    kusen_pintu();
    hiasan_pintu(0, 0);
    hiasan_pintu(0, 28);
    hiasan_pintu(0, 56);
    hiasan_pintu(14, 7);
    hiasan_pintu(14, 35);
    hiasan_pintu(14, 64);
    jendela1(0, 0);
    jendela1(122, 53);
    jendela2(0, 0);
    jendela2(107, -50);
    bayangan();
    genteng_dalam();
    genteng_luar();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) exit(EXIT_FAILURE);
    window = glfwCreateWindow(600, 416, "G64160091_RUMAH", NULL, NULL);
    if (!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window)){
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, 600, 416, 0, -4, 4);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        //Rumah
        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

