#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#define maroon1 83, 71, 65
#define maroon2 99, 85, 79
#define maroon3 117, 100, 94

float DETIK = 0.25;
float DETIK2 = 0.0;
float go =0.0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your code here, maybe
    glClear(GL_COLOR_BUFFER_BIT);

    // Background
    glColor3ub(226, 200, 181);
    glBegin(GL_POLYGON);
    glVertex2d(0, 0);
    glVertex2d(0, 800);
    glVertex2d(800, 800);
    glVertex2d(800, 0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(115,83,30);
    glVertex2d(372.23,340.55);
    glVertex2d(371.47,606.58);
    glVertex2d(535.37,701.2);
    glVertex2d(536.12,435.17);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(115,83,30);
    glVertex2d(536.12,435.17);
    glVertex2d(535.37,701.2);
    glVertex2d(698.2,606.58);
    glVertex2d(698.95,340.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,82,17);
    glVertex2d(210.15,247.18);
    glVertex2d(209.42,504.49);
    glVertex2d(373.31,599.12);
    glVertex2d(374.04,341.81);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(233,218,163);
    glVertex2d(372.97,152.56);
    glVertex2d(210.15,247.18);
    glVertex2d(536.12,435.17);
    glVertex2d(698.95,340.55);
    glEnd();
//Pintu
    glBegin(GL_POLYGON);
    glColor3ub(7,41,48);
    glVertex2d(222.71,398.68);
    glVertex2d(222.39,512.04);
    glVertex2d(292.56,552.55);
    glVertex2d(292.88,439.2);
    glEnd();
//Frame Jendela
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(384.39,367.1);
    glVertex2d(384.07,480.45);
    glVertex2d(525.04,561.84);
    glVertex2d(525.37,448.49);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(550.29,446.17);
    glVertex2d(550.61,559.52);
    glVertex2d(685.42,481.69);
    glVertex2d(685.1,368.34);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(561.12,595.83);
    glVertex2d(561.29,657.76);
    glVertex2d(687.42,584.94);
    glVertex2d(687.24,523.01);
    glEnd();
//Jendela
    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(386.66,371.05);
    glVertex2d(386.36,479.14);
    glVertex2d(522.77,557.9);
    glVertex2d(523.06,449.81);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(552.58,447.49);
    glVertex2d(552.89,555.58);
    glVertex2d(683.14,480.38);
    glVertex2d(685.1,368.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(563.4,597.14);
    glVertex2d(563.56,653.81);
    glVertex2d(685.14,583.62);
    glVertex2d(684.97,526.95);
    glEnd();
//tembok
    glBegin(GL_POLYGON);
    glColor3ub(77,48,4);
    glVertex2d(371.45,484.64);
    glVertex2d(261.43,548.57);
    glVertex2d(425.32,643.2);
    glVertex2d(535.34,579.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(154,102,29);
    glVertex2d(261.43,548.57);
    glVertex2d(261.09,669);
    glVertex2d(424.98,763.63);
    glVertex2d(425.32,643.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(154,102,29);
    glVertex2d(425.32,643.2);
    glVertex2d(424.98,763.63);
    glVertex2d(535,699.69);
    glVertex2d(535.34,579.26);
    glEnd();
//atap
    glBegin(GL_POLYGON);
    glColor3ub(115,83,30);
    glVertex2d(215.05,248.77);
    glVertex2d(106.03,312.71);
    glVertex2d(425.88,497.37);
    glVertex2d(535.9,433.44);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(233,218,163);
    glVertex2d(106.03,312.71);
    glVertex2d(105.96,338.7);
    glVertex2d(425.8,523.36);
    glVertex2d(425.88,497.37);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(233,218,163);
    glVertex2d(425.88,497.37);
    glVertex2d(425.8,523.36);
    glVertex2d(535.82,459.43);
    glVertex2d(535.9,433.44);
    glEnd();

    //RUMAH ATAS
//tembok
    glBegin(GL_POLYGON);
    glColor3ub(248,244,232);
    glVertex2d(185.21,129.55);
    glVertex2d(184.61,340.8);
    glVertex2d(266.04,387.82);
    glVertex2d(266.63,176.56);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(243,237,210);
    glVertex2d(266.63,176.56);
    glVertex2d(266.04,387.82);
    glVertex2d(342.64,344.3);
    glVertex2d(343.24,133.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(248,244,232);
    glVertex2d(343.24,133.04);
    glVertex2d(342.64,344.3);
    glVertex2d(499.35,434.77);
    glVertex2d(499.95,223.52);
    glEnd();
//atap
    glBegin(GL_POLYGON);
    glColor3ub(174,118,36);
    glVertex2d(568.03,159.8);
    glVertex2d(498.78,200.04);
    glVertex2d(580.21,247.06);
    glVertex2d(649.46,206.81);
    glEnd();


//tembok
    glBegin(GL_POLYGON);
    glColor3ub(243,237,210);
    glVertex2d(499.95,223.52);
    glVertex2d(499.35,434.77);
    glVertex2d(580.25,387.76);
    glVertex2d(580.85,176.5);
    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(243,237,210);
    glVertex2d(580.21,247.06);
    glVertex2d(579.81,387.96);
    glVertex2d(649.06,347.72);
    glVertex2d(649.46,206.81);
    glEnd();
//atap

    glBegin(GL_POLYGON);
    glColor3ub(174,118,36);
    glVertex2d(340.89,39.08);
    glVertex2d(185.21,129.55);
    glVertex2d(266.63,176.56);
    glVertex2d(424.14,86.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(174,118,36);
    glVertex2d(424.14,86.03);
    glVertex2d(340.24,133.04);
    glVertex2d(499.95,223.52);
    glVertex2d(580.85,176.5);
    glEnd();
//frame jendela

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(193.4,139.19);
    glVertex2d(193.16,223.56);
    glVertex2d(266.55,265.94);
    glVertex2d(266.31,181.57);
    glEnd();

      glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(266.31,181.57);
    glVertex2d(266.55,265.94);
    glVertex2d(339.96,223.56);
    glVertex2d(339.72,139.19 );
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(193.4,251.81);
    glVertex2d(193.16,336.18);
    glVertex2d(266.57,378.56);
    glVertex2d(266.81,294.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(427.31,187.48);
    glVertex2d(427.1,260.5);
    glVertex2d(500.15,302.89);
    glVertex2d(499.95,229.87);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(499.95,229.87);
    glVertex2d(500.15,302.89);
    glVertex2d(573.58,260.5);
    glVertex2d(573.37,187.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(421.75,310.11);
    glVertex2d(421.54,383.12);
    glVertex2d(467.81,409.83);
    glVertex2d(468.02,336.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(159,117,47);
    glVertex2d(507.41,327.06);
    glVertex2d(507.67,419.22);
    glVertex2d(642.17,341.57);
    glVertex2d(641.91,249.41);
    glEnd();
//jendela
    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(195.23,142.38);
    glVertex2d(195.01,222.5);
    glVertex2d(264.73,262.75);
    glVertex2d(264.96,182.64);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(268.16,182.64);
    glVertex2d(268.39,262.75);
    glVertex2d(338.11,222.5);
    glVertex2d(337.88,142.38);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(429.14,190.67);
    glVertex2d(428.95,259.43);
    glVertex2d(498.68,299.69);
    glVertex2d(498.88,230.94);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(501.8,230.94);
    glVertex2d(501.99,299.69);
    glVertex2d(571.72,257.98);
    glVertex2d(571.53,190.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(509.26,328.12);
    glVertex2d(509.52,416.03);
    glVertex2d(640.32,340.5);
    glVertex2d(640.07,252.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(423.59,313.3);
    glVertex2d(423.39,382.06);
    glVertex2d(465.97,406.64);
    glVertex2d(466.17,337.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,218,230);
    glVertex2d(195.23,255);
    glVertex2d(195.01,335.12);
    glVertex2d(264.73,374.72);
    glVertex2d(264.96,295.26);
    glEnd();

    glFlush();
    go++;
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);
    window = glfwCreateWindow(800, 800, "Tugas Nama - G64160034_Ghalyatama Ikram Fauzi", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        DETIK = glfwGetTime();
        DETIK2 = sin(DETIK);

        setup_viewport(window);

        display();
        if (go<255) go+=0.5;
        else go=2;


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
