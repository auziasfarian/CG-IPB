#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)   //fungsi kalo pencet esc, akan keluar
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    //ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1920, 1080, 0, 1.f, -1.f);   //batas kiri, kanan, bottom, top, near, far
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    //glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);

}


void display()  {
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void circle(double x, double y, double r){
    double cons=2*3.14/100;
    double pX, pY;
    double posX=x, posY=y;
    int sizee =r;
    glBegin(GL_POLYGON);
    for(int i=0; i<100; i++){
        pX=sin(i*cons)*sizee+ posX;
        pY=cos(i*cons)*sizee+ posY;
        glVertex2f(pX,pY);
    }
    glEnd();
}

void background(){
    glBegin(GL_POLYGON);
        glColor3ub(98, 199, 236);
        glVertex2f(0,0);
        glVertex2f(0,1080);
        glVertex2f(1920,1080);
        glVertex2f(1920,0);
    glEnd();
}

void house(){
    glBegin(GL_POLYGON);
        glColor3ub(65, 139, 189);
        glVertex2f(1078, 878);
        glVertex2f(600, 919);
        glVertex2f(439, 838);
        glVertex2f(421, 839);
        glVertex2f(214, 736);
        glVertex2f(583, 551);
        glVertex2f(707, 540);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(158, 159, 164);
        glVertex2f(707, 693);
        glVertex2f(1078, 878);
        glVertex2f(1078, 490);
        glVertex2f(915, 409);
        glVertex2f(915, 395);
        glVertex2f(707, 290);
    glEnd();


    glBegin(GL_POLYGON);
        glColor3ub(228, 228, 228);
        glVertex2f(1078, 878);
        glVertex2f(1449, 693);
        glVertex2f(1449, 304);
        glVertex2f(1078, 490);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(251, 251, 251);
        glVertex2f(1449, 304);
        glVertex2f(1078, 490);
        glVertex2f(915, 409);
        glVertex2f(1287, 222);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(222, 212, 210);
        glVertex2f(915, 409);
        glVertex2f(915, 395);
        glVertex2f(1287, 210);
        glVertex2f(1287, 222);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(251, 251, 248);
        glVertex2f(915, 395);
        glVertex2f(1287, 210);
        glVertex2f(1078, 104);
        glVertex2f(708, 290);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(228, 228, 228);
        glVertex2f(807, 649);
        glVertex2f(807, 573);
        glVertex2f(1054, 697);
        glVertex2f(1054, 773);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(200, 202, 220);
        glVertex2f(911, 700);
        glVertex2f(911, 625);
        glVertex2f(963, 650);
        glVertex2f(963, 674);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(251, 251, 248);
        glVertex2f(911, 700);
        glVertex2f(963, 726);
        glVertex2f(963, 674);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(251, 251, 248);
        glVertex2f(731, 686);
        glVertex2f(807, 648);
        glVertex2f(1054, 772);
        glVertex2f(1054, 847);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(238, 238, 238);
        glVertex2f(731, 686);
        glVertex2f(731, 535);
        glVertex2f(807, 573);
        glVertex2f(807, 648);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(90, 97, 136);
        glVertex2f(739, 617);
        glVertex2f(747, 621);
        glVertex2f(747, 605);
        glVertex2f(739, 567);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(129, 131, 143);
        glVertex2f(747, 621);
        glVertex2f(807, 591);
        glVertex2f(807, 573);
        glVertex2f(747, 605);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(119, 121, 133);
        glVertex2f(739, 567);
        glVertex2f(767, 553);
        glVertex2f(807, 573);
        glVertex2f(747, 605);
    glEnd();
//73,35
    int j=418;
    for(int i=736; i<=1050; i=i+73){
        glBegin(GL_POLYGON);
            glColor3ub(255, 255, 255);
            glVertex2f(i, j);
            glVertex2f(i+30, j+15);
            glVertex2f(i+30, j-18);
            glVertex2f(i, j-32);
        glEnd();
        j=j+35;
    }

    glBegin(GL_POLYGON);
        glColor3ub(119, 121, 134);
        glVertex2f(1151, 744);
        glVertex2f(1245, 700);
        glVertex2f(1245, 606);
        glVertex2f(1151, 655);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(222, 222, 223);
        glVertex2f(1235, 692);
        glVertex2f(1245, 700);
        glVertex2f(1151, 744);
        glVertex2f(1151, 735);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(129, 130, 139);
        glVertex2f(1235, 692);
        glVertex2f(1245, 700);
        glVertex2f(1245, 606);
        glVertex2f(1235, 613);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(242, 244, 255);
        glVertex2f(1152, 657);
        glVertex2f(1221, 621);
        glVertex2f(1221, 685);
        glVertex2f(1152, 721);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(142, 142, 144);
        glVertex2f(1319, 758);
        glVertex2f(1324, 761);
        glVertex2f(1324, 565);
        glVertex2f(1319, 562);
    glEnd();
//564, 567
    glBegin(GL_POLYGON);
        glColor3ub(255, 255, 255);
        glVertex2f(1324, 761);
        glVertex2f(1336, 755);
        glVertex2f(1336, 555);
        glVertex2f(1324, 564);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(255, 255, 255);
        glVertex2f(1324, 566);
        glVertex2f(1324, 576);
        glVertex2f(1421, 526);
        glVertex2f(1421, 517);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(255, 255, 255);
        glVertex2f(1412, 527);
        glVertex2f(1421, 522);
        glVertex2f(1421, 713);
        glVertex2f(1412, 717);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(142, 143, 145);
        glVertex2f(1421, 516);
        glVertex2f(1413, 513);
        glVertex2f(1319, 562);
        glVertex2f(1324, 565);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(142, 143, 145);
        glVertex2f(1412, 717);
        glVertex2f(1337, 679);
        glVertex2f(1337, 568);
        glVertex2f(1412, 531);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(98, 199, 236);
        glVertex2f(1336, 755);
        glVertex2f(1412, 717);
        glVertex2f(1337, 679);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(98, 199, 236);
        glVertex2f(1336, 755);
        glVertex2f(1412, 717);
        glVertex2f(1337, 679);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1920, 1080, "G64150093_M.Ghifari Haekal", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        background();
        house();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
