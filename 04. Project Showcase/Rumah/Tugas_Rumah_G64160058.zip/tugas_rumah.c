#include <C:/Program Files (x86)/CodeBlocks/MinGW/include/GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}

//untuk menerima input dari user dan apa yang harus dilakukan
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
        //akan close ketika tombol ESC di-press
}

void setup_viewport(GLFWwindow* window)
{
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width/(float)height;
    glViewport(0,0,width,height);

    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 0, 800, -1.f, 1.f);
    //kiri,kanan,bawah,atas,depan,belakang
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{

    //glClear(GL_COLOR_BUFFER_BIT);
    //grid(800,800);
    //glFlush();
}

void background()
{
    glBegin(GL_POLYGON);
    glColor3ub(133,193,233);
    glVertex2d(800,800);
    glVertex2d(800,0);
    glVertex2d(0,0);
    glVertex2d(0,800);
    glEnd();
}

void jalanan()
{
    glBegin(GL_POLYGON);
    glColor3ub(50,50,47);
    glVertex2d(800,200);
    glVertex2d(800,0);
    glVertex2d(0,0);
    glVertex2d(0,200);
    glEnd();
}

void bangunan()
{
    int a,i,j=0;

    //bangunan 4
    glBegin(GL_POLYGON);
    glColor3ub(178,34,34);
    glVertex2d(280,524);
    glVertex2d(280,309);
    glVertex2d(130,309);
    glVertex2d(130,479);
    glEnd();

    //jendela bangunan 4
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(226,425);
    glVertex2d(226,341);
    glVertex2d(154,341);
    glVertex2d(154,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(220,419);
    glVertex2d(220,347);
    glVertex2d(160,347);
    glVertex2d(160,419);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(193,425);
    glVertex2d(193,341);
    glVertex2d(187,341);
    glVertex2d(187,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(226,378);
    glVertex2d(226,385);
    glVertex2d(154,385);
    glVertex2d(154,378);
    glEnd();


    //bangunan 1
    glBegin(GL_POLYGON);
    glColor3ub(165,42,42);
    glVertex2d(683,446);
    glVertex2d(683,309);
    glVertex2d(473,309);
    glVertex2d(473,446);
    glEnd();

    //yang di atas bangunan 1
    glBegin(GL_POLYGON);
    glColor3ub(139,69,19);
    glVertex2d(695,477);
    glVertex2d(695,468);
    glVertex2d(478,468);
    glVertex2d(478,477);
    glEnd();

    //for(int b=0;b<3;b++)
    //{
    glBegin(GL_POLYGON);
    glColor3ub(139,69,19);
    glVertex2d(547+a,468);
    glVertex2d(547+a,430);
    glVertex2d(539+a,430);
    glVertex2d(539+a,468);
    glEnd();
    //a+=50;
    //}

      glBegin(GL_POLYGON);
    glColor3ub(139,69,19);
    glVertex2d(547+50,468);
    glVertex2d(547+50,430);
    glVertex2d(539+50,430);
    glVertex2d(539+50,468);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(139,69,19);
    glVertex2d(547+100,468);
    glVertex2d(547+100,430);
    glVertex2d(539+100,430);
    glVertex2d(539+100,468);
    glEnd();

    //jendela bangunan 1
    glBegin(GL_POLYGON);
    glColor3ub(165,255,255);
    glVertex2d(631,412);
    glVertex2d(631,326);
    glVertex2d(523,326);
    glVertex2d(523,412);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,255);
    glVertex2d(625,407);
    glVertex2d(625,332);
    glVertex2d(529,332);
    glVertex2d(529,407);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,255,255);
    glVertex2d(582,412);
    glVertex2d(582,326);
    glVertex2d(575,326);
    glVertex2d(575,412);
    glEnd();

    //bangunan 2
	glBegin(GL_POLYGON);
    glColor3ub(244, 244, 66);
    glVertex2d(483,577);
    glVertex2d(483,417);
    glVertex2d(266,417);
    glVertex2d(266,577);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0,0,0);
    glVertex2f(266, 444);
    glVertex2f(483, 444);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,0,0);
    glVertex2d(468,560);
    glVertex2d(468,466);
    glVertex2d(280,466);
    glVertex2d(280,560);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(68, 139, 255);
    glVertex2d(449,546);
    glVertex2d(449,466);
    glVertex2d(298,466);
    glVertex2d(298,546);
    glEnd();

    //bangunan 3
    glBegin(GL_POLYGON);
    glColor3ub(205,175,149);
    glVertex2d(473,415);
    glVertex2d(473,309);
    glVertex2d(280,309);
    glVertex2d(280,415);
    glEnd();

    //jendela bangunan 3
    glBegin(GL_POLYGON);
    glColor3ub(255, 114, 68);
    glVertex2d(437,415);
    glVertex2d(437,309);
    glVertex2d(326,309);
    glVertex2d(326,415);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,42,42);
    glVertex2d(430,408);
    glVertex2d(430,306);
    glVertex2d(333,306);
    glVertex2d(333,408);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(430,408);
    glVertex2d(430,309);
    glVertex2d(333,309);
    glVertex2d(333,408);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 114, 68);
    glVertex2d(385,415);
    glVertex2d(385,309);
    glVertex2d(380,309);
    glVertex2d(380,415);
    glEnd();

    //bangunan 5
    glBegin(GL_POLYGON);
    glColor3ub(205,175,149);
    glVertex2d(480,309);
    glVertex2d(480,150);
    glVertex2d(131,150);
    glVertex2d(131,309);
    glEnd();

    //jendela bangunan 5
    glBegin(GL_POLYGON);
    glColor3ub(165,42,42);
    glVertex2d(260,283);
    glVertex2d(260,190);
    glVertex2d(162,190);
    glVertex2d(162,283);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(255,278);
    glVertex2d(255,195);
    glVertex2d(167,195);
    glVertex2d(167,278);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,42,42);
    glVertex2d(215,283);
    glVertex2d(215,190);
    glVertex2d(208,190);
    glVertex2d(208,283);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165,42,42);
    glVertex2d(260,240);
    glVertex2d(260,233);
    glVertex2d(162,233);
    glVertex2d(162,240);
    glEnd();

    //bangunan 6
    glBegin(GL_POLYGON);
    glColor3ub(255,50,0);
    glVertex2d(700,309);
    glVertex2d(700,150);
    glVertex2d(480,150);
    glVertex2d(480,309);
    glEnd();

    //bagian dari lantai 2
    glBegin(GL_POLYGON);
    glColor3ub(255,222,185);
    glVertex2d(728,354);
    glVertex2d(728,301);
    glVertex2d(502,301);
    glVertex2d(502,354);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(70,130,180);//steel blue
    glVertex2d(502,354);
    glVertex2d(502,301);
    glVertex2d(456,301);
    glVertex2d(456,354);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(70,130,180);//steel blue
    glVertex2d(193,354);
    glVertex2d(193,301);
    glVertex2d(97,301);
    glVertex2d(97,354);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(70,130,180);//steel blue
    glVertex2d(456,309);
    glVertex2d(456,301);
    glVertex2d(193,301);
    glVertex2d(193,309);
    glEnd();

    //yang kayak pagar di lantai 2
    for(i=0;i<12;i++)
    {
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);//steel blue
    glVertex2d(209+j,350);
    glVertex2d(209+j,309);
    glVertex2d(202+j,309);
    glVertex2d(202+j,350);
    glEnd();
    j+=21;
    }

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);//steel blue
    glVertex2d(456,350);
    glVertex2d(456,345);
    glVertex2d(193,345);
    glVertex2d(193,350);
    glEnd();

}

void rumput()
{
    int k;
    float l=155;

    for(k=0;k<7;k++)
    {
            glBegin(GL_POLYGON);
            glColor3ub(48,99,0);
            for (int i=0; i <= 180; i++)
            {
            float rad = i*3.14159/180;
            glVertex2f(l+cos(rad)*20,140+sin(rad)*20);
            }
            glEnd();
            l+=30;
    }

    l+=100;

        for(k=0;k<7;k++)
    {
            glBegin(GL_POLYGON);
            glColor3ub(48,99,0);
            for (int i=0; i <= 180; i++)
            {
            float rad = i*3.14159/180;
            glVertex2f(l+cos(rad)*20,140+sin(rad)*20);
            }
            glEnd();
            l+=30;
    }

}

void jendela_tutup()
{
    //jendela bangunan 6
    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(631,287);
    glVertex2d(631,187);
    glVertex2d(525,187);
    glVertex2d(525,287);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(0,150,255);
    glVertex2d(627,283);
    glVertex2d(627,191);
    glVertex2d(529,191);
    glVertex2d(529,283);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(581,287);
    glVertex2d(581,187);
    glVertex2d(575,187);
    glVertex2d(575,287);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(631,238);
    glVertex2d(631,232);
    glVertex2d(525,232);
    glVertex2d(525,238);
    glEnd();
}

void jendela_buka()
{

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(631,287);
    glVertex2d(631,187);
    glVertex2d(525,187);
    glVertex2d(525,287);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(631,287);
    glVertex2d(631,187);
    glVertex2d(623,193);
    glVertex2d(623,281);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    glVertex2d(533,281);
    glVertex2d(533,193);
    glVertex2d(525,187);
    glVertex2d(525,287);
    glEnd();

}

void pintu_ketutup()
{
    //pintu ketutup
    glBegin(GL_POLYGON);
    glColor3ub(133,94,66);
    glVertex2d(415,277);
    glVertex2d(415,150);
    glVertex2d(356,150);
    glVertex2d(356,277);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(25,25,25);
        for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
      glVertex2f(405+cos(rad)*5,((277+150)/2)+sin(rad)*5);
   }
   glEnd();

}

void pintu_kebuka()
{

    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(415,277);
    glVertex2d(415,150);
    glVertex2d(356,150);
    glVertex2d(356,277);
    glEnd();

    //pintu kebuka
    glBegin(GL_POLYGON);
    glColor3ub(133,94,66);
    glVertex2d(363,270);
    glVertex2d(363,157);
    glVertex2d(356,150);
    glVertex2d(356,277);
    glEnd();
}
/*
void aspal()
{
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(800,100);
    glVertex2d(363,157);
    glVertex2d(356,150);
    glVertex2d(356,277);
    glEnd();
}
*/
void awan_1()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
      glVertex2f(550+cos(rad)*20,700+sin(rad)*20);
   }
      for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(565+cos(rad)*20,715+sin(rad)*20);
   }
        for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(550+cos(rad)*20,715+sin(rad)*20);
   }
         for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(580+cos(rad)*20,720+sin(rad)*20);
   }
          for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(580+cos(rad)*20,710+sin(rad)*20);
   }
           for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(535+cos(rad)*20,710+sin(rad)*20);
   }
        for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(600+cos(rad)*20,710+sin(rad)*20);
   }
    glEnd();
}

void awan_2()
{
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
      //glVertex2f(610+cos(rad)*83.6,347+sin(rad)*83.6);
      glVertex2f(150+cos(rad)*20,700+sin(rad)*20);
   }
      for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(165+cos(rad)*20,715+sin(rad)*20);
   }
        for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(150+cos(rad)*20,715+sin(rad)*20);
   }
         for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(180+cos(rad)*20,720+sin(rad)*20);
   }
          for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(180+cos(rad)*20,710+sin(rad)*20);
   }
           for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(135+cos(rad)*20,710+sin(rad)*20);
   }
        for (int i=0; i <= 360; i++)
   {
      float rad = i*3.14159/180;
       glVertex2f(200+cos(rad)*20,710+sin(rad)*20);
   }

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "TUGAS GRAFKOM RUMAH", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        int stateOpen = glfwGetKey(window, GLFW_KEY_O);

        background();
        jalanan();
        bangunan();
        awan_1();
        awan_2();
        rumput();

        if(stateOpen == GLFW_PRESS)
            {
            pintu_kebuka();
            jendela_buka();
            }
        else
            {
            pintu_ketutup();
            jendela_tutup();
            }



        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
