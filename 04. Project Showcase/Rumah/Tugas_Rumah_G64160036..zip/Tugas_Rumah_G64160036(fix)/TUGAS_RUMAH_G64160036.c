#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1400, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
glClear(GL_COLOR_BUFFER_BIT);
    glFlush();

//LANGIT//
glBegin(GL_POLYGON);
    glColor3ub(142,123,255);    glVertex2f(0,100);
    glColor3ub(213,160,216);    glVertex2f(1400,400);//4
    glColor3ub(243,176,255);    glVertex2f(0,500);
    glColor3ub(255,169,250);    glVertex2f(1400,500);//5
    glColor3ub(197,123,255);    glVertex2f(1400,400);//3
    glColor3ub(164,123,255);    glVertex2f(1400,100);//2
    glColor3ub(113,113,244);     glVertex2f(1400,0);//1
    glColor3ub(111,135,239);     glVertex2f(0,0);//1
glEnd();

//BINTANG
glPushMatrix();

int f;int j;
    glBegin(GL_POINTS);
        glColor3ub(225,225,225);
        glVertex2f(3,45);
        glEnd();
int colorf[3][3]={{225,225,225},{255,224,0},{0,255,255}};

    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);
        glVertex2f(-15+j,13+j);
        glEnd();
    }
int colorff[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(colorff[(clindex+1)%3][0],colorff[(clindex+1)%3][1],colorff[(clindex+1)%3][2]);
        glVertex2f(3+j,6+j);
        glEnd();
    }
int color1f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color1f[(clindex+1)%3][0],color1f[(clindex+1)%3][1],color1f[(clindex+1)%3][2]);
        glVertex2f(35+j,6+j);
        glEnd();
    }
int color2f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color2f[(clindex+1)%3][0],color2f[(clindex+1)%3][1],color2f[(clindex+1)%3][2]);
        glVertex2f(67+j,6+j);
        glEnd();
    }
int color3f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color3f[(clindex+1)%3][0],color3f[(clindex+1)%3][1],color3f[(clindex+1)%3][2]);
        glVertex2f(99+j,6+j);
        glEnd();
    }
int color4f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color4f[(clindex+1)%3][0],color4f[(clindex+1)%3][1],color4f[(clindex+1)%3][2]);
        glVertex2f(10+j,1+j);
        glEnd();
    }
int color5f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color5f[(clindex+1)%3][0],color5f[(clindex+1)%3][1],color5f[(clindex+1)%3][2]);
        glVertex2f(42+j,1+j);
        glEnd();
    }
int color6f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color6f[(clindex+1)%3][0],color6f[(clindex+1)%3][1],color6f[(clindex+1)%3][2]);
        glVertex2f(74+j,1+j);
        glEnd();
    }
int color7f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color7f[(clindex+1)%3][0],color7f[(clindex+1)%3][1],color7f[(clindex+1)%3][2]);
        glVertex2f(106+j,1+j);
        glEnd();
    }
int color8f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color8f[(clindex+1)%3][0],color8f[(clindex+1)%3][1],color8f[(clindex+1)%3][2]);
        glVertex2f(-9+j,6+j);
        glEnd();
    }
int color9f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color9f[(clindex+1)%3][0],color9f[(clindex+1)%3][1],color9f[(clindex+1)%3][2]);
        glVertex2f(23+j,6+j);
        glEnd();
    }
int color0f[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(color0f[(clindex+1)%3][0],color0f[(clindex+1)%3][1],color0f[(clindex+1)%3][2]);
        glVertex2f(55+j,6+j);
        glEnd();
    }
int colorfa[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(colorfa[(clindex+1)%3][0],colorfa[(clindex+1)%3][1],colorfa[(clindex+1)%3][2]);
        glVertex2f(87+j,6+j);
        glEnd();
    }
int colorfs[3][3]={{225,225,225},{255,224,0},{0,255,255}};
    for(f=0, j=-100; f<100; f++, j+=10)
    {
        glBegin(GL_POINTS);
        glColor3ub(colorfs[(clindex+1)%3][0],colorfs[(clindex+1)%3][1],colorfs[(clindex+1)%3][2]);
        glVertex2f(119+j,6+j);
        glEnd();
    }
glPopMatrix();


//RUMPUT//
glBegin(GL_QUADS);
    glColor3ub(105,140,30);     glVertex2f(0,500);
    glColor3ub(107,142,35);     glVertex2f(1400,500);
    glColor3ub(15,140,30);      glVertex2f(1400,641.37);
    glColor3ub(5,107,47);       glVertex2f(0,641.37);
glEnd();

//GAZEBO
//atap
glBegin(GL_POLYGON);
glColor3ub(45,23,2);
    glVertex2d(1231.83,233.45);
    glVertex2d(1340.57,296.66);
    glVertex2d(1123.11,296.66);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(45,23,2);
    glVertex2d(1231.83,252.86);
    glVertex2d(1382.51,340.47);
    glVertex2d(1081.15,340.47);
glEnd();


//coklat mudanya
glBegin(GL_POLYGON);
glColor3ub(162,139,109);
    glVertex2d(1118.08,414.68);
    glVertex2d(1345.58,414.68);
    glVertex2d(1345.58,488.9);
    glVertex2d(1118.08,489.9);
glEnd();

//atasnyaituloh
glLineWidth(5);
    glBegin(GL_LINES); //
    glColor3ub(45,23,2);
    glVertex2f(1118.08,414.68);
    glVertex2f(1345.58,414.68);
glEnd();
glLineWidth(7);
    glBegin(GL_LINES); //
    glColor3ub(45,23,2);
    glVertex2f(1118.08,427.64);
    glVertex2f(1193.92,427.64);
glEnd();
glLineWidth(7);
    glBegin(GL_LINES); //
    glColor3ub(45,23,2);
    glVertex2f(1269.75,427.64);
    glVertex2f(1345.58,427.64);
glEnd();


//dinding maybe
glBegin(GL_POLYGON);
glColor3ub(252,165,102);
    glVertex2d(1118.08,427.64);
    glVertex2d(1193.92,427.64);
    glVertex2d(1193.92,488.9);
    glVertex2d(1118.08,489.9);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(252,165,102);
    glVertex2d(1269.75,427.64);
    glVertex2d(1345.58,427.64);
    glVertex2d(1345.58,488.9);
    glVertex2d(1269.75,489.9);
glEnd();

//pagernya
glPushMatrix();
glLineWidth(5);
glColor3ub(45,23,2);
glBegin(GL_LINES);
    glVertex2f(1136.79,427.64);
    glVertex2f(1136.79,488.9);

    glVertex2f(1156,427.64);
    glVertex2f(1156,488.9);

    glVertex2f(1175.21,427.64);
    glVertex2f(1175.21,488.9);

    glVertex2f(1288.45,427.64);
    glVertex2f(1288.45,488.9);

    glVertex2f(1307.66,427.64);
    glVertex2f(1307.66,488.9);

    glVertex2f(1326.88,427.64);
    glVertex2f(1326.88,488.9);
glEnd();
glPopMatrix();

//tonggak
glPushMatrix();
glLineWidth(7);
glColor3ub(45,23,2);
glBegin(GL_LINES);
    glVertex2f(1118.08,340.72);
    glVertex2f(1118.08,489.9);

    glVertex2f(1193.2,340.47);
    glVertex2f(1193.2,489.9);

    glVertex2f(1269.75,340.47);
    glVertex2f(1269.75,489.9);

    glVertex2f(1345.58,340.47);
    glVertex2f(1345.58,489.9);
glEnd();
glPopMatrix();

//teras
glBegin(GL_POLYGON);
glColor3ub(122,114,105);
    glVertex2d(1102.41,488.9);
    glVertex2d(1361.25,488.9);
    glVertex2d(1361.25,506.67);
    glVertex2d(1102.41,506.67);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(156,150,143);
    glVertex2d(1081.15,506.67);
    glVertex2d(1382.51,506.67);
    glVertex2d(1382.51,520.2);
    glVertex2d(1081.15,520.2);
glEnd();

//DINDING KIRI BAWAH
glBegin(GL_POLYGON);
    glColor3ub(233,230,225);
    glVertex2d(130.27,388.94);
    glVertex2d(501.11,388.94);
    glVertex2d(500.27,609.56);
    glVertex2d(130.96,609.56);
glEnd();

//POHON
glBegin(GL_QUADS);
    glColor3ub(116,73,41);
    glVertex2f(1040.91,529.12);
    glVertex2f(1049.3,529.12);
    glVertex2f(1059.2,625.22);
    glVertex2f(1030.91,625.22);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(1041.49+cos(rad)*50,501.6+sin(rad)*50);
    }
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(1039.49+cos(rad)*50,490.6+sin(rad)*50);
    }
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(977.65+cos(rad)*50,450.22+sin(rad)*50);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(970.65+cos(rad)*50,440.22+sin(rad)*50);
    }
glEnd();

//
glBegin(GL_QUADS);
    glColor3ub(116,73,41);
    glVertex2f(52.96,538.22);
    glVertex2f(61.35,538.22);
    glVertex2f(71.35,622.31);
    glVertex2f(42.96,622.31);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(61.35+cos(rad)*50,513.92+sin(rad)*50);
    }
glEnd();

glBegin(GL_POLYGON);
        glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(55.35+cos(rad)*50,500.92+sin(rad)*50);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(17.36+cos(rad)*40,635.04+sin(rad)*40);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor4ub(89,128,49,150);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(17.36+cos(rad)*40,635.04+sin(rad)*40);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(77.47+cos(rad)*40,619.66+sin(rad)*40);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(144.31+cos(rad)*40,635.04+sin(rad)*40);
    }

glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(211.15+cos(rad)*40,619.66+sin(rad)*40);
    }
glEnd();

//tambahan POhon Bawah
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(144.31+cos(rad)*40,635.04+sin(rad)*40);
    }
    glBegin(GL_POLYGON);
    glColor4ub(89,128,49,100);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(144.31+cos(rad)*40,635.04+sin(rad)*40);
    }
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(211.15+cos(rad)*40,619.66+sin(rad)*40);
    }
glEnd();
//ASPAL
glBegin(GL_QUADS);
    glColor3ub(235,235,235);
    glVertex2f(0,641.37);
    glVertex2f(1400,641.37);
    glColor3ub(200,200,200);
    glVertex2f(1400,800);
    glVertex2f(0,800);
glEnd();
//
glBegin(GL_QUADS);
    glColor3ub(195,195,195);
    glVertex2f(0,630.62);
    glVertex2f(1400,630.62);
    glColor3ub(155,155,155);
    glVertex2f(1400,641.37);
    glVertex2f(0,641.37);
glEnd();

//jalan

glBegin(GL_QUADS);
    glColor3ub(214,185,144);
    glVertex2f(291.64,609.56);
    glVertex2f(438.27,609.56);
    glVertex2f(487,630);
    glColor3ub(240,230,140);
    glVertex2f(244.81,630);
glEnd();

glBegin(GL_QUADS);
    glColor3ub(240,230,140);

    glVertex2f(244.81,630);
            glColor3ub(186,180,184);
    glVertex2f(487,630);

    glColor3ub(204,204,204);
    glVertex2f(487,641.37);
    glVertex2f(244.81,641.37);
glEnd();

//BAGIAN RUMAH//

//RUMAH ATAS//
//DINDING
glBegin(GL_POLYGON);
    glColor3ub(233,230,225);
    glVertex2d(445.96,93.08);
    glVertex2d(986.9,93.08);
    glVertex2d(986.9,369.19);
    glVertex2d(500.27,369.19);
    glVertex2d(445.96,262.3);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(233,230,225);
    glVertex2d(396,338.42);
    glVertex2d(396,262.3);
    glVertex2d(445.96,262.3);
    glVertex2d(500.27,369.19);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(233,230,225);
    glVertex2d(130.96,338.42);
    glVertex2d(396,338.42);
    glVertex2d(501.11,367.49);
    glVertex2d(130.27,367.49);
glEnd();

//ATAP
glBegin(GL_POLYGON);
    glColor3ub(192,188,185);
    glVertex2d(445.96,114.37);
    glVertex2d(986.9,114.37);
    glVertex2d(986.9,135.82);
    glVertex2d(445.96,135.82);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(445.96,93.08);
    glVertex2d(999.14,93.08);
    glVertex2d(999.14,114.37);
    glVertex2d(445.96,114.37);
glEnd();

//DINDING COKLAT
glBegin(GL_POLYGON);
    glColor3ub(97,79,68);
    glVertex2d(276.51,41.2);
    glVertex2d(445.96,41.2);
    glVertex2d(445.96,338.42);
    glVertex2d(276.51,338.41);
glEnd();
//bata
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,42.79);
    glVertex2d(445.96,41.2);
    glVertex2d(445.96,51.94);
    glVertex2d(305.74,51.94);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,61.08);
    glVertex2d(423.73,61.08);
    glVertex2d(423.73,70.23);
    glVertex2d(276.51,70.23);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(321.54,79.37);
    glVertex2d(445.96,79.37);
    glVertex2d(445.96,88.52);
    glVertex2d(321.54,88.52);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(399.66,97.66);
    glVertex2d(445.96,97.66);
    glVertex2d(445.96,106.81);
    glVertex2d(399.66,106.81);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,115.95);
    glVertex2d(445.96,115.95);
    glVertex2d(445.96,125.1);
    glVertex2d(305.74,125.1);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,134.24);
    glVertex2d(423.73,134.24);
    glVertex2d(423.73,143.39);
    glVertex2d(276.51,143.39);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(321.54,152.23);
    glVertex2d(445.96,152.23);
    glVertex2d(445.96,161.68);
    glVertex2d(321.54,161.68);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(399.66,170.82);
    glVertex2d(445.96,170.82);
    glVertex2d(445.96,179.97);
    glVertex2d(399.66,179.97);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,179.97);
    glVertex2d(329.32,179.97);
    glVertex2d(329.32,189.12);
    glVertex2d(276.51,189.12);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,189.11);
    glVertex2d(445.96,189.11);
    glVertex2d(445.96,198.26);
    glVertex2d(305.74,198.26);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,207.53);
    glVertex2d(445.96,207.53);
    glVertex2d(445.96,216.67);
    glVertex2d(305.74,216.67);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,106.81);
    glVertex2d(329.32,106.81);
    glVertex2d(329.32,115.95);
    glVertex2d(276.51,115.95);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,225.82);
    glVertex2d(423.73,225.86);
    glVertex2d(423.73,234.96);
    glVertex2d(276.51,234.96);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(321.54,244.11);
    glVertex2d(445.96,244.11);
    glVertex2d(445.96,253.25);
    glVertex2d(321.54,253.25);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(276.51,271.55);
    glVertex2d(445.96,271.55);
    glVertex2d(445.96,280.69);
    glVertex2d(276.51,280.69);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,280.69);
    glVertex2d(423.73,280.69);
    glVertex2d(423.73,289.84);
    glVertex2d(305.74,289.84);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(305.74,298.98);
    glVertex2d(445.96,298.98);
    glVertex2d(445.96,308.13);
    glVertex2d(305.74,308.13);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(80,66,56);
    glVertex2d(321.54,317.27);
    glVertex2d(445.96,317.27);
    glVertex2d(445.96,326.42);
    glVertex2d(321.54,326.42);
glEnd();
/////
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,51.94);
    glVertex2d(382.25,51.94);
    glVertex2d(382.25,61.08);
    glVertex2d(276.51,61.08);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(354.62,70.23);
    glVertex2d(445.96,70.23);
    glVertex2d(445.96,79.37);
    glVertex2d(354.62,79.37);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,79.37);
    glVertex2d(321.54,79.37);
    glVertex2d(321.54,88.52);
    glVertex2d(276.51,88.52);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(445.96,88.52);
    glVertex2d(441.13,88.52);
    glVertex2d(441.13,97.66);
    glVertex2d(445.96,97.66);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,106.81);
    glVertex2d(445.96,106.81);
    glVertex2d(445.96,115.95);
    glVertex2d(389.72,115.95);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,125.1);
    glVertex2d(329.32,125.1);
    glVertex2d(329.32,134.24);
    glVertex2d(276.51,134.24);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,143.39);
    glVertex2d(445.96,143.39);
    glVertex2d(445.96,152.23);
    glVertex2d(389.72,152.23);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,152.53);
    glVertex2d(321.54,152.53);
    glVertex2d(321.54,161.68);
    glVertex2d(276.51,161.68);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(441.13,161.68);
    glVertex2d(445.96,161.68);
    glVertex2d(445.96,170.82);
    glVertex2d(441.13,170.82);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,106.81);
    glVertex2d(382.25,106.81);
    glVertex2d(382.25,115.95);
    glVertex2d(389.72,115.95);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,106.81);
    glVertex2d(382.25,106.81);
    glVertex2d(382.25,115.95);
    glVertex2d(389.72,115.95);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,178.55);
    glVertex2d(445.96,178.55);
    glVertex2d(445.96,189.11);
    glVertex2d(389.72,189.11);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,198.26);
    glVertex2d(329.32,198.26);
    glVertex2d(329.32,207.53);
    glVertex2d(276.51,207.53);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,216.67);
    glVertex2d(329.32,216.67);
    glVertex2d(329.32,225.82);
    glVertex2d(276.51,225.82);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,244.11);
    glVertex2d(321.54,244.11);
    glVertex2d(321.54,253.25);
    glVertex2d(276.51,253.25);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,234.96);
    glVertex2d(445.96,234.96);
    glVertex2d(445.96,244.11);
    glVertex2d(389.72,244.11);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(441.13,253.25);
    glVertex2d(445.96,253.25);
    glVertex2d(445.96,262.3);
    glVertex2d(441.13,262.3);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(389.72,271.55);
    glVertex2d(445.96,271.55);
    glVertex2d(445.96,280.69);
    glVertex2d(389.72,280.69);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,289.84);
    glVertex2d(382.25,289.84);
    glVertex2d(382.25,298.98);
    glVertex2d(276.51,298.98);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(354.62,308.13);
    glVertex2d(445.96,308.13);
    glVertex2d(445.96,317.27);
    glVertex2d(354.62,317.27);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(121,110,98);
    glVertex2d(276.51,326.42);
    glVertex2d(382.25,326.42);
    glVertex2d(382.25,335.56);
    glVertex2d(276.51,335.56);
glEnd();

//JeNDeLA ATAS
//bingkai
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(496.84,164.37);
    glVertex2d(578.41,164.37);
    glVertex2d(578.41,299.89);
    glVertex2d(496.84,299.89);
glEnd();

//kaca
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(501.55,169.7);
    glVertex2d(573.7,169.7);
    glVertex2d(573.7,295.3);
    glVertex2d(501.55,295.3);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(501.55,281.23);
    glVertex2d(573.7,184.72);
    glVertex2d(573.7,214.78);
    glVertex2d(513.5,295.3);
    glVertex2d(501.55,295.3);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(522.88,295.3);
    glVertex2d(573.7,227.32);
    glVertex2d(573.7,238.4);
    glVertex2d(531.16,295.3);
glEnd();

//bayangan petak
glBegin(GL_POLYGON);
    glColor4ub(226,170,71,200);
    glVertex2d(501.55,169.7);
    glVertex2d(573.7,169.7);
    glVertex2d(573.7,182.72);
    glVertex2d(501.55,182.72);
glEnd();


//JENDELA+PINTU
//bingkai
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(616.93,163.12);
    glVertex2d(921,163.12);
    glVertex2d(921,338.42);
    glVertex2d(616.93,338.42);
glEnd();

//kaca1
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(624.2,169.7);
    glVertex2d(763.82,169.7);
    glVertex2d(763.82,338.42);
    glVertex2d(624.2,338.42);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(624.2,285.65);
    glVertex2d(710.88,169.7);
    glVertex2d(733.35,169.7);
    glVertex2d(624.2,315.7);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(624.2,328.24);
    glVertex2d(742.72,169.7);
    glVertex2d(751.01,169.7);
    glVertex2d(624.2,338.42);
glEnd();

//bayangan petak1
glBegin(GL_POLYGON);
    glColor4ub(226,170,71,200);
    glVertex2d(624.2,169.7);
    glVertex2d(763.82,169.7);
    glVertex2d(763.82,189.3);
    glVertex2d(624.2,189.3);
glEnd();

//ganggang pintu
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(635.97,242.1);
    glVertex2d(642.25,242.1);
    glVertex2d(642.25,295.3);
    glVertex2d(635.97,295.3);
glEnd();

//kaca2
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(772.36,169.7);
    glVertex2d(840.13,169.7);
    glVertex2d(840.13,338.42);
    glVertex2d(772.36,338.42);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(822.81,338.42);
    glVertex2d(840.13,315.25);
    glVertex2d(840.13,285.2);
    glVertex2d(800.34,338.42);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(840.13,327.79);
    glVertex2d(840.13,338.42);
    glVertex2d(832.19,338.42);
glEnd();

//bayangan petak2
glBegin(GL_POLYGON);
    glColor4ub(226,170,71,200);
    glVertex2d(772.36,169.7);
    glVertex2d(840.13,169.7);
    glVertex2d(840.13,189.3);
    glVertex2d(772.36,189.3);
glEnd();

//kaca3
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(848.36,169.7);
    glVertex2d(915.13,169.7);
    glVertex2d(915.13,338.42);
    glVertex2d(848.36,338.42);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(848.36,274.19);
    glVertex2d(915.13,184.88);
    glVertex2d(915.13,214.94);
    glVertex2d(848.36,304.25);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(848.36,316.79);
    glVertex2d(915.13,227.48);
    glVertex2d(915.13,238.56);
    glVertex2d(848.36,327.87);
glEnd();

//bayangan petak3
glBegin(GL_POLYGON);
    glColor4ub(226,170,71,200);
    glVertex2d(848.36,169.7);
    glVertex2d(915.13,169.7);
    glVertex2d(915.13,189.3);
    glVertex2d(848.36,189.3);
glEnd();

//antara
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(621.04,205.77);
    glVertex2d(920.66,205.77);
    glVertex2d(920.66,209.6);
    glVertex2d(621.04,209.6);
glEnd();

//PAGAR1
glBegin(GL_POLYGON);
    glColor3ub(30,5,0);
    glVertex2d(130.96,223.71);
    glVertex2d(137.68,223.71);
    glVertex2d(137.68,338.42);
    glVertex2d(130.96,338.42);
glEnd();

glPushMatrix();
glLineWidth(3);
int n,m;
for(n=227.88; n<331.27; n+=4.24)
{
    glBegin(GL_LINES); //
    glColor3ub(30,5,0);
    glVertex2f(133.17,n);
    glVertex2f(276.51,n);
glEnd();
}
glPopMatrix();

//JENDELA PANJANG
//bingkai
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(329.32,99.18);
    glVertex2d(389.72,99.18);
    glVertex2d(389.72,285.68);
    glVertex2d(329.32,285.68);
glEnd();

//kaca
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(335.6,99.18);
    glVertex2d(389.72,99.18);
    glVertex2d(389.72,279.43);
    glVertex2d(335.6,279.18);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(335.6,197.26);
    glVertex2d(389.72,124.87);
    glVertex2d(389.72,154.93);
    glVertex2d(335.6,227.32);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(335.6,239.86);
    glVertex2d(389.72,167.47);
    glVertex2d(389.72,178.55);
    glVertex2d(335.6,250.40);
glEnd();

//bayangan petak
glBegin(GL_POLYGON);
    glColor4ub(226,170,71,200);
    glVertex2d(335.6,99.18);
    glVertex2d(389.72,99.18);
    glVertex2d(389.72,114.05);
    glVertex2d(335.6,114.05);
glEnd();

/////////////////////////////////////////
//TERAS
/*glBegin(GL_POLYGON);
    glColor3ub(186,180,184);
    glVertex2d(94.69,609.56);
    glVertex2d(1023.17,609.56);
    glVertex2d(1023.17,630.62);
    glVertex2d(94.69,630.62);
glEnd();*/


//DINDING ABU ATASNYA
glBegin(GL_POLYGON);
    glColor3ub(192,188,185);
    glVertex2d(130.27,367.49);
    glVertex2d(501.11,367.49);
    glVertex2d(501.11,388.94);
    glVertex2d(130.27,388.94);
glEnd();

//DINDING KANAN
glBegin(GL_POLYGON);
    glColor3ub(204,204,204);
    glVertex2d(501.11,388.94);
    glVertex2d(986.9,388.94);
    glVertex2d(987.13,609.56);
    glVertex2d(500.27,609.56);
glEnd();

//DINDING ABU ATASNYA
glBegin(GL_POLYGON);
    glColor3ub(170,170,170);
    glVertex2d(501.11,367.49);
    glVertex2d(986.9,367.49);
    glVertex2d(986.9,388.94);
    glVertex2d(501.11,388.94);
glEnd();

//JENDELA BAWAH
//bayangan
glBegin(GL_POLYGON);
    glColor3ub(192,188,185);
    glVertex2d(183.47,443.47);
    glVertex2d(243.81,443.7);
    glVertex2d(243.81,573.69);
    glVertex2d(183.47,573.69);
glEnd();

//bingkai
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(183.76,443.7);
    glVertex2d(239.1,443.7);
    glVertex2d(239.1,573.69);
    glVertex2d(183.76,573.69);
glEnd();

//kaca
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(188.47,449.03);
    glVertex2d(234.39,449.03);
    glVertex2d(234.39,568.39);
    glVertex2d(188.47,568.39);
glEnd();

//bayangan
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(188.47,523.77);
    glVertex2d(234.39,462.34);
    glVertex2d(234.39,492.4);
    glVertex2d(188.47,553.83);
glEnd();
//bayangan2
glBegin(GL_POLYGON);
    glColor3ub(255,192,67);
    glVertex2d(188.47,566.37);
    glVertex2d(234.39,504.94);
    glVertex2d(234.39,516.02);
    glVertex2d(195.26,568.36);
glEnd();


//pembatas1
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(185.49,485.1);
    glVertex2d(239.1,485.1);
    glVertex2d(239.1,488.93);
    glVertex2d(185.49,488.93);
glEnd();
//pembatas2
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(185.49,530.06);
    glVertex2d(239.1,530.06);
    glVertex2d(239.1,533.89);
    glVertex2d(185.49,533.89);
glEnd();

//bayangan petak
glBegin(GL_POLYGON);
    glColor3ub(226,170,71);
    glVertex2d(188.47,449.03);
    glVertex2d(234.39,449.03);
    glVertex2d(234.39,462.06);
    glVertex2d(188.47,462.06);
glEnd();
//PINTU
//bayangan
glBegin(GL_POLYGON);
    glColor3ub(192,188,185);
    glVertex2d(296.65,438.58);
    glVertex2d(443.29,438.58);
    glVertex2d(443.29,609.56);
    glVertex2d(296.65,609.56);
glEnd();

//bingkai
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(290.64,438.58);
    glVertex2d(437.27,438.58);
    glVertex2d(437.27,609.56);
    glVertex2d(290.64,609.56);
glEnd();

//kayu pintu
glBegin(GL_POLYGON);
    glColor3ub(97,79,68);
    glVertex2d(296.65,444.68);
    glVertex2d(431.26,444.68);
    glVertex2d(431.26,609.94);
    glVertex2d(296.65,609.94);
glEnd();

//kaca pintu1
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(333.24,458.26);
    glVertex2d(348.14,458.26);
    glVertex2d(348.14,591.01);
    glVertex2d(333.24,591.01);
glEnd();
//bayangan petak
glBegin(GL_POLYGON);
    glColor3ub(226,170,71);
    glVertex2d(333.24,458.26);
    glVertex2d(348.14,458.26);
    glVertex2d(348.14,470.94);
    glVertex2d(333.24,470.94);
glEnd();

//kaca pintu2
glBegin(GL_POLYGON);
    glColor3ub(224,164,39);
    glVertex2d(379.67,458.26);
    glVertex2d(394.56,458.26);
    glVertex2d(394.56,591.01);
    glVertex2d(379.67,591.01);
glEnd();
//bayangan petak
glBegin(GL_POLYGON);
    glColor3ub(226,170,71);
    glVertex2d(379.67,458.26);
    glVertex2d(394.56,458.26);
    glVertex2d(394.56,470.94);
    glVertex2d(379.67,470.94);
glEnd();

//ganggang pintu
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(352.08,499.06);
    glVertex2d(356.53,499.06);
    glVertex2d(356.53,555.57);
    glVertex2d(352.08,555.57);
glEnd();
//ganggang pintu
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(371.31,499.06);
    glVertex2d(375.76,499.06);
    glVertex2d(375.76,555.57);
    glVertex2d(371.31,555.57);
glEnd();

//batas kayu
glBegin(GL_POLYGON);
    glColor3ub(81,66,57);
    glVertex2d(363.09,444.68);
    glVertex2d(364.82,444.68);
    glVertex2d(364.82,609.94);
    glVertex2d(363.09,609.94);
glEnd();

//GARASI
glBegin(GL_POLYGON);
    glColor3ub(61,58,51);
    glVertex2d(557.95,438.58);
    glVertex2d(929.22,438.58);
    glVertex2d(929.22,609.56);
    glVertex2d(557.95,609.56);
glEnd();

//kayu
glBegin(GL_POLYGON);
    glColor3ub(97,79,68);
    glVertex2d(566.4,444.68);
    glVertex2d(920.77,444.68);
    glVertex2d(921,609.3);
    glVertex2d(566.4,609.3);
glEnd();

glPushMatrix();
glLineWidth(0.5);
int p,q;
for(p=445.68; p<609.3; p+=6)
{
    glBegin(GL_LINES); //
    glColor3ub(30,5,0);
    glVertex2f(566.4,p);
    glVertex2f(921,p);
glEnd();
}
glPopMatrix();

//TANAMAN
//rumput
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(503.8,552.51);
    glVertex2d(505.37,523.2);
    glVertex2d(508.11,552.83);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(507.87,553.6);
    glVertex2d(507.87,522.57);
    glVertex2d(512.98,553.6);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(514.15,552.97);
    glVertex2d(513.14,526.36);
    glVertex2d(516.8,553.6);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(519.7,552.53);
    glVertex2d(521.27,524.64);
    glVertex2d(524.02,552.83);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(525.63,552.51);
    glVertex2d(528.28,526.42);
    glVertex2d(529.85,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(533.23,553.6);
    glVertex2d(533.23,522.57);
    glVertex2d(538.33,553.6);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(539.51,552.97);
    glVertex2d(538.5,526.36);
    glVertex2d(542.16,553.6);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(545.06,552.53);
    glVertex2d(546.63,524.64);
    glVertex2d(549.38,552.83);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(550.43,552.51);
    glVertex2d(552,526.42);
    glVertex2d(554.66,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(553.62,552.51);
    glVertex2d(555.19,529);
    glVertex2d(557.84,552.51);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(500.15,552.51);
    glVertex2d(502.92,529);
    glVertex2d(504.49,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(511.26,552.51);
    glVertex2d(513.91,529);
    glVertex2d(514.49,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(522.45,552.51);
    glVertex2d(525.1,529);
    glVertex2d(526.51,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(536,552.51);
    glVertex2d(539.27,529);
    glVertex2d(542.49,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(547.8,552.51);
    glVertex2d(550.45,529);
    glVertex2d(552.02,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(553.62,552.51);
    glVertex2d(555.19,529);
    glVertex2d(557.84,552.51);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(515.48,552.51);
    glVertex2d(518.13,526.14);
    glVertex2d(519.7,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(529.15,552.51);
    glVertex2d(530.72,523.2);
    glVertex2d(533.47,552.51);
glEnd();

glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(540.84,552.51);
    glVertex2d(543.49,526.14);
    glVertex2d(545.06,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(553.62,552.51);
    glVertex2d(555.19,529);
    glVertex2d(557.7,552.51);
glEnd();
////sisi lainnya
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(942.17,552.51);
    glVertex2d(943.74,526.14);
    glVertex2d(946.39,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(953.76,552.51);
    glVertex2d(956.51,529);
    glVertex2d(958.08,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,211,74);
    glVertex2d(967.53,552.51);
    glVertex2d(969.1,526.14);
    glVertex2d(971.77,552.51);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(935.2,552.51);
    glVertex2d(936.77,529);
    glVertex2d(939.43,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(945.8,552.51);
    glVertex2d(947.96,529);
    glVertex2d(950.61,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(960.56,552.51);
    glVertex2d(962.13,529);
    glVertex2d(964.78,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(972.8,552.51);
    glVertex2d(973.32,529);
    glVertex2d(975.75,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(979.12,552.51);
    glVertex2d(981.86,523.2);
    glVertex2d(983.43,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(115,172,67);
    glVertex2d(982.74,552.51);
    glVertex2d(984.31,529);
    glVertex2d(986.96,552.51);
glEnd();
//
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(929.39,552.51);
    glVertex2d(932.04,529);
    glVertex2d(933.61,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(931.57,552.51);
    glVertex2d(935.23,526.42);
    glVertex2d(936.8,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(937.85,552.51);
    glVertex2d(940.6,524.64);
    glVertex2d(942.17,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(945.07,552.51);
    glVertex2d(948.37,526.36);
    glVertex2d(947.72,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(948.9,552.51);
    glVertex2d(954,522.57);
    glVertex2d(954,553.6);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(553.62,552.51);
    glVertex2d(555.19,529);
    glVertex2d(557.84,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(957.38,552.51);
    glVertex2d(958,526.42);
    glVertex2d(961.6,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(963.21,552.51);
    glVertex2d(965.96,524.64);
    glVertex2d(967.53,552.53);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(970.43,552.51);
    glVertex2d(974.09,526.36);
    glVertex2d(973.08,552.51);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(89,128,49);
    glVertex2d(974.25,552.51);
    glVertex2d(979.35,522.57);
    glVertex2d(979.35,552.51);
glEnd();
//pot
glBegin(GL_POLYGON);
    glColor3ub(123,111,99);
    glVertex2d(500.27,562.25);
    glVertex2d(558.18,562.25);
    glVertex2d(558.18,609.56);
    glVertex2d(500.27,609.56);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(92,85,73);
    glVertex2d(500.27,552.16);
    glVertex2d(558.18,552.16);
    glVertex2d(558.18,562.25);
    glVertex2d(500.27,562.25);
glEnd();

//pot2
glBegin(GL_POLYGON);
    glColor3ub(123,111,99);
    glVertex2d(929.22,562.25);
    glVertex2d(987.13,562.25);
    glVertex2d(987.13,609.56);
    glVertex2d(929.22,609.56);
glEnd();
glBegin(GL_POLYGON);
    glColor3ub(92,85,73);
    glVertex2d(929.22,552.16);
    glVertex2d(987.13,552.16);
    glVertex2d(987.13,562.25);
    glVertex2d(929.22,562.25);
glEnd();

//RUMAH ATAS
//PAGAR KACA//
glBegin(GL_POLYGON);
glColor4ub(68,171,185,45);
    glVertex2d(396,262.3);
    glVertex2d(943.45,262.3);
    glVertex2d(943.45,338.42);
    glVertex2d(396,338.42);
glEnd();

glPushMatrix();
glLineWidth(2.5);
glColor3ub(200,200,200);
glBegin(GL_LINES);
    glVertex2f(396,338.32);glColor3ub(61,58,51);
    glVertex2f(396,262.4);

    glVertex2f(943.45,338.2);glColor3ub(200,200,200);
    glVertex2f(943.45,262.4);

    glVertex2f(487.5,338.2);glColor3ub(61,58,51);
    glVertex2f(487.5,262.4);

    glVertex2f(578.5,338.2);glColor3ub(200,200,200);
    glVertex2f(578.5,262.4);

    glVertex2f(669.75,338.2);glColor3ub(61,58,51);
    glVertex2f(669.75,262.4);

    glVertex2f(761,338.2);glColor3ub(200,200,200);
    glVertex2f(761,262.4);

    glVertex2f(852.25,338.2);glColor3ub(61,58,51);
    glVertex2f(852.25,262.4);
glEnd();
glPopMatrix();

//////pagar jalan
glPushMatrix();
glLineWidth(10);
glColor3ub(76,53,63);
glBegin(GL_LINES);
    glVertex2f(291.64,609.56);
    glVertex2f(244.81,633.82);

    glVertex2f(438.27,609.56);
    glVertex2f(487,633.82);

glEnd();
glPopMatrix();
/*
//oto
//

glBegin(GL_POLYGON);
glColor3ub(125,207,122);
    //
    glVertex2d(849.07,682.81);
    glVertex2d(849.57,688.63);
    glVertex2d(851.48,697.09);
    glVertex2d(851.48,711.25);
    glVertex2d(853.91,716.66);
    glVertex2d(853.91,731.51);
    glVertex2d(860.86,741.36);
    glVertex2d(941.85,741.36);
    glVertex2d(974.62,750.7);
    glVertex2d(1262.48,750.7);
    glVertex2d(1334.74,739.07);
    glVertex2d(1370.63,710.08);
    glVertex2d(1367.59,682.81);
    //
    glVertex2d(1341.71,641.54);
    glVertex2d(1294.45,591.6);
    glVertex2d(1289.82,586.41);
    glVertex2d(1285.35,587.27);
    glVertex2d(1261.56,588.24);
    glVertex2d(1050.81,588.24);
    glVertex2d(1029.85,587.27);
    glVertex2d(1026.25,586.77);
    glVertex2d(1021.83,589.55);
    glVertex2d(1021.43,509.01);
    glVertex2d(980.18,638.4);
    glVertex2d(972.97,642.86);
    glVertex2d(969.43,640.54);
glVertex2d(914.2,646.33);
        glVertex2d(860.8,656.93);
    glVertex2d(849.57,665.1);
glEnd();
//atas abu
glBegin(GL_POLYGON);
glColor4ub(212,212,212,240);
    glVertex2d(1026.25,586.77);
    glVertex2d(1061.47,576.25);
    glVertex2d(1235.39,576.25);
    glVertex2d(1289.82,586.77);
glEnd();
//kaca depan
glBegin(GL_POLYGON);
glColor4ub(84,84,84,252);
    glVertex2d(980.01,638.55);
    glVertex2d(984.39,641.36);
    glVertex2d(988.69,640.77);
    glVertex2d(1028.35,593.52);
    glVertex2d(1027.68,589.75);
    glVertex2d(1021.43,590.01);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(84,84,84,252);
    glVertex2d(1008.14,646.98);
    glVertex2d(1142.23,646.98);
    glVertex2d(1149.87,599.15);
    glVertex2d(1142.23,590.62);
    glVertex2d(1054.34,590.62);
    glVertex2d(1039.06,595.95);
    glVertex2d(1003.8,640.37);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(84,84,84,252);
    glVertex2d(1163.71,646.98);
    glVertex2d(1280.78,646.98);
    glVertex2d(1292.24,637.28);
    glVertex2d(1269.43,599.4);
    glVertex2d(1253.68,590.62);
    glVertex2d(1167.76,590.62);
    glVertex2d(1158.02,597.78);
    glVertex2d(1158.03,642.46);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(84,84,84,252);
    glVertex2d(1294.45,591.6);
    glVertex2d(1338.83,638.6);
    glVertex2d(1341.71,641.54);
    glVertex2d(1334.98,641.54);
    glVertex2d(1320.99,634.23);
    glVertex2d(1293.51,598.69);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(84,84,84,252);
    glVertex2d(856.45,658.36);
    glVertex2d(862.79,654.55);
    glVertex2d(914.2,646.33);
    glVertex2d(969.43,640.54);
    glVertex2d(979.73,644.04);
glEnd();
*/

//lampu
glBegin(GL_POLYGON);
glColor4ub(252,170,0,40);
    glVertex2d(336.56,387.88);
    glVertex2d(385.92,387.88);
    glVertex2d(470.49,610.72);
    glColor4ub(0,0,0,30);
    glVertex2d(248.55,610.72);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(252,252,252,252);
    glVertex2d(1226.84,340.47);
    glVertex2d(1234.81,340.47);
    glVertex2d(1234.81,348.22);
    glVertex2d(1226.84,348.22);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(252,252,252,252);
    glVertex2d(1224.87,348.4);
    glVertex2d(1236.78,348.4);
    glVertex2d(1236.78,352.56);
    glVertex2d(1224.87,352.56);
glEnd();

glBegin(GL_POLYGON);
    glColor4ub(252,170,0,252);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(1230.83+cos(rad)*8,363.06+sin(rad)*8);
    }
glEnd();

glBegin(GL_POLYGON);
glColor4ub(114,64,20,252);
    glVertex2d(1215.51,364.83);
    glVertex2d(1226.84,352.56);
    glVertex2d(1234.81,352.56);
    glColor4ub(0,0,0,252);
    glVertex2d(1246.15,364.83);
glEnd();

glBegin(GL_POLYGON);
glColor4ub(252,170,0,40);
    glVertex2d(1215.69,364.83);
    glVertex2d(1245.85,364.8);
    glVertex2d(1282.58,424.42);
    glColor4ub(0,0,0,30);
    glVertex2d(1179.08,424.53);
glEnd();

//lampu taman
//
glBegin(GL_POLYGON);
glColor3ub(51,51,61);
    glVertex2d(1349.78,707.24);
    glVertex2d(1374.28,707.26);
    glVertex2d(1374.43,770.82);
    glVertex2d(1349.76,770.74);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1349.78,707.24);
    glVertex2d(1357.79,713.87);
    glVertex2d(1357.12,770.69);
    glVertex2d(1349.76,770.74);
glEnd();
glBegin(GL_POLYGON);
glColor4ub(51,51,61,45);
    glVertex2d(1349.76,770.74);
    glVertex2d(1374.43,770.82);
    glColor4ub(51,51,61,45);
    glVertex2d(1394.43,800);
    glVertex2d(1329.76,800);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(51,51,61);
    glVertex2d(1361.37,523.01);
    glVertex2d(1367.37,523.01);
    glVertex2d(1367.37,709.26);
    glVertex2d(1361.37,707.97);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1358.2,523.01);
    glVertex2d(1361.37,525.63);
    glVertex2d(1361.37,709.97);
    glVertex2d(1357.67,707.23);
glEnd();


glBegin(GL_POLYGON);
glColor3ub(78,78,94);
    glVertex2d(1362.86,511.27);
    glVertex2d(1379.21,520.71);
    glVertex2d(1362.86,530.15);
    glVertex2d(1346.52,520.71);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1346.52,520.71);
    glVertex2d(1362.86,530.15);
    glVertex2d(1362.86,533.02);
    glVertex2d(1346.52,523.59);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(51,51,51);
    glVertex2d(1362.86,530.15);
    glVertex2d(1379.21,520.71);
    glVertex2d(1379.21,523.59);
    glVertex2d(1362.86,533.02);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(19,19,23);
    glVertex2d(1348.3,524.6);
    glVertex2d(1362.86,533.02);
    glVertex2d(1362.86,535.57);
    glVertex2d(1348.3,527.16);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(19,19,23);
    glVertex2d(1362.86,533.02);
    glVertex2d(1377.43,523.59);
    glVertex2d(1377.43,527.16);
    glVertex2d(1362.86,535.57);
glEnd();



glBegin(GL_POLYGON);
glColor3ub(78,78,94);
    glVertex2d(1332.16,479.91);
    glVertex2d(1362.86,462.18);
    glVertex2d(1393.57,479.91);
    glVertex2d(1362.86,497.64);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1336.36,479.94);
    glVertex2d(1349.61,464.84);
    glVertex2d(1362.86,472.49);
    glVertex2d(1362.86,495.24);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(51,51,61);
    glVertex2d(1362.86,495.86);
    glVertex2d(1362.86,472.86);
    glVertex2d(1376.11,464.84);
    glVertex2d(1389.36,479.94);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(78,78,94);
    glVertex2d(1349.61,464.84);
    glVertex2d(1362.86,457.19);
    glVertex2d(1376.11,464.84);
    glVertex2d(1362.86,472.49);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1353.54,464.84);
    glVertex2d(1362.86,452.25);
    glVertex2d(1362.86,470.22);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(51,51,61);
    glVertex2d(1362.86,470.22);
    glVertex2d(1362.86,452.25);
    glVertex2d(1372.18,464.84);
glEnd();
//
glBegin(GL_POLYGON);
    glColor4ub(170,179,194,45);
    for (int i=0; i <=360; i++)
    {
        float rad = i*3.14159/180;
        glVertex2f(1380.76+cos(rad)*8,761.47+sin(rad)*8);
    }
glEnd();
glBegin(GL_POLYGON);
glColor3ub(26,26,31);
    glVertex2d(1336.36,482.3);
    glVertex2d(1362.86,497.6);
    glVertex2d(1362.86,528.2);
    glVertex2d(1349.61,520.56);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(51,51,61);
    glVertex2d(1362.86,497.6);
    glVertex2d(1389.36,482.3);
    glVertex2d(1376.11,520.55);
    glVertex2d(1362.86,528.2);
glEnd();
//lamp
glBegin(GL_POLYGON);
glColor3ub(247,148,30);
    glVertex2d(1339.92,487.21);
    glVertex2d(1361.37,499.59);
    glVertex2d(1361.37,524.36);
    glVertex2d(1350.64,518.16);
glEnd();
glBegin(GL_POLYGON);
glColor3ub(251,204,52);
    glVertex2d(1364.47,499.59);
    glVertex2d(1385.92,487.21);
    glVertex2d(1372.2,518.16);
    glVertex2d(1364.47,524.36);
glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1400, 800, "Tugas Rumahnya Salsa (Masih Proses)", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++; buff=buff%100;
        glClearColor (1.0f, 1.0f, 1.0f, 1.0f);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glShadeModel(GL_SMOOTH);

        setup_viewport(window);
        //lingkaran();
        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

