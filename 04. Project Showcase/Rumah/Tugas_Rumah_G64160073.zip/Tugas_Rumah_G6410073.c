#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

static void rightSideWindow(int x, int y) {
    int i;
    //left lid
    glBegin(GL_POLYGON);
    glColor3ub(139,53,38);
    glVertex2f(x,y);
    glVertex2f(x+12,y+6);
    glVertex2f(x+12,y+52);                          //532 451
    glVertex2f(x,y+45);
    glEnd();
    //right lid
    glBegin(GL_POLYGON);
    glColor3ub(139,53,38);
    glVertex2f(x+36,y+21);
    glVertex2f(x+12+36,y+6+21);
    glVertex2f(x+12+36,y+52+21);
    glVertex2f(x+36,y+45+21);
    glEnd();
    //glass
    glBegin(GL_POLYGON);
    glColor3ub(89,109,126);
    glVertex2f(x+12,y+6);
    glVertex2f(x+36,y+21);
    glVertex2f(x+36,y+45+21);
    glVertex2f(x+12,y+52);
    glEnd();
    //horizontal bar
    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+15,y+9);
    glVertex2f(x+34,y+20);
    glVertex2f(x+34,y+21);
    glVertex2f(x+15,y+11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+15,y+20);
    glVertex2f(x+34,y+31);
    glVertex2f(x+34,y+32);
    glVertex2f(x+15,y+22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+15,y+31);
    glVertex2f(x+34,y+42);
    glVertex2f(x+34,y+43);
    glVertex2f(x+15,y+33);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+15,y+42);
    glVertex2f(x+34,y+53);
    glVertex2f(x+34,y+54);
    glVertex2f(x+15,y+44);
    glEnd();
    //vertical bar
    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+24,y+15);
    glVertex2f(x+26,y+16);                               //532 451
    glVertex2f(x+26,y+58);
    glVertex2f(x+24,y+57);
    glEnd();

}

static void leftSideWindow(int x, int y) {
    int i;
    //left lid
    glBegin(GL_POLYGON);
    glColor3ub(139,53,38);
    glVertex2f(x,y);
    glVertex2f(x+12,y-6);
    glVertex2f(x+12,y+40);                          //532 451
    glVertex2f(x,y+45);
    glEnd();
    //right lid
    glBegin(GL_POLYGON);
    glColor3ub(139,53,38);
    glVertex2f(x+36,y-18);
    glVertex2f(x+12+36,y-24);
    glVertex2f(x+12+36,y+21);
    glVertex2f(x+36,y+27);
    glEnd();
    //glass
    glBegin(GL_POLYGON);
    glColor3ub(89,109,126);
    glVertex2f(x+12,y-6);
    glVertex2f(x+36,y-18);
    glVertex2f(x+36,y+27);
    glVertex2f(x+12,y+40);
    glEnd();
    //vertical bar
    glBegin(GL_POLYGON);
    glColor3ub(219,220,228);
    glVertex2f(x+24,y-12);
    glVertex2f(x+26,y-14);                               //532 451
    glVertex2f(x+26,y+35);
    glVertex2f(x+24,y+36);
    glEnd();

}

static void trees(int x, int y) { //528 262
    //trunk
    glBegin(GL_POLYGON);
    glColor3ub(139,53,38);
    glVertex2f(x,y);
    glVertex2f(x-8,y+5);
    glVertex2f(x-8,y-18);
    glVertex2f(x,y-22);
    glVertex2f(x+8,y-18);
    glVertex2f(x+8,y+5);
    glEnd();

    //side light leaves
    glBegin(GL_POLYGON);
    glColor3ub(149,204,136);
    glVertex2f(x,y+88);
    glVertex2f(x+25,y+102);
    glVertex2f(x,y+113);
    glVertex2f(x-25,y+102);
    glVertex2f(x-25 ,y+14);
    glVertex2f(x,y);
    glEnd();

    //dark leaves
    glBegin(GL_POLYGON);
    glColor3ub(78,168,107);
    glVertex2f(x,y);
    glVertex2f(x+25 ,y+14);
    glVertex2f(x+25,y+102);
    glVertex2f(x,y+88);
    glEnd();
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "G64160073", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);


while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 0, 800, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();

//langit
glBegin(GL_POLYGON);
glColor3ub(93,218,227);
glVertex2f(0,0);
glVertex2f(800,0);
glVertex2f(800,800);
glVertex2f(0,800);
glEnd();

//rumput pinggir dasar
glBegin(GL_POLYGON);
glColor3ub(86,133,74);
glVertex2f(392,69);
glVertex2f(4,292);
glVertex2f(4,308);
glVertex2f(392,85);
glVertex2f(796,318);
glVertex2f(796,303);
glEnd();

//tanah
glBegin(GL_POLYGON);
glColor3ub(181,148,111);
glVertex2f(392,69);
glVertex2f(4,292);
glVertex2f(4,-800);
glVertex2f(796,-800);
glVertex2f(796,303);
glEnd();

//rumput dasar
glBegin(GL_POLYGON);
glColor3ub(132,167,113);
glVertex2f(4,308);
glVertex2f(392,85);
glVertex2f(796,318);
glVertex2f(405,542);
glEnd();

//front dirt
glBegin(GL_POLYGON);
glColor3ub(247,220,167);
glVertex2f(122,240);
glVertex2f(271,154);
glVertex2f(441,253);
glVertex2f(291,340);
glEnd();

//front gravel strip
glBegin(GL_POLYGON);
glColor3ub(219,220,228);
glVertex2f(185,211);
glVertex2f(184,205);
glVertex2f(217,186);
glVertex2f(356,265);
glVertex2f(356,269);
glVertex2f(322,288);
glEnd();

//front grass strip
glBegin(GL_POLYGON);
glColor3ub(132,167,113);
glVertex2f(230,203);
glVertex2f(333,262);
glVertex2f(308,276);
glVertex2f(207,218);
glEnd();

//first floor left side wall
glBegin(GL_POLYGON);
glColor3ub(251,176,64);
glVertex2f(288,341);
glVertex2f(443,250);
glVertex2f(443,332);
glVertex2f(288,419);
glEnd();

//first floor right side wall
glBegin(GL_POLYGON);
glColor3ub(246,191,124);
glVertex2f(443,250);
glVertex2f(665,378);
glVertex2f(665,456);
glVertex2f(443,332);
glEnd();

//first floor roof darker
glBegin(GL_POLYGON);
glColor3ub(52,73,94);
glVertex2f(443,385);
glVertex2f(288,472);
glVertex2f(262,443);
glVertex2f(262,434);
glVertex2f(443,332);
glVertex2f(443,339);
glVertex2f(691,478);
glVertex2f(664,507);
glEnd();

//first floor roof lighter
glBegin(GL_POLYGON);
glColor3ub(89,109,126);
glVertex2f(443,332);
glVertex2f(691,470);
glVertex2f(691,478);
glVertex2f(443,341);
glEnd();

//first floor grey door strip
glBegin(GL_POLYGON);
glColor3ub(219,220,228);
glVertex2f(339,311);
glVertex2f(384,285);
glVertex2f(384,290);
glVertex2f(343,314);
glVertex2f(343,380);
glVertex2f(339,381);
glEnd();

//first floor door
glBegin(GL_POLYGON);
glColor3ub(139,53,38);
glVertex2f(343,314);
glVertex2f(384,290);
glVertex2f(384,356);
glVertex2f(343,380);
glEnd();

//second floor left side wall
glBegin(GL_POLYGON);
glColor3ub(251,176,64);
glVertex2f(288,472);
glVertex2f(443,385);
glVertex2f(443,459);
glVertex2f(355,593);
glVertex2f(288,554);
glEnd();

//second floor right side wall
glBegin(GL_POLYGON);
glColor3ub(246,191,124);
glVertex2f(443,385);
glVertex2f(664,507);
glVertex2f(664,582);
glVertex2f(443,459);
glEnd();

//second floor roof
glBegin(GL_POLYGON);
glColor3ub(52,73,94);
glVertex2f(355,593);
glVertex2f(445,456);
glVertex2f(671,586);
glVertex2f(578,731);
glVertex2f(281,557);
glVertex2f(284,552);
glEnd();

//second floor window
rightSideWindow(532, 451);
rightSideWindow(462, 410);
rightSideWindow(601, 490);

//first floor window
rightSideWindow(532, 325);
rightSideWindow(462, 284);
rightSideWindow(601, 364);

//second floor front window
leftSideWindow(337,480);

trees(528,230);
trees(612,279);
trees(685,325);

trees(95,320);
trees(269,255);

glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
