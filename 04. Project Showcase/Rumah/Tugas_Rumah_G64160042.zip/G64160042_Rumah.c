#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1600, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
void Tanah(){
    glBegin(GL_POLYGON);
    glColor3ub(184,234,87);
    glVertex2d(156,479);
    glColor3ub(122,178,15);
    glVertex2d(786,189);
    glVertex2d(1421,497);
    glVertex2d(790,768);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(122,178,15);
    glVertex2d(1421,497);
    glVertex2d(1422,520);
    glColor3ub(140,188,10);
    glVertex2d(787,788);
    glVertex2d(787,762);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140,188,10);
    glVertex2d(787,788);
    glVertex2d(787,762);
    glColor3ub(184,234,87);
    glVertex2d(156,479);
    glVertex2d(156,504);
    glEnd();
//bayangan
    glBegin(GL_POLYGON);
    glColor3ub(107,166,71);
    glVertex2d(1421,497);
    glVertex2d(1422,520);
    glColor3ub(107,175,75);
    glVertex2d(1221.5,605);
    glVertex2d(1221.5,579.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,166,71);
    glVertex2d(1221.5,579.73);
    glVertex2d(1421,497);
    glVertex2d(1090,335.38);
    glVertex2d(1074.98,568.72);
    glEnd();
}

void DasarRumah(){
    glBegin(GL_POLYGON);
    glColor3ub(237,215,204);
    glVertex2d(1102.98,596.96);
    glVertex2d(1366.17,479.45);
    glVertex2d(1089.86,357.25);
    glVertex2d(827.19,474.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224,184,167);
    glVertex2d(1154,575);
    glVertex2d(1366.17,479.45);
    glVertex2d(1220.72,415.11);
    glVertex2d(1074.98,568.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181,143,127);
    glVertex2d(1297.16,510.18);
    glVertex2d(1341.87,490.27);
    glVertex2d(1297.14,470.45);
    glVertex2d(1251.90,490.47);
    glEnd();
}

void Tembok(){
    glBegin(GL_POLYGON);
    glColor3ub(191,213,224);
    glVertex2d(1074.98,568.73);
    glVertex2d(1321.49,459.68);
    glVertex2d(1321.49,353.41);
    glVertex2d(1074.98,462.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,235,242);
    glVertex2d(1074.98,568.73);
    glVertex2d(1074.98,462.45);
    glVertex2d(867.30,368.35);
    glVertex2d(867.30,474.63);
    glEnd();
}

void TembokBawah(){
    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1251.90,490.47);
    glVertex2d(1297.14,470.45);
    glVertex2d(1297.14,405.90);
    glVertex2d(1251.90,426.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1299.24,441.23);
    glVertex2d(1304.95,438.71);
    glVertex2d(1304.95,430.56);
    glVertex2d(1299.24,433.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1098.55,548.80);
    glVertex2d(1239.78,486.33);
    glVertex2d(1239.78,432.13);
    glVertex2d(1098.55,494.60);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,142,135);
    glVertex2d(1098.55,546.79);
    glVertex2d(1237.30,485.41);
    glVertex2d(1237.30,432.13);
    glVertex2d(1098.55,494.60);
    glEnd();
}

void Tiang(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(45,78,101);
    glVertex2d(x+1099.12,y+586.67);
    glVertex2d(x+1102.54,y+588.19);
    glVertex2d(x+1102.54,y+510.20);
    glVertex2d(x+1099.12,y+508.69);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(33,57,74);
    glVertex2d(x+1102.54,y+588.19);
    glVertex2d(x+1102.54,y+510.20);
    glVertex2d(x+1106.13,y+508.61);
    glVertex2d(x+1106.13,y+586.59);
    glEnd();
}

void LantaiDua(){
    glBegin(GL_POLYGON);
    glColor3ub(184,146,129);
    glVertex2d(826.84,383.69);
    glVertex2d(1102.62,506.47);
    glVertex2d(1366.17,389.15);
    glVertex2d(1089.51,266.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(230,182,161);
    glVertex2d(826.84,383.69);
    glVertex2d(1102.62,506.47);
    glVertex2d(1102.62,515.35);
    glVertex2d(826.84,392.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,146,129);
    glVertex2d(826.84,385.26);
    glVertex2d(1102.62,508.04);
    glVertex2d(1102.62,515.35);
    glVertex2d(826.84,392.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(230,182,161);
    glVertex2d(1102.62,506.47);
    glVertex2d(1366.17,389.15);
    glVertex2d(1366.17,398.02);
    glVertex2d(1102.62,515.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,146,129);
    glVertex2d(1102.62,508.04);
    glVertex2d(1366.17,390.72);
    glVertex2d(1366.17,398.02);
    glVertex2d(1102.62,515.35);
    glEnd();
}

void TembokAtas(){
    glBegin(GL_POLYGON);
    glColor3ub(220,235,242);
    glVertex2d(865.36,366.32);
    glVertex2d(865.36,282.31);
    glVertex2d(1063.48,369.95);
    glVertex2d(1063.48,453.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191,213,224);
    glVertex2d(1063.48,369.95);
    glVertex2d(1063.48,453.96);
    glVertex2d(1204.50,391.17);
    glVertex2d(1204.50,307.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,236,242);
    glVertex2d(1063.48,374.54);
    glVertex2d(1063.48,453.96);
    glVertex2d(1204.50,391.17);
    glVertex2d(1204.50,371.12);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,235,242);
    glVertex2d(1204.50,391.17);
    glVertex2d(1204.50,307.15);
    glVertex2d(1243.00,324.18);
    glVertex2d(1243.00,408.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(225,236,242);
    glVertex2d(1243.00,324.18);
    glVertex2d(1243.00,408.19);
    glVertex2d(1325.10,371.64);
    glVertex2d(1325.10,287.63);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191,213,224);
    glVertex2d(1243.00,324.18);
    glVertex2d(1243.00,328.74);
    glVertex2d(1325.10,326.75);
    glVertex2d(1325.10,287.63);
    glEnd();
}

void Garis(int y){
    glBegin(GL_POLYGON);
    glColor3ub(156,173,184);
    glVertex2d(865.36,y+293.81);
    glVertex2d(865.36,y+294.71);
    glVertex2d(1063.48,y+382.35);
    glVertex2d(1063.48,y+381.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,147,154);
    glVertex2d(1063.48,y+382.35);
    glVertex2d(1063.48,y+381.45);
    glVertex2d(1204.50,y+318.66);
    glVertex2d(1204.50,y+319.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,147,154);
    glVertex2d(1204.50,y+318.66);
    glVertex2d(1204.50,y+319.55);
    glVertex2d(1243.00,y+336.58);
    glVertex2d(1243.00,y+335.69);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,147,154);
    glVertex2d(1243.00,y+336.58);
    glVertex2d(1243.00,y+335.69);
    glVertex2d(1325.10,y+299.13);
    glVertex2d(1325.10,y+300.03);
    glEnd();
}

void Kaca(){
    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1143.14,352.16);
    glVertex2d(1188.37,332.01);
    glVertex2d(1188.37,398.56);
    glVertex2d(1143.14,418.71);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(84,80,77);
    glVertex2d(1143.14,352.16);
    glVertex2d(1188.37,332.01);
    glVertex2d(1188.37,371.5);
    glVertex2d(1143.14,373.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1234.20,394.77);
    glVertex2d(1213.30,385.52);
    glVertex2d(1213.30,322.48);
    glVertex2d(1234.20,331.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,142,135);
    glVertex2d(1234.20,331.73);
    glVertex2d(1234.20,393.73);
    glVertex2d(1214.38,384.96);
    glVertex2d(1214.38,322.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(875.74,298.46);
    glVertex2d(875.74,361.42);
    glVertex2d(967.72,402.11);
    glVertex2d(967.72,339.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,142,135);
    glVertex2d(878.33,299.61);
    glVertex2d(878.33,360.55);
    glVertex2d(967.72,400.09);
    glVertex2d(967.72,339.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,169,165);
    glVertex2d(967.72,381.61);
    glVertex2d(967.72,360.96);
    glVertex2d(900.39,309.36);
    glVertex2d(878.33,299.61);
    glVertex2d(878.33,315.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175,169,165);
    glVertex2d(967.72,400.09);
    glVertex2d(967.72,398.87);
    glVertex2d(878.33,335.26);
    glVertex2d(878.33,360.55);
    glEnd();
}

void Atap(){
    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(865.36,271.21);
    glColor3ub(94,91,88);
    glVertex2d(1088.49,171.86);
    glVertex2d(1284,258);
    glVertex2d(1063.48,358.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(94,91,88);
    glVertex2d(1284,258);
    glVertex2d(1200.50,296.06);
    glVertex2d(1243.00,313.09);
    glVertex2d(1325.10,276.53);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,169,156);
    glVertex2d(865.36,271.21);
    glVertex2d(865.36,286.90);
    glVertex2d(1063.48,374.54);
    glVertex2d(1063.48,358.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,169,156);
    glVertex2d(1063.48,374.54);
    glVertex2d(1063.48,358.85);
    glVertex2d(1204.50,294.05);
    glVertex2d(1204.50,308.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,169,156);
    glVertex2d(1204.50,294.05);
    glVertex2d(1204.50,308.74);
    glVertex2d(1243.00,328.78);
    glVertex2d(1243.00,313.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,169,156);
    glVertex2d(1243.00,328.78);
    glVertex2d(1243.00,313.09);
    glVertex2d(1325.10,276.53);
    glVertex2d(1325.10,291.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(865.36,272.11);
    glVertex2d(865.36,286.90);
    glVertex2d(1063.48,374.54);
    glVertex2d(1063.48,359.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(87,82,77);
    glVertex2d(1063.48,374.54);
    glVertex2d(1063.48,359.74);
    glVertex2d(1204.50,294.95);
    glVertex2d(1204.50,308.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1204.50,294.95);
    glVertex2d(1204.50,308.74);
    glVertex2d(1243.00,328.78);
    glVertex2d(1243.00,313.98);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(87,82,77);
    glVertex2d(1243.00,328.78);
    glVertex2d(1243.00,313.98);
    glVertex2d(1325.10,277.42);
    glVertex2d(1325.10,291.22);
    glEnd();
}

void Panel(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(3,42,81);
    glVertex2d(x+1049.76,y+280.05);
    glColor3ub(17,59,94);
    glVertex2d(x+1122.85,y+247.72);
    glVertex2d(x+1139.93,y+272.68);
    glVertex2d(x+1066.85,y+305.01);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(17,59,94);
    glVertex2d(x+1072.31,y+270.08);
    glVertex2d(x+1122.85,y+247.72);
    glVertex2d(x+1139.93,y+272.68);
    glVertex2d(x+1115.91,y+283.31);
    glEnd();
}

void GarisPanel1(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(x+1075.97,y+298.11);
    glVertex2d(x+1076.42,y+297.90);
    glVertex2d(x+1062.35,y+277.35);
    glVertex2d(x+1061.90,y+277.56);
    glEnd();
}

void GarisPanel2(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(x+1053.03,y+280.90);
    glVertex2d(x+1053.80,y+281.14);
    glVertex2d(x+1121.83,y+251.05);
    glVertex2d(x+1121.98,y+250.40);
    glEnd();
}

void Corong(){
    glBegin(GL_POLYGON);
    glColor3ub(89,84,79);
    glVertex2d(1087.73,206.53);
    glVertex2d(1087.73,187.43);
    glColor3ub(94,91,88);
    glVertex2d(1123.68,187.43);
    glVertex2d(1166.86,206.53);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(89,84,79);
    glVertex2d(1067.55,189.67);
    glVertex2d(1067.55,197.55);
    glVertex2d(1087.86,206.53);
    glVertex2d(1087.86,198.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,67,63);
    glVertex2d(1087.86,206.53);
    glVertex2d(1087.86,198.65);
    glVertex2d(1108.04,189.67);
    glVertex2d(1108.04,197.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153,140,132);
    glVertex2d(1064.75,186.97);
    glVertex2d(1087.87,197.20);
    glVertex2d(1110.85,186.97);
    glVertex2d(1087.72,176.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1064.75,186.97);
    glVertex2d(1087.87,197.20);
    glVertex2d(1087.87,201.06);
    glVertex2d(1064.75,190.83);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(89,84,79);
    glVertex2d(1087.87,197.20);
    glVertex2d(1087.87,201.06);
    glVertex2d(1110.85,190.83);
    glVertex2d(1110.85,186.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(104,98,92);
    glVertex2d(1087.87,194.01);
    glVertex2d(1103.65,186.98);
    glColor3ub(71,67,63);
    glVertex2d(1087.73,179.94);
    glVertex2d(1071.94,186.98);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(66,63,58);
    glVertex2d(1087.87,194.01);
    glVertex2d(1098.33,189.35);
    glVertex2d(1087.73,184.66);
    glVertex2d(1077.32,189.32);
    glEnd();
}

void Besi(int y){
    glBegin(GL_POLYGON);
    glColor3ub(87,82,77);
    glVertex2d(1066.41,y+417.30);
    glVertex2d(1071.57,y+415.00);
    glVertex2d(1135.20,y+443.15);
    glVertex2d(1135.24,y+447.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(87,82,77);
    glVertex2d(1135.20,y+443.15);
    glVertex2d(1135.24,y+447.75);
    glVertex2d(1354.43,y+350.15);
    glVertex2d(1344.06,y+350.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(87,82,77);
    glVertex2d(1354.43,y+350.15);
    glVertex2d(1344.06,y+350.16);
    glVertex2d(1318.93,y+339.04);
    glVertex2d(1324.10,y+336.73);
    glEnd();
}

void Kolam(){
    glBegin(GL_POLYGON);
    glColor3ub(231,231,231);
    glVertex2d(677.20,540.75);
    glVertex2d(582.34,582.98);
    glVertex2d(793.40,676.35);
    glVertex2d(782.46,586.91);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(231,231,231);
    glVertex2d(793.40,676.35);
    glVertex2d(782.46,586.91);
    glVertex2d(924.91,523.48);
    glVertex2d(1030.65,570.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(206,206,206);
    glVertex2d(582.34,582.98);
    glVertex2d(793.40,676.35);
    glVertex2d(793.40,680.60);
    glVertex2d(582.34,587.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(190,190,190);
    glVertex2d(793.40,676.35);
    glVertex2d(793.40,680.60);
    glVertex2d(1030.65,570.65);
    glVertex2d(1030.78,574.90);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(28,125,242);
    glVertex2d(924.91,548.99);
    glVertex2d(997.37,581.27);
    glColor3ub(30,149,247);
    glVertex2d(793.39,672.10);
    glVertex2d(782.41,612.41);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(30,149,247);
    glVertex2d(793.39,672.10);
    glVertex2d(782.41,612.41);
    glColor3ub(51,153,255);
    glVertex2d(677.22,566.25);
    glVertex2d(615.86,593.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(151,213,255);
    glVertex2d(591.91,582.97);
    glVertex2d(615.86,593.57);
    glColor3ub(64,169,255);
    glVertex2d(677.22,566.25);
    glVertex2d(677.22,544.99);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(151,213,255);
    glVertex2d(677.22,566.25);
    glVertex2d(677.22,544.99);
    glColor3ub(64,169,255);
    glVertex2d(782.48,591.15);
    glVertex2d(782.48,612.41);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(151,213,255);
    glVertex2d(782.48,591.15);
    glVertex2d(782.48,612.41);
    glColor3ub(64,169,255);
    glVertex2d(924.91,548.99);
    glVertex2d(924.91,527.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(151,213,255);
    glVertex2d(924.91,548.99);
    glVertex2d(924.91,527.73);
    glColor3ub(64,169,255);
    glVertex2d(1021.23,570.65);
    glVertex2d(997.37,581.27);
    glEnd();
}

void Pohon(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(123,60,13);
    glVertex2d(x+1035.46,y+600.26);
    glVertex2d(x+1047.46,y+596.71);
    glVertex2d(x+1035.46,y+555.90);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(169,102,43);
    glVertex2d(x+1035.46,y+600.26);
    glVertex2d(x+1035.46,y+555.90);
    glVertex2d(x+1024.98,y+597.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91,43,10);
    glVertex2d(x+1035.52,y+592.42);
    glVertex2d(x+1045.38,y+588.99);
    glVertex2d(x+1043.36,y+582.77);
    glVertex2d(x+1027.31,y+587.93);
    glEnd();
//1
    glBegin(GL_POLYGON);
    glColor3ub(147,170,75);
    glVertex2d(x+1035.46,y+590.29);
    glVertex2d(x+1007.80,y+582.28);
    glVertex2d(x+1035.46,y+534.95);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(114,137,54);
    glVertex2d(x+1035.46,y+590.29);
    glVertex2d(x+1063.28,y+582.28);
    glVertex2d(x+1035.46,y+534.95);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(58,79,11);
    glVertex2d(x+1020.47,y+560.60);
    glVertex2d(x+1035.84,y+568.84);
    glVertex2d(x+1052.13,y+563.48);
    glVertex2d(x+1050.44,y+560.60);
    glVertex2d(x+1035.46,y+564.94);
    glEnd();

//2
    glBegin(GL_POLYGON);
    glColor3ub(147,170,75);
    glVertex2d(x+1035.46,y+564.94);
    glVertex2d(x+1013.29,y+558.51);
    glVertex2d(x+1035.46,y+520.58);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(114,137,54);
    glVertex2d(x+1035.46,y+564.94);
    glVertex2d(x+1057.63,y+558.51);
    glVertex2d(x+1035.46,y+520.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(58,79,11);
    glVertex2d(x+1035.46,y+544.13);
    glVertex2d(x+1047.59,y+541.34);
    glVertex2d(x+1042.86,y+533.25);
    glVertex2d(x+1024.96,y+538.55);
    glEnd();

//3
    glBegin(GL_POLYGON);
    glColor3ub(147,170,75);
    glVertex2d(x+1035.46,y+541.59);
    glVertex2d(x+1022.32,y+537.78);
    glVertex2d(x+1035.46,y+515.31);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(114,137,54);
    glVertex2d(x+1035.46,y+541.59);
    glVertex2d(x+1048.59,y+537.78);
    glVertex2d(x+1035.46,y+515.31);
    glEnd();
}

void Jalan(){
    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(0,435);
    glVertex2d(0,666);
    glVertex2d(292,800);
    glVertex2d(815,800);
    glEnd();
//Tanah
    glBegin(GL_POLYGON);
    glColor3ub(184,234,87);
    glVertex2d(0,800);
    glColor3ub(122,178,15);
    glVertex2d(0,666);
    glVertex2d(292,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(759,800);
    glVertex2d(1338,800);
    glVertex2d(1600,688);
    glVertex2d(1600,445);
    glEnd();
//Tanah
    glBegin(GL_POLYGON);
    glColor3ub(184,234,87);
    glVertex2d(1338,800);
    glColor3ub(122,178,15);
    glVertex2d(1600,800);
    glVertex2d(1600,688);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(1600,585);
    glVertex2d(1600,373);
    glVertex2d(759.73,1.2);
    glVertex2d(565.8,82.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(1200,0);
    glVertex2d(800,-14.5);
    glVertex2d(0,320);
    glVertex2d(0,550);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(156.5,477);
    glVertex2d(125,492);
    glVertex2d(156,506);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(1446,510);
    glVertex2d(1420,495);
    glVertex2d(1420,525);
    glEnd();

//Tanah Sebelah
    int x=850, y=-390;
    glBegin(GL_POLYGON);
    glColor3ub(184,234,87);
    glVertex2d(x+156,y+479);
    glColor3ub(122,178,15);
    glVertex2d(x+786,y+189);
    glVertex2d(x+1421,y+497);
    glVertex2d(x+790,y+768);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(122,178,15);
    glVertex2d(x+1421,y+497);
    glVertex2d(x+1422,y+520);
    glColor3ub(140,188,10);
    glVertex2d(x+787,y+788);
    glVertex2d(x+787,y+762);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140,188,10);
    glVertex2d(x+787,y+788);
    glVertex2d(x+787,y+762);
    glColor3ub(184,234,87);
    glVertex2d(x+156,y+479);
    glVertex2d(x+156,y+504);
    glEnd();
//Jalan
    int a=852, b=-390;
    glBegin(GL_POLYGON);
    glColor3ub(65,64,66);
    glVertex2d(a+156.5,b+477);
    glVertex2d(a+125,b+492);
    glVertex2d(a+156,b+506);
    glEnd();
}

void Zebra(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(220,219,218);
    glVertex2d(x+1381.44,y+557.31);
    glVertex2d(x+1406,y+568);
    glVertex2d(x+1479,y+538);
    glVertex2d(x+1454.22,y+526.58);
    glEnd();
}

void Zebra1(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(220,219,218);
    glVertex2d(x+1447.42,y+496.28);
    glVertex2d(x+1470,y+486);
    glVertex2d(x+1402,y+451);
    glVertex2d(x+1378,y+461);
    glEnd();
}

Laut(){
    glBegin(GL_POLYGON);
    glColor3ub(112,111,110);
    glVertex2d(800,-14.5);
    glVertex2d(0,320);
    glVertex2d(0,293);
    glVertex2d(712,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140,140,140);
    glVertex2d(712,0);
    glVertex2d(0,293);
    glVertex2d(0,233);
    glVertex2d(591,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(5,35,214);
    glVertex2d(0,0);
    glColor3ub(115,151,239);
    glVertex2d(0,233);
    glVertex2d(591,0);
    glEnd();
}

void Lapangan(){
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1368,0);
    glVertex2d(1222,68);
    glVertex2d(1213,64);
    glVertex2d(1352,0);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1213,64);
    glVertex2d(1205,68);
    glVertex2d(1600,242);
    glVertex2d(1600,231);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1331,115);
    glVertex2d(1322,112);
    glVertex2d(1460,42);
    glVertex2d(1475,42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1460,42);
    glVertex2d(1470,37);
    glVertex2d(1600,96);
    glVertex2d(1600,105);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1464,172);
    glVertex2d(1455,169);
    glVertex2d(1522,135);
    glVertex2d(1533,136);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(1522,135);
    glVertex2d(1529,132);
    glVertex2d(1600,164);
    glVertex2d(1600,171);
    glEnd();
}

void Kayu(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(142,76,32);
    glVertex2d(x+260.50,y+482.65);
    glVertex2d(x+276.22,y+490.61);
    glVertex2d(x+277.97,y+472.91);
    glVertex2d(x+261.37,y+465.83);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(169,102,43);
    glVertex2d(x+277.97,y+472.91);
    glVertex2d(x+261.37,y+465.83);
    glVertex2d(x+796.72,y+218.00);
    glVertex2d(x+812.00,y+225.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(123,60,13);
    glVertex2d(x+277.97,y+472.91);
    glVertex2d(x+812.00,y+225.52);
    glVertex2d(x+810.69,y+241.01);
    glVertex2d(x+276.22,y+490.61);
    glEnd();
}

void Kursi(){
    glBegin(GL_POLYGON);
    glColor3ub(119,123,125);
    glVertex2d(734.18,539.06);
    glVertex2d(768.53,552.83);
    glVertex2d(768.53,549.60);
    glVertex2d(734.18,535.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155,161,163);
    glVertex2d(768.53,552.83);
    glVertex2d(768.53,549.60);
    glVertex2d(842.15,519.96);
    glVertex2d(844.48,522.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155,161,163);
    glVertex2d(844.48,522.54);
    glVertex2d(866.00,491.03);
    glVertex2d(862.37,490.33);
    glVertex2d(842.15,519.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114,14,18);
    glVertex2d(734.18,535.82);
    glVertex2d(768.53,549.60);
    glVertex2d(768.53,546.49);
    glVertex2d(734.18,532.72);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(768.53,549.60);
    glVertex2d(768.53,546.49);
    glVertex2d(839.55,517.75);
    glVertex2d(842.15,519.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(842.15,519.96);
    glVertex2d(839.55,517.75);
    glVertex2d(858.65,489.77);
    glVertex2d(862.37,490.33);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,26,34);
    glVertex2d(768.53,546.49);
    glVertex2d(734.18,532.72);
    glVertex2d(804.22,504.75);
    glVertex2d(839.55,517.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220,26,34);
    glVertex2d(804.22,504.75);
    glVertex2d(839.55,517.75);
    glVertex2d(858.65,489.77);
    glVertex2d(824.29,476.00);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150,18,24);
    glVertex2d(858.65,489.77);
    glVertex2d(824.29,476.00);
    glVertex2d(828.01,476.55);
    glVertex2d(862.37,490.33);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,242,244);
    glVertex2d(828.01,476.55);
    glVertex2d(862.37,490.33);
    glVertex2d(866.00,491.03);
    glVertex2d(831.64,477.26);
    glEnd();
}

void Belang(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(229,236,241);
    glVertex2d(x+773.59,y+544.39);
    glVertex2d(x+779.32,y+542.11);
    glVertex2d(x+744.86,y+528.37);
    glVertex2d(x+739.15,y+530.66);
    glEnd();
}

void Belang1(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(229,236,241);
    glVertex2d(x+852.64,y+498.60);
    glVertex2d(x+855.53,y+494.34);
    glVertex2d(x+821.02,y+480.78);
    glVertex2d(x+818.25,y+484.85);
    glEnd();
}

void Kaki(int x, int y){
    glBegin(GL_POLYGON);
    glColor3ub(128,130,131);
    glVertex2d(x+734.99,y+545.23);
    glVertex2d(x+737.13,y+546.08);
    glVertex2d(x+737.13,y+539.39);
    glVertex2d(x+735.02,y+538.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,187,188);
    glVertex2d(x+737.13,y+546.08);
    glVertex2d(x+737.13,y+539.39);
    glVertex2d(x+738.93,y+538.68);
    glVertex2d(x+738.93,y+545.37);
    glEnd();
}

int buff=0, clindex=0;
int colorctrl1[4][3]={{244, 205, 118},{255,255,255},{244, 205, 118},{255,255,255}};
int i=0,j=0,k=0,a=0;
const float DEG2RAD = 3.14159/180;
void circle(float radius, float jumlah_titik, float x_tengah, float y_tengah){
    glBegin(GL_POLYGON);
    int i;
    for(i=0; i<=360; i++){
        //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
        glColor3ub(colorctrl1[clindex%4][0],colorctrl1[clindex%4][1],colorctrl1[clindex%4][2]);
        //glColor3ub(0+i,0+j,0+k);
        float sudut = i*(2*3.14/jumlah_titik);
        float x = x_tengah+radius*cos(sudut);
        float y = y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}
void circle1(float radius, float jumlah_titik, float x_tengah, float y_tengah){
    glBegin(GL_POLYGON);
    int i;
    for(i=0; i<=360; i++){
        //glColor3ub(242 + (0.8 * (255-i)), 242 + (1.4 * (255-i)), 242 + (0.5 * (255-i)));
        //glColor3ub(colorctrl1[clindex%4][0],colorctrl1[clindex%4][1],colorctrl1[clindex%4][2]);
        glColor3ub(0+i,0+j,0+k);
        float sudut = i*(2*3.14/jumlah_titik);
        float x = x_tengah+radius*cos(sudut);
        float y = y_tengah+radius*sin(sudut);
        glVertex2f(x,y);
    }
    glEnd();
}
int pecah=0;
void awan(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        //glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        glPushMatrix();
        glTranslated(pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        glPopMatrix();
    }
}

void awan1(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        //glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        glPushMatrix();
        glTranslated(-pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        glPopMatrix();
    }
}

void awankinton(float x, float y){
    int i, j;
    for(i=0; i<100; i++){
        glRotatef((float) glfwGetTime() * 10.f, 0.f, 0.f, 0.f);
        //glPushMatrix();
        //glTranslated(pecah,0,0);
        glBegin(GL_POLYGON);
        glColor3ub(254, 253, 251);
            circle(20, 70, 43.18 + x, 103.5 + y);
            circle(35, 70, 171.27 + x, 96.91 + y);
            circle(33, 70, 73.52 + x, 96.91 + y);
            circle(45, 35, 116.26 + x, 87.1 + y);
        glEnd();
        //glPopMatrix();
    }
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();// your code here, maybe
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Hilmi Farhan Ramadhani - <G64160042>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        Tanah();
        for(i=0;i<=8;i++)
            Kayu(i*19,i*8);
        int r=-2;
        for(i=1;i<=8;i++){
            Kayu(i*19,r*8);
            r++;
        }
        r=-4;
        for(i=2;i<=8;i++){
            Kayu(i*19,r*8);
            r++;
        }
        Jalan();
        for(i=0;i<=4;i++)
            Zebra(i*44,i*21);
        for(i=0;i<=4;i++)
            Zebra1(i*44,i*-18);
        for(i=0;i<=2;i++)
            Zebra((i*-144)-43,(i*60)+99);
        for(i=0;i<=7;i++)
            Zebra((i*-130)-500,(i*60)-530);
        for(i=0;i<=4;i++)
            Zebra1((i*-103)-21,(i*-45)-102);
        for(i=0;i>=-5;i--)
            Zebra1((i*-103)-1379,(i*-45)+91);

        int x=-8;
        for(i=4;i<=12;i++){
            Pohon(i*-47.86,x*20.87);
            x++;
        }
        Laut();
        DasarRumah();
        Tembok();
        TembokBawah();
        for(i=0;i<=3;i++)
            Tiang(i*56.05,i*-24.48);
        Tiang(4.4*56.05,4.4*-24.48);
        LantaiDua();
        TembokAtas();
        for(i=0;i<=5;i++)
            Garis(i*12.43);
        Kaca();
        Atap();
        //Panel Atap
        Panel(0,0);
        Panel(78.29,-34.7);
        for(i=-1;i<=7;i++)
            GarisPanel1(i*8.55,i*-3.79);
        for(i=-1;i<=7;i++)
            GarisPanel1(78.29+(i*8.55),-34.7+(i*-3.79));
        for(i=0;i<=3;i++)
            GarisPanel2(i*4.79,i*6.99);
        for(i=0;i<=3;i++)
            GarisPanel2(78.29+(i*4.79),-34.7+(i*6.99));
        Corong();
        for(i=0;i<=3;i++)
            Besi(i*8.7);
        Kolam();
        for(i=0;i<=5;i++)
            Pohon(i*-47.86,i*20.87);
        Lapangan();

        x=6;
        for(i=-12;i<=-5;i++){
            Pohon(i*-47.86,x*20.87);
            x++;
        }
        x=-28;
        for(i=-5;i<=-1;i++){
            Pohon(i*-47.86,x*20.87);
            x++;
        }
        x=13;
        for(i=14;i<=22;i++){
            Pohon(i*-47.86,x*20.87);
            x--;
        }
        x=-13;
        for(i=-12;i<=-2;i++){
            Pohon(i*-47.86,x*20.87);
            x--;
        }
        //kolam
        x=6;
        for(i=6;i<=11;i++){
            Pohon(i*-47.86,x*20.87);
            x--;
        }
        Kaki(0,0);
        Kaki(29.93,11.92);
        Kaki(102.39,-17.42);
        Kursi();
        for(i=0;i<=5;i++)
            Belang(i*11.76,i*-4.64);
        for(i=0;i<=2;i++)
            Belang1(i*-5.64,i*8.25);

        circle1(150, 70, 0, 0);
        awan1(1580, 0);
        awan(-210, 60);
        awankinton(560, 60);
        if(a<750){
            a++;i++;j++;k++;
        }
        else if(a>=750){
            i--;j--;k--;
            a++;
            if(a==1580){a=0;}
        }

        double currentTime = glfwGetTime();
        int ticks=0, c=0, b=0;
        while (currentTime / 1 > ticks) {
            ticks++;
            currentTime = glfwGetTime();
            c++;
            if(b<5){
                pecah++;
                b++;
            }
            else if(b>=5){
                pecah--;
                b++;
                if(b==10){
                    b=0;}
            }
            if(pecah==1800)
                pecah=0;

        }

        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%10;

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
