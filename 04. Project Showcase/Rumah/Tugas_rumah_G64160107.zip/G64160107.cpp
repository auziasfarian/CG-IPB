#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
double nol = 0, resetx=60, resety=-18;
int trigger = 0,i;
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1920, 1080, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable( GL_BLEND );

}


void  langit() {
    glBegin(GL_POLYGON);
    glColor3ub(138, 213, 255);
    glVertex2d(0, 0);
    glVertex2d(1920, 0);
    glColor3ub(243, 243, 243);
    glVertex2d(1920, 580);
    glVertex2d(1510, 580);
    glVertex2d(0,514);
    glEnd();

}

void warna(){

    if(trigger%2==0){
        nol+=0.5;}
    else{
        nol-=0.25;
    }
    if(nol==255 || nol == 0){
        trigger++;
    }

}
void bintang(){
    glBegin(GL_POINTS);
    glColor3f(1.0,1.0,1.0);
    glVertex2d(72,68);
    glVertex2d(291,220);
    glVertex2d(375,390);
    glVertex2d(793,77);
    glVertex2d(873,20);
    glVertex2d(128,82);
    glVertex2d(24,734);
    glVertex2d(643,112);
    glVertex2d(268,828);
    glVertex2d(238,178);
}

void kelip(){
    int s;
    float x,y;
    glColor3f(0.1,1.0,0.-1);
    for(int i=0;i<500;i++){
        s=rand()%4+1;
        glPointSize(s);
        glBegin(GL_POINTS);
        x=(float)rand()/RAND_MAX;
        y=(float)rand()/RAND_MAX;
        glVertex2f(x,y);
        glEnd();
    }
}

void pondasi () {
    glBegin(GL_POLYGON);
    glColor3ub(81,71,68);
    glVertex2d(980.44,928.93);
    glVertex2d(377, 518);
    glVertex2d(904, 239);
    glVertex2d(1508, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181, 111, 94);
    glVertex2d(1508, 594.65);
    glVertex2d(1508, 628.73);
    glVertex2d(979.5, 977);
    glVertex2d(979.5, 943.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181, 111, 94);
    glVertex2d(979.5, 977);
    glVertex2d(979.5, 943.35);
    glVertex2d(375, 533);
    glVertex2d(376, 567);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(61, 52, 50);
    glVertex2d(377, 518);
    glVertex2d(353, 518);
    glVertex2d(979.5, 943.35);
    glVertex2d(980.44, 928.93);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(40, 34, 32);
    glVertex2d(979.5, 943.35);
    glVertex2d(980.44, 928.93);
    glVertex2d(1510, 580);
    glVertex2d(1534, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(170, 93, 72);
    glVertex2d(582, 677);
    glVertex2d(582, 710);
    glVertex2d(304.54, 518);
    glVertex2d(353, 518);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181, 111, 94);
    glVertex2d(1508, 594.65);
    glVertex2d(1508, 628.73);
    glVertex2d(1573, 578);
    glVertex2d(1534, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 196, 192);
    glVertex2d(1120, 634);
    glVertex2d(984,727);
    glVertex2d(1170, 688);
    glVertex2d(1185, 678);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 196, 192);
    glVertex2d(984,727);
    glVertex2d(1170, 688);
    glVertex2d(1254, 749);
    glVertex2d(1135, 829);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 112, 110);
    glVertex2d(948, 615);
    glVertex2d(912, 591);
    glVertex2d(878, 610);
    glVertex2d(907,638);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 112, 110);
    glVertex2d(878, 610);
    glVertex2d(907,638);
    glVertex2d(882, 693);
    glVertex2d(855, 701);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 112, 110);
    glVertex2d(882, 693);
    glVertex2d(855, 701);
    glVertex2d(989, 797);
    glVertex2d(983, 766);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 112, 110);
    glVertex2d(989, 797);
    glVertex2d(983, 766);
    glVertex2d(1009, 744);
    glVertex2d(1032, 760);
    glEnd();


}


void depan() {

    glBegin(GL_POLYGON);
    glColor3ub(204, 203, 194);
    glVertex2d(900.91, 581.02);
    glVertex2d(1036.86, 678.05);
    glVertex2d(1036.86, 560.25);
    glVertex2d(992.97, 453.97);
    glVertex2d(902.08,391.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(98, 135, 27);
    glVertex2d(1028.06, 538.92);
    glVertex2d(1013.23, 503.03);
    glVertex2d(902.08, 424.79);
    glVertex2d(902.08, 450.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 113, 106);
    glVertex2d(1036.86, 678.05);
    glVertex2d(1036.86, 560.25);
    glVertex2d(1112.52, 507.24);
    glVertex2d(1111.62, 625.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175, 174, 168);
    glVertex2d(992.97, 453.97);
    glVertex2d(1232.07, 285.14);
    glVertex2d(1278.85, 389.79);
    glVertex2d(1036.86, 560.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237, 193, 180);
    glVertex2d(992.97, 453.97);
    glVertex2d(1084.92, 388.62);
    glVertex2d(994.71, 327.25);
    glVertex2d(902.08, 391.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158, 102, 82);
    glVertex2d(1125.85, 287.71);
    glVertex2d(1231.91, 211.85);
    glVertex2d(1232.07, 285.14);
    glVertex2d(1084.92, 388.62);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(226, 168, 147);
    glVertex2d(1125.85, 287.71);
    glVertex2d(1084.92, 388.62);
    glVertex2d(994.71, 327.25);
    glVertex2d(1034.97, 225.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(117,68, 56);
    glVertex2d(1034.97, 225.19);
    glVertex2d(1125.85, 287.71);
    glVertex2d(1231.91, 211.85);
    glVertex2d(1142.07, 150.64);
    glEnd();



}

void samping () {
    glBegin(GL_POLYGON);
    glColor3ub(235, 197, 133);
    glVertex2d(1112.52, 507.24);
    glVertex2d(1174.25, 550.06);
    glVertex2d(1186.2, 573.43);
    glVertex2d(1185.68, 677.84);
    glVertex2d(1111.62, 625.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(189, 163, 125);
    glVertex2d(1186.2, 573.43);
    glVertex2d(1185.68, 677.84);
    glVertex2d(1352.43, 560.08);
    glVertex2d(1353.33, 454.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140, 107, 81);
    glVertex2d(1174.25, 550.06);
    glVertex2d(1186.2, 573.43);
    glVertex2d(1353.33, 454.74);
    glVertex2d(1340.48, 433.38);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(148, 131, 103);
    glVertex2d(1112.52, 507.24);
    glVertex2d(1278.93, 389.62);
    glVertex2d(1340.48, 433.38);
    glVertex2d(1174.25, 550.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(117, 99, 71);
    glVertex2d(1120, 558);
    glVertex2d(1170, 591.39);
    glVertex2d(1170, 667);
    glVertex2d(1120, 633.61);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 127, 78);
    glVertex2d(1125, 578);
    glVertex2d(1166, 604.96);
    glVertex2d(1166, 612);
    glVertex2d(1125, 585.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 127, 78);
    glVertex2d(1127, 599);
    glVertex2d(1163, 622.79);
    glVertex2d(1163, 629);
    glVertex2d(1127, 605.21);
    glEnd();
}

void menara () {
    glBegin(GL_POLYGON);
    glColor3ub(186, 205, 202);
    glVertex2d(765.8, 662.07);
    glVertex2d(903.33, 583.75);
    glVertex2d(903.33, 389.77);
    glVertex2d(765.8, 467.36);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224, 239, 237);
    glVertex2d(662.84, 602.78);
    glVertex2d(662.84, 409.53);
    glVertex2d(765.8, 467.36);
    glVertex2d(765.8, 662.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181, 147, 129);
    glVertex2d(904, 272);
    glVertex2d(662.84, 409.53);
    glVertex2d(765.8, 467.36);
    glVertex2d(903.33, 389.77);
    glVertex2d(993, 328);
    glEnd();

}

void kotak_samping() {
    glBegin(GL_POLYGON);
    glColor3ub(83, 107, 131);
    glVertex2d(1198.24, 594);
    glVertex2d(1283.96, 654.95);
    glVertex2d(1283.88, 730);
    glVertex2d(1198, 669.05);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(55, 75, 99);
    glVertex2d(1283.96, 654.95);
    glVertex2d(1283.88, 730);
    glVertex2d(1342.93, 688);
    glVertex2d(1343, 612.95);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(148, 131, 103);
    glVertex2d(1198.24, 594);
    glVertex2d(1283.96, 654.95);
    glVertex2d(1343, 612.95);
    glVertex2d(1257.12,552);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1206, 615.11);
    glVertex2d(1230, 633.07);
    glVertex2d(1230, 669);
    glVertex2d(1206, 651.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(101, 179, 220);
    glVertex2d(1208.34, 620.36);
    glVertex2d(1227.66, 634.82);
    glVertex2d(1227.66, 663.75);
    glVertex2d(1208.34, 649.24);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1216.75, 623.16);
    glVertex2d(1219.25, 625.03);
    glVertex2d(1219.25, 660.95);
    glVertex2d(1216.75, 659.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1206, 631.2);
    glVertex2d(1230, 649.17);
    glVertex2d(1230, 652.91);
    glVertex2d(1206, 634.94);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1245, 642.11);
    glVertex2d(1269, 660.07);
    glVertex2d(1269, 696);
    glVertex2d(1245, 678.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(101, 179, 220);
    glVertex2d(1247.34, 647.36);
    glVertex2d(1266.66, 661.82);
    glVertex2d(1266.66, 690.75);
    glVertex2d(1247.34, 676.29);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1255.75, 650.16);
    glVertex2d(1258.25, 652.03);
    glVertex2d(1258.25, 687.95);
    glVertex2d(1255.75, 686.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(213, 190, 154);
    glVertex2d(1245, 658.2);
    glVertex2d(1245, 661.94);
    glVertex2d(1269, 679.91);
    glVertex2d(1269, 676.16);
    glEnd();


}

void pintu (){
    glBegin(GL_POLYGON);
    glColor3ub(142, 133, 121);
    glVertex2d(912, 591.24);
    glVertex2d(912, 515.64);
    glVertex2d(918.08, 511.63);
    glVertex2d(945.97, 530.04);
    glVertex2d(948,534.05);
    glVertex2d(948, 615);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 86);
    glVertex2d(915.4, 553.58);
    glVertex2d(915.4, 515.02);
    glVertex2d(944.6, 534.3);
    glVertex2d(944.6, 572.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(101, 179, 220);
    glVertex2d(918.24, 520.66);
    glVertex2d(941.76, 536.18);
    glVertex2d(941.76, 567.22);
    glVertex2d(918.24, 551.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 86);
    glVertex2d(915.4, 532.29);
    glVertex2d(944.6, 551.57);
    glVertex2d(944.6, 555.58);
    glVertex2d(915.4, 536.31);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 86);
    glVertex2d(928.48, 523.65);
    glVertex2d(931.52, 525.66);
    glVertex2d(931.52, 564.22);
    glVertex2d(928.48, 562.21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 242, 253);
    glVertex2d(959.21, 542.01);
    glVertex2d(959.25, 577.59);
    glVertex2d(1038.04, 620.99);
    glVertex2d(1038, 585.68);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2d(959.21, 542.01);
    glVertex2d(959.25, 577.59);
    glVertex2d(1038.04, 620.99);
    glVertex2d(1038, 585.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 242, 253);
    glVertex2d(1037, 583.09);
    glVertex2d(1037,622);
    glVertex2d(1080, 593.72);
    glVertex2d(1080, 556);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0,0,0);
    glVertex2d(1037, 583.09);
    glVertex2d(1037,622);
    glVertex2d(1080, 593.72);
    glVertex2d(1080, 556);
    glEnd();


}

void atas () {
    glBegin(GL_POLYGON);
    glColor3ub(229, 70, 21);
    glVertex2d(1061.02, 300.73);
    glVertex2d(1102.66, 271.75);
    glVertex2d(1061.02, 378.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242, 6, 158);
    glVertex2d(1061.02, 300.73);
    glVertex2d(1061.02, 378.58);
    glVertex2d(1019.69, 349.39);
    glVertex2d(1019.69, 272.46);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237, 193, 180);
    glVertex2d(1061.74, 243.6);
    glVertex2d(1019.69, 272.46);
    glVertex2d(1061.02, 300.73);
    glVertex2d(1102.66, 271.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(50, 127, 53);
    glVertex2d(1026.88, 290.82);
    glVertex2d(1050.24, 307.29);
    glVertex2d(1050.24, 369.58);
    glVertex2d(1026.88, 353.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(68, 71, 61);
    glVertex2d(1032.27, 303.95);
    glVertex2d(1044.85, 312.7);
    glVertex2d(1044.85, 336.73);
    glVertex2d(1032.27, 328.01);
    glEnd();
}

void jendela_besar () {

    glBegin(GL_POLYGON);
    glColor3ub(68, 71, 61);
    glVertex2d(1018.45, 452.5);
    glVertex2d(1055.83, 426.38);
    glVertex2d(1085.55, 493.96);
    glVertex2d(1047.07, 521.79);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(68, 71, 61);
    glVertex2d(1072.36, 415.31);
    glVertex2d(1109.74, 389.19);
    glVertex2d(1139.46, 456.77);
    glVertex2d(1100.98, 484.6);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(68, 71, 61);
    glVertex2d(1126.27, 378.12);
    glVertex2d(1163.42, 351.63);
    glVertex2d(1193, 419.56);
    glVertex2d(1154.89, 447.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(68, 71, 61);
    glVertex2d(1180.19, 340.93);
    glVertex2d(1217.56, 314.8);
    glVertex2d(1247.29, 382.39);
    glVertex2d(1208.8, 410.21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224, 178, 160);
    glVertex2d(1051.58, 532.72);
    glVertex2d(1095.6, 501.36);
    glVertex2d(1085.55, 493.96);
    glVertex2d(1047.07, 521.79);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224, 178, 160);
    glVertex2d(1105.49, 495.53);
    glVertex2d(1149.51, 464.17);
    glVertex2d(1139.46, 456.77);
    glVertex2d(1100.98, 484.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224, 178, 160);
    glVertex2d(1159.41, 458.34);
    glVertex2d(1203, 427);
    glVertex2d(1193, 419.56);
    glVertex2d(1154.89, 447.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(224, 178, 160);
    glVertex2d(1213.32, 421.14);
    glVertex2d(1257.34, 389.79);
    glVertex2d(1247.29, 382.39);
    glVertex2d(1208.8, 410.21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 150, 133);
    glVertex2d(1095.5, 501.36);
    glVertex2d(1085.55, 493.96);
    glVertex2d(1055.83, 426.38);
    glVertex2d(1061.23, 422.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 150, 133);
    glVertex2d(1149.51, 464.17);
    glVertex2d(1139.46, 456.77);
    glVertex2d(1109.74, 389.19);
    glVertex2d(1115.14, 385.41);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 150, 133);
    glVertex2d(1203, 427);
    glVertex2d(1193, 419.56);
    glVertex2d(1163.42, 351.63);
    glVertex2d(1168.8, 347.83);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(204, 150, 133);
    glVertex2d(1257.34, 389.79);
    glVertex2d(1247.29, 382.39);
    glVertex2d(1217.56, 314.8);
    glVertex2d(1222.97, 311.03);
    glEnd();


}

void jendela_menara () {
    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(802.9, 575.47);
    glVertex2d(871.81,537.35);
    glVertex2d(871.81, 601.74);
    glVertex2d(802.9, 641.17);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(817.37, 457.11);
    glVertex2d(855.9, 435.79);
    glVertex2d(855.9, 500.22);
    glVertex2d(817.37, 521.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(690.5, 444.87);
    glVertex2d(728.56, 465.92);
    glVertex2d(728.56, 530.82);
    glVertex2d(690.5, 509.04);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(672.99, 545.21);
    glVertex2d(686.19, 552.84);
    glVertex2d(686.19, 599.78);
    glVertex2d(672.99, 593.12);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(702.99, 562.21);
    glVertex2d(716.19, 569.84);
    glVertex2d(716.19, 616.78);
    glVertex2d(702.99, 610.12);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(116, 211, 215);
    glVertex2d(735.68, 579.96);
    glVertex2d(748.67, 587.59);
    glVertex2d(748.87, 634.53);
    glVertex2d(735.68, 627.87);
    glEnd();

    //garis kaca
    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(802.9, 575.47);
    glVertex2d(871.81,537.35);
    glVertex2d(871.81, 601.74);
    glVertex2d(802.9, 641.17);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(690.5, 444.87);
    glVertex2d(728.56, 465.92);
    glVertex2d(728.56, 530.82);
    glVertex2d(690.5, 509.04);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(709.53, 455.4);
    glVertex2d(709.53, 519.59);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(672.99, 545.21);
    glVertex2d(686.19, 552.84);
    glVertex2d(686.19, 599.78);
    glVertex2d(672.99, 593.12);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(702.99, 562.21);
    glVertex2d(716.19, 569.84);
    glVertex2d(716.19, 616.78);
    glVertex2d(702.99, 610.12);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(735.68, 579.96);
    glVertex2d(748.67, 587.59);
    glVertex2d(748.87, 634.53);
    glVertex2d(735.68, 627.87);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(817.37, 457.11);
    glVertex2d(855.9, 435.79);
    glVertex2d(855.9, 500.22);
    glVertex2d(817.37, 521.67);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(850.26, 548.9);
    glVertex2d(850.26, 614.64);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(836.64, 511.4);
    glVertex2d(836.64, 446.45);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(825.6, 562.72);
    glVertex2d(825.6, 628.47);
    glEnd();

    //balkon
    glBegin(GL_POLYGON);
    glColor3ub(181, 147, 129);
    glVertex2d(668.49, 516.58);
    glVertex2d(686.2, 506.61);
    glVertex2d(735.12, 534.76);
    glVertex2d(718.78, 544.44);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(181, 147, 129);
    glVertex2d(794.25, 534.2);
    glVertex2d(810.18, 543.01);
    glVertex2d(885.34, 501.42);
    glVertex2d(869.41,492.44);
    glEnd();


}
void kolam_renang () {
    glBegin(GL_POLYGON);
    glColor3ub(101, 191, 192);
    glVertex2d(801, 340.02);
    glVertex2d(801, 351.75);
    glVertex2d(705.09, 406.99);
    glVertex2d(693.78, 400.72);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(90, 205, 205);
    glVertex2d(801, 340.02);
    glVertex2d(801, 351.75);
    glVertex2d(862.21, 386.3);
    glVertex2d(872.98, 380.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(187, 232, 233);
    glVertex2d(801, 351.75);
    glVertex2d(862.21, 386.3);
    glVertex2d(766.04, 440.75);
    glVertex2d(705.09, 406.99);
    glEnd();


}

void tiang_atas() {
    glBegin(GL_POLYGON);
    glColor3ub(216, 122, 9);
    glVertex2d(1079.85, 349.27);
    glVertex2d(1078.23,348.29);
    glVertex2d(1076.61,349.27);
    glVertex2d(1076.61, 388.78);
    glVertex2d(1078.23, 389.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 86, 36);
    glVertex2d(1076.61, 349.27);
    glVertex2d(1079.03, 352.36);
    glVertex2d(993.11, 411.61);
    glVertex2d(991.51, 408.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 86, 36);
    glVertex2d(991.51, 421.52);
    glVertex2d(993.11, 424.96);
    glVertex2d(1079.3, 365.47);
    glVertex2d(1077.7, 362.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 86, 36);
    glVertex2d(995.19, 421.31);
    glVertex2d(993.54, 424.72);
    glVertex2d(908.83, 365.29);
    glVertex2d(910.47, 361.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 86, 36);
    glVertex2d(910.47, 349.46);
    glVertex2d(908.83, 352.87);
    glVertex2d(993.54, 412.29);
    glVertex2d(995.19, 408.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(216, 122, 9);
    glVertex2d(911.53, 350.39);
    glVertex2d(908.28, 350.39);
    glVertex2d(908.28, 390.47);
    glVertex2d(911.53, 390.47);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(216, 122, 9);
    glVertex2d(991.7, 407.48);
    glVertex2d(994.95, 407.48);
    glVertex2d(994.95, 447.23);
    glVertex2d(991.7, 447.48);
    glEnd();

}

void taman () {
    glBegin(GL_POLYGON);
    glColor3ub(197, 232, 107);
    glVertex2d(912, 591);
    glVertex2d(903.33, 583.75);
    glVertex2d(765.8, 662.07);
    glVertex2d(765, 673);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(197, 232, 107);
    glVertex2d(765.8, 662.07);
    glVertex2d(765, 673);
    glVertex2d(652, 609);
    glVertex2d(663, 603);
    glEnd();


}

void jalan () {

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(1007.17, 959);
    glVertex2d(1573.34, 578);
    glVertex2d(1638, 580);
    glVertex2d(1042.62, 978.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(959.09, 957.05);
    glVertex2d(927.81, 979.26);
    glVertex2d(237,517);
    glVertex2d(304.54,  518.71);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 88, 84);
    glVertex2d(237,517);
    glVertex2d(231,517);
    glVertex2d(928.06, 983.72);
    glVertex2d(927.81, 979.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63, 61, 61);
    glVertex2d(928.06, 983.72);
    glVertex2d(848.7, 1035.36);
    glVertex2d(79,515);
    glVertex2d(231,517);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 88, 84);
    glVertex2d(1042.62, 978.07);
    glVertex2d(1041.1, 983.72);
    glVertex2d(1638, 580);
    glVertex2d(1645,580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63, 61, 61);
    glVertex2d(1041.1,983.72);
    glVertex2d(1117.78, 1031.79);
    glVertex2d(1791, 580);
    glVertex2d(1646, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(1117.78, 1031.79);
    glVertex2d(1147.81, 1054.67);
    glVertex2d(1853, 580);
    glVertex2d(1791, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 88, 84);
    glVertex2d(1147.81, 1054.67);
    glVertex2d(1146.73, 1059.73);
    glVertex2d(1859, 580);
    glVertex2d(1853, 580);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(985, 973);
    glVertex2d(986.57, 1002.67);
    glVertex2d(1042.62, 978.07);
    glVertex2d(1007, 959);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(985, 973);
    glVertex2d(986.57, 1002.67);
    glVertex2d(927.81, 979.26);
    glVertex2d(959, 957);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 88, 84);
    glVertex2d(1042.62, 978.07);
    glVertex2d(1041.1, 983.72);
    glVertex2d(986.05, 1006.32);
    glVertex2d(986.47, 1002.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 88, 84);
    glVertex2d(986.05, 1006.32);
    glVertex2d(986.47, 1002.67);
    glVertex2d(927.81, 979.26);
    glVertex2d(928.06, 983.72);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(849, 1036);
    glVertex2d(818.48, 1056.82);
    glVertex2d(32, 514);
    glVertex2d(85, 515);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 105, 101);
    glVertex2d(818.48, 1056.82);
    glVertex2d(815.14, 1060.32);
    glVertex2d(27, 514);
    glVertex2d(32,514);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(1117.78, 1031.79);
    glVertex2d(1147.81, 1054.67);
    glVertex2d(1134, 1066);
    glVertex2d(1079, 1080);
    glVertex2d(1079, 1064);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(1079, 1080);
    glVertex2d(1134, 1066);
    glVertex2d(1135, 1080);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(849, 1036);
    glVertex2d(884, 1060);
    glVertex2d(828.12, 1074.1);
    glVertex2d(818.48, 1056.82);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(153, 143, 138);
    glVertex2d(884, 1060);
    glVertex2d(828.12, 1074.1);
    glVertex2d(826, 1080);
    glVertex2d(884, 1080);
    glEnd();



    glBegin(GL_POLYGON);
    glColor3ub(63, 61, 61);
    glVertex2d(1041.1, 983.72);
    glVertex2d(1117.78, 1031.79);
    glVertex2d(1079, 1064);
    glVertex2d(986.05, 1006.32);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63, 61, 61);
    glVertex2d(928.06, 983.72);
    glVertex2d(986.05, 1006.32);
    glVertex2d(884, 1060);
    glVertex2d(849, 1036);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(63, 61, 61);
    glVertex2d(986.05, 1006.32);
    glVertex2d(884, 1060);
    glVertex2d(884, 1080);
    glVertex2d(1079, 1080);
    glVertex2d(1079, 1064);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 105, 101);
    glVertex2d(815, 1060);
    glVertex2d(818.48, 1056.82);
    glVertex2d(828.12, 1074.1);
    glVertex2d(824, 1071);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167, 196, 91);
    glVertex2d(1859, 580);
    glVertex2d(1920, 580);
    glVertex2d(1920, 1080);
    glVertex2d(1135, 1080);
    glVertex2d(1134, 1069);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(167, 196, 91);
    glVertex2d(0, 514);
    glVertex2d(27, 514);
    glVertex2d(815, 1060);
    glVertex2d(824, 1071);
    glVertex2d(825, 1080);
    glVertex2d(0, 1080);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(834.81, 370.44);
    glVertex2d(834.56, 366.73);
    glVertex2d(834.81, 361.03);
    glVertex2d(842.52, 353.55);
    glVertex2d(849.69, 362.74);
    glVertex2d(838.2, 359.03);
    glVertex2d(837.03, 349.64);
    glVertex2d(829.32, 357.33);
    glVertex2d(829.07, 363.16);
    glEnd();


}
void aksesoris () {
    //cerobong asap
    glBegin(GL_POLYGON);
    glColor3ub(202, 108, 75);
    glVertex2d(1288.5, 501);
    glVertex2d(1308.18, 487.77);
    glVertex2d(1308.18, 443.14);
    glVertex2d(1288.5, 462.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242, 138, 104);
    glVertex2d(1288.5, 501);
    glVertex2d(1288.5, 462.42);
    glVertex2d(1268.82, 443.14);
    glVertex2d(1268.82, 465.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166, 87, 60);
    glVertex2d(1288.5, 447.94);
    glVertex2d(1288.5, 462.42);
    glVertex2d(1313, 445.94);
    glVertex2d(1313, 431.47);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(202, 108, 75);
    glVertex2d(1288.5, 447.94);
    glVertex2d(1288.5, 462.42);
    glVertex2d(1264, 445.94);
    glVertex2d(1264, 431.47);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(202, 108, 75);
    glVertex2d(1288.5, 415);
    glVertex2d(1264, 431.47);
    glVertex2d(1288.5, 447.94);
    glVertex2d(1313, 431.47);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(166, 87, 60);
    glVertex2d(1288.5, 441.89);
    glVertex2d(1288.5, 421.05);
    glVertex2d(1273, 431.47);
    glEnd();

    //jendela samping
    glBegin(GL_POLYGON);
    glColor3ub(117, 99, 71);
    glVertex2d(1294, 518.02);
    glVertex2d(1298.64, 521.13);
    glVertex2d(1298.64, 571.21);
    glVertex2d(1294, 568.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155, 130, 96);
    glVertex2d(1298.64, 521.13);
    glVertex2d(1298.64, 571.21);
    glVertex2d(1336, 546.17);
    glVertex2d(1336, 496.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186 , 156, 116);
    glVertex2d(1331.36, 493);
    glVertex2d(1294, 518.02);
    glVertex2d(1298.64, 521.13);
    glVertex2d(1336, 496.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(101, 179, 220);
    glVertex2d(1302.28, 523.57);
    glVertex2d(1332.36, 503.41);
    glVertex2d(1332.36, 543.73);
    glVertex2d(1302.28, 563.89);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(155  , 130, 96);
    glVertex2d(1322.83, 504.92);
    glVertex2d(1318.94, 507.53);
    glVertex2d(1318.94, 557.61);
    glVertex2d(1322.83, 555);
    glEnd();



}

void kaca   () {

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);


    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(662.84, 391.6);
    glVertex2d(662.84, 409.53);
    glVertex2d(765.8, 467.36);
    glVertex2d(765.8, 448.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(765.8, 448.8);
    glVertex2d(765.8, 467.36);
    glVertex2d(903.33, 389.77);
    glVertex2d(903.33, 372.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(662.84, 391.6);
    glVertex2d(662.84, 409.53);
    glVertex2d(904, 272);
    glVertex2d(904, 253);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(904, 272);
    glVertex2d(904, 253);
    glVertex2d(993, 308);
    glVertex2d(993, 328);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(686.2, 490.91);
    glVertex2d(686.2, 506.61);
    glVertex2d(668.49, 516.58);
    glVertex2d(668.49, 500.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(668.49, 516.58);
    glVertex2d(668.49, 500.67);
    glVertex2d(718.78, 528.83);
    glVertex2d(718.78, 544.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(718.78, 528.83);
    glVertex2d(718.78, 544.4);
    glVertex2d(735.12, 534.76);
    glVertex2d(735.12, 518.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(794.25,  508.83);
    glVertex2d(794.25, 534.2);
    glVertex2d(810.18, 543.01);
    glVertex2d(810.18, 518.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(810.18, 543.01);
    glVertex2d(810.18, 518.06);
    glVertex2d(885.34, 477.55);
    glVertex2d(885.34, 501.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(885.34, 477.55);
    glVertex2d(885.34, 501.42);
    glVertex2d(869.41, 492.44);
    glVertex2d(869.41, 467.07);
    glEnd();

}

void pohon() {
    //daun 1
    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(592.44, 549.15);
    glVertex2d(592.31, 559.19);
    glVertex2d(564.49, 538.38);
    glVertex2d(564.61, 529.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(592.44, 549.15);
    glVertex2d(592.31, 559.19);
    glVertex2d(620.41, 540.93);
    glVertex2d(620.55, 530.38);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(592.44, 549.15);
    glVertex2d(620.55, 530.38);
    glVertex2d(592.95, 510.54);
    glVertex2d(564.61, 529.1);
    glEnd();

    //tiang pohon
    glBegin(GL_POLYGON);
    glColor3ub(150, 84, 29);
    glVertex2d(592.21, 533.31);
    glVertex2d(598.77, 528.31);
    glVertex2d(598.86, 344.6);
    glVertex2d(592.3, 344.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86, 48, 10);
    glVertex2d(592.21, 533.31);
    glVertex2d(585.76, 528.31);
    glVertex2d(585.85, 344.6);
    glVertex2d(592.3, 344.6);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150, 84, 29);
    glVertex2d(598.57, 442.57);
    glVertex2d(598.61, 451.98);
    glVertex2d(615.6, 440.23);
    glVertex2d(615.6, 421.88);
    glVertex2d(609.1,425.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(86, 48, 10);
    glVertex2d(603.9, 421.88);
    glVertex2d(609.1, 425.84);
    glVertex2d(609.1, 435.18);
    glVertex2d(603.9, 431.05);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175, 110, 65);
    glVertex2d(609.1, 435.18);
    glVertex2d(603.9, 431.05);
    glVertex2d(598.7, 435.7);
    glVertex2d(598.7, 442.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150, 84, 29);
    glVertex2d(592.3, 378.8);
    glVertex2d(592.61, 385.43);
    glVertex2d(576.6, 394.7);
    glVertex2d(581.8, 384.28);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150, 84, 29);
    glVertex2d(576.6, 394.7);
    glVertex2d(576.6, 364.05);
    glVertex2d(581.8, 360.09);
    glVertex2d(581.8, 384.28);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175, 110, 65);
    glVertex2d(581.8, 376.3);
    glVertex2d(585.76, 374.19);
    glVertex2d(592.3, 378.2);
    glVertex2d(581.8, 384.28);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(175, 110, 29);
    glVertex2d(571.4, 360.09);
    glVertex2d(576.6, 364.25);
    glVertex2d(581.8, 360.09);
    glVertex2d(576.55, 356.01);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(571.4, 360.09);
    glVertex2d(576.6, 364.25);
    glVertex2d(576.6, 394.7);
    glVertex2d(571.4, 390.94);
    glEnd();

    //ddaun
    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(564.49, 510.54);
    glVertex2d(580.5, 522.41);
    glVertex2d(581.05, 540.94);
    glVertex2d(564.61, 529.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(580.5, 522.41);
    glVertex2d(581.05, 540.94);
    glVertex2d(596.4, 532.94);
    glVertex2d(595.54, 513.62);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(578.47, 502.33);
    glVertex2d(564.49, 510.54);
    glVertex2d(580.5, 522.41);
    glVertex2d(595.54,  513.62);
    glEnd();

    //ddanunn
    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(609.1, 400.97);
    glVertex2d(609.1, 425.84);
    glVertex2d(628.59, 414.98);
    glVertex2d(628.59, 406.32);
    glVertex2d(623.72, 403.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(623.72, 403.73);
    glVertex2d(628.59, 398.37);
    glVertex2d(628.59, 388.23);
    glVertex2d(609.1, 400.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(598.7, 393.3);
    glVertex2d(609.1, 400.97);
    glVertex2d(609.1, 425.84);
    glVertex2d(598.7, 418.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(609.04, 400.97);
    glVertex2d(628.59, 388.23);
    glVertex2d(616.73, 380.12);
    glVertex2d(598.7, 393.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(598.7, 393.3);
    glVertex2d(611.38, 380.99);
    glVertex2d(609.84, 374.19);
    glVertex2d(598.7, 384.28);
    glEnd();

    //dddanun
    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(553.2, 328.49);
    glVertex2d(592.2, 357.39);
    glVertex2d(592.2, 325.11);
    glVertex2d(553.2, 296.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(592.2, 357.39);
    glVertex2d(616.23, 341.61);
    glVertex2d(615.28, 338.14);
    glVertex2d(592.2, 325.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(615.28, 338.14);
    glVertex2d(592.2, 325.11);
    glVertex2d(632.49, 303.49);
    glVertex2d(632.49, 312.11);
    glVertex2d(630.38, 319.31);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(630.38, 319.31);
    glVertex2d(632.49, 325.89);
    glVertex2d(632.49, 333.41);
    glVertex2d(615.28, 338.14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(553.2, 296.73);
    glVertex2d(592.2, 325.11);
    glVertex2d(632.49, 300.83);
    glVertex2d(632.49, 294.54);
    glVertex2d(563.6, 291.28);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(563.6, 291.28);
    glVertex2d(592.2, 313.08);
    glVertex2d(592.2,280.04);
    glVertex2d(563.6, 259.51);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(592.2, 313.08);
    glVertex2d(592.2,280.04);
    glVertex2d(623.39, 261.97);
    glVertex2d(623.39, 294.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(563.6, 259.51);
    glVertex2d(592.2, 280.04);
    glVertex2d(623.39, 261.97);
    glVertex2d(615.6, 256.66);
    glVertex2d(571.4, 255.71);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(571.4, 255.71);
    glVertex2d(592.2, 270.86);
    glVertex2d(592.2, 241.81);
    glVertex2d(571.4, 225.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(592.2, 270.86);
    glVertex2d(592.2, 241.81);
    glVertex2d(615.6, 227.61);
    glVertex2d(615.6, 256.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(571.4, 225.03);
    glVertex2d(592.2, 241.81);
    glVertex2d(615.6, 227.61);
    glVertex2d(611.7, 224.42);
    glVertex2d(575.3, 222.71);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(129, 147, 22);
    glVertex2d(575.3, 222.71);
    glVertex2d(592.2, 235.79);
    glVertex2d(592.2, 230.14);
    glVertex2d(575.3, 216.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(592.2, 235.79);
    glVertex2d(592.2, 230.14);
    glVertex2d(611.7, 218.58);
    glVertex2d(611.7, 224.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);

    glVertex2d(592.2, 230.14);
    glVertex2d(611.7, 218.58);
    glVertex2d(593.75, 205.34);
    glVertex2d(575.3, 216.85);
    glEnd();
}

void pohon_jalan () {
    //pohon1
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1726.09+cos(rad)*9.5,719.33+sin(rad)*9.5);
    }

    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(1717.86, 666.93);
    glVertex2d(1734.32, 666.93);
    glVertex2d(1734.32, 717.76);
    glVertex2d(1717.86, 717.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1726.09+cos(rad)*45.5,643.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1713.03+cos(rad)*23.5,631.71+sin(rad)*23.5);
    }
    glEnd();

    //pohon2
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1608.09+cos(rad)*9.5,794.82+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(1615.49, 787.53);
    glVertex2d(1600.69, 787.53);
    glVertex2d(1600.69, 743.59);
    glVertex2d(1615.49, 743.59);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1608.09+cos(rad)*45.5,720.92+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1596.14+cos(rad)*23.5,710.13+sin(rad)*23.5);
    }
    glEnd();
    //pohon3
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1500.09+cos(rad)*9.5,878.33+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(1508.32, 825.93);
    glVertex2d(1508.32, 876.76);
    glVertex2d(1491.6, 876.76);
    glVertex2d(1491.6, 825.93);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1500.09+cos(rad)*45.5,802.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1486.03+cos(rad)*23.5,790.71+sin(rad)*23.5);
    }
    glEnd();

    //pohon4
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1378.09+cos(rad)*9.5,963.33+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2f(1369.86, 910.93);
    glVertex2f(1386.32, 910.93);
    glVertex2f(1386.32, 961.76);
    glVertex2f(1369.86, 961.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1378.09+cos(rad)*45.5,887.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1364.03+cos(rad)*23.5,875.71+sin(rad)*23.5);
    }
    glEnd();

    //lampu1
    glBegin(GL_POLYGON);
    glColor3ub(81,81,80);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1181.18+cos(rad)*5.5,1061.47+sin(rad)*5.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(150, 150, 150);
    glVertex2f(1178.4, 1060.38);
    glVertex2f(1178.89, 916.24);
    glVertex2f(1183.75, 916.24);
    glVertex2f(1184.29, 1060.24);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,214,40);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1182+cos(rad)*18.5,919.87+sin(rad)*18.5);
    }
    glEnd();

    //pohon 5
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(770.09+cos(rad)*9.5,1051.33+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(761.88, 1043.88);
    glVertex2d(761.86, 998.93);
    glVertex2d(778.32, 998.93);
    glVertex2d(778.32, 1043.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(770.09+cos(rad)*45.5,975.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(756.03+cos(rad)*23.5,963.71+sin(rad)*23.5);
    }
    glEnd();

    //pohon 6
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(617.09+cos(rad)*9.5,939.33+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(608.86, 931.88);
    glVertex2d(608.86, 886.93);
    glVertex2d(625.32, 886.93);
    glVertex2d(625.32, 937.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(617.09+cos(rad)*45.5,863.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(603.03+cos(rad)*23.5,849.71+sin(rad)*23.5);
    }
    glEnd();

    //pohon 7
    glBegin(GL_POLYGON);
    glColor3ub(140,100,77);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(184.09+cos(rad)*9.5,655.33+sin(rad)*9.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(165, 118, 103);
    glVertex2d(175.86, 647.88);
    glVertex2d(175.86, 602.93);
    glVertex2d(192.32, 602.93);
    glVertex2d(192.32, 653.76);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(107,156,49);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(184.09+cos(rad)*45.5,579.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(126,184,59);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(170.03+cos(rad)*23.5,565.71+sin(rad)*23.5);
    }
    glEnd();




}

void kincir () {
    //tiang kncir
    glBegin(GL_POLYGON);
    glColor3ub(42, 108, 153);
    glVertex2d(1396.76, 625.62);
    glVertex2d(1415.59, 616.14);
    glVertex2d(1415.61, 623.17);
    glVertex2d(1396.79, 632.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(29, 74, 105);
    glVertex2d(1396.76, 625.62);
    glVertex2d(1396.79, 632.65);
    glVertex2d(1386.69, 627.53);
    glVertex2d(1386.67, 620.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(31, 81, 113);
    glVertex2d(1396.76, 625.62);
    glVertex2d(1415.59, 616.14);
    glVertex2d(1405.49, 611.02);
    glVertex2d(1386.67, 620.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(42, 108, 153);
    glVertex2d(1411.22, 618.34);
    glVertex2d(1401.11, 623.43);
    glVertex2d(1401, 464);
    glVertex2d(1410.67, 464.49);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(29, 74, 105);
    glVertex2d(1401, 464);
    glVertex2d(1390.68, 460.11);
    glVertex2d(1391.01, 618.31);
    glVertex2d(1401.11, 623.43);
    glEnd();

    //baling
    glBegin(GL_POLYGON);
    glColor3ub(249, 249, 249);
    glVertex2d(1394.42, 453.81);
    glVertex2d(1405.78, 470.47);
    glVertex2d(1328.22, 554.17);
    glVertex2d(1333.53, 536.41);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(1394.42, 453.81);
    glVertex2d(1396.7, 367.14);
    glVertex2d(1407.13,374.09);
    glVertex2d(1421.35, 443.9);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(1421.35, 443.9);
    glVertex2d(1494, 452.31);
    glVertex2d(1482.67, 461.35);
    glVertex2d(1405.78, 470.47);
    glEnd();


}
void pager () {
    //pondasi pager
    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(383, 453.87);
    glVertex2d(383, 463.51);
    glVertex2d(808.34, 735.7);
    glVertex2d(808.34, 726.81);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 244, 178);
    glVertex2d(383, 453.87);
    glVertex2d(384.73, 453.88);
    glVertex2d(810, 726.81);
    glVertex2d(808.34, 726.81);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(808.34, 735.7);
    glVertex2d(808.34, 726.81);
    glVertex2d(810, 726.81);
    glVertex2d(810, 735.7);
    glEnd();

    //pager 1
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(388.29, 438.86);
    glVertex2d(392.6, 433.45);
    glVertex2d(398.43, 445.54);
    glVertex2d(398.43, 533.87);
    glVertex2d(388.29, 527.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(392.6, 433.45);
    glVertex2d(396.33, 431);
    glVertex2d(402.15, 443.09);
    glVertex2d(398.43, 445.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(402.15, 443.09);
    glVertex2d(398.43, 445.54);
    glVertex2d(398.43, 533.87);
    glVertex2d(402.15, 531.42);
    glEnd();

    //pager 2
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(413.94, 455.34);
    glVertex2d(418.25, 449.93);
    glVertex2d(424.08, 462.02);
    glVertex2d(424.08, 550.35);
    glVertex2d(413.94, 543.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(418.25, 449.93);
    glVertex2d(421.98, 447.48);
    glVertex2d(427.8, 459.57);
    glVertex2d(424.08, 462.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(427.8, 459.57);
    glVertex2d(424.08, 462.02);
    glVertex2d(424.08, 550.35);
    glVertex2d(427.8, 547.9);
    glEnd();

    //pager 3
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(443.08, 464.67);
    glVertex2d(448.9, 476.76);
    glVertex2d(448.9, 565.09);
    glVertex2d(438.76, 558.41);
    glVertex2d(438.76, 470.08);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(443.08, 464.67);
    glVertex2d(448.9, 476.76);
    glVertex2d(452.63, 474.3);
    glVertex2d(446.8, 462.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(452.63, 474.3);
    glVertex2d(448.9, 476.76);
    glVertex2d(448.9, 565.09);
    glVertex2d(452.63, 562.64);
    glEnd();


    //pager4
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(471.73, 481.15);
    glVertex2d(477.55, 493.23);
    glVertex2d(477.55, 581.57);
    glVertex2d(467.41, 574.89);
    glVertex2d(467.41, 486.56);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(471.73, 481.15);
    glVertex2d(477.55, 493.23);
    glVertex2d(481.28, 490.78);
    glVertex2d(475.45, 478.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(477.55, 493.23);
    glVertex2d(481.28, 490.78);
    glVertex2d(477.55, 581.57);
    glVertex2d(481.28, 579.11);
    glEnd();

    //pager 5
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(499.55, 503.89);
    glVertex2d(505.38, 515.97);
    glVertex2d(505.38, 604.3);
    glVertex2d(495.24, 597.63);
    glVertex2d(495.24, 509.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(499.55, 503.89);
    glVertex2d(505.38, 515.97);
    glVertex2d(509.1,513.52);
    glVertex2d(503.28, 501.43);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(505.38, 515.97);
    glVertex2d(509.1,513.52);
    glVertex2d(509.1,601.85);
    glVertex2d(505.38, 604.3);
    glEnd();

    //pager6
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(526.2, 520.36);
    glVertex2d(532.03, 532.45);
    glVertex2d(532.03, 620.78);
    glVertex2d(521.89, 614.11);
    glVertex2d(521.89, 525.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(526.2, 520.36);
    glVertex2d(532.03, 532.45);
    glVertex2d(535.75,530);
    glVertex2d(529.92, 517.91);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(532.03, 532.45);
    glVertex2d(535.75,530);
    glVertex2d(535.75, 618.33);
    glVertex2d(532.03, 620.78);
    glEnd();

    //pager 7
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(553.03, 539.1);
    glVertex2d(558.55, 551.19);
    glVertex2d(558.85, 639.52);
    glVertex2d(548.71, 632.85);
    glVertex2d(548.71,544.51);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(553.03, 539.1);
    glVertex2d(558.55, 551.19);
    glVertex2d(562.58, 548.74);
    glVertex2d(556.75, 536.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(558.55, 551.19);
    glVertex2d(562.58, 548.74);
    glVertex2d(562.58, 637.07);
    glVertex2d(558.85, 639.52);
    glEnd();


    //pager 8
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(581.68, 558.58);
    glVertex2d(587.5, 570.67);
    glVertex2d(587.5, 659);
    glVertex2d(577.36, 652.32);
    glVertex2d(577.36, 563.99);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(581.68, 558.58);
    glVertex2d(587.5, 570.67);
    glVertex2d(591.23, 568.22);
    glVertex2d(585.4, 556.13);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(587.5, 570.67);
    glVertex2d(591.23, 568.22);
    glVertex2d(591.23, 656.55);
    glVertex2d(587.5, 659);
    glEnd();

    //pager9
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(610.25, 577.26);
    glVertex2d(615.86, 588.41);
    glVertex2d(615.86, 669.89);
    glVertex2d(606.09, 663.73);
    glVertex2d(606.09, 582.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(610.25, 577.26);
    glVertex2d(615.86, 588.41);
    glVertex2d(619.45, 586.15);
    glVertex2d(613.84, 575);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(615.86, 588.41);
    glVertex2d(619.45, 586.15);
    glVertex2d(619.45, 667.63);
    glVertex2d(615.86, 669.89);
    glEnd();

    //pager10
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(637.58, 594.92);
    glVertex2d(643.2, 606.07);
    glVertex2d(643.2, 687.55);
    glVertex2d(633.43, 681.39);
    glVertex2d(633.43, 599.91);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(637.58, 594.92);
    glVertex2d(643.2, 606.07);
    glVertex2d(646.78, 603.81);
    glVertex2d(641.17, 592.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(643.2, 606.07);
    glVertex2d(646.78, 603.81);
    glVertex2d(646.78, 685.28);
    glVertex2d(643.2, 687.55);
    glEnd();

    //pager11
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(666.92, 612.57);
    glVertex2d(672.53, 623.72);
    glVertex2d(672.53, 705.2);
    glVertex2d(662.76, 699.04);
    glVertex2d(662.76, 617.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(666.92, 612.57);
    glVertex2d(672.53, 623.72);
    glVertex2d(676.12, 621.46);
    glVertex2d(670.51, 610.31);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(672.53, 623.72);
    glVertex2d(676.12, 621.46);
    glVertex2d(676.12, 702.94);
    glVertex2d(672.53, 705.2);
    glVertex2d(672.53, 623.72);
    glEnd();

    //pager 12
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(693.25,  630.23);
    glVertex2d(698.87, 641.38);
    glVertex2d(698.87, 722.86);
    glVertex2d(689.1, 716.7);
    glVertex2d(689.1, 635.22);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(693.25,  630.23);
    glVertex2d(698.87, 641.38);
    glVertex2d(702.45, 639.12);
    glVertex2d(696.84, 627.97);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(698.87, 641.38);
    glVertex2d(702.45, 639.12);
    glVertex2d(702.45, 720.6);
    glVertex2d(698.87, 722.86);
    glEnd();


    //pager 13
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(721.42, 647.06);
    glVertex2d(727.03, 658.21);
    glVertex2d(727.03, 739.69);
    glVertex2d(717.27, 733.53);
    glVertex2d(717.27, 652.05);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(721.42, 647.06);
    glVertex2d(727.03, 658.21);
    glVertex2d(730.62, 655.95);
    glVertex2d(725.01, 644.8);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(727.03, 658.21);
    glVertex2d(730.62, 655.95);
    glVertex2d(730.62, 737.43);
    glVertex2d(727.03, 739.69);
    glEnd();

    //pager 14
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(747.59, 663.89);
    glVertex2d(753.2, 675.04);
    glVertex2d(753.2, 756.52);
    glVertex2d(743.43, 750.36);
    glVertex2d(743.43, 668.88);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(747.59, 663.89);
    glVertex2d(753.2, 675.04);
    glVertex2d(756.79, 672.78);
    glVertex2d(751.18, 661.63);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(753.2, 675.04);
    glVertex2d(756.79, 672.78);
    glVertex2d(756.79, 754.25);
    glVertex2d(753.2, 756.52);
    glEnd();

    //pager15
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(773.76, 680.72);
    glVertex2d(779.37, 691.87);
    glVertex2d(779.37, 773.34);
    glVertex2d(769.6, 767.19);
    glVertex2d(769.6, 685.71);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(773.76, 680.72);
    glVertex2d(779.37, 691.87);
    glVertex2d(782.96, 689.6);
    glVertex2d(777.34, 678.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(779.37, 691.87);
    glVertex2d(782.96, 689.6);
    glVertex2d(782.96, 771.08);
    glVertex2d(779.37, 773.34);
    glEnd();

    //pager16
    glBegin(GL_POLYGON);
    glColor3ub(255, 224, 178);
    glVertex2d(799.09, 696.37);
    glVertex2d(804.7, 707.52);
    glVertex2d(804.7, 789);
    glVertex2d(794.94, 782.84);
    glVertex2d(794.94, 701.36);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(247, 197, 129);
    glVertex2d(799.09, 696.37);
    glVertex2d(804.7, 707.52);
    glVertex2d(808.29, 705.26);
    glVertex2d(802.68, 694.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196, 149, 88);
    glVertex2d(804.7, 707.52);
    glVertex2d(808.29, 705.26);
    glVertex2d(808.29, 786.74);
    glVertex2d(804.7, 789);
    glEnd();




}

void marka() {
    //zebra cross
    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1051.96,975.53);
    glVertex2d(1065.15, 984.68);
    glVertex2f(1118.97, 946.53);
    glVertex2f(1106.73, 937.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1072.54, 989.01);
    glVertex2d(1085.65, 997.9);
    glVertex2d(1139.59, 959.93);
    glVertex2d(1127.21, 951.32);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1094.12, 1003.65);
    glVertex2f(1107.14, 1012.67);
    glVertex2d(1161.21, 974.43);
    glVertex2d(1149.01, 965.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1116.12, 1018.92);
    glVertex2d(1129.21, 1028.21);
    glVertex2d(1183.44, 990.22);
    glVertex2d(1171, 981.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(902.07, 984.57);
    glVertex2d(915.38, 975.43);
    glVertex2d(860.15, 937.73);
    glVertex2d(847.8, 946.42);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(803.87, 976.11);
    glVertex2f(816.18, 967.36);
    glVertex2d(871.54, 1005.33);
    glVertex2d(858.4, 1014.35);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(880.08, 999.35);
    glVertex2d(893.31, 990.37);
    glVertex2d(838.16, 952.68);
    glVertex2d(825.68, 961.29);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2f(835.87, 1030.19);
    glVertex2d(849.07, 1020.9);
    glVertex2d(793.72, 983.2);
    glVertex2d(781.21, 992.2);
    glEnd();

    //kanan
    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1195.03, 916.78);
    glVertex2f(1201.68, 921.44);
    glVertex2d(1255, 884.63);
    glVertex2d(1248.33, 880);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1317, 834.51);
    glVertex2d(1324.48, 840);
    glVertex2d(1387, 798.31);
    glVertex2d(1379.27, 793);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1462, 740.02);
    glVertex2d(1469.59, 745);
    glVertex2d(1530.43,705.64);
    glVertex2d(1522.82, 700.69);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(1582, 660.09);
    glVertex2d(1588.29, 665);
    glVertex2d(1641, 627.78);
    glVertex2d(1634.54, 623);
    glEnd();

    //kiri
    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(775.16, 934);
    glVertex2d(781, 929.65);
    glVertex2d(732.36, 896.72);
    glVertex2d(726.32, 900.93);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2d(644.98, 848);
    glVertex2d(651, 843.78);
    glVertex2d(600.89, 811.88);
    glVertex2d(594.66, 815.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(504.41, 756);
    glVertex2d(510, 751.9);
    glVertex2d(463.44, 720.88);
    glVertex2d(457.66, 724.85);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(368.39, 661.7);
    glVertex2d(374.14, 657.91);
    glVertex2d(330.46, 628);
    glVertex2d(325, 631.75);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 219, 218);
    glVertex2d(265.12, 593.73);
    glVertex2d(271.1, 589.55);
    glVertex2d(221.15, 558);
    glVertex2d(215, 562.07);
    glEnd();

}
void rumput () {
    glBegin(GL_POLYGON);
    glColor3ub(114, 137, 19);
    glVertex2d(807, 798.75);
    glVertex2d(981.71, 911.44);
    glVertex2d(981.71, 876.07);
    glVertex2d(807, 761.81);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(981.71, 911.44);
    glVertex2d(981.71, 876.07);
    glVertex2d(1103.26, 799.13);
    glVertex2d(1103.26, 836.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(1103.26, 799.13);
    glVertex2d(1071.88, 782.08);
    glVertex2d(980.63, 841.52);
    glVertex2d(981.71, 876.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(980.63, 841.52);
    glVertex2d(981.71, 876.07);
    glVertex2d(807, 761.81);
    glVertex2d(833.25, 743.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(812.94, 750.21);
    glVertex2d(812.94, 758.63);
    glVertex2d(981.71, 868.25);
    glVertex2d(981.71, 860.69);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(91, 104, 14);
    glVertex2d(981.71, 868.25);
    glVertex2d(981.71, 860.69);
    glVertex2d(1098.05,789.16);
    glVertex2d(1098.05, 796.29);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(1068.67, 775);
    glVertex2d(1098.05, 789.16);
    glVertex2d(981.71, 860.69);
    glVertex2d(979.11, 831.68);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(981.71, 860.69);
    glVertex2d(979.11, 831.68);
    glVertex2d(833.45, 737);
    glVertex2d(812.94, 750.21);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 137, 19);
    glVertex2d(934, 608.52);
    glVertex2d(1021.47, 668.43);
    glVertex2d(1021.47, 692.04);
    glVertex2d(934, 631.62);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 137, 19);
    glVertex2d(1021.47, 668.43);
    glVertex2d(1021.47, 692.04);
    glVertex2d(1037.07, 678.55);
    glVertex2d(1037.07, 655.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(1021.47, 668.43);
    glVertex2d(1037.07, 655.1);
    glVertex2d(952.23, 597.22);
    glVertex2d(934, 608.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 137, 19);
    glVertex2d(938.13, 601.26);
    glVertex2d(938.13, 606.52);
    glVertex2d(1021.47, 663.2);
    glVertex2d(1021.47, 657.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(114, 137, 19);
    glVertex2d(1021.47, 663.2);
    glVertex2d(1021.47, 657.3);
    glVertex2d(1033.61, 647.52);
    glVertex2d(1033.61, 652.96);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 204, 39);
    glVertex2d(1021.47, 657.3);
    glVertex2d(1033.61, 647.52);
    glVertex2d(952.36, 593);
    glVertex2d(938.13, 601.26);
    glEnd();


}
void tambahan () {
    glBegin(GL_POLYGON);
    glColor3ub(204, 196, 192);
    glVertex2d(549, 878);
    glVertex2d(591, 906);
    glVertex2d(474, 980);
    glVertex2d(432,952);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 196, 192);
    glVertex2d(598, 1080);
    glVertex2d(474, 980);
    glVertex2d(432, 952);
    glVertex2d(264, 845);
    glVertex2d(110, 1080);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204, 196, 192);
    glVertex2d(1521, 925);
    glVertex2d(1621, 849);
    glVertex2d(1696, 799);
    glVertex2d(1920, 799);
    glVertex2d(1920, 1080);
    glVertex2d(1635, 1080);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158, 183, 118);
    glVertex2d(1589, 873);
    glVertex2d(1621, 849);
    glVertex2d(1546, 798);
    glVertex2d(1515, 819);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(240, 228, 211);
    glVertex2d(1588.84, 837.11);
    glVertex2d(1607.91, 850.07);
    glVertex2d(1589.53, 863.8);
    glVertex2d(1571.01, 850.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(240, 228, 211);
    glVertex2d(1538.03, 826.3);
    glVertex2d(1554.87, 813.09);
    glVertex2d(1572.91, 826.07);
    glVertex2d(1555.55, 839.78);
    glEnd();

}

void halte () {
    //pondasi
    glBegin(GL_POLYGON);
    glColor3ub(204, 170, 125);
    glVertex2d(272.37, 832.83);
    glVertex2d(361.39, 777.65);
    glVertex2d(522.32, 877.54);
    glVertex2d(433.89, 933.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(433.98, 932.58);
    glVertex2d(433.98, 936);
    glVertex2d(522.19, 880.69);
    glVertex2d(522.32, 877.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191, 138, 75);
    glVertex2d(433.98, 932.58);
    glVertex2d(433.98, 936);
    glVertex2d(272, 835.24);
    glVertex2d(272.37, 832.83);
    glEnd();

    //kursi
    glBegin(GL_POLYGON);
    glColor3ub(153, 100, 51);
    glVertex2d(284.37, 807.06);
    glVertex2d(306.18, 793.11);
    glVertex2d(447.8, 882);
    glVertex2d(425.58, 897.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 81, 49);
    glVertex2d(284.37, 807.06);
    glVertex2d(425.58, 897.03);
    glVertex2d(425.58, 899.93);
    glVertex2d(284,809.48);
    glEnd();

    //tiang
    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(276.75, 709.58);
    glVertex2d(280.39, 707.22);
    glVertex2d(280.16, 832.99);
    glVertex2d(276.75, 835.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(433.98, 931.81);
    glVertex2d(437.39, 929.61);
    glVertex2d(437.62, 803.84);
    glVertex2d(433.98, 806.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(433.98, 805.23);
    glVertex2d(433.98, 811.04);
    glVertex2d(524, 754.78);
    glVertex2d(524, 748.88);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191, 138, 75);
    glVertex2d(433.98,931.81);
    glVertex2d(430.38, 929.61);
    glVertex2d(430.38, 803.34);
    glVertex2d(433.98, 806.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191, 138, 75);
    glVertex2d(433.98, 811.04);
    glVertex2d(433.98, 805.23);
    glVertex2d(272.97, 705.29);
    glVertex2d(273.15, 710.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191, 138, 75);
    glVertex2d(273.15, 832.99);
    glVertex2d(276.75, 835.19);
    glVertex2d(276.75, 709.58);
    glVertex2d(273.15, 707.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239, 188, 134);
    glVertex2d(524, 748.88);
    glVertex2d(513.82, 748.88);
    glVertex2d(363.17, 655.48);
    glVertex2d(363.17, 650);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239, 188, 134);
    glVertex2d(524, 748.88);
    glVertex2d(513.82, 748.88);
    glVertex2d(433.98, 799.33);
    glVertex2d(433.98, 805.23);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239, 188, 134);
    glVertex2d(433.98, 799.33);
    glVertex2d(433.98, 805.23);
    glVertex2d(283.47, 705.29);
    glVertex2d(272.97, 705.29);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239, 188, 134);
    glVertex2d(283.47, 705.29);
    glVertex2d(272.97, 705.29);
    glVertex2d(363.17, 650);
    glVertex2d(363.17, 655.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(363.17, 655.48);
    glVertex2d(363.17, 661.27);
    glVertex2d(288.63, 708.51);
    glVertex2d(283.47, 705.29);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(191, 138,75);
    glVertex2d(363.17, 655.48);
    glVertex2d(363.17, 661.27);
    glVertex2d(509.41, 751.66);
    glVertex2d(513.82, 748.88);
    glEnd();


}

void halte_kaca () {
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);


    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(280.39, 730.92);
    glVertex2d(280.16, 832.99);
    glVertex2d(431.58, 925.72);
    glVertex2d(430.38,827.19);
    glEnd();

    glBegin(GL_POLYGON);
    glColor4f(0.0, 1.0, 1.0, 0.1);
    glVertex2d(363.17, 659.34);
    glVertex2d(286.72, 707.32);
    glVertex2d(433.32, 798.74);
    glVertex2d(510.72, 750.38);
    glEnd();

}

void ayunan () {
    //bak pasir
    glBegin(GL_POLYGON);
    glColor3ub(220, 220, 220);
    glVertex2d(1731.24, 876.86);
    glVertex2d(1815, 927.11);
    glVertex2d(1731.78, 977.36);
    glVertex2d(1648.02, 927.11);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 208, 14);
    glVertex2d(1731.31, 895.53);
    glVertex2d(1789.56, 928.18);
    glVertex2d(1731.97, 962.95);
    glVertex2d(1674, 928.18);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(137, 137, 137);
    glVertex2d(1648.02, 927.11);
    glVertex2d(1648, 929.75);
    glVertex2d(1731.76, 980);
    glVertex2d(1731.78, 977.36);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(197, 197, 197);
    glVertex2d(1731.76, 980);
    glVertex2d(1731.78, 977.36);
    glVertex2d(1815, 927.11);
    glVertex2d(1814.98, 929.75);
    glEnd();
    //tiang main
    glBegin(GL_POLYGON);
    glColor3ub(251, 5, 15);
    glVertex2d(1746.06, 870.46);
    glVertex2d(1753.25, 873.86);
    glVertex2d(1753.56, 761.89);
    glVertex2d(1746.39, 750.78);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173, 0, 7);
    glVertex2d(1753.56,761.69);
    glVertex2d(1761.48, 761.41);
    glVertex2d(1761.19, 870.08);
    glVertex2d(1753.25, 873.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251, 5, 15);
    glVertex2d(1753.56, 761.89);
    glVertex2d(1746.39, 750.78);
    glVertex2d(1830.06, 790.32);
    glVertex2d(1822.84, 794.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(251, 5, 15);
    glVertex2d(1830.06, 790.32);
    glVertex2d(1822.84, 794.43);
    glVertex2d(1822.53, 906.6);
    glVertex2d(1829.73, 910);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(254, 111, 106);
    glVertex2d(1746.39, 750.78);
    glVertex2d(1830.06, 790.32);
    glVertex2d(1838, 786.54);
    glVertex2d(1754.33, 747);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173, 0, 7);
    glVertex2d(1830.06, 790.32);
    glVertex2d(1838, 786.54);
    glVertex2d(1837.67, 906.22);
    glVertex2d(1829.73, 910);
    glEnd();

    //AYUNAN
    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex2d(1768.59, 863.78);
    glVertex2d(1793.76, 877.75);
    glVertex2d(1806.66, 870.53);
    glVertex2d(1781.5, 856.56);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(240, 231, 216);
    glVertex2d(1779.65, 857.6);
    glVertex2d(1779.68, 846.25);
    glVertex2d(1804.85, 860.22);
    glVertex2d(1804.82, 871.57);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255, 255, 255);
    glVertex2d(1804.85, 860.22);
    glVertex2d(1806.69, 859.19);
    glVertex2d(1781.53, 845.22);
    glVertex2d(1779.68, 846.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(237, 206, 186);
    glVertex2d(1768.59, 863.78);
    glVertex2d(1793.76, 877.75);
    glVertex2d(1793.75, 879.7);
    glVertex2d(1768.59, 865.73);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(220, 206, 182);
    glVertex2d(1793.76, 877.75);
    glVertex2d(1793.75, 879.7);
    glVertex2d(1806.66,872.49);
    glVertex2d(1806.66, 870.54);
    glEnd();

    glBegin(GL_LINE_LOOP);
    glColor3ub(0, 0, 0);
    glVertex2d(1787.58, 778);
    glVertex2d(1800.77, 782);
    glVertex2d(1800.77, 858);
    glVertex2d(1787.58, 851);
    glEnd();

    //kursi taman
    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(350.43, 971.2);
    glVertex2d(350.43, 988);
    glVertex2d(369.68, 977.66);
    glVertex2d(369.68, 973.67);
    glVertex2d(362.15, 977.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(178, 126, 70);
    glVertex2d(350.43, 971.2);
    glVertex2d(350.43, 988);
    glVertex2d(346.58, 986.2);
    glVertex2d(346.58, 969.09);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(178, 126, 70);
    glVertex2d(362.09, 973.74);
    glVertex2d(362.15, 977.66);
    glVertex2d(293.82, 940.83);
    glVertex2d(293.62, 937.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(178, 126, 70);
    glVertex2d(303.26, 963.06);
    glVertex2d(303.26, 945.76);
    glVertex2d(306.15, 947.17);
    glVertex2d(306.15, 964.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140, 91,47);
    glVertex2d(362.09, 973.74);
    glVertex2d(362.15, 977.66);
    glVertex2d(382.72, 966.79);
    glVertex2d(382.7, 962.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 114, 69);
    glVertex2d(326.34,923.14);
    glVertex2d(330.07, 923.7);
    glVertex2d(326.34, 934.07);
    glVertex2d(323.58, 932.2);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140,91, 47);
    glVertex2d(326.34, 934.07);
    glVertex2d(329.11, 935.39);
    glVertex2d(332.52, 925.76);
    glVertex2d(330.07, 923.7);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 114, 69);
    glVertex2d(367.73, 957.03);
    glVertex2d(371.46, 946.66);
    glVertex2d(367.73, 946.1);
    glVertex2d(364.97, 955.15);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(140, 91, 47);
    glVertex2d(367.73, 957.03);
    glVertex2d(371.46, 946.66);
    glVertex2d(373.91, 948.72);
    glVertex2d(370.5, 958.35);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(204, 160, 113);
    glVertex2d(382.7, 962.92);
    glVertex2d(362.09, 973.74);
    glVertex2d(293.62, 937.16);
    glVertex2d(314.57, 926.14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(124, 79, 35);
    glVertex2d(306.15, 964.86);
    glVertex2d(322.52, 956.26);
    glVertex2d(306.15,  947.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(137, 129, 125);
    glVertex2d(362.09, 969.79);
    glVertex2d(375.81, 962.42);
    glVertex2d(314.72, 929.64);
    glVertex2d(300.4, 937.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(186, 134, 82);
    glVertex2d(389.75, 937.05);
    glVertex2d(385.9, 958.02);
    glVertex2d(316.12, 920.86);
    glVertex2d(320.13, 899.96);
    glEnd();

    //meja
    glBegin(GL_POLYGON);
    glColor3ub(64, 73, 74);
    glVertex2d(331.96, 1004.14);
    glVertex2d(327.87,1006.13);
    glVertex2d(327.87, 1033);
    glVertex2d(331.98, 1030.74);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 108, 109);
    glVertex2d(327.87,1006.13);
    glVertex2d(327.87, 1033);
    glVertex2d(323.36, 1030.8);
    glVertex2d(323.36, 1008.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(64, 73, 74);
    glVertex2d(264.39, 970.06);
    glVertex2d(260.3, 972.06);
    glVertex2d(260.3, 998.92);
    glVertex2d(264.41, 996.67);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(96, 108, 109);
    glVertex2d(260.3, 972.06);
    glVertex2d(260.3, 998.92);
    glVertex2d(255.79, 996.73);
    glVertex2d(255.79, 974.58);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(160, 174, 175);
    glVertex2d(324.77, 1014.49);
    glVertex2d(241, 971.08);
    glVertex2d(266.64, 958);
    glVertex2d(349.98, 1001.65);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(115, 129, 130);
    glVertex2d(341.55, 1001.06);
    glVertex2d(324.77, 1009.8);
    glVertex2d(249.3, 971.08);
    glVertex2d(266.82, 962.15);
    glEnd();

}

void awan () {
    //awan 1
    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(259.09+nol+cos(rad)*45.5,108.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(315.09+nol+cos(rad)*45.5,144.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(343.09+nol+cos(rad)*45.5,93.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(402.09+nol+cos(rad)*45.5,100.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(369.09+nol+cos(rad)*45.5,144.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(451.09+nol+cos(rad)*45.5,123.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(428.09+nol+cos(rad)*45.5,159.73+sin(rad)*45.5);
    }
    glEnd();

    //awan 2
    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(216.09-nol+cos(rad)*45.5,312.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(162.09-nol+cos(rad)*45.5,296.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(140.09-nol+cos(rad)*45.5,332.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(196.09-nol+cos(rad)*45.5,348.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(263.09-nol+cos(rad)*45.5,300.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(268.09-nol+cos(rad)*45.5,344.73+sin(rad)*45.5);
    }
    glEnd();

    //awan 3
    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1403.09+nol+cos(rad)*45.5,103.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1423.09+nol+cos(rad)*45.5,139.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1451.09+nol+cos(rad)*45.5,88.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1477.09+nol+cos(rad)*45.5,139.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1510.09+nol+cos(rad)*45.5,95.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1534.09+nol+cos(rad)*45.5,154.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1559.09+nol+cos(rad)*45.5,118.73+sin(rad)*45.5);
    }
    glEnd();

    //awan 4
    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1621.09-nol+cos(rad)*45.5,280.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1599.09-nol+cos(rad)*45.5,316.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1675.09-nol+cos(rad)*45.5,296.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1655.09-nol+cos(rad)*45.5,332.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1726.09-nol+cos(rad)*45.5,278.73+sin(rad)*45.5);
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(244,247,240);
    for (i=0; i <= 360; i++) {
        float rad = i*3.14159/180;
        glVertex2f(1727.09-nol+cos(rad)*45.5,320.73+sin(rad)*45.5);
    }
    glEnd();
}






int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);
    window = glfwCreateWindow(1920, 1080, "Fakhri Ahnaf D- <G64160107>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);


    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        langit();
        pondasi();
        depan();
        atas();
        menara();
        samping();
        kotak_samping();
        jendela_besar();
        tiang_atas();
        kolam_renang();
        aksesoris();
        warna();
        pintu();
        jendela_menara();
        kaca();
        pohon();
        taman();
        kincir();
        rumput();
        pager();
        jalan();
        marka();
        halte();
        halte_kaca();
        tambahan();
        ayunan();
        pohon_jalan();
        awan();
        bintang();
        kelip();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}

