//latihan bikin nama
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

/////warna/////
#define biruLangit 143, 202, 196
#define coklatTembok 191, 155, 129
#define coklatLala 140, 114, 94
#define coklatTua 98, 80, 66
#define kuningTanah 208, 173, 52
#define kuningBawah 195, 138, 45
#define putih 255, 255, 255
#define kuningMatahari 255, 187, 55
#define biruJendela 207, 233, 237
#define lightgray 247, 247, 247
#define darkbrown 57, 47, 38
#define matahariWarna 232, 186, 52
#define merahBata 180, 48, 26
#define biruDongker 37, 35, 76
#define kelip1 250, 255, 170
#define kelip2 255, 220, 170
#define kelip3 255, 204, 228
#define hijauTanah 89, 214, 76
#define hijauBawah 74, 174, 66
#define biruLangitGelap 38, 38, 59
#define warnaBulan 207, 201, 135
#define awanGelap 90, 90, 90

//kelapkelip
int clindex=0,buff=0;
int colorf[3][3]={{kelip1},{kelip2},{kelip3}};


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 0, -1); //

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    // your drawing code here, maybe
    /*glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glBegin(GL_TRIANGLES);
    glColor3f(1.f, 0.f, 0.f);
    glVertex3f(-0.6f, -0.4f, 0.f);
    glColor3f(0.f, 1.f, 0.f);
    glVertex3f(0.6f, -0.4f, 0.f);
    glColor3f(0.f, 0.f, 1.f);
    glVertex3f(0.f, 0.6f, 0.f);
    glEnd();*/
    glClear(GL_COLOR_BUFFER_BIT);

    glFlush();
}

void bground()
{
    glBegin(GL_POLYGON);

    glColor3ub(biruLangitGelap);

    glVertex2d(0, 0);
    glVertex2d(800, 0);
    glVertex2d(800, 800);
    glVertex2d(0, 800);

    glEnd();

}

void tanah()
{
    glBegin(GL_POLYGON);

    glColor3ub(hijauBawah);

    glVertex2d(14, 662);
    glVertex2d(568, 662);
    glVertex2d(568, 700);
    glVertex2d(14, 700);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(hijauBawah);

    glVertex2d(568, 662);
    glVertex2d(760, 502);
    glVertex2d(760, 536);
    glVertex2d(568, 700);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(hijauTanah);

    glVertex2d(258, 502);
    glVertex2d(760, 502);
    glVertex2d(568, 662);
    glVertex2d(14, 662);

    glEnd();

    //aspal

    glBegin(GL_POLYGON);

    glColor3ub(merahBata);

    glVertex2d(273, 568);
    glVertex2d(363, 568);
    glVertex2d(265, 662);
    glVertex2d(165, 662);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100, 100, 100);

    glVertex2d(590, 572);
    glVertex2d(465, 572);
    glVertex2d(375, 663);
    glVertex2d(505, 663);

    glEnd();

}

void lantai1()
{
    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(177, 422);
    glVertex2d(454, 422);
    glVertex2d(454, 572);
    glVertex2d(177, 572);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(272, 496);
    glVertex2d(345, 496);
    glVertex2d(345, 572);
    glVertex2d(272, 572);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(coklatTua);

    glVertex2d(272, 496);
    glVertex2d(292, 496);
    glVertex2d(292, 554);
    glVertex2d(272, 572);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(coklatTua);

    glVertex2d(292, 496);
    glVertex2d(345, 496);
    glVertex2d(345, 554);
    glVertex2d(292, 554);

    glEnd();

    //pintu

    glBegin(GL_POLYGON);

    glColor3ub(255, 222, 202);

    glVertex2d(301, 518);
    glVertex2d(334, 518);
    glVertex2d(334, 554);
    glVertex2d(301, 554);

    glEnd();

    //ATAP + BAGASI//

    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(279, 359);
    glVertex2d(686, 359);
    glVertex2d(602, 422);
    glVertex2d(178, 422);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(454, 422);
    glVertex2d(602, 422);
    glVertex2d(602, 500);
    glVertex2d(454, 500);

    glEnd();

    //bagasi bawah

    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(454, 500);
    glVertex2d(602, 500);
    glVertex2d(602, 572);
    glVertex2d(454, 572);

    glEnd();

    //BAGASI

    glBegin(GL_POLYGON);

    glColor3ub(150, 150, 150);

    glVertex2d(465, 510);
    glVertex2d(590, 510);
    glVertex2d(590, 572);
    glVertex2d(465, 572);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(200, 200, 200);

    glVertex2d(465, 520);
    glVertex2d(590, 520);
    glVertex2d(590, 530);
    glVertex2d(465, 530);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(200, 200, 200);

    glVertex2d(465, 540);
    glVertex2d(590, 540);
    glVertex2d(590, 550);
    glVertex2d(465, 550);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(200, 200, 200);

    glVertex2d(465, 560);
    glVertex2d(590, 560);
    glVertex2d(590, 570);
    glVertex2d(465, 570);

    glEnd();

    //pinggir

    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(602, 422);
    glVertex2d(686, 359);
    glVertex2d(686, 507);
    glVertex2d(602, 572);

    glEnd();

}

void jendela1()
{
        //jendela

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(185, 463);
    glVertex2d(237, 463);
    glVertex2d(237, 564);
    glVertex2d(185, 564);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(401, 463);
    glVertex2d(453, 463);
    glVertex2d(453, 564);
    glVertex2d(401, 564);

    glEnd();


    //pinggiran jendela 1

    glBegin(GL_POLYGON);

    glColor3ub(biruJendela);

    glVertex2d(191, 470);
    glVertex2d(232, 470);
    glVertex2d(232, 559);
    glVertex2d(191, 559);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(208, 470);
    glVertex2d(215, 470);
    glVertex2d(215, 559);
    glVertex2d(208, 559);

    glEnd();

    //jendela 2 pinggiran

    glBegin(GL_POLYGON);

    glColor3ub(biruJendela);

    glVertex2d(407, 469);
    glVertex2d(447, 469);
    glVertex2d(447, 558);
    glVertex2d(407, 558);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(424, 469);
    glVertex2d(430, 469);
    glVertex2d(430, 558);
    glVertex2d(424, 558);

    glEnd();
}

void lantai2()

{   //depan
    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(271, 268);
    glVertex2d(447, 268);
    glVertex2d(447, 402);
    glVertex2d(271, 402);

    glEnd();

    //samping

    glBegin(GL_POLYGON);

    glColor3ub(coklatTembok);

    glVertex2d(447, 268);
    glVertex2d(512, 225);
    glVertex2d(512, 359);
    glVertex2d(447, 402);

    glEnd();

    //belom pintu
    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(318, 338);
    glVertex2d(379, 338);
    glVertex2d(379, 402);
    glVertex2d(318, 402);

    glEnd();

    //shading belom pintu #1
    glBegin(GL_POLYGON);

    glColor3ub(coklatTua);

    glVertex2d(318, 338);
    glVertex2d(335, 338);
    glVertex2d(335, 387);
    glVertex2d(318, 402);

    glEnd();

    //#2
    glBegin(GL_POLYGON);

    glColor3ub(coklatTua);

    glVertex2d(335, 338);
    glVertex2d(379, 338);
    glVertex2d(379, 387);
    glVertex2d(335, 387);

    glEnd();

    //pintu
    glBegin(GL_POLYGON);

    glColor3ub(255, 222, 202);

    glVertex2d(348, 354);
    glVertex2d(365, 354);
    glVertex2d(365, 387);
    glVertex2d(348, 387);

    glEnd();
}

void jendela2()
{
    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(279, 279);
    glVertex2d(319, 279);
    glVertex2d(319, 330);
    glVertex2d(279, 330);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(biruJendela);

    glVertex2d(285, 285);
    glVertex2d(313, 285);
    glVertex2d(313, 324);
    glVertex2d(285, 324);

    glEnd();


    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(394, 279);
    glVertex2d(434, 279);
    glVertex2d(434, 330);
    glVertex2d(394, 330);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(biruJendela);

    glVertex2d(400, 285);
    glVertex2d(428, 285);
    glVertex2d(428, 324);
    glVertex2d(400, 324);

    glEnd();

    ////////////////

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(296, 279);
    glVertex2d(302, 279);
    glVertex2d(302, 330);
    glVertex2d(296, 330);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(lightgray);

    glVertex2d(411, 279);
    glVertex2d(417, 279);
    glVertex2d(417, 330);
    glVertex2d(411, 330);

    glEnd();
}

void atap()
{

    //depan
    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(260, 251);
    glVertex2d(457, 251);
    glVertex2d(457, 268);
    glVertex2d(260, 268);

    glEnd();

    //samping
    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(457, 251);
    glVertex2d(515, 206);
    glVertex2d(515, 229);
    glVertex2d(457, 268);

    glEnd();

    //qtqw

    glBegin(GL_POLYGON);

    glColor3ub(coklatLala);

    glVertex2d(332, 206);
    glVertex2d(515, 206);
    glVertex2d(457, 251);
    glVertex2d(260, 251);

    glEnd();
}

void pager()
{
    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(176, 370);
    glVertex2d(605, 370);
    glVertex2d(605, 380);
    glVertex2d(176, 380);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(176, 400);
    glVertex2d(605, 400);
    glVertex2d(605, 410);
    glVertex2d(176, 410);

    glEnd();

    //samping kanan

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(605, 368);
    glVertex2d(686, 315);
    glVertex2d(686, 325);
    glVertex2d(605, 380);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(605, 398);
    glVertex2d(686, 336);
    glVertex2d(686, 345);
    glVertex2d(605, 410);

    glEnd();

    //vertikal depan
    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(178, 366);
    glVertex2d(200, 366);
    glVertex2d(200, 422);
    glVertex2d(178, 422);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(580, 366);
    glVertex2d(600, 366);
    glVertex2d(600, 422);
    glVertex2d(580, 422);

    glEnd();


    //////////////

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(676, 315);
    glVertex2d(686, 310);
    glVertex2d(686, 357);
    glVertex2d(676, 364);

    glEnd();


}

void pager2()
{

    //kanan vertikal
    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(603, 363);
    glVertex2d(616, 358);
    glVertex2d(616, 412);
    glVertex2d(603, 422);

    glEnd();

    //kiri
    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(176, 370);
    glVertex2d(270, 317);
    glVertex2d(270, 327);
    glVertex2d(176, 380);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(176, 400);
    glVertex2d(270, 347);
    glVertex2d(270, 357);
    glVertex2d(176, 410);

    glEnd();

    //panjang bawah

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(512, 315);
    glVertex2d(686, 315);
    glVertex2d(686, 325);
    glVertex2d(512, 325);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(darkbrown);

    glVertex2d(512, 336);
    glVertex2d(686, 336);
    glVertex2d(686, 345);
    glVertex2d(512, 345);

    glEnd();
}

void matahari()
{

 float theta;

    glClear(GL_COLOR);

    glBegin(GL_POLYGON);
    glColor3ub(warnaBulan);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(60+50*cos(theta),60+50*sin(theta));
    }

    glEnd();

}

void awan()
{

     float theta;
    glClear(GL_COLOR);

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(250+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(300+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(280+40*cos(theta),90+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(270+40*cos(theta),110+20*sin(theta));
    }

    glEnd();

    ////////////////////////////////////////

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(500+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(480+40*cos(theta),80+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(470+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    ///////////////////

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(700+40*cos(theta),80+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(720+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(680+40*cos(theta),100+20*sin(theta));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(awanGelap);
    for(int i = 0; i < 360; i++){
        theta=i*3.142/180;
        glVertex2f(660+40*cos(theta),80+20*sin(theta));
    }

    glEnd();
}

void lampu()
{
    glBegin(GL_POLYGON);

    glColor3ub(biruDongker);

    glVertex2d(79, 550);
    glVertex2d(92, 550);
    glVertex2d(92, 662);
    glVertex2d(79, 662);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(biruDongker);

    glVertex2d(345, 550);
    glVertex2d(357, 550);
    glVertex2d(357, 662);
    glVertex2d(345, 662);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(biruDongker);

    glVertex2d(539, 550);
    glVertex2d(550, 550);
    glVertex2d(550, 662);
    glVertex2d(539, 662);

    glEnd();
}

void bunder()
{

 float theta;

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex)%3][0],colorf[(clindex)%3][1],colorf[(clindex)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(85+30*cos(theta),550+30*sin(theta));
    }

    glEnd();

///////////////////////////

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(350+30*cos(theta),550+30*sin(theta));
    }

    glEnd();

///////////////////////////////////////

    glBegin(GL_POLYGON);
    glColor3ub(colorf[(clindex+2)%3][0],colorf[(clindex+2)%3][1],colorf[(clindex+2)%3][2]);

    for(int i = 20; i < 380; i++){
        theta=i*3.14/180;
        glVertex2f(545+30*cos(theta),550+30*sin(theta));
    }

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Rumah - Yasmin Rizky F - G64160106", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POLYGON_SMOOTH);
    glEnable(GL_POINT_SMOOTH);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);

        display();

        //////////////////////////////

        bground();
        tanah();
        lantai1();
        jendela1();
        lantai2();
        jendela2();
        atap();
        pager();
        pager2();
        matahari();
        awan();
        lampu();
        bunder();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
