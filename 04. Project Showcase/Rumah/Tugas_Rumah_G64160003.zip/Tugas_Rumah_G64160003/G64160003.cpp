#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
int clindex=0,buff=0;
int colorf[3][4]={{255,255,255,0},{109,106,106,0},{255,255,255,0}};
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();

}
void bg(){ //MEMBUAT BACKGROUND LANGIT
    glBegin(GL_POLYGON);

    glColor3ub(134,212,239);glVertex2f(0,0);
    //glColor3ub(134,212,239);glVertex2d(800,0);
    glColor3ub(156,201,216);glVertex2f(0,800);
    glColor3ub(209,224,229); glVertex2d(800,800);

    glColor3ub(134,212,239);glVertex2f(0,0);
    glColor3ub(134,212,239);glVertex2d(800,0);
    //glColor3ub(156,201,216);glVertex2f(0,678);
    glColor3ub(209,224,229); glVertex2d(800,800);

    glEnd();
}
void halaman(){
    glBegin(GL_POLYGON);
    glColor3ub(52,214,48);
    glVertex2d(0,445);glVertex2d(800,445);
    glVertex2d(800,800);glVertex2d(0,800);
    glEnd();
}
void rumah(){
        //RUMAHATASBAGASI
glBegin(GL_TRIANGLES);//atap
    glColor3ub(38,50,56);
    glVertex2d(162,182);glVertex2d(326,149);
    glVertex2d(490,182);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(206,165,152);//atap
    glVertex2d(162,182);glVertex2d(490,182);
    glVertex2d(490,191);glVertex2d(162,191);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(112,89,83);
    glVertex2d(174,191);glVertex2d(336,191);
    glVertex2d(336,201);glVertex2d(174,201);
        glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(101,200,208);
    glVertex2d(183,201);glVertex2d(361,201);
    glVertex2d(361,268);glVertex2d(183,268);
    glEnd();
    glBegin(GL_POLYGON);//jendela
    glColor3ub(255,255,255);
    glVertex2d(224,201);glVertex2d(320,201);
    glVertex2d(320,260);glVertex2d(224,260);
    glEnd();
        glBegin(GL_POLYGON);//kaca1
    glColor3ub(128,216,255);
    glVertex2d(228,207);glVertex2d(254,207);
    glVertex2d(254,260);glVertex2d(228,260);
    glEnd();
                glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(244,207);glVertex2d(248,207);
    glVertex2d(228,256);glVertex2d(228,245);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(254,207);glVertex2d(254,241);
    glVertex2d(246,260);glVertex2d(232,260);
    glEnd();
            glBegin(GL_POLYGON);//kaca2
    glColor3ub(128,216,255);
    glVertex2d(259,207);glVertex2d(285,207);
    glVertex2d(285,260);glVertex2d(259,260);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(259,207);glVertex2d(268,207);
    glVertex2d(259,229); glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(285,232);glVertex2d(285,242);
    glVertex2d(278,260);glVertex2d(273,260);
    glEnd();
            glBegin(GL_POLYGON);//kaca3
    glColor3ub(128,216,255);
    glVertex2d(290,207);glVertex2d(315,207);
    glVertex2d(315,260);glVertex2d(290,260);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(295,207);glVertex2d(299,207);
    glVertex2d(290,230);glVertex2d(290,219);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(304,207);glVertex2d(315,207);glVertex2d(315,216);
    glVertex2d(297,260);glVertex2d(290,260);glVertex2d(290,243);
    glEnd();
    glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,110);
    glVertex2d(183,201);glVertex2d(361,201);
    glVertex2d(361,227);glVertex2d(183,227);
    glEnd();
            glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,110);
    glVertex2d(336,227);glVertex2d(361,227);
    glVertex2d(361,252);glVertex2d(336,252);
    glEnd();
    //RUMAHDEPAN
    glBegin(GL_TRIANGLES);//atap
    glColor3ub(55,71,79);
    glVertex2d(327,182);glVertex2d(518,126);
    glVertex2d(710,182);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);//atap
    glVertex2d(321,182);glVertex2d(716,182);
    glVertex2d(716,191);glVertex2d(321,191);
    glEnd();
        glBegin(GL_POLYGON);//atap
    glColor3ub(144,164,174);
    glVertex2d(336,191);glVertex2d(701,191);
    glVertex2d(701,201);glVertex2d(336,201);
        glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(101,200,208);
    glVertex2d(361,201);glVertex2d(676,201);
    glVertex2d(676,490);glVertex2d(361,490);
    glEnd();
    glBegin(GL_POLYGON);//tiang1
    glColor3ub(60,76,89);
    glVertex2d(329,252);glVertex2d(392,252);
    glVertex2d(392,490);glVertex2d(329,490);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(215,204,200);//tiang1atas
    glVertex2d(329,252);glVertex2d(392,252);
    glVertex2d(392,265);glVertex2d(329,265);
    glEnd();
        glBegin(GL_POLYGON);//tiang1bawah
    glColor3ub(215,204,200);
    glVertex2d(329,458);glVertex2d(392,458);
    glVertex2d(392,490);glVertex2d(329,490);
    glEnd();
        glBegin(GL_POLYGON);//jendelabesar
    glColor3ub(255,255,255);
    glVertex2d(401,201);glVertex2d(555,201);
    glVertex2d(555,280);glVertex2d(401,280);
    glEnd();
        glBegin(GL_POLYGON);//kaca1
    glColor3ub(128,216,255);
    glVertex2d(408,210);glVertex2d(448,210);
    glVertex2d(448,280);glVertex2d(408,280);
    glEnd();
       glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(412,210);glVertex2d(418,210);
    glVertex2d(408,234);glVertex2d(408,220);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(425,210);glVertex2d(444,210);
    glVertex2d(415,280);glVertex2d(408,280);glVertex2d(408,215);
    glEnd();
            glBegin(GL_POLYGON);//kaca2
    glColor3ub(128,216,255);
    glVertex2d(458,210);glVertex2d(498,210);
    glVertex2d(498,280);glVertex2d(458,280);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(475,210);glVertex2d(481,210);
    glVertex2d(458,266);glVertex2d(458,252);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(488,210);glVertex2d(498,210);glVertex2d(498,233);
    glVertex2d(479,280);glVertex2d(460,280);
    glEnd();
            glBegin(GL_POLYGON);//kaca3
    glColor3ub(128,216,255);
    glVertex2d(509,210);glVertex2d(548,210);
    glVertex2d(548,280);glVertex2d(509,280);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(539,210);glVertex2d(545,210);
    glVertex2d(516,280);glVertex2d(510,280);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(548,218);glVertex2d(548,265);
    glVertex2d(542,280);glVertex2d(523,280);
    glEnd();
            glBegin(GL_POLYGON);//jendelabesar2
    glColor3ub(255,255,255);
    glVertex2d(608,201);glVertex2d(660,201);
    glVertex2d(660,311);glVertex2d(608,311);
    glEnd();
        glBegin(GL_POLYGON);//kaca2.1
    glColor3ub(128,216,255);
    glVertex2d(614,210);glVertex2d(654,210);
    glVertex2d(654,302);glVertex2d(614,302);
    glEnd();
            glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(635,210);glVertex2d(641,210);
    glVertex2d(614,277);glVertex2d(614,262);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(648,210);glVertex2d(654,210);glVertex2d(654,242);
    glVertex2d(630,302);glVertex2d(614,302);glVertex2d(614,294);
    glEnd();
            glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,70);
    glVertex2d(361,201);glVertex2d(676,201);
    glVertex2d(676,226);glVertex2d(361,226);
    glEnd();

        glBegin(GL_POLYGON);//jendelabawah1
    glColor3ub(255,255,255);
    glVertex2d(609,342);glVertex2d(659,342);
    glVertex2d(659,460);glVertex2d(609,460);
    glEnd();
        glBegin(GL_POLYGON);//kaca
    glColor3ub(128,216,255);
    glVertex2d(615,351);glVertex2d(653,351);
    glVertex2d(653,449);glVertex2d(615,449);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(650,351);glVertex2d(653,351);glVertex2d(653,390);
    glVertex2d(628,451);glVertex2d(615,451);glVertex2d(615,437);
    glEnd();
              glPopMatrix();
    GLfloat a;
    glLineWidth(1);
    glBegin(GL_LINES);
    for(a=356;a<=449;a+=5){
        glColor3ub(237,118,82);
        glVertex2d(615,a);glVertex2d(653,a);
    }
    glEnd(); glPopMatrix();
        glBegin(GL_POLYGON);//jendelabawah2
    glColor3ub(255,255,255);
    glVertex2d(513,342);glVertex2d(563,342);
    glVertex2d(563,460);glVertex2d(513,460);
    glEnd();
        glBegin(GL_POLYGON);//kaca
    glColor3ub(128,216,255);
    glVertex2d(519,351);glVertex2d(557,351);
    glVertex2d(557,451);glVertex2d(519,451);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(552,351);glVertex2d(557,351);glVertex2d(557,386);
    glVertex2d(531,451);glVertex2d(519,451);glVertex2d(519,432);
    glEnd();
            glPopMatrix();
    GLfloat y;
    glLineWidth(1);
    glBegin(GL_LINES);
    for(y=356;y<=449;y+=5){
        glColor3ub(237,118,82);
        glVertex2d(519,y);glVertex2d(557,y);
    }
    glEnd(); glPopMatrix();
        glLineWidth(1);
    glBegin(GL_LINES);
    glColor3ub(237,118,82);
    glVertex2d(538,352);glVertex2d(538,451);glEnd();
        glBegin(GL_POLYGON);//tiang2
    glColor3ub(60,76,89);
    glVertex2d(577,252);glVertex2d(640,252);
    glVertex2d(640,490);glVertex2d(577,490);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(215,204,200);//tiang2atas
    glVertex2d(577,252);glVertex2d(640,252);
    glVertex2d(640,265);glVertex2d(577,265);
    glEnd();
        glBegin(GL_POLYGON);//tiang2bawah
    glColor3ub(215,204,200);
    glVertex2d(577,458);glVertex2d(640,458);
    glVertex2d(640,490);glVertex2d(577,490);
    glEnd();
        glBegin(GL_POLYGON);//pintu
    glColor3ub(255,255,255);
    glVertex2d(401,342);glVertex2d(458,342);
    glVertex2d(458,467);glVertex2d(401,467);
    glEnd();
        glBegin(GL_POLYGON);//kacapintu
    glColor3ub(128,216,255);
    glVertex2d(409,439);glVertex2d(450,439);
    glVertex2d(450,456);glVertex2d(409,456);
    glEnd();
    glBegin(GL_POLYGON);//kacapintu
    glColor3ub(128,216,255);
    glVertex2d(409,410);glVertex2d(450,410);
    glVertex2d(450,428);glVertex2d(409,428);
    glEnd();
    glBegin(GL_POLYGON);//kacapintu
    glColor3ub(128,216,255);
    glVertex2d(409,384);glVertex2d(450,384);
    glVertex2d(450,399);glVertex2d(409,399);
    glEnd();
    glBegin(GL_POLYGON);//kacapintu
    glColor3ub(128,216,255);
    glVertex2d(409,353);glVertex2d(450,353);
    glVertex2d(450,370);glVertex2d(409,370);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(448,439);glVertex2d(450,439);glVertex2d(450,448);
    glVertex2d(447,456);glVertex2d(441,456);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(436,353);glVertex2d(450,353);glVertex2d(450,364);
    glVertex2d(413,456);glVertex2d(409,456);glVertex2d(409,419);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(423,353);glVertex2d(429,353);
    glVertex2d(410,399);glVertex2d(409,388);
    glEnd();
        glBegin(GL_POLYGON);//pintu
    glColor3ub(255,255,255);
    glVertex2d(458,342);glVertex2d(485,342);
    glVertex2d(485,467);glVertex2d(458,467);
    glEnd();
        glBegin(GL_POLYGON);//kacapintu
    glColor3ub(128,216,255);
    glVertex2d(463,348);glVertex2d(480,348);
    glVertex2d(480,462);glVertex2d(463,462);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(480,362);glVertex2d(480,376);
    glVertex2d(463,416);glVertex2d(463,402);
    glEnd();
        glBegin(GL_POLYGON);//gradasikaca
    glColor4ub(255,255,255,90);
    glVertex2d(480,393);glVertex2d(480,440);
    glVertex2d(471,462);glVertex2d(463,462);glVertex2d(463,433);
    glEnd();
    glLineWidth(3);
    glBegin(GL_LINE_STRIP);//gagangpintu
    glColor3ub(215,204,200);
    glVertex2d(457,426);glVertex2d(457,384);
    glEnd();
    //BAGASI
    glBegin(GL_POLYGON);
    glColor3ub(101,200,208);
    glVertex2d(78,344);glVertex2d(329,344);
    glVertex2d(329,490);glVertex2d(78,490);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(50,54,56);
    glVertex2d(97,355);glVertex2d(311,355);
    glVertex2d(311,490);glVertex2d(97,490);
    glEnd();
        glPopMatrix();
    //glTranslatef(0.0f,0.0f,-20.0f);
    GLfloat z;
    glBegin(GL_LINES);
    for(z=368;z<=476;z+=15){
        glColor3ub(237,118,82);glVertex2d(97,z);
        glVertex2d(311,z);
    }
    glEnd(); glPopMatrix();
        glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,110);
    glVertex2d(97,355);glVertex2d(311,355);
    glVertex2d(311,360);glVertex2d(97,360);
    glEnd();
    //ATAPBAGASI
        glBegin(GL_POLYGON);//atap
    glColor3ub(55,71,79);
    glVertex2d(53,325);glVertex2d(200,260);
    glVertex2d(329,260);glVertex2d(329,325);
    glEnd();
            glBegin(GL_POLYGON);
    glColor3ub(144,164,174);
    glVertex2d(65,334);glVertex2d(329,334);
    glVertex2d(329,344);glVertex2d(65,344);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(53,325);glVertex2d(329,325);
    glVertex2d(329,334);glVertex2d(53,334);
    glEnd();
    //BALKON
        glBegin(GL_POLYGON);
    glColor3ub(249,245,244);
    glVertex2d(361,280);glVertex2d(608,280);
    glVertex2d(608,342);glVertex2d(361,342);
    glEnd();
            glBegin(GL_POLYGON);
    glColor3ub(215,204,200);
    glVertex2d(361,280);glVertex2d(608,280);
    glVertex2d(608,291);glVertex2d(361,291);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(215,204,200);
    glVertex2d(361,332);glVertex2d(608,332);
    glVertex2d(608,342);glVertex2d(361,342);
    glEnd();
    //pagarbalkon
    glBegin(GL_POLYGON);
    glColor3ub(40,38,38);
    glVertex2d(392,257);glVertex2d(577,257);
    glVertex2d(577,264);glVertex2d(392,264);
    glEnd();
    glLineWidth(6);
        glBegin(GL_LINE_STRIP);
    glColor3ub(40,38,38);
    glVertex2d(405,264);glVertex2d(405,280);
    glEnd();
        glLineWidth(6);
        glBegin(GL_LINE_STRIP);
    glColor3ub(40,38,38);
    glVertex2d(460,264);glVertex2d(460,280);
    glEnd();
        glLineWidth(6);
        glBegin(GL_LINE_STRIP);
    glColor3ub(40,38,38);
    glVertex2d(516,264);glVertex2d(516,280);
    glEnd();
        glLineWidth(6);
        glBegin(GL_LINE_STRIP);
    glColor3ub(40,38,38);
    glVertex2d(564,264);glVertex2d(564,280);
    glEnd();
        glBegin(GL_POLYGON);//BAYANGAN
    glColor4ub(0,0,0,100);
    glVertex2d(361,342);glVertex2d(392,342);
    glVertex2d(392,357);glVertex2d(361,357);
    glEnd();
        glBegin(GL_POLYGON);//BAYANGAN
    glColor4ub(0,0,0,100);
    glVertex2d(577,342);glVertex2d(608,342);
    glVertex2d(608,357);glVertex2d(577,357);
    glEnd();
        glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,130);
    glVertex2d(392,342);glVertex2d(485,342);
    glVertex2d(485,373);glVertex2d(392,373);
    glEnd();
        glBegin(GL_POLYGON);//bayangan
    glColor4ub(0,0,0,130);
    glVertex2d(485,342);glVertex2d(577,342);
    glVertex2d(577,361);glVertex2d(485,361);
    glEnd();
    //LANTAIDEPAN
    glBegin(GL_POLYGON);
    glColor3ub(188,175,175);
    glVertex2d(392,467);glVertex2d(577,467);
    glVertex2d(577,490);glVertex2d(392,490);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(142,134,133);
    glVertex2d(392,481);glVertex2d(577,481);
    glVertex2d(577,490);glVertex2d(392,490);
    glEnd();
//Lampu
        glBegin(GL_POLYGON);
    glColor3ub(255,255,204);glVertex2d(608,375);
    glColor4ub(255,255,153,0);glVertex2d(600,397);
    glColor4ub(255,255,153,0);glVertex2d(621,397);
    glColor3ub(255,255,204);glVertex2d(613,375);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(255,255,204);glVertex2d(355,375);
    glColor4ub(255,255,153,0);glVertex2d(347,397);
    glColor4ub(255,255,153,0);glVertex2d(367,397);
    glColor3ub(255,255,204);glVertex2d(360,375);
    glEnd();
}
void jalan(){
        glBegin(GL_POLYGON);//jalankecil
    glColor3ub(90,94,94);
    glVertex2d(413,489);glVertex2d(478,489);
    glVertex2d(515,659);glVertex2d(390,659);
    glEnd();
        glBegin(GL_POLYGON);//jalanbesar
    glColor3ub(65,65,71);
    glVertex2d(0,645);glVertex2d(800,645);
    glVertex2d(800,800);glVertex2d(0,800);
    glEnd();
    glPopMatrix();GLfloat s;
    for(s=3;s<800;s+=52){
        glLineWidth(2);
    glBegin(GL_LINES);//STRIPJALAN
    glColor3ub(255,255,255);
    glVertex2d(s,724);glVertex2d(s+24,724);}
    glEnd(); glPushMatrix();
}
void Lingkaran(double poX, double poY, double rad)
{
    double cons = (3.14/100);
    double px, py;
    double posX = poX, posY = poY;
    double radius1 = 0;
    double radius2 = rad;
    int i;

    glBegin(GL_TRIANGLE_STRIP);
        for(i=0; i<360;i++)
        {
            px = sin(i*cons)*radius1+posX;
            py = cos(i*cons)*radius1+posY;
            glVertex2d(px,py);
            px = sin(i*cons)*radius2+posX;
            py = cos(i*cons)*radius2+posY;
            glVertex2d(px,py);
        }
    glEnd();
}

void pohon(){
    glBegin(GL_POLYGON);//jalanmobil
    glColor3ub(90,94,94);
    glVertex2d(106,497);glVertex2d(424,515);
    glVertex2d(474,564);glVertex2d(114,544);
    glEnd();

    glColor3ub(20,163,30);
    Lingkaran(64,515,64);
    glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(67,503);glVertex2d(71,503);
    glVertex2d(71,615);glVertex2d(63,615);
    glEnd();
        glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(41,517);glVertex2d(42,515);
    glVertex2d(66,530);glVertex2d(66,538);
    glEnd();

    glColor3ub(20,163,30);
    Lingkaran(738,393,53);
    glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(733,382);glVertex2d(736,382);
    glVertex2d(740,482);glVertex2d(733,482);
    glEnd();
        glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(757,393);glVertex2d(759,394);
    glVertex2d(737,413);glVertex2d(737,406);
    glEnd();

    glColor3ub(20,163,30);
    Lingkaran(753,519,43);
    glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(754,515);glVertex2d(758,516);
    glVertex2d(758,595);glVertex2d(751,595);
    glEnd();
        glBegin(GL_POLYGON); //batang
    glColor3ub(132,72,68);
    glVertex2d(774,526);glVertex2d(775,527);
    glVertex2d(758,540);glVertex2d(758,537);
    glEnd();
}
void pagar(){
    glBegin(GL_POLYGON);
        glColor3ub(229,229,229);
        glVertex2d(1,599);glVertex2d(800,599);
    glVertex2d(800,605);glVertex2d(1,605);
    glEnd();
     glBegin(GL_POLYGON);
        glColor3ub(229,229,229);
        glVertex2d(1,627);glVertex2d(800,627);
    glVertex2d(800,633);glVertex2d(1,633);
    glEnd();

      glPopMatrix();GLfloat j;
    glBegin(GL_LINES);
    for(j=1;j<=793;j+=11){
        glColor3ub(229,229,229);
        glVertex2d(j,585);glVertex2d(j,644);
    }
    glEnd(); glPopMatrix();
    glPopMatrix();GLfloat i;

    glBegin(GL_LINES);
    for(i=9;i<=799;i+=11){
        glColor3ub(229,229,229);
        glVertex2d(i,585);glVertex2d(i,644);
    }
    glEnd(); glPopMatrix();

    glPopMatrix();GLfloat s;
    glBegin(GL_LINES);
    for(s=1;s<=795;s+=11){
        glColor3ub(229,229,229);
        glVertex2d(s,585);glVertex2d(s+4,581);
    }
    glEnd(); glPopMatrix();

        glPopMatrix();GLfloat r;
    glBegin(GL_LINES);
    for(r=9;r<=800;r+=11){
        glColor3ub(229,229,229);
        glVertex2d(r,585);glVertex2d(r-4,581);
    }
    glEnd(); glPopMatrix();

        //glVertex2d(1,585);glVertex2d(5,581);glVertex2d(9,585);
        //glVertex2d(9,644);glVertex2d(1,644);
    //glEnd();
}
rumput(){
    glBegin(GL_POLYGON);
        glColor3ub(26,142,16);
        glVertex2d(516,539);glVertex2d(509,528);
    glVertex2d(521,533);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(527,531);glVertex2d(518,519);
    glVertex2d(521,533);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(527,531);glVertex2d(537,522);
    glVertex2d(529,536);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(529,536);glVertex2d(536,532);
    glVertex2d(531,539);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(516,539);glVertex2d(521,533);
    glVertex2d(527,531);glVertex2d(529,536);
    glVertex2d(531,539);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(26,142,16);
        glVertex2d(638,552);glVertex2d(633,545);
    glVertex2d(640,549);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(640,549);glVertex2d(632,535);
    glVertex2d(642,544);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(642,544);glVertex2d(651,532);
    glVertex2d(648,546);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(648,546);glVertex2d(660,541);
    glVertex2d(653,552);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(26,142,16);
    glVertex2d(638,552);glVertex2d(640,549);
    glVertex2d(642,544);glVertex2d(648,546);
    glVertex2d(653,552);
    glEnd();
    //pot
        glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(598,481);glVertex2d(616,481);
    glVertex2d(616,494);glVertex2d(598,494);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(607,469);glVertex2d(608,469);
    glVertex2d(608,483);glVertex2d(607,483);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(607,469);glVertex2d(608,469);
    glVertex2d(614,464);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(607,469);glVertex2d(608,469);
    glVertex2d(604,467);
    glEnd();
    glColor3ub(20,163,30);
    Lingkaran(607,458,8);
    Lingkaran(600,463,2);
    Lingkaran(601,469,5);
    Lingkaran(615,464,4);
    Lingkaran(613,470,5);
    Lingkaran(608,467,7);
    //pot2
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(357,480);glVertex2d(375,480);
    glVertex2d(375,493);glVertex2d(357,493);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(365,468);glVertex2d(367,468);
    glVertex2d(367,482);glVertex2d(365,482);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(365,468);glVertex2d(366,468);
    glVertex2d(362,466);
    glEnd();
        glBegin(GL_POLYGON);
    glColor3ub(93,64,55);
    glVertex2d(366,468);glVertex2d(367,468);
    glVertex2d(373,463);
    glEnd();
    glColor3ub(20,163,30);
    Lingkaran(366,457,8);
    Lingkaran(358,462,2);
    Lingkaran(360,469,5);
    Lingkaran(371,469,6);
    Lingkaran(374,464,4);
    Lingkaran(366,466,7);
}
awan(){
    glColor3ub(242,245,247);
    Lingkaran(161,85,29);
    Lingkaran(190,76,37);
    Lingkaran(219,81,33);
    Lingkaran(241,85,28);

    Lingkaran(675,81,26);
    Lingkaran(704,81,33);
    Lingkaran(738,81,23);
}
void mobil(){
    glBegin(GL_POLYGON);
    glColor3ub(228,77,80);
    glVertex2d(155,502);glVertex2d(175,499);
    glVertex2d(151,530);glVertex2d(351,511);
    glVertex2d(355,529);glVertex2d(356,534);glVertex2d(151,530);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(228,77,80);
    glVertex2d(155,502);glVertex2d(216,484);
    glVertex2d(261,484);glVertex2d(298,501);
    glVertex2d(352,512);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(78,179,194);
    glVertex2d(181,501);glVertex2d(215,486);glVertex2d(235,486);
    glVertex2d(234,501);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(78,179,194);
    glVertex2d(237,486);glVertex2d(259,486);
    glVertex2d(292,502);glVertex2d(236,502);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    glVertex2d(341,511);glVertex2d(350,511);
    glVertex2d(352,518);glVertex2d(343,516);
    glEnd();
    glColor3ub(85,75,65);
    Lingkaran(187,533,15);
    glColor3ub(92,92,92);
    Lingkaran(187,533,11);

    glColor3ub(85,75,65);
    Lingkaran(317,534,15);
    glColor3ub(92,92,92);
    Lingkaran(317,534,11);
}
void ha(){
    glBegin(GL_POLYGON);
    //glColor4ub(109,106,106,100);
    glColor4ub(colorf[(clindex+1)%3][0],colorf[(clindex+1)%3][1],colorf[(clindex+1)%3][2],100);
    glVertex2d(0,0);glVertex2d(800,0);
    glVertex2d(800,800);glVertex2d(0,800);
    glEnd();
}
int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Tugas Rumah - <G64160003>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;
        setup_viewport(window);
glEnable(GL_BLEND);
glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        display();
        //panggil fungsi
bg(); halaman();
rumah(); rumput();pohon();pagar();jalan();
awan(); mobil(); //ha();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
