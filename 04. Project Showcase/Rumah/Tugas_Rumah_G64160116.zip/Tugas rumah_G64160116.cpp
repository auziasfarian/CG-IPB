#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
    double nol = 0, resetx=10, resety=0;
    int trigger = 0,i;
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1920, 1080, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
void belakang(){
    glBegin(GL_POLYGON);
    glColor3ub(180,239,217);
      glVertex2d(0,0-nol);
       glVertex2d(1920,0-nol);
          glColor3ub(242,214,135);
    glVertex2d(1920,1080-nol);
       glVertex2d(0,1080-nol);
glEnd();

}
void warna(){

 if(trigger%2==0){
            nol+=0.15;}
        else{
            nol-=0.25;
        }
        if(nol==255 || nol == 0){
        trigger++;
        }
}



void bintang(){
    glBegin(GL_POINTS);
    glColor3f(1.0,1.0,1.0);
    glVertex2d(1549,401);
    glVertex2d(72,68);
    glVertex2d(291,220);
    glVertex2d(375,390);
    glVertex2d(793,77);
    glVertex2d(873,20);
    glVertex2d(128,82);
    glVertex2d(1277,83);
    glVertex2d(1487,157);
    glVertex2d(1290,222);
    glVertex2d(1430,279);
    glVertex2d(1125,105);
    glVertex2d(1718,239);
    glVertex2d(1795,360);
       glVertex2d(22,67);
    glVertex2d(518,27);
    glVertex2d(826,117);
    glVertex2d(171,169);
       glVertex2d(548,199);
       glVertex2d(306,46);
       glEnd();
}

void matahari(){
glBegin(GL_POLYGON);
        glColor3ub(244,134,59);
          glColor3ub(239,170,123);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(1495+cos(rad)*80+nol,184+sin(rad)*80+nol);
           }
        glEnd();


}

void kelip(){
    int s;
    float x,y;
    glColor3f(0.0,0.0,0.0);
    for(int i=0;i<500;i++){
        s=rand()%4+1;
        glPointSize(s);
        glBegin(GL_POINTS);
        x=(float)rand()/RAND_MAX;
        y=(float)rand()/RAND_MAX;
        glVertex2f(x,y);
        glEnd();
    }
}


void pondasi()
{
    glBegin(GL_POLYGON);

    glColor3ub(137,202,53);
    glVertex2d(40,473);
    glVertex2d(431,259);
    glVertex2d(1570,828);
    glVertex2d(1136,1058);
    glEnd();

    glBegin(GL_POLYGON);
  glColor3ub(74,116,62);
    glVertex2d(40,492);
    glVertex2d(40,473);
    glVertex2d(438,686);
    glVertex2d(439,706);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(74,116,62);
    glVertex2d(439,706);
    glVertex2d(438,686);
    glVertex2d(1136,1058);
    glVertex2d(1138,1080);
    glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(137,202,53);
    glVertex2d(772,438);
    glVertex2d(1033,297);
    glVertex2d(1859,696);
    glVertex2d(1570,828);
    glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(74,116,62);
    glVertex2d(1136,1058);
    glVertex2d(1570,828);
    glVertex2d(1570,849);
    glVertex2d(1138,1080);
    glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(74,116,62);
    glVertex2d(1570,828);
    glVertex2d(1859,696);
    glVertex2d(1859,716);
    glVertex2d(1570,849);
    glEnd();
}

void taman(){

    glBegin(GL_POLYGON);
     glColor3ub(76,155,36);
    glVertex2d(161,539);
    glVertex2d(433,390);
    glVertex2d(463,406);
    glVertex2d(182,550);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(76,155,36);
    glVertex2d(432,411);
    glVertex2d(463,406);
    glVertex2d(705,538);
    glVertex2d(685,549);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(76,155,36);
    glVertex2d(256,449);
    glVertex2d(286,434);
    glVertex2d(320,452);
    glVertex2d(292,468);
    glEnd();
    //taman gedung
glBegin(GL_POLYGON);
    glColor3ub(76,155,36);
    glVertex2d(398,373);
    glVertex2d(452,342);
    glVertex2d(514,380);
    glVertex2d(463,406);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(0,111,0);
    glVertex2d(480,358);
    glVertex2d(480,328);
    glVertex2d(515,347);
    glVertex2d(515,376);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(65,155,25);
    glVertex2d(480,329);
    glVertex2d(546,295);
    glVertex2d(580,311);
    glVertex2d(515,347);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(98,180,23);
    glVertex2d(515,377);
    glVertex2d(515,347);
    glVertex2d(580,311);
    glVertex2d(580,341);
    glEnd();

//taman gedung 2
glBegin(GL_POLYGON);
    glColor3ub(193,239,127);
    glVertex2d(463,406);
    glVertex2d(579,341);
    glVertex2d(826,473);
    glVertex2d(705,538);
    glEnd();

//TAMAN RUMAH 2
 glBegin(GL_POLYGON);
    glColor3ub(181,232,97);
    glVertex2d(825,429);
    glVertex2d(1046,314);
    glVertex2d(1266,429);
    glVertex2d(1046,544);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(154,196,82);
    glVertex2d(906,488);
    glVertex2d(967,456);
    glVertex2d(1007,477);
    glVertex2d(956,509);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(154,196,82);
    glVertex2d(588,474);
    glVertex2d(623,454);
    glVertex2d(674,483);
    glVertex2d(640,502);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(229,195,149);
    glVertex2d(866,595);
    glVertex2d(938,554);
    glVertex2d(992,586);
    glVertex2d(921,627);
    glEnd();

}

void rumah(){

glBegin(GL_POLYGON);
    glColor3ub(199,202,195);
    glVertex2d(117,431);
    glVertex2d(117,338);
    glVertex2d(206,340);
    glVertex2d(206,478);
    glEnd();

glBegin(GL_POLYGON);

    glColor3ub(224,223,220);
    glVertex2d(206,478);
    glVertex2d(206,350);
    glVertex2d(263,290);
    glVertex2d(318,320);
    glVertex2d(318,416);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(225,56,65);
    glVertex2d(102,364);
    glVertex2d(174,239);
    glVertex2d(257,283);
    glVertex2d(184,410);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(225,56,65);
    glVertex2d(184,410);
    glVertex2d(257,283);
    glVertex2d(262,297);
    glVertex2d(205,398);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(225,56,65);
    glVertex2d(262,297);
    glVertex2d(257,283);
    glVertex2d(337,327);
    glVertex2d(327,332);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(225,56,65);
    glVertex2d(317,325);
    glVertex2d(328,332);
    glVertex2d(316,338);
    glEnd();

//jendela

glBegin(GL_POLYGON);
   glColor3ub(224,207,164);
    glVertex2d(293,373);
    glVertex2d(311,364);
    glVertex2d(311,405);
    glVertex2d(293,415);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(151,85,255);
    glVertex2d(299,376);
    glVertex2d(305,372);
    glVertex2d(305,385);
    glVertex2d(299,390);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(151,85,255);
    glVertex2d(299,394);
    glVertex2d(305,390);
    glVertex2d(305,404);
    glVertex2d(299,408);
    glEnd();

glBegin(GL_POLYGON);
 glColor3ub(224,207,164);
    glVertex2d(260,334);
    glVertex2d(277,325);
    glVertex2d(277,366);
    glVertex2d(260,376);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(151,85,255);
    glVertex2d(265,355);
    glVertex2d(274,351);
    glVertex2d(274,364);
    glVertex2d(265,368);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(151,85,255);
    glVertex2d(265,336);
    glVertex2d(274,332);
    glVertex2d(274,346);
    glVertex2d(265,350);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(224,207,164);
    glVertex2d(224,410);
    glVertex2d(241,401);
    glVertex2d(241,443);
    glVertex2d(224,452);
    glEnd();

glBegin(GL_POLYGON);
  glColor3ub(151,85,255);
    glVertex2d(230,413);
    glVertex2d(237,409);
    glVertex2d(237,423);
    glVertex2d(230,427);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(151,85,255);
    glVertex2d(230,431);
    glVertex2d(237,427);
    glVertex2d(237,441);
    glVertex2d(230,445);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(224,207,164);
    glVertex2d(143,393);
    glVertex2d(171,408);
    glVertex2d(171,449);
    glVertex2d(143,435);
    glEnd();

glBegin(GL_POLYGON);glColor3ub(151,85,255);
    glVertex2d(148,400);
    glVertex2d(155,404);
    glVertex2d(155,418);
    glVertex2d(148,414);
    glEnd();

glBegin(GL_POLYGON);
glColor3ub(151,85,255);
    glVertex2d(159,406);
    glVertex2d(167,410);
    glVertex2d(167,424);
    glVertex2d(159,420);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(151,85,255);
    glVertex2d(159,424);
    glVertex2d(167,429);
    glVertex2d(167,442);
    glVertex2d(159,438);
    glEnd();

glBegin(GL_POLYGON);
 glColor3ub(151,85,255);
    glVertex2d(148,418);
    glVertex2d(155,422);
    glVertex2d(155,436);
    glVertex2d(148,432);
    glEnd();

//PINTU

glBegin(GL_POLYGON);
   glColor3ub(198,123,58);
    glVertex2d(263,401);
    glVertex2d(280,391);
    glVertex2d(280,438);
    glVertex2d(263,448);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(221,158,95);
    glVertex2d(266,403);
    glVertex2d(276,398);
    glVertex2d(276,423);
    glVertex2d(266,429);
    glEnd();
}

void gedung1(){

glBegin(GL_POLYGON);
  glColor3ub(199,202,195);
    glVertex2d(277,346);
    glVertex2d(277,191);
    glVertex2d(363,237);
    glVertex2d(363,393);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(224,223,220);
   glVertex2d(363,393);
   glVertex2d(363,237);
    glVertex2d(484,169);
    glVertex2d(484,324);
    glEnd();

glBegin(GL_POLYGON);
     glColor3ub(224,223,220);
   glVertex2d(277,191);
   glVertex2d(401,125);
    glVertex2d(484,169);
    glVertex2d(363,237);
    glEnd();


glBegin(GL_POLYGON);
  glColor3ub(161,167,155);
   glVertex2d(299,191);
   glVertex2d(401,137);
    glVertex2d(400,151);
    glVertex2d(313,197);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(161,167,155);
   glVertex2d(401,137);
   glVertex2d(463,169);
    glVertex2d(452,176);
    glVertex2d(400,151);
    glEnd();

    //garis2 gedung urut dr kiri atas
glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
   glVertex2d(277,235);
   glVertex2d(277,222);
    glVertex2d(363,269);
    glVertex2d(363,282);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2d(363,269);
   glVertex2d(484,203);
    glVertex2d(484,215);
    glVertex2d(363,281);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2d(277,265);
   glVertex2d(277,253);
    glVertex2d(363,300);
    glVertex2d(363,312);
    glEnd();

glBegin(GL_POLYGON);
 glColor3ub(255,255,255);
   glVertex2d(363,312);
   glVertex2d(363,300);
    glVertex2d(484,234);
    glVertex2d(484,246);
    glEnd();

glBegin(GL_POLYGON);
  glColor3ub(255,255,255);
   glVertex2d(277,297);
   glVertex2d(277,285);
    glVertex2d(363,331);
    glVertex2d(363,345);
    glEnd();

glBegin(GL_POLYGON);
glColor3ub(255,255,255);
   glVertex2d(363,344);
   glVertex2d(363,331);
    glVertex2d(484,265);
    glVertex2d(484,278);
    glEnd();

//pimtu gedung
glBegin(GL_POLYGON);
   glColor3ub(107,112,103);
   glVertex2d(398,373);
   glVertex2d(398,340);
    glVertex2d(426,325);
    glVertex2d(426,357);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(161,167,155);
   glVertex2d(426,357);
   glVertex2d(426,325);
    glVertex2d(452,310);
    glVertex2d(452,345);
    glEnd();

}

void gedung2(){
glBegin(GL_POLYGON);
     glColor3ub(89,129,173);
    glVertex2d(588,434);
    glVertex2d(588,224);
    glVertex2d(710,296);
    glVertex2d(710,504);
    glEnd();

glBegin(GL_POLYGON);
   glColor3ub(106,160,219);
    glVertex2d(710,504);
    glVertex2d(710,296);
    glVertex2d(797,249);
    glVertex2d(797,456);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(588,227);
    glVertex2d(673,183);
    glVertex2d(797,249);
    glVertex2d(711,296);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(77,98,129);
    glVertex2d(610,227);
    glVertex2d(673,194);
    glVertex2d(673,209);
    glVertex2d(624,235);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(77,98,129);
    glVertex2d(673,209);
    glVertex2d(673,194);
    glVertex2d(775,249);
    glVertex2d(760,257);

glBegin(GL_POLYGON);
    glColor3ub(77,98,129);
    glVertex2d(673,209);
    glVertex2d(673,194);
    glVertex2d(775,249);
    glVertex2d(760,257);
    glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(603,296);
    glVertex2d(603,269);
    glVertex2d(695,319);
    glVertex2d(695,346);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(603,337);
    glVertex2d(603,310);
    glVertex2d(695,360);
    glVertex2d(695,387);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(603,378);
    glVertex2d(603,351);
    glVertex2d(695,401);
    glVertex2d(695,428);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(603,419);
    glVertex2d(603,391);
    glVertex2d(614,398);
    glVertex2d(614,425);
     glEnd();



glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(684,463);
    glVertex2d(684,435);
    glVertex2d(695,442);
    glVertex2d(695,469);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(728,317);
    glVertex2d(739,310);
    glVertex2d(739,462);
    glVertex2d(728,467);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(749,307);
    glVertex2d(760,301);
    glVertex2d(760,328);
    glVertex2d(749,334);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(749,347);
    glVertex2d(760,341);
    glVertex2d(760,369);
    glVertex2d(749,375);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(749,388);
    glVertex2d(760,382);
    glVertex2d(760,409);
    glVertex2d(749,416);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(749,431);
    glVertex2d(760,425);
    glVertex2d(760,452);
    glVertex2d(749,458);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(769,295);
    glVertex2d(780,289);
    glVertex2d(780,440);
    glVertex2d(769,446);
     glEnd();

//pintu
glBegin(GL_POLYGON);
    glColor3ub(121,125,116);
    glVertex2d(623,454);
    glVertex2d(623,403);
    glVertex2d(674,432);
    glVertex2d(674,483);
     glEnd();

glBegin(GL_POLYGON);
   glColor3ub(161,167,155);
    glVertex2d(630,457);
    glVertex2d(630,416);
    glVertex2d(643,423);
    glVertex2d(643,465);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(161,167,155);
    glVertex2d(651,469);
    glVertex2d(651,427);
    glVertex2d(667,437);
    glVertex2d(667,479);
     glEnd();
}

void jalan(){
    //pinggir
glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(182,550);
    glVertex2d(433,411);
    glVertex2d(433,434);
    glVertex2d(198,560);
     glEnd();

     glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(1474,879);
    glVertex2d(1138,703);
    glVertex2d(1139,682);
    glVertex2d(1499,865);
     glEnd();

      glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(801,883);
    glVertex2d(939,793);
    glVertex2d(963,808);
    glVertex2d(828,893);
     glEnd();

       glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(717,835);
    glVertex2d(870,747);
    glVertex2d(890,762);
       glVertex2d(739,847);
     glEnd();

glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(433,434);
    glVertex2d(433,411);
    glVertex2d(685,549);
    glVertex2d(667,559);
     glEnd();

glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
    glVertex2d(270,598);
    glVertex2d(433,509);
    glVertex2d(432,528);
    glVertex2d(286,608);
     glEnd();


glBegin(GL_POLYGON);
    glColor3ub(206,215,221);
    glVertex2d(432,528);
    glVertex2d(433,509);
    glVertex2d(594,598);
    glVertex2d(576,608);
     glEnd();

     glBegin(GL_POLYGON);
      glColor3ub(206,215,221);
   glVertex2d(594,598);
    glVertex2d(900,765);
    glVertex2d(868,776);
    glVertex2d(576,608);
     glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(206,215,221);
   glVertex2d(664,559);
    glVertex2d(844,462);
    glVertex2d(865,473);
    glVertex2d(686,571);
     glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(206,215,221);
   glVertex2d(916,502);
    glVertex2d(935,511);
    glVertex2d(667,659);
    glVertex2d(630,648);
     glEnd();


//PAKE PAGER
glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(779,616);
     glVertex2d(779,557);
    glVertex2d(782,553);
    glVertex2d(786,561);
    glVertex2d(786,621);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(791,624);
     glVertex2d(791,565);
    glVertex2d(794,561);
    glVertex2d(798,569);
    glVertex2d(798,629);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(803,632);
     glVertex2d(803,572);
    glVertex2d(806,569);
    glVertex2d(810,577);
    glVertex2d(810,634);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(815,640);
     glVertex2d(815,580);
    glVertex2d(818,577);
    glVertex2d(822,585);
    glVertex2d(822,645);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(828,648);
     glVertex2d(828,588);
    glVertex2d(831,585);
    glVertex2d(835,593);
    glVertex2d(835,652);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(840,656);
     glVertex2d(840,596);
    glVertex2d(843,593);
    glVertex2d(847,601);
    glVertex2d(847,660);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(852,664);
     glVertex2d(852,604);
    glVertex2d(855,600);
    glVertex2d(859,609);
    glVertex2d(859,668);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(865,672);
     glVertex2d(865,612);
    glVertex2d(868,608);
    glVertex2d(872,617);
    glVertex2d(872,676);
     glEnd();

glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(876,690);
    glVertex2d(876,620);
    glVertex2d(878,616);
    glVertex2d(884,625);
    glVertex2d(884,684);
     glEnd();

glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(889,688);
     glVertex2d(889,628);
    glVertex2d(892,624);
    glVertex2d(896,632);
    glVertex2d(896,692);
     glEnd();
     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(899,695);
     glVertex2d(899,636);
    glVertex2d(904,632);
    glVertex2d(908,640);
    glVertex2d(908,700);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(933,707);
     glVertex2d(933,651);
    glVertex2d(937,643);
    glVertex2d(940,647);
    glVertex2d(940,703);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(946,700);
     glVertex2d(946,644);
    glVertex2d(951,636);
    glVertex2d(954,639);
    glVertex2d(954,695);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(960,692);
     glVertex2d(960,636);
    glVertex2d(964,628);
    glVertex2d(967,632);
    glVertex2d(967,688);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(973,685);
     glVertex2d(973,629);
    glVertex2d(978,621);
    glVertex2d(981,624);
    glVertex2d(981,680);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(987,676);
     glVertex2d(987,621);
    glVertex2d(991,614);
    glVertex2d(995,617);
    glVertex2d(995,673);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1000,670);
     glVertex2d(1000,614);
    glVertex2d(1005,606);
    glVertex2d(1008,610);
    glVertex2d(1008,666);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1014,662);
     glVertex2d(1014,606);
    glVertex2d(1018,599);
    glVertex2d(1022,603);
    glVertex2d(1022,658);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1027,655);
     glVertex2d(1027,599);
    glVertex2d(1032,591);
    glVertex2d(1035,595);
    glVertex2d(1035,651);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1041,647);
     glVertex2d(1041,591);
    glVertex2d(1045,584);
    glVertex2d(1048,587);
    glVertex2d(1048,643);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1054,640);
     glVertex2d(1054,584);
    glVertex2d(1059,576);
    glVertex2d(1062,580);
    glVertex2d(1062,636);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(239,222,243);
   glVertex2d(1068,631);
     glVertex2d(1068,577);
    glVertex2d(1072,569);
    glVertex2d(1076,572);
    glVertex2d(1076,628);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(206,215,221);
   glVertex2d(915,701);
     glVertex2d(915,644);
    glVertex2d(920,640);
    glVertex2d(927,648);
    glVertex2d(927,705);
     glEnd();

       glBegin(GL_POLYGON);
     glColor3ub(206,215,221);
   glVertex2d(917,718);
     glVertex2d(1136,604);
    glVertex2d(1156,618);
    glVertex2d(933,739);
     glEnd();

       glBegin(GL_POLYGON);
     glColor3ub(206,215,221);
   glVertex2d(984,767);
     glVertex2d(1207,644);
    glVertex2d(1228,656);
    glVertex2d(1012,782);
     glEnd();
       glBegin(GL_POLYGON);
   glColor3ub(206,215,221);
   glVertex2d(1185,657);
     glVertex2d(1207,644);
    glVertex2d(1572,831);
    glVertex2d(1540,843);

     glEnd();


//jalan gede abu
glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(198,560);
    glVertex2d(433,434);
    glVertex2d(433,509);
    glVertex2d(270,599);
     glEnd();

glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(433,509);
    glVertex2d(433,434);
    glVertex2d(667,559);
    glVertex2d(594,598);
     glEnd();


glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(594,598);
    glVertex2d(667,559);
    glVertex2d(1027,771);
    glVertex2d(961,806);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(596,616);
    glVertex2d(865,473);
    glVertex2d(916,502);
    glVertex2d(647,647);
     glEnd();

          glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(933,739);
    glVertex2d(1150,622);
    glVertex2d(1201,650);
    glVertex2d(984,767);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(933,739);
    glVertex2d(984,767);
    glVertex2d(801,880);
    glVertex2d(739,847);
     glEnd();



       glBegin(GL_POLYGON);
   glColor3ub(80,82,83);
    glVertex2d(1139,682);
    glVertex2d(1185,657);
    glVertex2d(1544,839);
    glVertex2d(1498,865);
     glEnd();



}
void rumah1(){
     //PAGER
    glBegin(GL_POLYGON);
    glColor3ub(239,222,243);
    glVertex2d(1194,393);
    glVertex2d(1195,351);
    glVertex2d(1196,349);
    glVertex2d(1200,355);
    glVertex2d(1200,397);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(1205,399);
    glVertex2d(1205,361);
    glVertex2d(1207,354);
    glVertex2d(1211,360);
    glVertex2d(1211,402);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(1215,405);
    glVertex2d(1215,363);
    glVertex2d(1217,360);
    glVertex2d(1221,366);
    glVertex2d(1221,408 );
    glEnd();
    //RUMAH

glBegin(GL_POLYGON);
   glColor3ub(239,222,192);
    glVertex2d(911,427);
    glVertex2d(911,349);
    glVertex2d(987,317);
    glVertex2d(1064,429);
    glVertex2d(1064,506);
     glEnd();

glBegin(GL_POLYGON);
   glColor3ub(239,222,192);
    glVertex2d(1064,506);
     glVertex2d(1064,429);
    glVertex2d(1196,355);
    glVertex2d(1196,437);
     glEnd();

      //atap
glBegin(GL_POLYGON);
   glColor3ub(151,107,79);
    glVertex2d(910,351);
     glVertex2d(907,340);
    glVertex2d(980,313);
    glVertex2d(987,316);
     glEnd();

glBegin(GL_POLYGON);
    glColor3ub(151,107,79);
   glVertex2d(987,320);
   glVertex2d(987,310);
    glVertex2d(1067,424);
     glVertex2d(1064,429);
     glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(151,107,79);
   glVertex2d(907,340);
   glVertex2d(1038,272);
    glVertex2d(1118,241);
     glVertex2d(989,313);
     glEnd();

      glBegin(GL_POLYGON);
     glColor3ub(151,107,79);
  glVertex2d(989,313);
   glVertex2d(1118,241);
  glVertex2d(1202,361);
   glVertex2d(1066,431);
     glEnd();
     //jendela
    glBegin(GL_POLYGON);
   glColor3ub(213,190,154);
  glVertex2d(968,364);
   glVertex2d(968,340);
  glVertex2d(987,332);
  glVertex2d(1007,360);
   glVertex2d(1007,384);
     glEnd();

glBegin(GL_POLYGON);
  glColor3ub(101,179,220);
    glVertex2d(973,344);
    glVertex2d(987,338);
    glVertex2d(1002,359);
    glVertex2d(1002,377);
    glVertex2d(973,362);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(213,190,154);
    glVertex2d(968,349);
    glVertex2d(968,345);
    glVertex2d(1007,365);
    glVertex2d(1007,370);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(213,190,154);
    glVertex2d(985,373);
    glVertex2d(985,333);
    glVertex2d(987,332);
    glVertex2d(989,335);
    glVertex2d(989,375);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(101,179,220);
    glVertex2d(924,402);
    glVertex2d(924,367);
    glVertex2d(958,384);
    glVertex2d(958,419);
     glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(213,190,154);
    glVertex2d(924,386);
    glVertex2d(924,382);
    glVertex2d(958,400);
    glVertex2d(958,403);
     glEnd();

    glBegin(GL_POLYGON);
  glColor3ub(213,190,154);

    glVertex2d(939,409);
    glVertex2d(939,375);
    glVertex2d(942,375);
    glVertex2d(942,411);
     glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(213,190,154);
    glVertex2d(924,386);
    glVertex2d(924,382);
    glVertex2d(958,400);
    glVertex2d(958,403);
     glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(101,179,220);
    glVertex2d(1016,450);
    glVertex2d(1016,415);
    glVertex2d(1050,432);
    glVertex2d(1050,467);
     glEnd();

 glBegin(GL_POLYGON);
    glColor3ub(213,190,154);

    glVertex2d(1016,434);
    glVertex2d(1016,430);
    glVertex2d(1050,448);
    glVertex2d(1050,452);
     glEnd();

 glBegin(GL_POLYGON);
glColor3ub(213,190,154);
    glVertex2d(1031,457);
    glVertex2d(1031,423);
    glVertex2d(1035,424);
    glVertex2d(1035,459);
     glEnd();
     //jendela samping
      glBegin(GL_POLYGON);
  glColor3ub(101,179,220);
    glVertex2d(1093,464);
    glVertex2d(1093,430);
    glVertex2d(1126,412);
    glVertex2d(1126,447);
     glEnd();

     //pintuuu
      glBegin(GL_POLYGON);

  glColor3ub(196,171,130);
    glVertex2d(968,456);
    glVertex2d(968,373);
    glVertex2d(1007,393);
    glVertex2d(1007,477);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(101,179,220);
    glVertex2d(971,412);
    glVertex2d(971,379);
    glVertex2d(1003,396);
    glVertex2d(1003,428);
     glEnd();
//PINTU JENDELA
glBegin(GL_POLYGON);
  glColor3ub(196,171,130);
    glVertex2d(985,382);
    glVertex2d(989,384);
    glVertex2d(989,425);
    glVertex2d(985,423);
     glEnd();

     glBegin(GL_POLYGON);

  glColor3ub(196,171,130);
    glVertex2d(968,396);
    glVertex2d(968 ,392);
    glVertex2d(1007,412);
    glVertex2d(1007,416);
     glEnd();

     //JENDELA

     glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(1108,422);
    glVertex2d(1112,420);
    glVertex2d(1112,455);
    glVertex2d(1108,457);
     glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(1093,445);
    glVertex2d(1127,428);
    glVertex2d(1127,432);
    glVertex2d(1093,449);
     glEnd();
//SINI
         glBegin(GL_POLYGON);
 glColor3ub(101,179,220);
    glVertex2d(1148,437);
    glVertex2d(1148,402);
    glVertex2d(1182,385);
    glVertex2d(1182,420);
     glEnd();

         glBegin(GL_POLYGON);
    glColor3ub(243,243,243);
    glVertex2d(1163,395);
    glVertex2d(1166,393);
    glVertex2d(1166,427);
    glVertex2d(1163,429);
     glEnd();

       glBegin(GL_POLYGON);
      glColor3ub(101,179,220);
    glVertex2d(1148,418);
    glVertex2d(1181,400);
    glVertex2d(1181,404);
    glVertex2d(1148,421);
     glEnd();
}

void rumah2(){
    //pondasi
       glBegin(GL_POLYGON);
       glColor3ub(229,181,128);
    glVertex2d(1163,538);
    glVertex2d(1164,421);
    glVertex2d(1200,398);
    glVertex2d(1264,439);
    glVertex2d(1264,611);
     glEnd();

  glBegin(GL_POLYGON);
    glColor3ub(216,155,78);
    glVertex2d(1264,611);
    glVertex2d(1264,481);
    glVertex2d(1363,433);
    glVertex2d(1363,547);
     glEnd();
//jendela
    glBegin(GL_POLYGON);
   glColor3ub(0,118,133);
    glVertex2d(1279,537);
    glVertex2d(1279,494);
    glVertex2d(1299,481);
    glVertex2d(1299,524);
     glEnd();

       glBegin(GL_POLYGON);
      glColor3ub(0,118,133);
    glVertex2d(1307,520);
    glVertex2d(1307,477);
    glVertex2d(1327,463);
    glVertex2d(1327,507);
     glEnd();

      glBegin(GL_POLYGON);
      glColor3ub(0,118,133);
    glVertex2d(1336,502);
    glVertex2d(1336,459);
    glVertex2d(1356,446);
    glVertex2d(1356,489);
     glEnd();
//atap
      glBegin(GL_POLYGON);
   glColor3ub(193,40,28);
    glVertex2d(1282,512);
    glVertex2d(1211,415);
    glVertex2d(1307,353);
    glVertex2d(1378,449);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(193,40,28);
    glVertex2d(1143,419);
    glVertex2d(1235,359);
    glVertex2d(1307,353);
    glVertex2d(1211,415);
     glEnd();
//

      glBegin(GL_POLYGON);
      glColor3ub(229,181,128);
    glVertex2d(1277,602);
    glVertex2d(1277,550);
    glVertex2d(1290,542);
    glVertex2d(1336,571);
    glVertex2d(1336,641);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(217,155,78);
    glVertex2d(1336,641);
    glVertex2d(1336,591);
    glVertex2d(1395,553);
    glVertex2d(1395,603);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(0,159,180);
    glVertex2d(1169,539);
    glVertex2d(1169,494);
    glVertex2d(1189,508);
    glVertex2d(1189,553);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(0,159,180);
    glVertex2d(1231,580);
    glVertex2d(1231,535);
    glVertex2d(1254,549);
    glVertex2d(1254,594);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(104,17,11);
    glVertex2d(1202,558);
    glVertex2d(1202,523);
    glVertex2d(1222,534);
    glVertex2d(1222,571);
     glEnd();
//tangga
     glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1185,582);
    glVertex2d(1185,576);
    glVertex2d(1206,589);
    glVertex2d(1206,595);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(240,182,117);
    glVertex2d(1185,576);
    glVertex2d(1192,572);
    glVertex2d(1212,585);
    glVertex2d(1206,589);
     glEnd();

     glBegin(GL_POLYGON);
      glColor3ub(158,119,73);
    glVertex2d(1206,595);
    glVertex2d(1206,589);
    glVertex2d(1212,585);
    glVertex2d(1212,591);
     glEnd();

     glBegin(GL_POLYGON);
       glColor3ub(158,119,73);
    glVertex2d(1192,572);
    glVertex2d(1192,565);
    glVertex2d(1212,578);
    glVertex2d(1212,585);
     glEnd();


     glBegin(GL_POLYGON);
     glColor3ub(240,182,117);
    glVertex2d(1192,565);
    glVertex2d(1202,558);
    glVertex2d(1222,571);
    glVertex2d(1212,578);
     glEnd();


     glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1212,578);
    glVertex2d(1222,571);
    glVertex2d(1222,584);
    glVertex2d(1212,591);
     glEnd();

//pondasi
 glBegin(GL_POLYGON);
  glColor3ub(129,90,9);
    glVertex2d(1277,603);
    glVertex2d(1277,594);
    glVertex2d(1336,632);
    glVertex2d(1336,641);
     glEnd();

     //pintudepan
      glBegin(GL_POLYGON);
   glColor3ub(129,90,9);
    glVertex2d(1336,641);
    glVertex2d(1336,632);
    glVertex2d(1395,594);
    glVertex2d(1395,603);
     glEnd();
//atap
     glBegin(GL_POLYGON);
  glColor3ub(193,40,28);
    glVertex2d(1337,612);
    glVertex2d(1295,548);
    glVertex2d(1372,499);
    glVertex2d(1412,563);
     glEnd();

     glBegin(GL_POLYGON);
  glColor3ub(193,40,28);
    glVertex2d(1295,548);
    glVertex2d(1253,559);
    glVertex2d(1331,509);
    glVertex2d(1373,499);
     glEnd();
//pintu samping
     glBegin(GL_POLYGON);
      glColor3ub(158,119,73);
    glVertex2d(1288,610);
    glVertex2d(1288,575);
    glVertex2d(1318,592);
    glVertex2d(1318,629);
     glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(129,90,9);
    glVertex2d(1336,641);
    glVertex2d(1336,632);
    glVertex2d(1395,594);
    glVertex2d(1395,603);
     glEnd();
//jendela balkon
 glBegin(GL_POLYGON);
  glColor3ub(0,159,180);
    glVertex2d(1182,427);
    glVertex2d(1182,470);
    glVertex2d(1245,515);
    glVertex2d(1245,464);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(273,273,273);
    glVertex2d(1213,489);
    glVertex2d(1213,446);
    glVertex2d(1215,447);
    glVertex2d(1214,517);
     glEnd();
//balkon

glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.0, 1.0, 1.0, 0.1);
      glVertex2d(1179,468);
    glVertex2d(1161,480);
    glVertex2d(1234,527);
    glVertex2d(1252,515);
     glEnd();



     glBegin(GL_POLYGON);
 glColor3ub(158,119,73);
    glVertex2d(1161,483);
    glVertex2d(1161,480);
    glVertex2d(1234,526);
    glVertex2d(1234,530);
     glEnd();

     glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1234,530);
    glVertex2d(1234,526);
    glVertex2d(1252,515);
    glVertex2d(1252,519);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1166,460);
    glVertex2d(1181,450);
    glVertex2d(1181,451);
    glVertex2d(1166,461);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1166,462);
    glVertex2d(1166,461);
    glVertex2d(1181,451);
    glVertex2d(1181,452);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1234,530);
    glVertex2d(1234,526);
    glVertex2d(1252,515);
    glVertex2d(1252,519);
     glEnd();

  glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1164,461);
    glVertex2d(1165,460);
    glVertex2d(1235,505);
    glVertex2d(1235,506);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1164,462);
    glVertex2d(1164,461);
    glVertex2d(1234,506);
    glVertex2d(1234,507);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1234,530);
    glVertex2d(1234,526);
    glVertex2d(1252,515);
    glVertex2d(1252,519);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1240,505);
    glVertex2d(1251,495);
    glVertex2d(1251,495);
    glVertex2d(1236,505);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1232,505);
    glVertex2d(1233,506);
    glVertex2d(1233,525);
    glVertex2d(1232,525);
     glEnd();

         glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1233,525);
    glVertex2d(1233,505);
    glVertex2d(1234,505);
    glVertex2d(1234,525);
     glEnd();

         glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1165,482);
    glVertex2d(1165,462);
    glVertex2d(1167,463);
    glVertex2d(1167,483);
     glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1202,505);
    glVertex2d(1202,486);
    glVertex2d(1203,486);
    glVertex2d(1203,506);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1203,506);
    glVertex2d(1203,486);
    glVertex2d(1204,486);
    glVertex2d(1203,505);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1202,505);
    glVertex2d(1202,486);
    glVertex2d(1203,486);
    glVertex2d(1203,506);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1193,500);
    glVertex2d(1194,480);
    glVertex2d(1195,480);
    glVertex2d(1195,500);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1183,493);
    glVertex2d(1183,473);
    glVertex2d(1184,474);
    glVertex2d(1184,494);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(158,119,73);
    glVertex2d(1211,511);
    glVertex2d(1211,491);
    glVertex2d(1213,492);
    glVertex2d(1213,512);
     glEnd();

//pohon
       //batang
 glBegin(GL_POLYGON);
        glColor3ub(165,118,103);
              glVertex2f(1420,515);
              glVertex2f(1420,481);
              glVertex2f(1431,481);
              glVertex2f(1431,511);
        glEnd();
  glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(1423+cos(rad)*30,467+sin(rad)*30);
           }
        glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(126,184,59);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(1415+cos(rad)*14,457+sin(rad)*14);
           }
        glEnd();

          //batang
 glBegin(GL_POLYGON);
        glColor3ub(165,118,103);
              glVertex2f(134,512);
              glVertex2f(134,478);
              glVertex2f(147,478);
              glVertex2f(147,512);
        glEnd();
  glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(140+cos(rad)*35,467+sin(rad)*30);
           }
        glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(126,184,59);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(155+cos(rad)*14,462+sin(rad)*14);
           }
        glEnd();

        //BATANG
    glBegin(GL_POLYGON);
    glColor3ub(165,118,103);
    glVertex2d(920,593);
    glVertex2d(920,559);
    glVertex2d(933,559);
    glVertex2d(933,593);
    glEnd();
         glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(930+cos(rad)*30,551+sin(rad)*30);
           }
        glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(126,184,59);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(950+cos(rad)*20,871+sin(rad)*14);
           }
        glEnd();
}

void rumah3(){

//taman

 glBegin(GL_POLYGON);
   glColor3ub(181,232,97);
    glVertex2d(1321,696);
    glVertex2d(1572,578);
    glVertex2d(1822,696);
    glVertex2d(1572,813);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(154,196,82);
    glVertex2d(1368,725);
    glVertex2d(1432,695);
    glVertex2d(1476,716);
    glVertex2d(1412,746);
     glEnd();




//pondasi
  glBegin(GL_POLYGON);
   glColor3ub(232,228,208);
    glVertex2d(1404,692);
     glColor3ub(220,216,194);
    glVertex2d(1404,557);
    glVertex2d(1574,678);
    glVertex2d(1574,772);
     glEnd();


  glBegin(GL_POLYGON);
   glColor3ub(232,228,208);
     glVertex2d(1574,772);
   glVertex2d(1574,678);
    glVertex2d(1743,598);
       glColor3ub(220,216,194);
    glVertex2d(1743,692);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(242,138,104);
     glVertex2d(1578,683);
   glVertex2d(1399,553);
    glVertex2d(1573,473);
    glVertex2d(1747,600);
    glVertex2d(1744,604);
    glVertex2d(1578,683);
     glEnd();

     //pintu
     glBegin(GL_POLYGON);
    glColor3ub(125,117,73);
    glVertex2d(1420,699);
    glVertex2d(1420,616);
    glVertex2d(1465,637);
    glVertex2d(1465,720);
     glEnd();

     glBegin(GL_POLYGON);
      glColor3ub(101,179,220);
     glVertex2d(1425,656);
   glVertex2d(1425,623);
    glVertex2d(1460,640);
    glVertex2d(1460,673);
     glEnd();

      glBegin(GL_POLYGON);
   glColor3ub(143,133,85);
    glVertex2d(1440,668);
    glVertex2d(1440,626);
    glVertex2d(1445,628);
    glVertex2d(1445,670);
     glEnd();

       glBegin(GL_POLYGON);
    glColor3ub(143,133,85);
    glVertex2d(1420,640);
    glVertex2d(1420,635);
    glVertex2d(1465,656);
    glVertex2d(1465,661);
     glEnd();

     //JENDELA

      glBegin(GL_POLYGON);
   glColor3ub(125,117,73);
    glVertex2d(1585,723);
    glVertex2d(1585,686);
    glVertex2d(1732,617);
    glVertex2d(1732,654);
     glEnd();

       glBegin(GL_POLYGON);
   glColor3ub(101,179,220);
    glVertex2d(1588,718);
    glVertex2d(1588,688);
    glVertex2d(1729,622);
    glVertex2d(1729,652);
     glEnd();
//cerobong
 glBegin(GL_POLYGON);
    glColor3ub(220,216,194);
    glVertex2d(1552,537);
    glVertex2d(1552,518);
    glVertex2d(1577,530);
    glVertex2d(1577,569);
     glEnd();

      glBegin(GL_POLYGON);
    glColor3ub(220,216,194);
    glVertex2d(1577,569);
    glVertex2d(1577,530);
    glVertex2d(1602,518);
    glVertex2d(1602,557);
     glEnd();

     glBegin(GL_POLYGON);
     glColor3ub(143,133,85);
    glVertex2d(1546,521);
    glVertex2d(1546,508);
    glVertex2d(1577,522);
    glVertex2d(1577,535);
     glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(220,216,194);
    glVertex2d(1577,569);
    glVertex2d(1577,530);
    glVertex2d(1602,518);
    glVertex2d(1602,557);
     glEnd();

      glBegin(GL_POLYGON);
  glColor3ub(143,133,85);
    glVertex2d(1577,535);
    glVertex2d(1577,522);
    glVertex2d(1608,508);
    glVertex2d(1608,521);
     glEnd();

      glBegin(GL_POLYGON);
glColor3ub(178,172,130);
    glVertex2d(1577,522);
    glVertex2d(1546,508);
    glVertex2d(1577,493);
    glVertex2d(1608,508);
     glEnd();

       glBegin(GL_POLYGON);
glColor3ub(115,107,67);
    glVertex2d(1577,517);
    glVertex2d(1558,508);
    glVertex2d(1577,499);
     glEnd();

       glBegin(GL_POLYGON);
glColor3ub(143,133,85);
    glVertex2d(1577,517);
    glVertex2d(1577,499);
    glVertex2d(1597,508);
     glEnd();
//jendela
 glBegin(GL_POLYGON);
glColor3ub(49,114,144);
    glVertex2d(1492,688);
    glVertex2d(1492,647);
    glVertex2d(1537,668);
    glVertex2d(1537,709);
     glEnd();

}
void rumah4(){
    //genteng
      glBegin(GL_POLYGON);
glColor3ub(49,114,144);
    glVertex2d(1151,868);
    glVertex2d(1092,901);
    glVertex2d(1040,785);
    glVertex2d(1100,754);
     glEnd();

      glBegin(GL_POLYGON);
glColor3ub(49,114,144);
    glVertex2d(1089,902);
    glVertex2d(1044,795);
    glVertex2d(1040,785);
    glVertex2d(1095,900);

    glBegin(GL_POLYGON);
glColor3ub(49,114,144);
    glVertex2d(995,845);
    glVertex2d(1040,785);
    glVertex2d(1044,795);
    glVertex2d(1000,849);
     glEnd();

      glBegin(GL_POLYGON);
glColor3ub(49,114,144);
    glVertex2d(1041,814);
    glVertex2d(1039,809);
    glVertex2d(1087,697);
    glVertex2d(1090,695);
    glVertex2d(1092,696);
    glVertex2d(1201,760);
    glVertex2d(1156,878);
     glEnd();


      glBegin(GL_POLYGON);
glColor3ub(49,114,144);
     glVertex2d(1156,878);
    glVertex2d(1201,760);
    glVertex2d(1207,770);
    glVertex2d(1162,877);
    glEnd();

    glBegin(GL_POLYGON);
glColor3ub(49,114,144);
  glVertex2d(1203,770);
    glVertex2d(1208,761);
    glVertex2d(1256,820);
    glVertex2d(1251,824);
     glEnd();


    glBegin(GL_POLYGON);
glColor3ub(49,114,144);
  glVertex2d(1202,762);
    glVertex2d(1208,761);
    glVertex2d(1207,770);
    glEnd();

     //tembok
 glBegin(GL_POLYGON);
glColor3ub(247,197,129);
    glVertex2d(997,886);
    glVertex2d(997,847);
    glVertex2d(1045,789);
    glVertex2d(1092,901);
    glVertex2d(1092,940);
     glEnd();

glBegin(GL_POLYGON);
glColor3ub(247,197,129);
    glVertex2d(1092,940);
    glVertex2d(1092,901);
    glVertex2d(1148,870);
    glVertex2d(1148,909);
     glEnd();

     glBegin(GL_POLYGON);
glColor3ub(247,197,129);
    glVertex2d(1148,909);
    glVertex2d(1148,870);
    glVertex2d(1159,876);
    glVertex2d(1159,915);
     glEnd();

     glBegin(GL_POLYGON);
glColor3ub(247,197,129);
    glVertex2d(1159,915);
    glVertex2d(1159,876);
    glVertex2d(1206,763);
    glVertex2d(1254,822);
    glVertex2d(1254,861);
     glEnd();

//pintu

    glBegin(GL_POLYGON);
glColor3ub(163,125,70);
  glVertex2d(1023,901);
    glVertex2d(1023,838);
    glVertex2d(1029,835);
    glVertex2d(1056,850);
    glVertex2d(1056,920);
     glEnd();


    glBegin(GL_POLYGON);
glColor3ub(196,149,86);
  glVertex2d(1026,869);
    glVertex2d(1026,837);
    glVertex2d(1054,853);
    glVertex2d(1054,885);
     glEnd();


    glBegin(GL_POLYGON);
glColor3ub(127,198,229);
  glVertex2d(1029,868);
    glVertex2d(1029,842);
    glVertex2d(1052,855);
    glVertex2d(1052,881);
     glEnd();


    glBegin(GL_POLYGON);
glColor3ub(196,149,86);
  glVertex2d(1039,877);
    glVertex2d(1039,845);
    glVertex2d(1042,846);
    glVertex2d(1042,875);
     glEnd();


    glBegin(GL_POLYGON);
glColor3ub(196,149,86);
  glVertex2d(1055,871);
    glVertex2d(1026,855);
    glVertex2d(1026,852);
    glVertex2d(1055,867);
     glEnd();

     //GARASI

    glBegin(GL_POLYGON);
glColor3ub(196,149,86);
  glVertex2d(1189,897);
    glVertex2d(1189,839);
    glVertex2d(1231,816);
    glVertex2d(1231,873);
     glEnd();

         glBegin(GL_POLYGON);
glColor3ub(125,95,52);
  glVertex2d(1189,885);
    glVertex2d(1189,872);
    glVertex2d(1231,849);
    glVertex2d(1231,861);
     glEnd();

       glBegin(GL_POLYGON);
glColor3ub(125,95,52);
  glVertex2d(1189,865);
    glVertex2d(1189,852);
    glVertex2d(1231,828);
    glVertex2d(1231,841);
     glEnd();

    //batang
 glBegin(GL_POLYGON);
        glColor3ub(165,118,103);
              glVertex2f(869,424);
              glVertex2f(869,389);
              glVertex2f(861,389);
              glVertex2f(861,424);
        glEnd();
  glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(865+cos(rad)*30,374.53+sin(rad)*30);
           }
        glEnd();
    glBegin(GL_POLYGON);
        glColor3ub(126,184,59);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(870+cos(rad)*14,365+sin(rad)*14);
           }
        glEnd();
}

void kolam(){
    //RUMPUT
  glBegin(GL_POLYGON);
        glColor3ub(124,398,575);
          glVertex2d(330,609);
          glVertex2d(430,550);
          glVertex2d(530,608);
          glVertex2d(430,666);
          glEnd();


glBegin(GL_POLYGON);
   glColor3ub(108,191,216);
    glVertex2d(362,612);
    glVertex2d(434,571);
    glVertex2d(488,602);
    glVertex2d(418,643);
     glEnd();
     //JEMBATAN
//lantai jembatan dari kanan
        glBegin(GL_POLYGON);
        glColor3ub(150,108,72);
        glVertex2d(458,644);
        glVertex2d(434,616);
         glVertex2d(459,602);
          glVertex2d(482,630);
          glEnd();

             glBegin(GL_POLYGON);
        glColor3ub(198,161,123);
           glVertex2d(434,616);
            glVertex2d(397,598);
            glVertex2d(423,581);
          glVertex2d(459,602);
          glEnd();

            glBegin(GL_POLYGON);
        glColor3ub(234,193,148);
                  glVertex2d(397,598);
            glVertex2d(367,592);
            glVertex2d(391,577);
          glVertex2d(423,581);
          glEnd();
        //jembatan PINGGIR
        glBegin(GL_POLYGON);
        glColor3ub(124,76,35);
    glVertex2d(373,595);
    glVertex2d(367,592);
    glVertex2d(398,595);
    glVertex2d(397,598);
    glEnd();

      glBegin(GL_POLYGON);
        glColor3ub(124,76,35);
          glVertex2d(397,598);
          glVertex2d(398,595);
    glVertex2d(434,616);
    glVertex2d(433,619);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(124,76,35);
         glVertex2d(433,619);
          glVertex2d(434,616);
          glVertex2d(458,644);
          glVertex2d(450,639);
          glEnd();
//pager
       glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(860,898);
          glVertex2d(860,843);
          glVertex2d(864,835);
          glVertex2d(867,839);
          glVertex2d(867,893);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(873,890);
          glVertex2d(873,836);
          glVertex2d(877,828);
          glVertex2d(880,831);
          glVertex2d(880,886);
          glEnd();


           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(886,883);
          glVertex2d(886,828);
          glVertex2d(890,821);
          glVertex2d(894,824);
          glVertex2d(894,877);
          glEnd();


           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(899,876);
          glVertex2d(899,821);
          glVertex2d(904,813);
          glVertex2d(907,817);
          glVertex2d(907,872);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(913,868);
          glVertex2d(913,814);
          glVertex2d(917,806);
          glVertex2d(920,810);
          glVertex2d(920,864);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(926,861);
          glVertex2d(926,806);
          glVertex2d(930,799);
          glVertex2d(933,802);
          glVertex2d(933,857);
          glEnd();


           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(939,854);
          glVertex2d(939,800);
          glVertex2d(943,792);
          glVertex2d(947,795);
          glVertex2d(947,850);
          glEnd();


           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(952,847);
          glVertex2d(952,792);
          glVertex2d(956,784);
          glVertex2d(960,788);
          glVertex2d(960,842);
          glEnd();

             glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(966,839);
          glVertex2d(966,785);
          glVertex2d(970,777);
          glVertex2d(973,780);
          glVertex2d(973,835);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(979,832);
          glVertex2d(979,777);
          glVertex2d(983,770);
          glVertex2d(986,773);
          glVertex2d(986,828);
          glEnd();

            glBegin(GL_POLYGON);
        glColor3ub(242,214,177);
         glVertex2d(857,862);
          glVertex2d(857,856);
          glVertex2d(989,783);
          glVertex2d(989,787);
          glEnd();

          //bangku taman
           glBegin(GL_POLYGON);
        glColor3ub(124,79,35);
         glVertex2d(1235,980);
          glVertex2d(1235,968);
          glVertex2d(1246,973);
          glVertex2d(1253,970);
          glVertex2d(1253,973);
          glEnd();

              glBegin(GL_POLYGON);
        glColor3ub(124,79,35);
         glVertex2d(1231,978);
          glVertex2d(1231,967);
          glVertex2d(1235,968);
          glVertex2d(1235,980);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(178,126,70);
        glVertex2d(1246,973);
         glVertex2d(1246,970);
          glVertex2d(1266,963);
          glVertex2d(1266,965);
          glEnd();


           glBegin(GL_POLYGON);
        glColor3ub(178,126,70);
        glVertex2d(1182,948);
         glVertex2d(1182,945);
         glVertex2d(1246,970);
         glVertex2d(1246,973);
          glEnd();

          glBegin(GL_POLYGON);
        glColor3ub(178,126,70);
         glVertex2d(1231,978);
          glVertex2d(1231,967);
          glVertex2d(1235,968);
          glVertex2d(1235,980);
          glEnd();

           glBegin(GL_POLYGON);
        glColor3ub(204,160,113);
         glVertex2d(1182,945);
          glVertex2d(1201,938);
          glVertex2d(1266,963);
          glVertex2d(1246,970);
          glEnd();

             glBegin(GL_POLYGON);
        glColor3ub(137,129,125);
         glVertex2d(1188,945);
          glVertex2d(1201,940);
          glVertex2d(1259,962);
          glVertex2d(1246,967);
          glEnd();

             glBegin(GL_POLYGON);
          glColor3ub(124,79,35);
         glVertex2d(1193,964);
          glVertex2d(1193,952);
          glVertex2d(1209,958);
          glEnd();

             glBegin(GL_POLYGON);
   glColor3ub(124,79,35);
         glVertex2d(1191,963);
          glVertex2d(1191,951);
          glVertex2d(1193,952);
           glVertex2d(1193,964);
          glEnd();

             glBegin(GL_POLYGON);
   glColor3ub(160,114,69);
         glVertex2d(1210,942);
          glVertex2d(1212,935);
          glVertex2d(1216,936);
           glVertex2d(1212,943);
          glEnd();


             glBegin(GL_POLYGON);
   glColor3ub(160,114,69);
    glVertex2d(1212,943);
     glVertex2d(1216,936);
         glVertex2d(1218,938);
          glVertex2d(1215,944);
          glEnd();

        glBegin(GL_POLYGON);
   glColor3ub(160,114,69);
    glVertex2d(1249,957);
     glVertex2d(1252,951);
         glVertex2d(1255,952);
          glVertex2d(1252,959);
          glEnd();


             glBegin(GL_POLYGON);
   glColor3ub(160,114,69);
    glVertex2d(1252,959);
     glVertex2d(1255,952);
         glVertex2d(1257,953);
          glVertex2d(1254,960);
          glEnd();

          glBegin(GL_POLYGON);
   glColor3ub(186,134,82);
    glVertex2d(1203,934);
     glVertex2d(1206,920);
         glVertex2d(1272,945);
          glVertex2d(1269,959);
          glEnd();

          glBegin(GL_POLYGON);
   glColor3ub(216,169,125);
    glVertex2d(1206,920);
     glVertex2d(1210,919);
         glVertex2d(1275,944);
          glVertex2d(1272,945);
          glEnd();

          glBegin(GL_POLYGON);
   glColor3ub(140,91,47);
    glVertex2d(1269,959);
     glVertex2d(1272,945);
         glVertex2d(1275,944);
          glVertex2d(1272,958);
          glEnd();

//pohon
//batang
glBegin(GL_POLYGON);
   glColor3ub(160,114,69);
    glVertex2d(1372,910);
     glVertex2d(1372,833);
         glVertex2d(1385,833);
          glVertex2d(1385,910);
          glEnd();

//daun
glBegin(GL_POLYGON);
   glColor3ub(137,176,53);
    glVertex2d(1334,869);
     glVertex2d(1334,827);
         glVertex2d(1378,852);
          glVertex2d(1378,893);
          glEnd();

          glBegin(GL_POLYGON);
            glColor3ub(108,143,27);
             glVertex2d(1378,893);
               glVertex2d(1378,852);
            glVertex2d(1421,825);
            glVertex2d(1421,867);
          glEnd();

           glBegin(GL_POLYGON);
            glColor3ub(159,193,88);
             glVertex2d(1334,827);
               glVertex2d(1377,801);
            glVertex2d(1421,825);
            glVertex2d(1378,852);
          glEnd();

           glBegin(GL_POLYGON);
            glColor3ub(137,176,53);
             glVertex2d(1343,825);
               glVertex2d(1343,787);
            glVertex2d(1376,805);
            glVertex2d(1376,844);
          glEnd();

           glBegin(GL_POLYGON);
            glColor3ub(108,143,27);
             glVertex2d(1377,844);
               glVertex2d(1377,805);
            glVertex2d(1410,785);
            glVertex2d(1410,823);
          glEnd();

           glBegin(GL_POLYGON);
  glColor3ub(159,193,88);
             glVertex2d(1342,787);
               glVertex2d(1376,766);
            glVertex2d(1410,785);
            glVertex2d(1376,806);
          glEnd();

          glBegin(GL_POLYGON);
            glColor3ub(137,176,53);
             glVertex2d(1351,785);
               glVertex2d(1351,758);
            glVertex2d(1376,771);
            glVertex2d(1376,799);
          glEnd();

  glBegin(GL_POLYGON);
            glColor3ub(108,143,27);
                glVertex2d(1376,799);
                glVertex2d(1376,771);
             glVertex2d(1400,756);
               glVertex2d(1400,784);
          glEnd();

            glBegin(GL_POLYGON);
              glColor3ub(159,193,88);
                glVertex2d(1350,758);
                glVertex2d(1375,743);
             glVertex2d(1400,756);
               glVertex2d(1375,771);
          glEnd();

}
void ayunan (){
  glBegin(GL_POLYGON);
              glColor3ub(253,207,0);
                glVertex2d(566,674);
                glVertex2d(566,606);
             glVertex2d(572,607);
               glVertex2d(572,674);
          glEnd();
 glBegin(GL_POLYGON);
              glColor3ub(253,207,0);
               glVertex2d(568,608);
                glVertex2d(568,600);
                glVertex2d(670,664);
               glVertex2d(670,672);
          glEnd();

           glBegin(GL_POLYGON);
              glColor3ub(253,207,0);
               glVertex2d(670,720);
                glVertex2d(670,664);
                glVertex2d(676,670);
               glVertex2d(676,725);
          glEnd();

//pohon
//batang
 glBegin(GL_POLYGON);
              glColor3ub(165,118,103);
                glVertex2d(703,804);
                glVertex2d(703,769);
             glVertex2d(717,769);
               glVertex2d(717,804);
          glEnd();

           glBegin(GL_POLYGON);
              glColor3ub(165,118,103);
                glVertex2d(761,778);
                glVertex2d(761,744);
             glVertex2d(775,744);
               glVertex2d(775,778);
          glEnd();

//daun hijau tua
 glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(710+cos(rad)*30,750+sin(rad)*30);
           }
        glEnd();

         glBegin(GL_POLYGON);
        glColor3ub(107,156,49);
                for (i=0; i <= 360; i++) {
              float rad = i*3.14159/180;
              glVertex2f(768+cos(rad)*30,730+sin(rad)*30);
           }
        glEnd();



}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1920, 1080, "Dwika Ayu N- <G64160116>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);



    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        warna();
        belakang();
        bintang();
        kelip();
        pondasi();
        taman();
        gedung1();
        rumah();
        gedung2();
        jalan();
        rumah1();
        rumah2();
        rumah3();
        rumah4();
        kolam();
        ayunan();
        matahari();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}




