#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define clchange color,color,color


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1000, 1000, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void background(){
    //langit
   glBegin(GL_POLYGON);
   glColor3ub(0,255,255);
   glVertex2d(0,0);
   glVertex2d(0,766);
   glVertex2d(1000,766);
   glVertex2d(1000,0);
   glEnd();

    //jalan
   glBegin(GL_POLYGON);
   glColor3ub(131,139,197);
   glVertex2d(0,766);
   glVertex2d(1000,766);
   glVertex2d(1000,1000);
   glVertex2d(0,1000);
   glEnd();
}

void semak(float size){
    int N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    glColor3ub(115,99,40);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}

void pohon(float size){
    int N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    glColor3ub(87,85,34);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
}

void taman(){
   glBegin(GL_POLYGON);
   glColor3ub(171,145,43);
   glVertex2f(0,640);
   glVertex2f(1000,640);
   glVertex2f(1000,830);
   glVertex2f(0,830);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(128,128,0);
   glVertex2f(883.3,707.89);
   glVertex2f(891.92,717.03);
   glVertex2f(883.3,726.17);
   glVertex2f(160.61,726.17);
   glVertex2f(152,717.03);
   glVertex2f(160.61,707.89);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(128,128,0);
   glVertex2f(328.97,733.91);
   glVertex2f(316.46,742.26);
   glVertex2f(328.97,750.61);
   glVertex2f(424.39,750.61);
   glVertex2f(436.9,742.26);
   glVertex2f(424.39,733.91);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(128,128,0);
   glVertex2f(0,732.26);
   glVertex2f(192.4,732.26);
   glVertex2f(199.44,749.61);
   glVertex2f(192.4,749.61);
   glVertex2f(0,749.61);
   glEnd();
}

void tembok(){
    //putih
   glBegin(GL_POLYGON);
   glColor3ub(255,248,246);
   glVertex2f(175.42,403.37);
   glVertex2f(175.42,636.07);
   glVertex2f(564.2,636.07);
   glVertex2f(564.2,403.37);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,248,246);
   glVertex2f(603.02,276.66);
   glVertex2f(833.77,276.66);
   glVertex2f(833.77,675.51);
   glVertex2f(603.22,675.51);
   glEnd();

    //abu-abu
   glBegin(GL_POLYGON);
   glColor3ub(220,220,220);
   glVertex2f(383.16,403.37);
   glVertex2f(567.61,403.37);
   glVertex2f(567.61,635.79);
   glVertex2f(383.16,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(220,220,220);
   glVertex2f(603.02,276.66);
   glVertex2f(628.16,276.66);
   glVertex2f(628.16,675.41);
   glVertex2f(603.02,675.41);
   glEnd();
}

void balkon(){
   glBegin(GL_POLYGON);
   glColor3ub(59,59,61);
   glVertex2f(175.423,393.36);
   glVertex2f(567.61,393.36);
   glVertex2f(567.61,403.367);
   glVertex2f(175.423,403.367);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(175.42,371.951);
   glVertex2f(415.07,371.95);
   glVertex2f(415.07,374.93);
   glVertex2f(175.42,374.93);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(175.42,380.78);
   glVertex2f(415.07,380.78);
   glVertex2f(415.07,383.77);
   glVertex2f(175.423,383.77);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(175.42,371.95);
   glVertex2f(178.24,371.95);
   glVertex2f(178.24,393.36);
   glVertex2f(175.423,393.36);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(242.7,371.95);
   glVertex2f(245.51,371.95);
   glVertex2f(245.51,393.36);
   glVertex2f(242.7,393.36);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(321.78,371.95);
   glVertex2f(324.59,371.95);
   glVertex2f(323.59,393.36);
   glVertex2f(321.78,393.36);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(400.86,371.95);
   glVertex2f(403.67,371.95);
   glVertex2f(403.67,393.36);
   glVertex2f(400.86,393.36);
   glEnd();
}

void bata(){
   glBegin(GL_POLYGON);
   glColor3ub(64,64,64);
   glVertex2f(532.94,111.1);
   glVertex2f(603.02,111.1);
   glVertex2f(603.02,357.58);
   glVertex2f(532.94,357.58);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(64,64,64);
   glVertex2f(400.9,56.46);
   glVertex2f(603.02,56.46);
   glVertex2f(603.02,111.1);
   glVertex2f(400.9,111.1);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(64,64,64);
   glVertex2f(400.9,357.58);
   glVertex2f(603.02,357.58);
   glVertex2f(603.02,675.412);
   glVertex2f(400.9,675.412);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(415.07,111.1);
   glVertex2f(532.94,111.1);
   glVertex2f(532.94,357.58);
   glVertex2f(415.07,357.58);
   glEnd();

   //list1
   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(415.07,121.11);
   glVertex2f(523.49,121.11);
   glVertex2f(523.49,176.66);
   glVertex2f(415.07,176.66);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(432.67,138.43);
   glVertex2f(523.49,138.43);
   glVertex2f(523.49,176.66);
   glVertex2f(432.67,176.66);
   glEnd();

   //list2
   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(415.07,186.19);
   glVertex2f(523.49,186.19);
   glVertex2f(523.49,347.57);
   glVertex2f(415.07,347.57);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(432.67,186.19);
   glVertex2f(523.49,186.19);
   glVertex2f(523.49,347.57);
   glVertex2f(432.67,347.57);
   glEnd();
}

void jendela(){
    //atas
   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(175.42,442.92);
   glVertex2f(227.05,442.92);
   glVertex2f(227.05,468.37);
   glVertex2f(175.42,468.37);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(264.7,442.92);
   glVertex2f(371.52,442.92);
   glVertex2f(371.52,468.37);
   glVertex2f(264.7,468.37);
   glEnd();


   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(734.08,340.36);
   glVertex2f(760.79,340.36);
   glVertex2f(760.79,466.37);
   glVertex2f(734.08,466.37);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(784.67,340.36);
   glVertex2f(811.38,340.36);
   glVertex2f(811.38,466.37);
   glVertex2f(784.67,466.37);
   glEnd();


   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(180.73,446.69);
   glVertex2f(223.49,446.69);
   glVertex2f(223.49,464.6);
   glVertex2f(180.73,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(273.57,446.69);
   glVertex2f(316.33,446.69);
   glVertex2f(316.33,464.6);
   glVertex2f(273.57,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(325.2,446.69);
   glVertex2f(367.96,446.69);
   glVertex2f(367.96,464.6);
   glVertex2f(325.2,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(738.04,405.47);
   glVertex2f(756.83,405.47);
   glVertex2f(756.83,462.18);
   glVertex2f(738.04,462.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(788.63,405.47);
   glVertex2f(807.42,405.47);
   glVertex2f(807.42,462.18);
   glVertex2f(788.63,462.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(268.26,446.69);
   glVertex2f(273.57,446.69);
   glVertex2f(273.57,464.6);
   glVertex2f(268.26,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(319.89,446.69);
   glVertex2f(325.2,446.69);
   glVertex2f(325.2,464.6);
   glVertex2f(319.89,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(175.42,446.69);
   glVertex2f(180.73,446.69);
   glVertex2f(180.73,464.6);
   glVertex2f(175.42,464.6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(738.04,344.56);
   glVertex2f(756.83,344.56);
   glVertex2f(756.83,401.27);
   glVertex2f(738.04,401.27);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(788.63,344.56);
   glVertex2f(807.42,344.56);
   glVertex2f(807.42,401.27);
   glVertex2f(788.63,401.27);
   glEnd();

   //bawah
   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(603.52,534.36);
   glVertex2f(696.29,534.36);
   glVertex2f(696.29,661.51);
   glVertex2f(603.52,661.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(632.1,539.71);
   glVertex2f(639.18,539.71);
   glVertex2f(639.18,661.51);
   glVertex2f(632.1,661.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(656.88,539.71);
   glVertex2f(671.05,539.71);
   glVertex2f(671.05,661.51);
   glVertex2f(656.88,661.51);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(606.88,539.71);
   glVertex2f(621.05,539.71);
   glVertex2f(621.05,661.51);
   glVertex2f(606.88,661.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(686.79,539.71);
   glVertex2f(691.9,539.71);
   glVertex2f(691.9,661.51);
   glVertex2f(686.79,661.51);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(603.52,534.36);
   glVertex2f(696.29,534.36);
   glVertex2f(696.29,539.71);
   glVertex2f(603.52,539.71);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(603.52,551.04);
   glVertex2f(696.29,551.04);
   glVertex2f(696.29,556.4);
   glVertex2f(603.52,556.4);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(647.13,534.36);
   glVertex2f(652.18,534.36);
   glVertex2f(652.18,661.51);
   glVertex2f(647.13,661.51);
   glEnd();

   //kanan
    glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(800.49,534.36);
   glVertex2f(833.77,534.36);
   glVertex2f(833.77,661.51);
   glVertex2f(800.49,661.51);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(809.58,556.58);
   glVertex2f(833.42,556.04);
   glVertex2f(833.42,661.51);
   glVertex2f(809.58,661.51);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(819.38,539.71);
   glVertex2f(826.85,539.36);
   glVertex2f(826.85,661.51);
   glVertex2f(819.38,661.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(800.49,534.36);
   glVertex2f(833.77,534.36);
   glVertex2f(833.77,539.71);
   glVertex2f(800.49,539.71);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(800.49,551.04);
   glVertex2f(833.77,551.04);
   glVertex2f(833.77,556.4);
   glVertex2f(800.49,556.4);
   glEnd();
}

void pintu(){
    //kanan
   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(710.34,514.36);
   glVertex2f(787.78,514.36);
   glVertex2f(787.78,672.511);
   glVertex2f(710.34,672.511);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(725.76,533.72);
   glVertex2f(746.6,533.72);
   glVertex2f(746.6,609.82);
   glVertex2f(725.76,609.82);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(751.89,533.72);
   glVertex2f(772.73,533.72);
   glVertex2f(772.73,609.82);
   glVertex2f(751.89,609.82);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(731.25,548.67);
   glVertex2f(746.6,548.67);
   glVertex2f(746.6,609.82);
   glVertex2f(731.25,609.82);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(757.38,548.67);
   glVertex2f(772.73,548.67);
   glVertex2f(772.73,609.82);
   glVertex2f(757.38,609.82);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(255,248,246);
   glVertex2f(716.49,580.23);
   glVertex2f(720.29,580.23);
   glVertex2f(720.29,600.33);
   glVertex2f(716.49,600.33);
   glEnd();

    //tengah
   glBegin(GL_POLYGON);
   glColor3ub(255,248,246);
   glVertex2f(425.13,496.13);
   glVertex2f(578.79,496.13);
   glVertex2f(578.79,671.51);
   glVertex2f(425.13,671.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(433.73,505.53);
   glVertex2f(570.19,505.53);
   glVertex2f(570.19,671.51);
   glVertex2f(433.73,671.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(446.71,520.34);
   glVertex2f(498.22,520.34);
   glVertex2f(498.22,670.51);
   glVertex2f(446.71,670.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(505.7,520.34);
   glVertex2f(557.34,520.34);
   glVertex2f(557.34,670.51);
   glVertex2f(505.7,670.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(446.58,520.34);
   glVertex2f(457.13,520.34);
   glVertex2f(457.13,670.51);
   glVertex2f(446.58,670.51);
   glEnd();


   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(505.7,520.34);
   glVertex2f(515.25,520.34);
   glVertex2f(515.25,670.51);
   glVertex2f(505.7,670.51);
   glEnd();

   //kiri
   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(205.2,518.31);
   glVertex2f(379.39,518.31);
   glVertex2f(379.39,635.79);
   glVertex2f(205.2,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(210.2,523.86);
   glVertex2f(258.12,523.86);
   glVertex2f(258.12,635.79);
   glVertex2f(210.2,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(264.295,523.86);
   glVertex2f(319.14,523.86);
   glVertex2f(319.14,635.79);
   glVertex2f(264.295,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(247,146,74);
   glVertex2f(325.247,523.86);
   glVertex2f(375.16,523.86);
   glVertex2f(375.16,635.79);
   glVertex2f(325.47,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(210.2,523.86);
   glVertex2f(216.2,523.86);
   glVertex2f(216.2,635.79);
   glVertex2f(210.2,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(264.295,523.86);
   glVertex2f(270.14,523.86);
   glVertex2f(270.14,635.79);
   glVertex2f(264.295,635.79);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(325.247,523.86);
   glVertex2f(331.16,523.86);
   glVertex2f(331.16,635.79);
   glVertex2f(325.47,635.79);
   glEnd();
}

void list(){
   glBegin(GL_POLYGON);
   glColor3ub(255,248,246);
   glVertex2f(400.9,673.41);
   glVertex2f(603.02,673.41);
   glVertex2f(603.02,695.51);
   glVertex2f(400.9,695.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(112,65,44);
   glVertex2f(603.02,673.41);
   glVertex2f(833.77,673.41);
   glVertex2f(833.71,695.51);
   glVertex2f(603.02,695.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(244,201,146);
   glVertex2f(702.34,684.46);
   glVertex2f(779.78,684.46);
   glVertex2f(779.78,695.51);
   glVertex2f(702.34,695.51);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(222,179,118);
   glVertex2f(706.34,673.41);
   glVertex2f(783.78,673.41);
   glVertex2f(783.78,684.46);
   glVertex2f(706.34,684.46);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(79,46,31);
   glVertex2f(833.77,248.89);
   glVertex2f(842.96,248.89);
   glVertex2f(842.96,695.51);
   glVertex2f(833.77,695.51);
   glEnd();
}

void tangga(){
   glBegin(GL_POLYGON);
   glColor3ub(79,46,31);
   glVertex2f(161.43,635.79);
   glVertex2f(400.62,635.79);
   glVertex2f(400.62,675.41);
   glVertex2f(161.43,675.41);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(222,179,118);
   glVertex2f(265.96,635.79);
   glVertex2f(313.718,635.79);
   glVertex2f(313.718,649);
   glVertex2f(265.496,649);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(244,201,146);
   glVertex2f(255.96,649);
   glVertex2f(303.718,649);
   glVertex2f(303.718,662.2);
   glVertex2f(255.496,662.2);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(222,179,118);
   glVertex2f(245.96,662.2);
   glVertex2f(293.718,662.2);
   glVertex2f(293.718,675.41);
   glVertex2f(245.496,675.41);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(248.17,632.26);
   glVertex2f(250.43,632.26);
   glVertex2f(250.43,662.43);
   glVertex2f(248.17,662.43);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(290.16,632.26);
   glVertex2f(292.96,632.26);
   glVertex2f(292.96,662.43);
   glVertex2f(290.16,662.43);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(265.41,622.67);
   glVertex2f(267.68,622.67);
   glVertex2f(267.68,648.53);
   glVertex2f(265.41,648.53);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(305.72,622.67);
   glVertex2f(307.99,622.67);
   glVertex2f(307.99,648.53);
   glVertex2f(305.72,648.53);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(268.11,619.98);
   glVertex2f(269.65,620.42);
   glVertex2f(269.24,622.06);
   glVertex2f(247.438,635.44);
   glVertex2f(245.83,635);
   glVertex2f(246.25,633.36);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(255,255,255);
   glVertex2f(309.72,619.98);
   glVertex2f(311.27,620.42);
   glVertex2f(310.85,622.06);
   glVertex2f(289,635.44);
   glVertex2f(290.45,635);
   glVertex2f(287.86,633.36);
   glEnd();
}

float angle_earth = 0.0, angle_moon = 0.0;
void sun(float size)
{
    int N = 30;
    float pX, pY;
    glPushMatrix();
    glTranslatef(100,100,0);
    glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);
    glBegin(GL_POLYGON);
    glColor3ub(255,255,0);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
    glPopMatrix();
}

void kincir(float size)
{
    int N = 30;
    float pX, pY;
    glPushMatrix();
    glTranslatef(930,400,0);

   glBegin(GL_POLYGON);
   glColor3ub(48,48,50);
   glVertex2f(-3,0);
   glVertex2f(3,0);
   glVertex2f(3,300);
   glVertex2f(-3,300);
   glEnd();

    glRotatef((float) glfwGetTime() * 50.f, 0.f, 0.f, 1.f);

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(-6,0);
   glVertex2f(6,0);
   glVertex2f(6,55);
   glVertex2f(-6,55);
   glEnd();

    glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(-6,0);
   glVertex2f(6,0);
   glVertex2f(6,-55);
   glVertex2f(-6,-55);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(0,6);
   glVertex2f(55,6);
   glVertex2f(55,-6);
   glVertex2f(0,-6);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(250,175,94);
   glVertex2f(-55,6);
   glVertex2f(0,6);
   glVertex2f(0,-6);
   glVertex2f(-55,-6);
   glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(247,146,74);
    for(int i = 0; i < N; i++)
    {
        pX = sin(i*2*3.14 / N);
        pY = cos(i*2*3.14 / N);
        glVertex2f(pX * size, pY * size);
    }
    glEnd();
    glPopMatrix();

}

void cloud(float size)
{
    int N = 30;
    float pX, pY;
    glBegin(GL_POLYGON);
    glColor3ub(255,255,255);
    for(int i = 0; i < N; i++)
    {
        pX = (cos(i*2*3.14 / N));
        pY = (sin(i*2*3.14 / N));
        glVertex2f(pX * size, pY * size);
    }
    glEnd();

}

void batang(){

   glBegin(GL_POLYGON);
   glColor3ub(99,59,39);
   glVertex2f(80.17,462.66);
   glVertex2f(85.15,458.33);
   glVertex2f(98.66,475.76);
   glVertex2f(93.68,480.1);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(99,59,39);
   glVertex2f(46,532.16);
   glVertex2f(63.78,522.23);
   glVertex2f(65.94,528.53);
   glVertex2f(48.16,538.49);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(99,59,39);
   glVertex2f(44.2,512.7);
   glVertex2f(49.97,509.83);
   glVertex2f(98.19,560.99);
   glVertex2f(95.49,567.26);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(99,59,39);
   glVertex2f(93.17,443.3);
   glVertex2f(99.62,443.3);
   glVertex2f(99.62,645.41);
   glVertex2f(93.17,645.41);
   glEnd();
}

void pagar(){
    //kiri
    glBegin(GL_POLYGON);
   glColor3ub(194,190,188);
   glVertex2f(0,685);
   glVertex2f(34.01,685);
   glVertex2f(34.01,695.26);
   glVertex2f(0,695.26);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(194,190,188);
   glVertex2f(206.72,685);
   glVertex2f(240.03,685);
   glVertex2f(240.03,695.26);
   glVertex2f(206.72,695.26);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(227,221,219);
   glVertex2f(0,695.26);
   glVertex2f(34.01,695.26);
   glVertex2f(34.01,782.18);
   glVertex2f(0,782.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(227,221,219);
   glVertex2f(206.64,695.26);
   glVertex2f(240.11,695.26);
   glVertex2f(240.11,782.18);
   glVertex2f(206.64,782.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(199,177,140);
   glVertex2f(34.01,751.26);
   glVertex2f(206.64,751.26);
   glVertex2f(206.64,782.18);
   glVertex2f(34.01,782.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(246,217,173);
   glVertex2f(0,782.18);
   glVertex2f(240.03,782.18);
   glVertex2f(240.03,792.18);
   glVertex2f(0,792.18);
   glEnd();

   glBegin(GL_POLYGON);
   glColor3ub(107,95,75);
   glVertex2f(0,792.18);
   glVertex2f(240.03,792.18);
   glVertex2f(240.03,832.18);
   glVertex2f(0,832.18);
   glEnd();
}

void besi(){
    glBegin(GL_POLYGON);
   glColor3ub(48,29,19);
   glVertex2f(34.01,702.26);
   glVertex2f(206.64,702.26);
   glVertex2f(206.64,710.18);
   glVertex2f(34.01,710.18);
   glEnd();

}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(1000, 1000, "Tugas Rumah - <G64160035>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {

        setup_viewport(window);

        display();
        background();

        //semak
        glPushMatrix();
        glTranslatef(40,630,0);
        semak(50);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(120,630,0);
        semak(70);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(850,610,0);
        semak(50);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(950,610,0);
        semak(80);
        glPopMatrix();

        kincir(15);

        taman();
        tembok();
        balkon();
        bata();
        jendela();
        pintu();
        list();
        tangga();
        sun(50);

        //awan
        glPushMatrix();
        glTranslatef(800,140,0);
        cloud(40);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(850,140,0);
        cloud(30);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(750,150,0);
        cloud(30);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(210,230,0);
        cloud(20);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(250,230,0);
        cloud(30);
        glPopMatrix();

         glPushMatrix();
        glTranslatef(290,230,0);
        cloud(20);
        glPopMatrix();

        //pohon
         glPushMatrix();
        glTranslatef(95,450,0);
        pohon(40);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(50,520,0);
        pohon(40);
        glPopMatrix();

        batang();
        pagar();

        glPushMatrix();
        glTranslatef(600,0,0);
        pagar();
        besi();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(806,0,0);
        pagar();
        besi();
        glPopMatrix();

        besi();
        glPushMatrix();
        glTranslatef(0,30,0);
        besi();
        glPopMatrix();

         glPushMatrix();
        glTranslatef(600,30,0);
        besi();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0,60,0);
        besi();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(600,60,0);
        besi();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(806,30,0);
        besi();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(806,60,0);
        besi();
        glPopMatrix();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
