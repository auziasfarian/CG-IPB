#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

// g++ -o rumah rumah.cpp -lGL -lGLU -lglfw3 -lX11 -lXxf86vm -lXrandr -lpthread -lXi -ldl -lXinerama -lXcursor

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 450, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void nama(){
	
	glBegin(GL_POLYGON);
	glColor3ub(200,199,195);
	glVertex2f(0, 0);
	glVertex2f(800, 0);
	glVertex2f(800, 450);
	glVertex2f(0, 450);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(126,116,124);
	glVertex2f(542, 75);
	glVertex2f(800, 223);
	glVertex2f(800, 298);
	glVertex2f(536, 450);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(163,172,115);
	glVertex2f(102, 297);
	glVertex2f(470, 30);
	glVertex2f(800, 221);
	glVertex2f(651.5, 306.5);
	glVertex2f(559.5, 432.5);
	glVertex2f(525.5, 450);
	glVertex2f(369, 460);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(209,179,169);
	glVertex2f(247.3, 267.7);
	glVertex2f(349.5, 353.5);
	glVertex2f(265.5, 400.5);
	glVertex2f(143.5, 330.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(234,222,224);
	glVertex2f(248.5, 261.5);
	glVertex2f(456.5, 366.5);
	glVertex2f(412.5, 394.5);
	glVertex2f(240.3, 289.7);
	glVertex2f(243.3, 286.7);
	glVertex2f(226.3, 277.7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(198,178,179);
	glVertex2f(227.3, 277.7);
	glVertex2f(242.3, 286.7);
	glVertex2f(242.3, 283.7);
	glVertex2f(227.3, 274.7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(235,225,226);
	glVertex2f(357, 0);
	glVertex2f(385, 0);
	glVertex2f(275, 63);
	glVertex2f(247, 63);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(163,150,157);
	glVertex2f(275, 63);
	glVertex2f(395, -6);
	glVertex2f(395, 7);
	glVertex2f(286, 69);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(53,56,61);
	glVertex2f(286, 69);
	glVertex2f(395, 7);
	glVertex2f(403.2, 12);
	glVertex2f(295, 74.2);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(104,95,100);
	glVertex2f(295, 74.2);
	glVertex2f(403.2, 12);
	glVertex2f(504, 69);
	glVertex2f(395, 132);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(196,184,186);
	glVertex2f(395, -6);
	glVertex2f(514, 63);
	glVertex2f(504, 69);
	glVertex2f(395, 7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(163,150,157);
	glVertex2f(395, -6);
	glVertex2f(403.2, 12);
	glVertex2f(395, 7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(235,225,226);
	glVertex2f(247, 63);
	glVertex2f(275, 63);
	glVertex2f(395, 132);
	glVertex2f(395, 147);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(235,225,226);
	glVertex2f(395, 132);
	glVertex2f(514, 63);
	glVertex2f(542, 63);
	glVertex2f(395, 147);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(235,225,226);
	glVertex2f(404, 0);
	glVertex2f(432, 0);
	glVertex2f(542, 63);
	glVertex2f(514, 63);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(195,183,185);
	glVertex2f(247, 63);
	glVertex2f(395, 147);
	glVertex2f(395, 360);
	glVertex2f(247, 276.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(145,134,138);
	glVertex2f(259, 99);
	glVertex2f(283, 112.8);
	glVertex2f(283, 145.8);
	glVertex2f(259, 158.2);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(141,130,134);
	glVertex2f(259, 158.2);
	glVertex2f(283, 145.8);
	glVertex2f(306.5, 159.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(235,225,226);
	glVertex2f(259, 158.2);
	glVertex2f(306.5, 159.5);
	glVertex2f(381.5, 202.5);
	glVertex2f(381.5, 229);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(95,83,87);
	glVertex2f(283, 145.8);
	glVertex2f(283, 113.5);
	glVertex2f(306.5, 127.5);
	glVertex2f(306.5, 159.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(95,83,87);
	glVertex2f(306.5, 127.5);
	glVertex2f(382, 170.2);
	glVertex2f(382, 189.2);
	glVertex2f(306.5, 147.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(122,110,114);
	glVertex2f(306.5, 147.2);
	glVertex2f(382, 189.2);
	glVertex2f(382, 201.2);
	glVertex2f(306.5, 158.2);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(108,97,103);
	glVertex2f(260.2, 165.8);
	glVertex2f(382, 235.8);
	glVertex2f(374, 240.5);
	glVertex2f(252.8, 170);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(50,55,61);
	glVertex2f(374, 240.5);
	glVertex2f(382, 235.8);
	glVertex2f(382, 273.8);
	glVertex2f(374, 278.5);
	
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(96,81,86);
	glVertex2f(261.8, 179);
	glVertex2f(371.8, 242);
	glVertex2f(371.8, 265);
	glVertex2f(261.8, 201.8);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(76,69,76);
	glVertex2f(252.8, 170);
	glVertex2f(374, 240.5);
	glVertex2f(374, 244);
	glVertex2f(252.8, 174);
	glEnd();
	
	
	
	glBegin(GL_POLYGON);
	glColor3ub(76,69,76);
	glVertex2f(371.2, 241);
	glVertex2f(374, 244);
	glVertex2f(374, 278.5);
	glVertex2f(371.2, 275.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(114,107,114);
	glVertex2f(258.8, 178);
	glVertex2f(261.8, 178);
	glVertex2f(261.8, 202);
	glVertex2f(258.8, 202);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(167,152,157);
	glVertex2f(272.5, 185);
	glVertex2f(274.8, 186.5);
	glVertex2f(274.8, 210);
	glVertex2f(272.5, 210);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(167,152,157);
	glVertex2f(287.5, 193);
	glVertex2f(290, 194.5);
	glVertex2f(290, 218);
	glVertex2f(287.5, 218);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(167,152,157);
	glVertex2f(345, 227.5);
	glVertex2f(348.5, 229);
	glVertex2f(348.5, 262.5);
	glVertex2f(345, 262.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(167,152,157);
	glVertex2f(360, 235.5);
	glVertex2f(363.5, 237);
	glVertex2f(363.5, 262.5);
	glVertex2f(360, 262.5);
	glEnd();
	
	
	glBegin(GL_POLYGON);
	glColor3ub(168,156,160);
	glVertex2f(258.8, 203);
	glVertex2f(261.8, 202);
	glVertex2f(371.5, 265.2);
	glVertex2f(369.2, 267);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(88,84,85);
	glVertex2f(259.1, 203);
	glVertex2f(371.2, 268.5);
	glVertex2f(371.2, 272.5);
	glVertex2f(255, 204);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(195,183,185);
	glVertex2f(298.8, 201.8);
	glVertex2f(329.8, 220.2);
	glVertex2f(329.8, 246.2);
	glVertex2f(298.8, 228.2);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(150,138,142);
	glVertex2f(329.8, 220.2);
	glVertex2f(334, 220.2);
	glVertex2f(334, 244.2);
	glVertex2f(329.8, 246.2);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(81,71,79);
	glVertex2f(252, 170);
	glVertex2f(256.2, 172.2);
	glVertex2f(255.5, 208.2);
	glVertex2f(252, 206.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(49,49,57);
	glVertex2f(256, 176);
	glVertex2f(259, 177);
	glVertex2f(259, 203);
	glVertex2f(255, 204);
	glEnd();
		
	glBegin(GL_POLYGON);
	glColor3ub(49,49,57);
	glVertex2f(259.1, 203);
	glVertex2f(261.2, 205.8);
	glVertex2f(258.4, 205.9);
	glVertex2f(255, 204);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(49,49,57);
	glVertex2f(255, 204);
	glVertex2f(371, 272);
	glVertex2f(371, 276);
	glVertex2f(255, 208);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(236,226,227);
	glVertex2f(221, 199);
	glVertex2f(368, 282);
	glVertex2f(335, 301);
	glVertex2f(189, 217);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(236,226,227);
	glVertex2f(221, 199);
	glVertex2f(245, 182);
	glVertex2f(245, 214);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(194,184,182);
	glVertex2f(189, 217);
	glVertex2f(335, 301);
	glVertex2f(335, 306);
	glVertex2f(189, 222);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(165,154,160);
	glVertex2f(335, 301);
	glVertex2f(368, 282);
	glVertex2f(368, 287);
	glVertex2f(335, 306);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(165,153,157);
	glVertex2f(349.7, 293);
	glVertex2f(368, 282);
	glVertex2f(383, 310);
	glVertex2f(384, 315);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(78,72,76);
	glVertex2f(260, 264.7);
	glVertex2f(315, 296);
	glVertex2f(315, 314);
	glVertex2f(260, 282);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(232,219,226);
	glVertex2f(542, 92);
	glVertex2f(679, 170);
	glVertex2f(654, 186);
	glVertex2f(542, 120);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3ub(196,181,188);
	glVertex2f(542, 106);
	glVertex2f(627, 155);
	glVertex2f(622, 158.5);
	glVertex2f(542, 112);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(165,153,157);
	glVertex2f(541, 117);
	glVertex2f(655, 186);
	glVertex2f(549, 247);
	glVertex2f(513, 222);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(13,130,137);
	glVertex2f(541, 123);
	glVertex2f(610, 165);
	glVertex2f(567, 190);
	glVertex2f(538, 174);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(60,173,167);
	glVertex2f(541, 110);
	glVertex2f(622, 158);
	glVertex2f(610, 165);
	glVertex2f(541, 123);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(151,141,149);
	glVertex2f(395, 149);
	glVertex2f(541, 65);
	glVertex2f(541, 204);
	glVertex2f(513, 222);
	glVertex2f(479, 267);
	glVertex2f(421, 301);
	glVertex2f(421, 348.5);
	glVertex2f(421, 348.5);
	glVertex2f(395, 361.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(62,56,60);
	glVertex2f(488, 132);
	glVertex2f(528, 110);
	glVertex2f(528, 146);
	glVertex2f(488, 168);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(94,83,87);
	glVertex2f(488, 132);
	glVertex2f(526, 110);
	glVertex2f(526, 144);
	glVertex2f(488, 166);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(62,56,60);
	glVertex2f(434, 163);
	glVertex2f(447, 156);
	glVertex2f(447, 212);
	glVertex2f(434, 217);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(94,83,87);
	glVertex2f(434, 163);
	glVertex2f(445, 157);
	glVertex2f(445, 210);
	glVertex2f(434, 217);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(62,56,60);
	glVertex2f(414, 218);
	glVertex2f(425, 212);
	glVertex2f(425, 265);
	glVertex2f(414, 272);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(94,83,87);
	glVertex2f(414, 218);
	glVertex2f(423, 213);
	glVertex2f(423, 263);
	glVertex2f(414, 272);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(62,56,60);
	glVertex2f(460, 213);
	glVertex2f(481, 201);
	glVertex2f(481, 233);
	glVertex2f(460, 246);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(94,83,87);
	glVertex2f(460, 213);
	glVertex2f(479, 202);
	glVertex2f(479, 231);
	glVertex2f(460, 246);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(152,141,147);
	glVertex2f(512, 222);
	glVertex2f(550, 245);
	glVertex2f(516, 289);
	glVertex2f(477.5, 268.7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(161,148,155);
	glVertex2f(476, 268);
	glVertex2f(516, 289);
	glVertex2f(457, 321);
	glVertex2f(420, 302);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(158,145,152);
	glVertex2f(457, 321);
	glVertex2f(516, 289);
	glVertex2f(457, 371);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(158,145,152);
	glVertex2f(420, 302);
	glVertex2f(457, 321);
	glVertex2f(457, 371);
	glVertex2f(420, 345);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(196,184,186);
	glVertex2f(447.3, 316.7);
	glVertex2f(457, 321);
	glVertex2f(457, 370);
	glVertex2f(447.3, 363.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(225,213,215);
	glVertex2f(447.3, 316.7);
	glVertex2f(466.3, 316.7);
	glVertex2f(457, 321);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(185,187,112);
	glVertex2f(549.3, 247.7);
	glVertex2f(651.3, 306.7);
	glVertex2f(559, 432);
	glVertex2f(458, 372);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(121,131,94);
	glVertex2f(548.3, 244.7);
	glVertex2f(585.5, 268.5);
	glVertex2f(558.5, 305.5);
	glVertex2f(509.5, 333.5);
	glVertex2f(505.5, 342.5);
	glVertex2f(458, 369.5);
	glEnd();
	
	
	glBegin(GL_POLYGON);
	glColor3ub(109,124,91);
	glVertex2f(655.5, 185.5);
	glVertex2f(689.5, 205.5);
	glVertex2f(585.5, 268.5);
	glVertex2f(548.3, 244.7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(78,67,73);
	glVertex2f(262.5, 143.5);
	glVertex2f(382.5, 213.5);
	glVertex2f(382.5, 215.5);
	glVertex2f(262.3, 146);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(166,157,160);
	glVertex2f(278.5, 158.5);
	glVertex2f(382.5, 218.5);
	glVertex2f(382.5, 220.5);
	glVertex2f(276.3, 159);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(59,54,56);
	glVertex2f(335.5, 144.5);
	glVertex2f(337.5, 146.5);
	glVertex2f(337.5, 176.5);
	glVertex2f(335.3, 174);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(195,171,159);
	glVertex2f(89.3, 294.7);
	glVertex2f(156.5, 333.5);
	glVertex2f(156.5, 343.5);
	glVertex2f(89.5, 305.5);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(225,202,184);
	glVertex2f(95.5, 291.5);
	glVertex2f(162.5, 330.5);
	glVertex2f(156.5, 333.5);
	glVertex2f(89.3, 294.7);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(131,119,123);
	glVertex2f(156.5, 333.5);
	glVertex2f(162.5, 330.5);
	glVertex2f(162.5, 340.5);
	glVertex2f(156.5, 343.5);
	glEnd();
	int x = 95, y = 57;
	
	glBegin(GL_POLYGON);
	glColor3ub(195,171,159);
	glVertex2f(89.3+x, 294.7+y);
	glVertex2f(156.5+3*x, 333.5+3*y);
	glVertex2f(156.5+3*x, 343.5+3*y);
	glVertex2f(89.5+x, 305.5+y);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(225,202,184);
	glVertex2f(95.5+x, 291.5+y);
	glVertex2f(162.5+3*x, 330.5+3*y);
	glVertex2f(156.5+3*x, 333.5+3*y);
	glVertex2f(89.3+x, 294.7+y);
	glEnd();
	
	glBegin(GL_POLYGON);
	glColor3ub(131,119,123);
	glVertex2f(156.5+3*x, 333.5+3*y);
	glVertex2f(162.5+3*x, 330.5+3*y);
	glVertex2f(162.5+3*x, 340.5+3*y);
	glVertex2f(156.5+3*x, 343.5+3*y);
	glEnd();
	
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 450, "Tugas Rumah - G64160052", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();
        nama();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
