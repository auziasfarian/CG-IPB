#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1000, 1000, 0, 1.f, -1.f);//(0,800,0,800)
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void latar(){
    glBegin(GL_POLYGON);
    glColor3ub(0,0,0);
    glVertex2d(1000,0);
    glColor3ub(0,0,0);
    glVertex2d(0,0);
    glColor3ub(77,149,158);
    glVertex2d(0,1000);
    glColor3ub(37,92,99);
    glVertex2d(1000,1000);
    glColor3ub(16,62,68);
    glEnd();
}
void pondasi(){
    glBegin(GL_POLYGON);
    glColor3ub(61,91,12);
    glVertex2d(970,513);
    glVertex2d(501,768);
    glVertex2d(501,722);
    glVertex2d(970,463);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(71,104,14);
    glVertex2d(501,768);
    glVertex2d(29,513);
    glVertex2d(29,468);
    glVertex2d(501,722);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(125,178,32);
    glVertex2d(970,463);
    glVertex2d(501,722);
    glVertex2d(29,468);
    glVertex2d(498,214);
    glEnd();
}

void depan(){
    glBegin(GL_POLYGON);
    glColor3ub(142,131,158);
    glVertex2d(550,533);
    glVertex2d(365,626);
    glVertex2d(365,520);
    glVertex2d(550,427);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,242,242);
    glVertex2d(365,626);
    glVertex2d(241,564);
    glVertex2d(242,458);
    glVertex2d(365,520);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,242,242);
    glVertex2d(550,427);
    glVertex2d(365,520);
    glVertex2d(242,458);
    glVertex2d(427,365);
    glEnd();

    glBegin(GL_POLYGON); //jendela
    glColor3ub(168,163,115);
    glVertex2d(471,561);
    glVertex2d(412,591);
    glVertex2d(412,590);
    glVertex2d(470,560);
    glEnd();

    glBegin(GL_POLYGON); //jendela
    glColor3ub(168,163,115);
    glVertex2d(471,513);
    glVertex2d(471,561);
    glVertex2d(470,560);
    glVertex2d(470,514);
    glEnd();

    glBegin(GL_POLYGON); //jendela
    glColor3ub(168,163,115);
    glVertex2d(475,563);
    glVertex2d(473,562);
    glVertex2d(473,512);
    glVertex2d(475,510);
    glEnd();

    glBegin(GL_POLYGON); //jendela
    glColor3ub(188,184,134);
    glVertex2d(475,563);
    glVertex2d(412,595);
    glVertex2d(412,592);
    glVertex2d(470,560);
    glEnd();

    glBegin(GL_POLYGON); //jendela
    glColor3ub(255,251,230);
    glVertex2d(470,561);
    glVertex2d(412,590);
    glVertex2d(412,542);
    glVertex2d(470,513);
    glEnd();

    glBegin(GL_POLYGON); //pintu
    glColor3ub(163,163,163);
    glVertex2d(549,522);
    glVertex2d(508,542);
    glVertex2d(508,534);
    glVertex2d(541,518);
    glEnd();

    glBegin(GL_POLYGON); //pintu
    glColor3ub(109,101,119);
    glVertex2d(549,468);
    glVertex2d(549,522);
    glVertex2d(541,518);
    glVertex2d(541,472);
    glEnd();

    glBegin(GL_POLYGON); //pintu
    glColor3ub(240,240,240);
    glVertex2d(541,518);
    glVertex2d(508,534);
    glVertex2d(508,489);
    glVertex2d(541,472);
    glEnd();

}

void tangga(){
    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);
    glVertex2d(579,548);
    glVertex2d(515,580);
    glVertex2d(515,576);
    glVertex2d(579,544);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);//1
    glVertex2d(579,544);
    glVertex2d(515,576);
    glVertex2d(517,566);
    glVertex2d(570,539);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163,163,163);//1
    glVertex2d(515,576);
    glVertex2d(487,562);
    glVertex2d(498,557);
    glVertex2d(517,566);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163,163,163);//2
    glVertex2d(570,539);
    glVertex2d(517,566);
    glVertex2d(517,561);
    glVertex2d(569,535);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);//2
    glVertex2d(517,566);
    glVertex2d(498,557);
    glVertex2d(498,552);
    glVertex2d(517,561);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);//2
    glVertex2d(569,535);
    glVertex2d(517,561);
    glVertex2d(519,552);
    glVertex2d(561,531);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);//2
    glVertex2d(517,561);
    glVertex2d(498,552);
    glVertex2d(508,546);
    glVertex2d(519,552);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163,163,163);//3
    glVertex2d(561,531);
    glVertex2d(519,552);
    glVertex2d(519,548);
    glVertex2d(561,526);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163,163,163);//3
    glVertex2d(519,552);
    glVertex2d(508,546);
    glVertex2d(508,542);
    glVertex2d(519,548);
    glEnd();

    glBegin(GL_POLYGON);//3
    glColor3ub(172,172,172);
    glVertex2d(519,552);
    glVertex2d(508,546);
    glVertex2d(508,542);
    glVertex2d(519,548);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(172,172,172);//3
    glVertex2d(561,526);
    glVertex2d(519,548);
    glVertex2d(508,542);
    glVertex2d(551,521);
    glEnd();
}

void atap(){
    glBegin(GL_POLYGON);
    glColor3ub(196,192,140);//1
    glVertex2d(444,372);
    glVertex2d(254,468);
    glVertex2d(243,463);
    glVertex2d(444,362);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(188,184,134);//1
    glVertex2d(561,431);
    glVertex2d(444,372);
    glVertex2d(444,362);
    glVertex2d(572,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,234,182);//2
    glVertex2d(593,458);
    glVertex2d(371,569);
    glVertex2d(371,537);
    glVertex2d(593,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(211,209,159);//2
    glVertex2d(371,569);
    glVertex2d(222,495);
    glVertex2d(222,463);
    glVertex2d(371,537);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,250,215);//3
    glVertex2d(593,425);
    glVertex2d(371,537);
    glVertex2d(222,463);
    glVertex2d(445,351);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196,192,140);//4
    glVertex2d(561,431);
    glVertex2d(444,372);
    glVertex2d(444,362);
    glVertex2d(573,425);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(196,192,140);//4
    glVertex2d(444,372);
    glVertex2d(254,468);
    glVertex2d(243,463);
    glVertex2d(444,362);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,234,182);//kecil
    glVertex2d(508,415);
    glVertex2d(444,447);
    glVertex2d(444,380);
    glVertex2d(508,348);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(211,209,159);//kecil
    glVertex2d(444,447);
    glVertex2d(378,414);
    glVertex2d(378,374);
    glVertex2d(444,380);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,250,215);//kecil
    glVertex2d(508,348);
    glVertex2d(444,380);
    glVertex2d(378,374);
    glVertex2d(442,341);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(188,184,134);//jendela1
    glVertex2d(497,406);
    glVertex2d(455,427);
    glVertex2d(455,425);
    glVertex2d(495,405);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(188,184,134);//jendela2
    glVertex2d(498,370);
    glVertex2d(497,406);
    glVertex2d(495,405);
    glVertex2d(495,371);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(61,59,45);//jendela4
    glVertex2d(495,404);
    glVertex2d(455,424);
    glVertex2d(455,423);
    glVertex2d(494,404);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(61,59,45);//jendela4
    glVertex2d(495,372);
    glVertex2d(495,404);
    glVertex2d(494,404);
    glVertex2d(494,372);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,251,230);//jendela5
    glVertex2d(494,404);
    glVertex2d(455,423);
    glVertex2d(455,392);
    glVertex2d(494,372);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(117,111,109);//jalan
    glVertex2d(708,607);
    glVertex2d(657,638);
    glVertex2d(515,580);
    glVertex2d(579,548);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,123,121);//jalan
    glVertex2d(708,607);
    glVertex2d(676,624);
    glVertex2d(613,567);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(132,123,121);//jalan
    glVertex2d(657,638);
    glVertex2d(563,597);
    glVertex2d(583,569);
    glEnd();
}

void tembokkiri(){
    glBegin(GL_POLYGON);
    glColor3ub(239,234,182);
    glVertex2d(402,617);
    glVertex2d(370,633);
    glVertex2d(371,537);
    glVertex2d(402,521);
    glEnd();

    glBegin(GL_POLYGON);
     glColor3ub(211,209,159);
    glVertex2d(370,633);
    glVertex2d(222,559);
    glVertex2d(222,463);
    glVertex2d(371,537);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(242,242,242);
    glVertex2d(402,521);
    glVertex2d(371,537);
    glVertex2d(222,463);
    glVertex2d(286,463);
    glEnd();

}

void garasi(){
    glBegin(GL_POLYGON);
    glColor3ub(239,234,182);
    glVertex2d(806,514);
    glVertex2d(678,569);
    glVertex2d(679,469);
    glVertex2d(806,414);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(211,209,159);
    glVertex2d(678,569);
    glVertex2d(487,486);
    glVertex2d(487,386);
    glVertex2d(679,469);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,250,215);
    glVertex2d(806,414);
    glVertex2d(679,469);
    glVertex2d(487,386);
    glVertex2d(615,330);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(53,52,48);//pintu
    glVertex2d(795,522);
    glVertex2d(793,520);
    glVertex2d(793,457);
    glVertex2d(795,457);
    glVertex2d(793,520);
    glVertex2d(699,561);
    glVertex2d(699,497);
    glVertex2d(793,457);
    glEnd();
}

void kolomrenang(){
    glBegin(GL_POLYGON);//1
    glColor3ub(193,191,178);
    glVertex2d(432,335);
    glVertex2d(284,415);
    glVertex2d(230,385);
    glVertex2d(378,306);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(204,204,204);//2
    glVertex2d(417,336);
    glVertex2d(378,315);
    glVertex2d(378,306);
    glVertex2d(419,335);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(206,206,206);//3
    glVertex2d(378,315);
    glVertex2d(245,386);
    glVertex2d(244,385);
    glVertex2d(378,313);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(146,234,255);
    glVertex2d(419,335);
    glVertex2d(284,407);
    glVertex2d(244,385);
    glVertex2d(378,313);
    glEnd();
}

void gazebo(){
     glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//penyanggah1
    glVertex2d(517,294);
    glVertex2d(517,333);
    glVertex2d(515,335);
    glVertex2d(513,333);
    glVertex2d(513,294);
    glVertex2d(515,292);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//penyanggah1.2
    glVertex2d(446,302);
    glVertex2d(444,304);
    glVertex2d(442,302);
    glVertex2d(442,262);
    glVertex2d(444,260);
    glVertex2d(446,262);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//penyanggah1.3
    glVertex2d(588,262);
    glVertex2d(588,302);
    glVertex2d(586,304);
    glVertex2d(583,302);
    glVertex2d(583,262);
    glVertex2d(586,260);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,103,17);//penyanggah21.1
    glVertex2d(587,268);
    glVertex2d(517,328);
    glVertex2d(515,329);
    glVertex2d(514,328);
    glVertex2d(514,325);
    glVertex2d(584,266);
    glVertex2d(587,266);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,103,17);//penyanggah21.2
    glVertex2d(513,328);
    glVertex2d(443,268);
    glVertex2d(443,266);
    glVertex2d(446,266);
    glVertex2d(517,325);
    glVertex2d(517,328);
    glVertex2d(515,329);
    glVertex2d(513,328);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,84,17);//penyanggah21.3
    glVertex2d(584,297);
    glVertex2d(514,238);
    glVertex2d(514,235);
    glVertex2d(517,235);
    glVertex2d(587,295);
    glVertex2d(587,297);
    glVertex2d(586,298);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,84,17);//penyanggah21.4
    glVertex2d(517,238);
    glVertex2d(447,297);
    glVertex2d(445,298);
    glVertex2d(443,297);
    glVertex2d(443,295);
    glVertex2d(514,235);
    glVertex2d(517,235);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,103,17);//penyanggah21.5
    glVertex2d(586,298);
    glVertex2d(515,300);
    glVertex2d(513,298);
    glVertex2d(515,296);
    glVertex2d(586,294);
    glVertex2d(588,296);
    glVertex2d(586,298);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(184,103,17);//penyanggah21.5
    glVertex2d(445,298);
    glVertex2d(442,296);
    glVertex2d(445,294);
    glVertex2d(515,296);
    glVertex2d(517,298);
    glVertex2d(515,300);
    glVertex2d(445,298);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,84,17);//penyanggah21.6
    glVertex2d(445,269);
    glVertex2d(445,269);
    glVertex2d(443,267);
    glVertex2d(445,265);
    glVertex2d(515,263);
    glVertex2d(518,265);
    glVertex2d(515,267);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(139,84,17);//penyanggah21.7
    glVertex2d(515,267);
    glVertex2d(513,265);
    glVertex2d(515,263);
    glVertex2d(586,265);
    glVertex2d(588,267);
    glVertex2d(586,269);
    glVertex2d(586,269);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(109,81,36);//lantai1
    glVertex2d(593,254);
    glVertex2d(515,291);
    glVertex2d(436,254);
    glVertex2d(515,217);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(109,81,36);//lantai2
    glVertex2d(593,260);
    glVertex2d(515,298);
    glVertex2d(515,291);
    glVertex2d(593,254);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(109,81,36);//lantai3
    glVertex2d(515,298);
    glVertex2d(436,260);
    glVertex2d(436,254);
    glVertex2d(515,291);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//tongkat1
    glVertex2d(573,242);
    glVertex2d(571,243);
    glVertex2d(568,242);
    glVertex2d(568,186);
    glVertex2d(571,184);
    glVertex2d(573,186);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//tongkat1
    glVertex2d(517,285);
    glVertex2d(515,287);
    glVertex2d(513,285);
    glVertex2d(513,219);
    glVertex2d(515,217);
    glVertex2d(517,219);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//tongkat2
    glVertex2d(446,254);
    glVertex2d(444,256);
    glVertex2d(442,254);
    glVertex2d(442,191);
    glVertex2d(444,190);
    glVertex2d(446,191);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar1
    glVertex2d(470,235);
    glVertex2d(471,237);
    glVertex2d(469,238);
    glVertex2d(444,227);
    glVertex2d(443,224);
    glVertex2d(446,224);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,72,36);//pagar1.2
    glVertex2d(515,193);
    glVertex2d(448,225);
    glVertex2d(445,224);
    glVertex2d(446,222);
    glVertex2d(513,189);
    glVertex2d(516,189);
    glVertex2d(584,222);
    glVertex2d(585,224);
    glVertex2d(583,225);
    glVertex2d(583,225);
    glVertex2d(582,225);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar1.3
    glVertex2d(515,260);
    glVertex2d(490,249);
    glVertex2d(489,246);
    glVertex2d(493,245);
    glVertex2d(515,256);
    glVertex2d(583,224);
    glVertex2d(586,224);
    glVertex2d(585,227);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar1
    glVertex2d(470,235);
    glVertex2d(471,237);
    glVertex2d(469,238);
    glVertex2d(444,227);
    glVertex2d(443,224);
    glVertex2d(446,224);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,72,36);//pagar1.2
    glVertex2d(515,193);
    glVertex2d(448,225);
    glVertex2d(445,224);
    glVertex2d(446,222);
    glVertex2d(513,189);
    glVertex2d(516,189);
    glVertex2d(584,222);
    glVertex2d(585,224);
    glVertex2d(583,225);
    glVertex2d(583,225);
    glVertex2d(582,225);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar1.3
    glVertex2d(515,260);
    glVertex2d(490,249);
    glVertex2d(489,246);
    glVertex2d(493,245);
    glVertex2d(515,256);
    glVertex2d(583,224);
    glVertex2d(586,224);
    glVertex2d(585,227);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar2
    glVertex2d(469,253);
    glVertex2d(444,242);
    glVertex2d(443,239);
    glVertex2d(446,239);
    glVertex2d(470,250);
    glVertex2d(471,252);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,72,36);//pagar2.2
    glVertex2d(515,209);
    glVertex2d(448,240);
    glVertex2d(447,241);
    glVertex2d(445,240);
    glVertex2d(446,237);
    glVertex2d(513,205);
    glVertex2d(584,237);
    glVertex2d(585,240);
    glVertex2d(582,240);
    glVertex2d(515,209);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(227,97,36);//pagar2.3
    glVertex2d(515,275);
    glVertex2d(490,264);
    glVertex2d(489,261);
    glVertex2d(493,261);
    glVertex2d(515,271);
    glVertex2d(583,239);
    glVertex2d(586,240);
    glVertex2d(585,242);
    glVertex2d(515,275);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//pagar2.4
    glVertex2d(492,273);
    glVertex2d(490,275);
    glVertex2d(488,273);
    glVertex2d(488,244);
    glVertex2d(490,242);
    glVertex2d(492,244);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//pagar2.5
    glVertex2d(471,263);
    glVertex2d(469,265);
    glVertex2d(466,263);
    glVertex2d(466,234);
    glVertex2d(469,232);
    glVertex2d(471,234);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//tangga1
    glVertex2d(491,271);
    glVertex2d(492,274);
    glVertex2d(479,327);
    glVertex2d(476,328);
    glVertex2d(476,328);
    glVertex2d(474,326);
    glVertex2d(488,273);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//tangga2
    glVertex2d(471,263);
    glVertex2d(457,317);
    glVertex2d(455,319);
    glVertex2d(454,319);
    glVertex2d(453,316);
    glVertex2d(466,263);
    glVertex2d(469,261);
    glVertex2d(471,263);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//anak1
    glVertex2d(487,281);
    glVertex2d(466,270);
    glVertex2d(465,268);
    glVertex2d(468,267);
    glVertex2d(490,277);
    glVertex2d(491,280);
    glVertex2d(489,281);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//anak2
    glVertex2d(485,291);
    glVertex2d(463,281);
    glVertex2d(462,278);
    glVertex2d(466,278);
    glVertex2d(487,288);
    glVertex2d(488,290);
    glVertex2d(486,291);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//anak3
    glVertex2d(483,302);
    glVertex2d(461,291);
    glVertex2d(460,289);
    glVertex2d(463,288);
    glVertex2d(484,298);
    glVertex2d(485,301);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//anak4
    glVertex2d(480,312);
    glVertex2d(458,302);
    glVertex2d(457,299);
    glVertex2d(460,299);
    glVertex2d(482,309);
    glVertex2d(482,311);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(249,112,36);//anak5
    glVertex2d(477,322);
    glVertex2d(455,312);
    glVertex2d(454,310);
    glVertex2d(457,309);
    glVertex2d(479,319);
    glVertex2d(480,322);
    glVertex2d(478,323);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(119,94,55);//1
    glVertex2d(593,184);
    glVertex2d(515,222);
    glVertex2d(436,184);
    glVertex2d(515,147);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,192,36);//2
    glVertex2d(593,191);
    glVertex2d(515,228);
    glVertex2d(515,222);
    glVertex2d(593,184);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(239,145,36);//3
    glVertex2d(515,228);
    glVertex2d(436,191);
    glVertex2d(436,184);
    glVertex2d(515,222);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(99,81,40);//atap1
    glVertex2d(582,183);
    glVertex2d(515,215);
    glVertex2d(515,138);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(58,39,25);//atap2
    glVertex2d(515,215);
    glVertex2d(447,183);
    glVertex2d(515,138);
    glEnd();

}

void bintang(){
    glBegin(GL_POINTS);
    glColor3f(1.0,1.0,1.0);
    glVertex2d(72,68);
    glVertex2d(291,220);
    glVertex2d(375,390);
    glVertex2d(793,77);
    glVertex2d(873,20);
    glVertex2d(128,82);
    glVertex2d(24,734);
    glVertex2d(643,112);
    glVertex2d(268,828);
    glVertex2d(238,178);
}

void kelip(){
    int s;
    float x,y;
    glColor3f(0.0,0.0,0.0);
    for(int i=0;i<500;i++){
        s=rand()%4+1;
        glPointSize(s);
        glBegin(GL_POINTS);
        x=(float)rand()/RAND_MAX;
        y=(float)rand()/RAND_MAX;
        glVertex2f(x,y);
        glEnd();
    }
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "G64160022", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);

        display();

        latar();
        pondasi();
        garasi();
        depan();
        tangga();
        tembokkiri();
        atap();
        kolomrenang();
        gazebo();
        bintang();
        kelip();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
