SPACE 		   : Open box
Left Click + Drag  : Move camera
Mouse Scroll 	   : Zoom in/out
R 		   : Move camera to initial postition
ESC 		   : Close program
