#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

bool bolbox = 0, reset = 0, res = 0;
float boxc = 0;
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (!res) glfwTerminate();
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
    else if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        if(bolbox) bolbox = 0;
        else bolbox = 1;
    }
    else if (key == GLFW_KEY_R && action == GLFW_PRESS)
        reset = 1;
}

bool bolmb = 0;
double xpos, ypos;
static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        bolmb = 1;
        glfwGetCursorPos(window, &xpos, &ypos);
    }
    else if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) bolmb = 0;
}

double yw = 1;
static void scroll_callback(GLFWwindow* window, double x, double y)
{
    yw += y/10;
    if(yw > 2) yw = 2;
    else if(yw < 0.4) yw = 0.4;
    if(!res) yw = rand();
}

void zoom();
void mrotate(GLFWwindow* window);
void snowflake(float s);
void base();
void roof();
void top();
void landscape(float s);
void landscape2();
void door();
void window(float x, float y, int status1, int status2);
float z = 80;
float t = 0;
float r, g, b;
void lighting() {
    //glClearColor();

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glEnable(GL_COLOR_MATERIAL);
    float mat[] = {0.3,0.3,0.3};
    float shi[] = {100};
    glMaterialfv(GL_FRONT,GL_AMBIENT,mat);
    glMaterialfv(GL_FRONT,GL_DIFFUSE,mat);
    glMaterialfv(GL_FRONT,GL_SPECULAR,mat);
    glMaterialfv(GL_FRONT,GL_SHININESS,shi);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_NORMALIZE);

    ///*
    float *amb1, *dif1, *spe1;
    if(t < 0.52) {
        r = 1.91*t, g = 0.45*t, b = 0.45*t;
        float amb[] = {r,g,b};
        float dif[] = {r,g,b};
        float spe[] = {r,g,b};
        amb1 = amb;
        dif1 = dif;
        spe1 = spe;
    }
    else if (t < 1.57) {
        g = b = 0.22;
        float t1 = t - 0.52;
        float g1 = 0.73*t1, b1 = 0.6*t1;
        g += g1; b += b1;
        float amb[] = {1,g,b};
        float dif[] = {1,g,b};
        float spe[] = {1,g,b};
        amb1 = amb;
        dif1 = dif;
        spe1 = spe;
    }
    else if (t < 2.62) {
        g = 1, b = 0.87;
        float t1 = t - 1.57;
        float g1 = 0.73*t1, b1 = 0.6*t1;
        g -= g1; b -= b1;
        float amb[] = {1,g,b};
        float dif[] = {1,g,b};
        float spe[] = {1,g,b};
        amb1 = amb;
        dif1 = dif;
        spe1 = spe;
    }
    else if (t < 3.14){
        r = 1, g = b = 0.24;
        float t1 = t - 2.62;
        float r1 = 1.91*t1, g1 = 0.45*t1, b1 = 0.45*t1;
        r -= r1; g -= g1; b -= b1;
        float amb[] = {r,g,b};
        float dif[] = {r,g,b};
        float spe[] = {r,g,b};
        amb1 = amb;
        dif1 = dif;
        spe1 = spe;
    }
    else {
        float amb[] = {0,0,0};
        float dif[] = {0,0,0};
        float spe[] = {0,0,0};
        amb1 = amb;
        dif1 = dif;
        spe1 = spe;
    }
    if(res?0x0000:'/') glDisable(GL_DEPTH_TEST);
    //*/
    float pos1[] = {540*cos(t),0,540*sin(t),1};

    glLightfv(GL_LIGHT0,GL_POSITION,pos1);
    //glLightfv(GL_LIGHT0,GL_AMBIENT,amb1);
    glLightfv(GL_LIGHT0,GL_DIFFUSE,dif1);
    glLightfv(GL_LIGHT0,GL_SPECULAR,spe1);

    t += 0.002;
    if (t >= 6.28) t = 0;
}

float r2, g2, b2;
void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1500, 1500, 1500, -1500, 1500, -1500);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glRotatef(110,1,0,0);

    //glRotatef(dg,0,0,1);
    glRotatef(150,0,0,1);
    glTranslatef(0,0,-200);
    glScalef(1.2,1.2,1.2);
    lighting();
    //glTranslated(0,-200,0);
    glPushMatrix();
    glTranslatef(-119,-144.5,0);
    base();
    roof();
    top();
    door();
    window(0,63.5,0,0);
    window(238,63.5,0,1);
    window(85,208,0,0);
    window(234,208,0,1);
    //pond(-100,250,50,100,25);
    glPopMatrix();
    //snowflake(400);
    landscape(400);
    glFlush();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);
    window = glfwCreateWindow(1080, 1080, "Rumah - G64160055", NULL, NULL);
    res = GL_LINES;
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetScrollCallback(window, scroll_callback);
    while (!glfwWindowShouldClose(window))
    {
        setup_viewport(window);
        zoom();
        mrotate(window);
        display();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}

void zoom() {
    if(reset) yw = 1;
    glScaled(yw,yw,yw);
}

double x=0, y=0, x1=0, y1=0;
int op=0;
void mrotate(GLFWwindow* window) {
    double xt, yt;
    if(bolmb) {
        op = 0;
        glfwGetCursorPos(window, &xt, &yt);
        x = xt - xpos;
        y = yt - ypos;
        glRotated(-(x+x1)*0.5,0,1,0);
        glRotated(-(y+y1)*0.5,1,0,0);
    }
    else {
        if(!op) {
            x1 += x;
            y1 += y;
            op = 1;
        }
        if(reset) {
            x1 = 0;
            y1 = 0;
            reset = 0;
        }
        glRotated(-x1*0.5,0,1,0);
        glRotated(-y1*0.5,1,0,0);
    }
}

float h = z - 10;
void door() {
    float x = 50;
    glPushAttrib(1);
    glColor3ub(161,137,127);
    glBegin(GL_POLYGON);
    glVertex3f(85+x,290,h);
    glVertex3f(85+x,290,0);
    glVertex3f(234-x,290,0);
    glVertex3f(234-x,290,h);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(255,241,118);
    for(float i = 0; i < 6.28; i += 0.01) {
        float x1 = 85+x+9 + 3*cos(i);
        float z1 = h/2-5 + 3*sin(i);
        glVertex3f(x1,291,z1);
    }
    glEnd();
    glPopAttrib();
}

void window(float x, float y, int status1, int status2) {
    float h1 = h - 40;
    float l = 15;
    float s = -1;
    float w = 4;
    if(status2) s = 1;
    glPushAttrib(1);
    if(status1) {
        y += s;
        float x1 = x + l;
        float x2 = x - l;
        glColor3ub(138,225,235);
        glBegin(GL_POLYGON);
        glVertex3f(x2,y,h);
        glVertex3f(x1,y,h);
        glVertex3f(x1,y,h1);
        glVertex3f(x2,y,h1);
        glEnd();

        glColor3ub(161,137,127);
        glBegin(GL_QUADS);
        glVertex3f(x2,y,h);
        glVertex3f(x2,y,h+w);
        glVertex3f(x1+w,y,h+w);
        glVertex3f(x1+w,y,h);

        glVertex3f(x1,y,h);
        glVertex3f(x1,y,h1-w);
        glVertex3f(x1+w,y,h1-w);
        glVertex3f(x1+w,y,h);

        glVertex3f(x2-w,y,h1);
        glVertex3f(x2-w,y,h1-w);
        glVertex3f(x1,y,h1-w);
        glVertex3f(x1,y,h1);

        glVertex3f(x2,y,h+w);
        glVertex3f(x2,y,h1);
        glVertex3f(x2-w,y,h1);
        glVertex3f(x2-w,y,h+w);
        glEnd();
    }
    else {
        x += s;
        float y1 = y + l;
        float y2 = y - l;
        glColor3ub(138,225,235);
        glBegin(GL_POLYGON);
        glVertex3f(x,y2,h);
        glVertex3f(x,y1,h);
        glVertex3f(x,y1,h1);
        glVertex3f(x,y2,h1);
        glEnd();

        glColor3ub(161,137,127);
        glBegin(GL_QUADS);
        glVertex3f(x,y2,h);
        glVertex3f(x,y2,h+w);
        glVertex3f(x,y1+w,h+w);
        glVertex3f(x,y1+w,h);

        glVertex3f(x,y1,h);
        glVertex3f(x,y1,h1-w);
        glVertex3f(x,y1+w,h1-w);
        glVertex3f(x,y1+w,h);

        glVertex3f(x,y2-w,h1);
        glVertex3f(x,y2-w,h1-w);
        glVertex3f(x,y1,h1-w);
        glVertex3f(x,y1,h1);

        glVertex3f(x,y2,h+w);
        glVertex3f(x,y2,h1);
        glVertex3f(x,y2-w,h1);
        glVertex3f(x,y2-w,h+w);
        glEnd();
    }
    glPopAttrib();
}

void base() {
    glPushMatrix();
    int n = 8, i;
    float d = (float)z/n;
    float f1, f2, c;
    for(i = c = 0; c < n; c++, i+=2) {
        f1 = d*c;
        f2 = d*(c + 1);
        glColor3ub(223,228,232);
        glBegin(GL_POLYGON);
        glVertex3f(0,0,f1);
        glVertex3f(0,127,f1);
        glVertex3f(0,127,f2);
        glVertex3f(0,0,f2);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(0,127,f1);
        glVertex3f(0,127,f2);
        glVertex3f(85,127,f2);
        glVertex3f(85,127,f1);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(85,127,f2);
        glVertex3f(85,127,f1);
        glVertex3f(85,289,f1);
        glVertex3f(85,289,f2);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(85,289,f1);
        glVertex3f(85,289,f2);
        glVertex3f(234,289,f2);
        glVertex3f(234,289,f1);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(234,289,f2);
        glVertex3f(234,289,f1);
        glVertex3f(234,127,f1);
        glVertex3f(234,127,f2);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(234,127,f1);
        glVertex3f(234,127,f2);
        glVertex3f(238,127,f2);
        glVertex3f(238,127,f1);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(238,127,f2);
        glVertex3f(238,127,f1);
        glVertex3f(238,0,f1);
        glVertex3f(238,0,f2);
        glEnd();

        glBegin(GL_POLYGON);
        glVertex3f(238,0,f1);
        glVertex3f(238,0,f2);
        glVertex3f(0,0,f2);
        glVertex3f(0,0,f1);
        glEnd();
    }
    glPopMatrix();
}


float z1 = 100;
void top() {
    //segitiga
    glColor3ub(223,228,232);
    glBegin(GL_POLYGON);
    glVertex3f(0,127,z);
    glVertex3f(0,0,z);
    glVertex3f(0,63.5,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(85,289,z);
    glVertex3f(234,289,z);
    glVertex3f(159.5,289,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,127,z);
    glVertex3f(238,0,z);
    glVertex3f(238,63.5,z+z1);
    glEnd();

    glColor3ub(144,164,173);
    //garis
    glBegin(GL_LINE_STRIP);
    glVertex3f(238,63.5,z+z1);
    glVertex3f(0,63.5,z+z1);
    glEnd();

    glBegin(GL_LINE_STRIP);
    glVertex3f(159.5,63.5,z+z1);
    glVertex3f(159.5,289,z+z1);
    glEnd();

    glBegin(GL_LINE_STRIP);
    glVertex3f(159.5,63.5,z+z1);
    glVertex3f(85,127,z);
    glEnd();

    glBegin(GL_LINE_STRIP);
    glVertex3f(159.5,63.5,z+z1);
    glVertex3f(238,127,z);
    glEnd();

    //kerangka lurus
    float s = 10;
    glBegin(GL_POLYGON);
    glVertex3f(159.5-s/2,289,z+z1);
    glVertex3f(159.5+s/2,289,z+z1);
    glVertex3f(159.5+s/2,289,z+z1+s);
    glVertex3f(159.5-s/2,289,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5-s/2,63.5,z+z1);
    glVertex3f(159.5+s/2,63.5,z+z1);
    glVertex3f(159.5+s/2,63.5,z+z1+s);
    glVertex3f(159.5-s/2,63.5,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5+s/2,289,z+z1+s);
    glVertex3f(159.5-s/2,289,z+z1+s);
    glVertex3f(159.5-s/2,63.5,z+z1+s);
    glVertex3f(159.5+s/2,63.5,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5+s/2,289,z+z1);
    glVertex3f(159.5+s/2,289,z+z1+s);
    glVertex3f(159.5+s/2,63.5,z+z1+s);
    glVertex3f(159.5+s/2,63.5,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5-s/2,289,z+z1);
    glVertex3f(159.5-s/2,289,z+z1+s);
    glVertex3f(159.5-s/2,63.5,z+z1+s);
    glVertex3f(159.5-s/2,63.5,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5+s/2,289,z+z1);
    glVertex3f(159.5-s/2,289,z+z1);
    glVertex3f(159.5-s/2,63.5,z+z1);
    glVertex3f(159.5+s/2,63.5,z+z1);
    glEnd();

    //kerangka lurus 2
    glBegin(GL_POLYGON);
    glVertex3f(0,63.5-s/2,z+z1);
    glVertex3f(0,63.5-s/2,z+z1+s);
    glVertex3f(0,63.5+s/2,z+z1+s);
    glVertex3f(0,63.5+s/2,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,63.5-s/2,z+z1);
    glVertex3f(238,63.5-s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,63.5-s/2,z+z1);
    glVertex3f(238,63.5-s/2,z+z1+s);
    glVertex3f(0,63.5-s/2,z+z1+s);
    glVertex3f(0,63.5-s/2,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,63.5-s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1+s);
    glVertex3f(0,63.5+s/2,z+z1+s);
    glVertex3f(0,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,63.5+s/2,z+z1);
    glVertex3f(0,63.5+s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,63.5-s/2,z+z1);
    glVertex3f(238,63.5+s/2,z+z1);
    glVertex3f(0,63.5+s/2,z+z1);
    glVertex3f(0,63.5-s/2,z+z1);
    glEnd();

    //kerangka miring kiri
    glBegin(GL_POLYGON);
    glVertex3f(0,63.5,z+z1+s);
    glVertex3f(0,63.5,z+z1);
    glVertex3f(0,127,z);
    glVertex3f(0,127+s,z);
    glVertex3f(0,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,127,z);
    glVertex3f(0,127+s,z);
    glVertex3f(0-s,127+s,z);
    glVertex3f(0-s,127,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0-s,63.5,z+z1+s);
    glVertex3f(0-s,63.5,z+z1);
    glVertex3f(0-s,127,z);
    glVertex3f(0-s,127+s,z);
    glVertex3f(0-s,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,127+s,z);
    glVertex3f(0-s,127+s,z);
    glVertex3f(0-s,63.5+s/2,z+z1+s);
    glVertex3f(0,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,127,z);
    glVertex3f(0-s,127,z);
    glVertex3f(0-s,63.5,z+z1);
    glVertex3f(0,63.5,z+z1);
    glEnd();
    //
    //

    //kerangka miring kiri 2
    glBegin(GL_POLYGON);
    glVertex3f(0,63.5,z+z1+s);
    glVertex3f(0,63.5,z+z1);
    glVertex3f(0,0,z);
    glVertex3f(0,0-s,z);
    glVertex3f(0,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,0,z);
    glVertex3f(0,0-s,z);
    glVertex3f(0-s,0-s,z);
    glVertex3f(0-s,0,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0-s,63.5,z+z1+s);
    glVertex3f(0-s,63.5,z+z1);
    glVertex3f(0-s,0,z);
    glVertex3f(0-s,0-s,z);
    glVertex3f(0-s,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,0-s,z);
    glVertex3f(0-s,0-s,z);
    glVertex3f(0-s,63.5-s/2,z+z1+s);
    glVertex3f(0,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(0,0,z);
    glVertex3f(0-s,0,z);
    glVertex3f(0-s,63.5,z+z1);
    glVertex3f(0,63.5,z+z1);
    glEnd();
    //
    //

    //kerangka miring kanan
    glBegin(GL_POLYGON);
    glVertex3f(238,63.5,z+z1+s);
    glVertex3f(238,63.5,z+z1);
    glVertex3f(238,127,z);
    glVertex3f(238,127+s,z);
    glVertex3f(238,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,127,z);
    glVertex3f(238,127+s,z);
    glVertex3f(238+s,127+s,z);
    glVertex3f(238+s,127,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238+s,63.5,z+z1+s);
    glVertex3f(238+s,63.5,z+z1);
    glVertex3f(238+s,127,z);
    glVertex3f(238+s,127+s,z);
    glVertex3f(238+s,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,127+s,z);
    glVertex3f(238+s,127+s,z);
    glVertex3f(238+s,63.5+s/2,z+z1+s);
    glVertex3f(238,63.5+s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,127,z);
    glVertex3f(238+s,127,z);
    glVertex3f(238+s,63.5,z+z1);
    glVertex3f(238,63.5,z+z1);
    glEnd();
    //
    //

    //kerangka miring kanan 2
    glBegin(GL_POLYGON);
    glVertex3f(238,63.5,z+z1+s);
    glVertex3f(238,63.5,z+z1);
    glVertex3f(238,0,z);
    glVertex3f(238,0-s,z);
    glVertex3f(238,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,0,z);
    glVertex3f(238,0-s,z);
    glVertex3f(238+s,0-s,z);
    glVertex3f(238+s,0,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238+s,63.5,z+z1+s);
    glVertex3f(238+s,63.5,z+z1);
    glVertex3f(238+s,0,z);
    glVertex3f(238+s,0-s,z);
    glVertex3f(238+s,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,0-s,z);
    glVertex3f(238+s,0-s,z);
    glVertex3f(238+s,63.5-s/2,z+z1+s);
    glVertex3f(238,63.5-s/2,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(238,0,z);
    glVertex3f(238+s,0,z);
    glVertex3f(238+s,63.5,z+z1);
    glVertex3f(238,63.5,z+z1);
    glEnd();
    //
    //

    //kerangka miring depan
    glBegin(GL_POLYGON);
    glVertex3f(159.5,289,z+z1+s);
    glVertex3f(159.5,289,z+z1);
    glVertex3f(234,289,z);
    glVertex3f(234+s,289,z);
    glVertex3f(159.5+s/2,289,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(234,289,z);
    glVertex3f(234,289+s,z);
    glVertex3f(234+s,289+s,z);
    glVertex3f(234+s,289,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5,289+s,z+z1+s);
    glVertex3f(159.5,289+s,z+z1);
    glVertex3f(234,289+s,z);
    glVertex3f(234+s,289+s,z);
    glVertex3f(159.5+s/2,289+s,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(234+s,289,z);
    glVertex3f(234+s,289+s,z);
    glVertex3f(159.5+s/2,289+s,z+z1+s);
    glVertex3f(159.5+s/2,289,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(234,289,z);
    glVertex3f(234,289+s,z);
    glVertex3f(159.5,289+s,z+z1);
    glVertex3f(159.5,289,z+z1);
    glEnd();
    //
    //

    //kerangka miring depan 2
    glBegin(GL_POLYGON);
    glVertex3f(159.5,289,z+z1+s);
    glVertex3f(159.5,289,z+z1);
    glVertex3f(85,289,z);
    glVertex3f(85-s,289,z);
    glVertex3f(159.5-s/2,289,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(85,289,z);
    glVertex3f(85,289+s,z);
    glVertex3f(85-s,289+s,z);
    glVertex3f(85-s,289,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(159.5,289+s,z+z1+s);
    glVertex3f(159.5,289+s,z+z1);
    glVertex3f(85,289+s,z);
    glVertex3f(85-s,289+s,z);
    glVertex3f(159.5-s/2,289+s,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(85-s,289,z);
    glVertex3f(85-s,289+s,z);
    glVertex3f(159.5-s/2,289+s,z+z1+s);
    glVertex3f(159.5-s/2,289,z+z1+s);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(85,289,z);
    glVertex3f(85,289+s,z);
    glVertex3f(159.5,289+s,z+z1);
    glVertex3f(159.5,289,z+z1);
    glEnd();
}

void roof() {
    glColor3ub(98,122,134);
    //depan kiri
    glBegin(GL_POLYGON);
    glVertex3f(85,289,z);
    glVertex3f(159.5,289,z+z1);
    glVertex3f(159.5,63.5,z+z1);
    glVertex3f(85,127,z);
    glEnd();

    //depan kanan
    glBegin(GL_POLYGON);
    glVertex3f(234,289,z);
    glVertex3f(159.5,289,z+z1);
    glVertex3f(159.5,63.5,z+z1);
    glVertex3f(234,127,z);
    glEnd();

    //tengah
    glBegin(GL_POLYGON);
    glVertex3f(0,63.5,z+z1);
    glVertex3f(238,63.5,z+z1);
    glVertex3f(238,127,z);
    glVertex3f(0,127,z);
    glEnd();

    //belakang
    glBegin(GL_POLYGON);
    glVertex3f(0,63.5,z+z1);
    glVertex3f(238,63.5,z+z1);
    glVertex3f(238,0,z);
    glVertex3f(0,0,z);
    glEnd();
}

float r1, g1, b1;
void landscape(float s) {
    glColor3ub(84,169,88);
    //bawah
    glBegin(GL_POLYGON);
    glVertex3f(-s,-s,0);
    glVertex3f(-s,s,0);
    glVertex3f(s,s,0);
    glVertex3f(s,-s,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(-s,-s,-20);
    glVertex3f(-s,s,-20);
    glVertex3f(s,s,-20);
    glVertex3f(s,-s,-20);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(-s,-s,0);
    glVertex3f(-s,-s,-20);
    glVertex3f(-s,s,-20);
    glVertex3f(-s,s,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(s,-s,0);
    glVertex3f(s,-s,-20);
    glVertex3f(s,s,-20);
    glVertex3f(s,s,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(s,-s,0);
    glVertex3f(s,-s,-20);
    glVertex3f(-s,-s,-20);
    glVertex3f(-s,-s,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(s,s,0);
    glVertex3f(s,s,-20);
    glVertex3f(-s,s,-20);
    glVertex3f(-s,s,0);
    glEnd();

    //background
    glPushAttrib(1);
    if(t < 0.26) {
        r1 = 980*t; g1 = b1 = 230*t;
        glColor3ub(r1,g1,b1);
    }
    else if (t < 1.57) {
        r1 = 255; g1 = b1 = 60;
        float t1 = t - 0.26;
        float rr = 105*t1, gg = 95*t1, bb = 142*t1;
        r1-=rr; g1+=gg; b1+=bb;
        glColor3ub(r1,g1,b1);
    }
    else if (t < 2.88) {
        r1 = 117; g1 = 185; b1 = 247;
        float t1 = t - 1.57;
        float rr = 105*t1, gg = 95*t1, bb = 142*t1;
        r1+=rr; g1-=gg; b1-=bb;
        glColor3ub(r1,g1,b1);
    }
    else if (t < 3.14){
        r1 = 255; g1 = b1 = 60;
        float t1 = t - 2.88;
        float rr = 980*t1, gg = 230*t1, bb = 230*t1;
        r1-=rr; g1-=gg; b1-=bb;
        glColor3ub(r1,g1,b1);
    }
    else {
        glColor3ub(0,0,0);
    }
    glBegin(GL_POLYGON);
    glVertex3f(s,-s,s);
    glVertex3f(s,-s,0);
    glVertex3f(-s,-s,0);
    glVertex3f(-s,-s,s);
    glEnd();
    glPopAttrib();

    //kaca
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4ub(173,216,230,69);
        //kiri
    glPushMatrix();
    if(bolbox && boxc <= 45) {
        glTranslatef(-3*boxc,0,0);
        glRotatef(-boxc,0,1,0);
        boxc += 0.5;
        if(boxc > 45) boxc = 45;
    }
    else if(!bolbox && boxc > 0) {
        glTranslatef(-3*boxc,0,0);
        glRotatef(-boxc,0,1,0);
        boxc -= 0.5;
    }
    glBegin(GL_POLYGON);
    glVertex3f(-s,-s,0);
    glVertex3f(-s,-s,s);
    glVertex3f(-s,s,s);
    glVertex3f(-s,s,0);
    glEnd();
    glPopMatrix();
        //kanan
    glPushMatrix();
    if(bolbox && boxc <= 45) {
        glTranslatef(3*boxc,0,0);
        glRotatef(boxc,0,1,0);
        boxc += 0.5;
        if(boxc > 45) boxc = 45;
    }
    else if(!bolbox && boxc > 0) {
        glTranslatef(3*boxc,0,0);
        glRotatef(boxc,0,1,0);
        boxc -= 0.5;
    }
    glBegin(GL_POLYGON);
    glVertex3f(s,-s,0);
    glVertex3f(s,-s,s);
    glVertex3f(s,s,s);
    glVertex3f(s,s,0);
    glEnd();
    glPopMatrix();
        //depan
    glPushMatrix();
    if(bolbox && boxc <= 45) {
        glTranslatef(0,3*boxc,0);
        glRotatef(-boxc,1,0,0);
        boxc += 0.5;
        if(boxc > 45) boxc = 45;
    }
    else if(!bolbox && boxc > 0) {
        glTranslatef(0,3*boxc,0);
        glRotatef(-boxc,1,0,0);
        boxc -= 0.5;
    }
    glBegin(GL_POLYGON);
    glVertex3f(s,s,s);
    glVertex3f(s,s,0);
    glVertex3f(-s,s,0);
    glVertex3f(-s,s,s);
    glEnd();
    glPopMatrix();
        //atas
    glPushMatrix();
    if(bolbox && boxc <= 45) {
        glTranslatef(0,0,boxc*7);
        glRotatef(boxc,1,0,0);
        boxc += 0.5;
        if(boxc > 45) boxc = 45;
    }
    else if(!bolbox && boxc > 0) {
        glTranslatef(0,0,boxc*7);
        glRotatef(boxc,1,0,0);
        boxc -= 0.5;
    }
    glBegin(GL_POLYGON);
    glVertex3f(s,s,s);
    glVertex3f(s,-s,s);
    glVertex3f(-s,-s,s);
    glVertex3f(-s,s,s);
    glEnd();
    glPopMatrix();
    glDisable(GL_BLEND);
    /*
    glColor3ub(70,90,101);
    //samping
    glBegin(GL_POLYGON);
    glVertex3f(-300,-300,0);
    glVertex3f(-300,-300,z);
    glVertex3f(-300,300,z);
    glVertex3f(-300,300,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(-280,-300,0);
    glVertex3f(-280,-300,z);
    glVertex3f(-280,300,z);
    glVertex3f(-280,300,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(-300,300,0);
    glVertex3f(-280,300,0);
    glVertex3f(-280,300,z);
    glVertex3f(-300,300,z);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(-300,-300,z);
    glVertex3f(-280,-300,z);
    glVertex3f(-280,300,z);
    glVertex3f(-300,300,z);
    glEnd();

    //belakang
    glBegin(GL_POLYGON);
    glVertex3f(300,-300,0);
    glVertex3f(300,-300,z);
    glVertex3f(-300,-300,z);
    glVertex3f(-300,-300,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(300,-280,0);
    glVertex3f(300,-280,z);
    glVertex3f(-300,-280,z);
    glVertex3f(-300,-280,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(300,-280,0);
    glVertex3f(300,-280,z);
    glVertex3f(300,-300,z);
    glVertex3f(300,-300,0);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex3f(300,-300,z);
    glVertex3f(300,-280,z);
    glVertex3f(-300,-280,z);
    glVertex3f(-300,-300,z);
    glEnd();
    */
}

void kotak(float x, float y, float w, float l, float h) {
    glBegin(GL_QUADS);
    glVertex3f(x-l,y-w,0);
    glVertex3f(x-l,y-w,h);
    glVertex3f(x-l,y+w,h);
    glVertex3f(x-l,y+w,0);

    glVertex3f(x-l,y-w,0);
    glVertex3f(x-l,y-w,h);
    glVertex3f(x+l,y-w,h);
    glVertex3f(x+l,y-w,0);

    glVertex3f(x+l,y-w,0);
    glVertex3f(x+l,y-w,h);
    glVertex3f(x+l,y+w,h);
    glVertex3f(x+l,y+w,0);

    glVertex3f(x-l,y+w,0);
    glVertex3f(x-l,y+w,h);
    glVertex3f(x+l,y+w,h);
    glVertex3f(x+l,y+w,0);
    glEnd();
}

void pond(float x, float y, float w, float l, float h) {
    glPushMatrix();
    glPushAttrib(1);
    kotak(x,y,w,l,h);
    float w1 = w + 4;
    float l1 = l + 4;
    kotak(x,y,w1,l1,h);
    glBegin(GL_QUADS);
    glVertex3f(x-l,y-w,1);
    glVertex3f(x-l,y+w,1);
    glVertex3f(x+l,y+w,1);
    glVertex3f(x+l,y-w,1);

    glVertex3f(x-l,y-w,h);
    glVertex3f(x-l1,y-w,h);
    glVertex3f(x-l1,y+w1,h);
    glVertex3f(x-l,y+w1,h);

    glVertex3f(x-l,y+w,h);
    glVertex3f(x-l,y+w1,h);
    glVertex3f(x+l1,y+w1,h);
    glVertex3f(x+l1,y+w,h);

    glVertex3f(x+l,y+w,h);
    glVertex3f(x+l1,y+w,h);
    glVertex3f(x+l1,y-w1,h);
    glVertex3f(x+l,y-w1,h);

    glVertex3f(x+l,y-w,h);
    glVertex3f(x+l,y-w1,h);
    glVertex3f(x-l1,y-w1,h);
    glVertex3f(x-l1,y-w,h);
    glEnd();

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0,0.8,1,0.2);
    for(float i = x-l; i < x+l; i += 5) {
        glBegin(GL_TRIANGLE_STRIP);
        for(float j = y-w; j <= y+w; j += 5) {
            float t = glfwGetTime()*10;
            float k = h - 3 + cos(i+t)/2 + sin(j+t)/2;
            glVertex3f(i,j,k);
            glVertex3f(i+5,j,k);
        }
        glEnd();
    }
    glDisable(GL_BLEND);
    glPopAttrib();
    glPopMatrix();
}

void landscape2() {
    glPushAttrib(1);
    glColor3ub(84,169,88);
    glBegin(GL_POLYGON);
    for(float i = 0; i < 6.28; i += 0.01) {
        float r = 400*sqrt(2);
        float x = r*cos(i);
        float y = r*sin(i);
        glVertex3f(x,y,-250);
    }
    glEnd();

    if(t < 0.52) {
        r2 = 1.91*t, g2 = 0.45*t, b2 = 0.45*t;
        glColor3f(r2,g2,b2);
    }
    else if (t < 1.57) {
        g2 = b2 = 0.22; r2 = 1;
        float t1 = t - 0.52;
        float g1 = 0.54*t1, b1 = 0.73*t1, r1 = 0.28*t1;
        g2 += g1; b2 += b1; r2 -= r1;
        glColor3f(r2,g2,b2);
    }
    else if (t < 2.62) {
        r2 = 0.71; g2 = 0.8, b2 = 1;
        float t1 = t - 1.57;
        float g1 = 0.54*t1, b1 = 0.73*t1, r1 = 0.28*t1;
        g2 -= g1; b2 -= b1; r2 += r1;
        glColor3f(r2,g2,b2);

    }
    else if (t < 3.14){
        r2 = 1, g2 = b2 = 0.24;
        float t1 = t - 2.62;
        float r1 = 1.91*t1, g1 = 0.45*t1, b1 = 0.45*t1;
        r2 -= r1; g2 -= g1; b2 -= b1;
        glColor3f(r2,g2,b2);
    }
    else {
        glColor3f(0,0,0);

    }
    glBegin(GL_TRIANGLE_STRIP);
    for(float i = 0; i <= 3.14; i += 0.01) {
        float r = 400*sqrt(2);
        float x = r*cos(i);
        float y = r*sin(i);
        glVertex3f(x,y,-250);
        glVertex3f(x,y,150);
    }
    glEnd();
    glPopAttrib();
}

void snowflake(float s) {
    for(int i = -s+5; i <= s-5; i += 5) {
        for(int j = -s+5; j <= s-5; j += 5)
            if(!(rand()%123)) {
                glPushMatrix();
                //glTranslatef(0,0,-glfwGetTime()*10);
                glBegin(GL_LINES);
                float z = rand()%389;
                for(int k = 0; k < 2; k++) {
                    glVertex3f(i-5,j,s-5-z);
                    glVertex3f(i+5,j,s-5-z);
                    glVertex3f(i,j,s-10-z);
                    glVertex3f(i,j,s-z);
                }
                glEnd();
                glRotatef(45,0,1,0);
                glPopMatrix();
            }
    }
}
