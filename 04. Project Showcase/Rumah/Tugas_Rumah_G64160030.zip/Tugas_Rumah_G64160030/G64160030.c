#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define putih 255, 255, 255
#define maroon 237, 29, 36
#define coklatmuda 250,179,122
#define coklattua 135,73,31
#define hijaumuda 197,249,147
#define hijautua 97,147,63
#define hijau 157,216,100
#define kolam 237,244,249
#define airkolam 0,235,255
#define tembok 243,237,210
#define atap 174,118,36
#define atapdepan 132,86,20
#define atapsamping 104,66,10
#define jendelatua 60,199,219
#define jendelamuda 126,226,241
#define batu 172,145,116
#define batudepan 54,41,29
#define batusamping 89,68,49

double gerak=0, pindah=0;
static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}

int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(1080, 1080, "G64160030",NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);

int buff=0, blink=0, status=0, pending=0, stat=1, kedip=0;

while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glDisable( GL_DEPTH_TEST ); // here for illustrative purposes, depth test is initially DISABLED (key!)

glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
void star(int x, int y, int a){
    int m=0, n=-1000;
    glPushMatrix();
    glTranslatef((float)glfwGetTime() * 100,0.1,-1);
    for(m=0, n=-1000; m<1000; m+=5,n+=400){

    glBegin(GL_POLYGON);

    glColor4ub(247,188,5, a);
        glVertex2d(33 + x + n, 110 + y);
        glVertex2d(34 + x + n, 103 + y);
        glVertex2d(39 + x + n, 107 + y);
        glVertex2d(45 + x + n, 105 + y);
        glVertex2d(43 + x + n, 111 + y);
        glVertex2d(46 + x + n, 117 + y);
        glVertex2d(40 + x + n, 116 + y);
        glVertex2d(36 + x + n, 122 + y);
        glVertex2d(34 + x + n, 115 + y);
        glVertex2d(28 + x + n, 113 + y);

    glEnd();
    }
    glPopMatrix();
}

int idx = 0;
void cityofstars() {
    glPushMatrix();
        star(100, 100, idx);
        star(200, 20, idx);
        star(10, -60, idx);

        star(800, -89, idx);
        star(643, -81, idx);
        star(715, -9, idx);

        if(idx<1000) idx+=89;
        else idx=0;
    glPopMatrix();
}

// background main
glBegin(GL_POLYGON);
glColor3ub(putih);
glVertex2f(0, 800);
glVertex2f(0, 0);
glVertex2f(800, 0);
glVertex2f(800, 800);
glEnd();

// background gradation
glBegin(GL_POLYGON);
glColor3ub(94,75,112);
glVertex2f(0, 160);
glColor3ub(34,43,84);
glVertex2f(0, 0);
glColor3ub(34,43,84);
glVertex2f(800, 0);
glColor3ub(94,75,112);
glVertex2f(800, 160);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(141,84,103);
glVertex2f(0, 320);
glColor3ub(94,75,112);
glVertex2f(0, 160);
glColor3ub(94,75,112);
glVertex2f(800, 160);
glColor3ub(141,84,103);
glVertex2f(800, 320);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(186,93,86);
glVertex2f(0, 480);
glColor3ub(141,84,103);
glVertex2f(0, 320);
glColor3ub(141,84,103);
glVertex2f(800, 320);
glColor3ub(186,93,86);
glVertex2f(800, 480);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(228,66,20);
glVertex2f(0, 640);
glColor3ub(186,93,86);
glVertex2f(0, 480);
glColor3ub(186,93,86);
glVertex2f(800, 480);
glColor3ub(228,66,20);
glVertex2f(800, 640);
glEnd();

glBegin(GL_POLYGON);
glColor3ub(195,39,13);
glVertex2f(0, 800);
glColor3ub(228,66,20);
glVertex2f(0, 640);
glColor3ub(228,66,20);
glVertex2f(800, 640);
glColor3ub(195,39,13);
glVertex2f(800, 800);
glEnd();

cityofstars();

// TANAH
// tanah depan
glBegin(GL_POLYGON);
glColor3ub(coklatmuda);
glVertex2f(15.1,522.57);
glVertex2f(14.94,495.69);
glVertex2f(406.87,721.98);
glVertex2f(407.03,748.86);
glEnd();

//tanah samping
glBegin(GL_POLYGON);
glColor3ub(coklattua);
glVertex2f(407.03,748.86);
glVertex2f(406.87,721.98);
glVertex2f(796.13,500.33);
glVertex2f(796.29,527.21);
glEnd();

//rumput depan
glBegin(GL_POLYGON);
glColor3ub(hijaumuda);
glVertex2f(15.94,495.69);
glVertex2f(14.88,485.61);
glVertex2f(406.81,711.89);
glVertex2f(406.87,721.98);
glEnd();

//rumput samping
glBegin(GL_POLYGON);
glColor3ub(hijautua);
glVertex2f(406.87,721.98);
glVertex2f(406.81,711.89);
glVertex2f(796.07,490.25);
glVertex2f(796.13,500.33);
glEnd();

//rumput tengah
glBegin(GL_POLYGON);
glColor3ub(hijau);
glVertex2f(14.88,485.61);
glVertex2f(404.13,263.96);
glVertex2f(796.07,490.25);
glVertex2f(406.81,711.21);
glEnd();


//PAGAR
for(int i=0; i<41; i++){
    if(i<20 || i>24){
        //pagar_depan
        glBegin(GL_POLYGON);
        glColor3ub(238,72,54);
        glVertex2f(23.49+(i*9.48),488.92+(i*5.47));
        glVertex2f(23.55+(i*9.48),457.57+(i*5.47));
        glVertex2f(29.75+(i*9.48),461.15+(i*5.47));
        glVertex2f(29.69+(i*9.48),492.5+(i*5.47));
        glEnd();

        //pagar_samping
        glBegin(GL_POLYGON);
        glColor3ub(216,30,24);
        glVertex2f(29.69+(i*9.48),492.5+(i*5.47));
        glVertex2f(29.75+(i*9.48),461.15+(i*5.47));
        glVertex2f(31.5+(i*9.48),460.13+(i*5.47));
        glVertex2f(31.43+(i*9.48),491.48+(i*5.47));
        glEnd();
    }
}

for(int i=0; i<10; i++){
    if(i!=5){
        //Pagar_atas
        glBegin(GL_POLYGON);
        glColor3ub(238,119,107);
        glVertex2f(21.81+(i*39.24),468.21+(i*22.61));
        glVertex2f(21.82+(i*39.24),464.72+(i*22.61));
        glVertex2f(61.05+(i*39.24),487.37+(i*22.61));
        glVertex2f(61.05+(i*39.24),490.86+(i*22.61));
        glEnd();

        //Pagar_bawah
        glBegin(GL_POLYGON);
        glColor3ub(238,119,107);
        glVertex2f(21.81+(i*39.24),484.04+(i*22.61));
        glVertex2f(21.82+(i*39.24),480.55+(i*22.61));
        glVertex2f(61.05+(i*39.24),503.2+(i*22.61));
        glVertex2f(61.05+(i*39.24),506.7+(i*22.61));
        glEnd();
    }
}

//RUMAH
//1
glBegin(GL_POLYGON);
glColor3ub(tembok);
glVertex2f(222.02,444.26);
glVertex2f(212.87,284.93);
glVertex2f(290.93,315.75);
glVertex2f(300.08,475.08);
glEnd();

//2
glBegin(GL_POLYGON);
glColor3ub(tembok);
glVertex2f(300.08,475.08);
glVertex2f(290.93,315.75);
glVertex2f(431.88,238.68);
glVertex2f(441.03,398.01);
glEnd();

//3
glBegin(GL_POLYGON);
glColor3ub(tembok);
glVertex2f(369.48,437.91);
glVertex2f(360.33,278.58);
glVertex2f(510.55,337.9);
glVertex2f(519.7,497.23);
glEnd();

//4
glBegin(GL_POLYGON);
glColor3ub(tembok);
glVertex2f(519.7,497.23);
glVertex2f(510.55,337.9);
glVertex2f(583.8,297.85);
glVertex2f(592.95,457.18);
glEnd();

//5
glBegin(GL_POLYGON);
glColor3ub(tembok);
glVertex2f(592.55,457.36);
glVertex2f(586.44,351.09);
glVertex2f(649.15,316.81);
glVertex2f(655.25,423.08);
glEnd();

//6
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(212.87,284.93);
glVertex2f(353.82,207.86);
glVertex2f(433.82,239.45);
glVertex2f(290.93,315.75);
glEnd();

//7
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(360.33,278.58);
glVertex2f(433.58,238.54);
glVertex2f(583.8,297.85);
glVertex2f(510.55,337.9);
glEnd();

//8
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(586.06,320.27);
glVertex2f(586.06,285.98);
glVertex2f(649.15,316.81);
glVertex2f(586.06,351.09);
glEnd();

//1.1
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(208.92,284.08);
glVertex2f(208.29,273.13);
glVertex2f(293.73,306.87);
glVertex2f(294.36,317.82);
glEnd();

//1.2
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(294.36,317.82);
glVertex2f(293.73,306.87);
glVertex2f(360.88,270.16);
glVertex2f(361.51,281.1);
glEnd();

//1.3
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(361.51,281.1);
glVertex2f(360.88,270.16);
glVertex2f(511.49,329.63);
glVertex2f(512.12,340.58);
glEnd();

//1.4
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(512.12,340.58);
glVertex2f(511.49,329.63);
glVertex2f(588.15,287.71);
glVertex2f(588.78,298.66);
glEnd();

//1.5
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(586.67,358.07);
glVertex2f(586.06,347.38);
glVertex2f(652.09,311.27);
glVertex2f(652.71,321.96);
glEnd();

//1.6
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(215.95,283.65);
glVertex2f(215.32,272.7);
glVertex2f(352.87,197.5);
glVertex2f(353.5,208.44);
glEnd();

//1.7
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(353.5,208.44);
glVertex2f(352.87,197.5);
glVertex2f(581.1,288.14);
glVertex2f(581.73,299.09);
glEnd();

//1.8
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(571.32,292.96);
glVertex2f(570.7,282.27);
glVertex2f(645.21,311.69);
glVertex2f(645.83,322.38);
glEnd();

//2.1
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(208.29,273.13);
glVertex2f(352.65,194.2);
glVertex2f(352.87,197.5);
glVertex2f(215.32,272.7);
glEnd();

//2.2
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(352.87,197.5);
glVertex2f(352.65,194.2);
glVertex2f(588.15,287.71);
glVertex2f(581.1,288.14);
glEnd();

//2.3
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(511.26,326.33);
glVertex2f(581.1,288.14);
glVertex2f(588.15,287.71);
glVertex2f(511.49,329.63);
glEnd();

//2.4
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(570.7,282.27);
glVertex2f(570.48,279.05);
glVertex2f(652.09,311.27);
glVertex2f(645.21,311.69);
glEnd();

//2.5
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(585.84,344.15);
glVertex2f(645.21,311.69);
glVertex2f(652.09,311.27);
glVertex2f(586.06,347.38);
glEnd();

//Jendela 1.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(229.77,440.29);
glVertex2f(231.45,439.38);
glVertex2f(298.29,465.77);
glVertex2f(300.15,468.07);
glEnd();

//Jendela 1.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(229.77,440.29);
glVertex2f(226.12,376.65);
glVertex2f(227.98,378.96);
glVertex2f(231.45,439.38);
glEnd();

//Jendela 1.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(226.12,376.65);
glVertex2f(296.49,404.44);
glVertex2f(294.82,405.35);
glVertex2f(227.98,378.96);
glEnd();

//Jendela 1.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(296.49,404.44);
glVertex2f(300.15,468.07);
glVertex2f(298.29,465.77);
glVertex2f(294.82,405.35);
glEnd();

//Jendela 1.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(231.45,439.38);
glVertex2f(227.98,378.96);
glVertex2f(294.82,405.35);
glVertex2f(298.29,465.77);
glEnd();

//Jendela 2.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(224.6,355.36);
glVertex2f(226.27,354.46);
glVertex2f(293.11,380.85);
glVertex2f(294.96,383.15);
glEnd();

//Jendela 2.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(224.6,355.36);
glVertex2f(220.94,291.73);
glVertex2f(222.8,294.04);
glVertex2f(226.27,354.46);
glEnd();

//Jendela 2.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(222.8,294.04);
glVertex2f(220.94,291.73);
glVertex2f(290.85,319.55);
glVertex2f(289.64,320.43);
glEnd();

//Jendela 2.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(293.11,380.85);
glVertex2f(289.64,320.43);
glVertex2f(290.85,319.55);
glVertex2f(294.96,383.15);
glEnd();

//Jendela 2.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(226.27,354.46);
glVertex2f(222.8,294.04);
glVertex2f(289.64,320.43);
glVertex2f(293.11,380.85);
glEnd();

//Jendela 3.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(294.96,383.15);
glVertex2f(296.52,380.64);
glVertex2f(359.66,346.33);
glVertex2f(361.43,347.02);
glEnd();

//Jendela 3.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(294.96,383.15);
glVertex2f(290.85,319.55);
glVertex2f(292.63,320.25);
glVertex2f(296.52,380.64);
glEnd();

//Jendela 3.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(292.63,320.25);
glVertex2f(290.85,319.55);
glVertex2f(357.33,283.42);
glVertex2f(355.77,285.93);
glEnd();

//Jendela 3.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(359.66,346.33);
glVertex2f(355.77,285.93);
glVertex2f(357.33,283.42);
glVertex2f(361.43,347.02);
glEnd();

//Jendela 3.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(296.52,380.64);
glVertex2f(292.63,320.25);
glVertex2f(355.77,285.93);
glVertex2f(359.66,346.33);
glEnd();

//Jendela 4.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(444.81,462.7);
glVertex2f(441.65,407.64);
glVertex2f(443.51,409.94);
glVertex2f(446.49,461.8);
glEnd();

//Jendela 4.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(443.51,409.94);
glVertex2f(441.65,407.64);
glVertex2f(486,425.15);
glVertex2f(484.32,426.06);
glEnd();

//Jendela 4.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(487.3,477.91);
glVertex2f(484.32,426.06);
glVertex2f(486,425.15);
glVertex2f(489.16,480.22);
glEnd();

//Jendela 4.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(444.81,462.7);
glVertex2f(446.49,461.8);
glVertex2f(487.3,477.91);
glVertex2f(489.16,480.22);
glEnd();

//Jendela 4.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(446.49,461.8);
glVertex2f(443.51,409.94);
glVertex2f(484.32,426.06);
glVertex2f(487.3,477.91);
glEnd();

//Jendela_5.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(444.35,369.92);
glVertex2f(446.03,369.01);
glVertex2f(512.88,395.41);
glVertex2f(514.39,397.74);
glEnd();

//Jendela_5.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(444.35,369.92);
glVertex2f(441.19,314.85);
glVertex2f(443.05,317.16);
glVertex2f(446.03,369.01);
glEnd();

//Jendela_5.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(443.05,317.16);
glVertex2f(441.19,315.85);
glVertex2f(510.84,342.69);
glVertex2f(509.9,343.55);
glEnd();

//Jendela_5.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(512.88,395.41);
glVertex2f(509.9,343.55);
glVertex2f(510.84,342.69);
glVertex2f(514.39,397.74);
glEnd();

//Jendela_5.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(446.03,369.01);
glVertex2f(443.05,317.16);
glVertex2f(509.9,343.55);
glVertex2f(512.88,395.41);
glEnd();

//Jendela_6.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(514.39,397.74);
glVertex2f(515.96,395.22);
glVertex2f(579.11,360.9);
glVertex2f(580.88,361.6);
glEnd();

//Jendela_6.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(514.39,397.74);
glVertex2f(510.84,342.69);
glVertex2f(512.62,343.39);
glVertex2f(515.96,395.22);
glEnd();

//Jendela_6.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(512.62,343.39);
glVertex2f(510.84,342.69);
glVertex2f(577.33,306.56);
glVertex2f(575.77,309.07);
glEnd();

//Jendela_6.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(579.11,360.9);
glVertex2f(575.77,309.07);
glVertex2f(577.33,306.56);
glVertex2f(580.88,361.6);
glEnd();

//Jendela_6.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(515.96,395.22);
glVertex2f(512.62,343.39);
glVertex2f(575.77,309.07);
glVertex2f(579.11,360.9);
glEnd();

//Jendela_7.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(526.75,485.03);
glVertex2f(528.32,482.52);
glVertex2f(646.77,418.14);
glVertex2f(648.55,418.83);
glEnd();

//Jendela_7.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(526.75,485.03);
glVertex2f(522.27,415.55);
glVertex2f(524.04,416.25);
glVertex2f(528.32,482.52);
glEnd();

//Jendela_7.3
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(524.04,416.25);
glVertex2f(522.27,415.55);
glVertex2f(644.07,349.36);
glVertex2f(642.5,351.87);
glEnd();

//Jendela_7.4
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(646.77,418.14);
glVertex2f(642.5,351.87);
glVertex2f(644.07,349.36);
glVertex2f(648.55,418.83);
glEnd();

//Jendela_7.5
glBegin(GL_POLYGON);
glColor3ub(jendelamuda);
glVertex2f(528.32,482.52);
glVertex2f(524.04,416.25);
glVertex2f(642.5,351.87);
glVertex2f(646.77,418.14);
glEnd();

//Kayu_1.1
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(299.57,391.44);
glVertex2f(298.98,381.26);
glVertex2f(327.14,392.38);
glVertex2f(327.72,402.56);
glEnd();

//Kayu_1.2
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(327.72,402.56);
glVertex2f(327.14,392.38);
glVertex2f(368.87,369.56);
glVertex2f(369.46,379.74);
glEnd();

//Kayu_1.3
glBegin(GL_POLYGON);
glColor3ub(atapdepan);
glVertex2f(369.46,379.74);
glVertex2f(368.87,369.56);
glVertex2f(483.19,414.7);
glVertex2f(483.77,424.88);
glEnd();

//Kayu_1.4
glBegin(GL_POLYGON);
glColor3ub(atapsamping);
glVertex2f(483.77,424.88);
glVertex2f(483.19,414.7);
glVertex2f(509.61,400.25);
glVertex2f(510.19,410.43);
glEnd();

//Kayu_2.1
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(298.98,381.26);
glVertex2f(366.58,343.78);
glVertex2f(368.87,369.56);
glVertex2f(327.14,392.38);
glEnd();

//Kayu_2.2
glBegin(GL_POLYGON);
glColor3ub(atap);
glVertex2f(368.87,369.56);
glVertex2f(366.58,343.78);
glVertex2f(509.61,400.25);
glVertex2f(483.19,414.7);
glEnd();

//Penyangga_1
glBegin(GL_POLYGON);
glColor3ub(114,74,13);
glVertex2f(316.84,485.51);
glVertex2f(311.01,395.92);
glVertex2f(331.2,400.24);
glVertex2f(336.94,485.34);
glEnd();

//Penyangga_2
glBegin(GL_POLYGON);
glColor3ub(114,74,13);
glVertex2f(484.18,518.37);
glVertex2f(478.96,421.2);
glVertex2f(498.19,417.05);
glVertex2f(504.33,518.03);
glEnd();

//Pintu
glBegin(GL_POLYGON);
glColor3ub(58,32,0);
glVertex2f(382.58,443.38);
glVertex2f(379.42,388.31);
glVertex2f(415.49,402.55);
glVertex2f(418.65,457.62);
glEnd();

//Batu_1.1
glBegin(GL_POLYGON);
glColor3ub(batudepan);
glVertex2f(233.63,587.82);
glVertex2f(233.72,585.62);
glVertex2f(260.41,602.94);
glVertex2f(260.31,605.15);
glEnd();

//Batu_1.2
glBegin(GL_POLYGON);
glColor3ub(batusamping);
glVertex2f(260.31,605.15);
glVertex2f(260.41,602.94);
glVertex2f(288.25,587.87);
glVertex2f(288.16,590.08);
glEnd();

//Batu_1.3
glBegin(GL_POLYGON);
glColor3ub(batu);
glVertex2f(233.72,585.62);
glVertex2f(261.57,570.55);
glVertex2f(288.25,587.87);
glVertex2f(260.41,602.94);
glEnd();

//Batu_2.1
glBegin(GL_POLYGON);
glColor3ub(batudepan);
glVertex2f(279.52,562.89);
glVertex2f(279.57,560.69);
glVertex2f(306.59,577.48);
glVertex2f(306.54,579.68);
glEnd();

//Batu_2.2
glBegin(GL_POLYGON);
glColor3ub(batusamping);
glVertex2f(306.59,577.48);
glVertex2f(306.54,579.68);
glVertex2f(334.13,561.86);
glVertex2f(334.08,565.06);
glEnd();

//Batu_2.3
glBegin(GL_POLYGON);
glColor3ub(batu);
glVertex2f(279.57,560.69);
glVertex2f(307.11,545.06);
glVertex2f(334.13,561.86);
glVertex2f(306.54,579.68);
glEnd();

//Batu_3.1
glBegin(GL_POLYGON);
glColor3ub(batudepan);
glVertex2f(320.44,539.06);
glVertex2f(319.99,536.9);
glVertex2f(350.1,547.17);
glVertex2f(350.55,549.33);
glEnd();

//Batu_3.2
glBegin(GL_POLYGON);
glColor3ub(batusamping);
glVertex2f(350.1,547.17);
glVertex2f(350.55,549.33);
glVertex2f(373.41,525.75);
glVertex2f(373.86,527.91);
glEnd();

//Batu_3.3
glBegin(GL_POLYGON);
glColor3ub(batu);
glVertex2f(319.99,536.9);
glVertex2f(343.3,515.47);
glVertex2f(373.41,525.75);
glVertex2f(350.55,549.33);
glEnd();

//Batu_4.1
glBegin(GL_POLYGON);
glColor3ub(batudepan);
glVertex2f(355.43,507.42);
glVertex2f(354.67,505.34);
glVertex2f(385.94,511.23);
glVertex2f(386.69,513.3);
glEnd();

//Batu_4.2
glBegin(GL_POLYGON);
glColor3ub(batusamping);
glVertex2f(385.94,511.23);
glVertex2f(386.69,513.3);
glVertex2f(405.97,486.7);
glVertex2f(406.72,488.78);
glEnd();

//Batu_4.3
glBegin(GL_POLYGON);
glColor3ub(batu);
glVertex2f(354.67,505.34);
glVertex2f(374.7,480.82);
glVertex2f(405.97,486.7);
glVertex2f(386.69,513.3);
glEnd();

//Ayunan_1.1
glBegin(GL_POLYGON);
glColor3ub(251,5,15);
glVertex2f(203.63,469.73);
glVertex2f(203.75,408.69);
glVertex2f(206.26,413.36);
glVertex2f(206.15,471.19);
glEnd();

//Ayunan_1.2
glBegin(GL_POLYGON);
glColor3ub(173,0,7);
glVertex2f(206.15,471.19);
glVertex2f(206.26,413.36);
glVertex2f(209.04,415.36);
glVertex2f(208.93,469.57);
glEnd();

//Ayunan_2.1
glBegin(GL_POLYGON);
glColor3ub(251,5,15);
glVertex2f(206.26,411.91);
glVertex2f(203.75,408.69);
glVertex2f(233.04,425.6);
glVertex2f(230.51,427.36);
glEnd();

//Ayunan_2.2
glBegin(GL_POLYGON);
glColor3ub(254,111,106);
glVertex2f(203.75,408.69);
glVertex2f(206.53,407.08);
glVertex2f(235.82,423.99);
glVertex2f(233.04,425.6);
glEnd();

//Ayunan_3.1
glBegin(GL_POLYGON);
glColor3ub(251,5,15);
glVertex2f(230.4,485.19);
glVertex2f(230.51,427.36);
glVertex2f(233.04,425.6);
glVertex2f(232.92,486.65);
glEnd();

//Ayunan_3.2
glBegin(GL_POLYGON);
glColor3ub(173,0,7);
glVertex2f(232.92,486.65);
glVertex2f(233.04,425.6);
glVertex2f(235.82,423.99);
glVertex2f(235.7,485.03);
glEnd();

//Tali_1
glBegin(GL_POLYGON);
glColor3ub(173,0,7);
glVertex2f(214.6,457.79);
glVertex2f(214.6,418.18);
glVertex2f(215.36,418.18);
glVertex2f(215.36,457.79);
glEnd();

//Tali_2
glBegin(GL_POLYGON);
glColor3ub(173,0,7);
glVertex2f(223.77,462.86);
glVertex2f(223.77,423.47);
glVertex2f(224.53,423.47);
glVertex2f(224.53,463.3);
glEnd();

//Kursi_1
glBegin(GL_POLYGON);
glColor3ub(255,255,255);
glVertex2f(207.59,466.01);
glVertex2f(212.75,463.01);
glVertex2f(224.49,469.79);
glVertex2f(219.33,472.78);
glEnd();

//Kursi_2
glBegin(GL_POLYGON);
glColor3ub(240,231,216);
glVertex2f(212.75,463.01);
glVertex2f(212.77,457.5);
glVertex2f(224.51,464.28);
glVertex2f(224.49,469.79);
glEnd();

//KOLAM RENANG
//bawah
glBegin(GL_POLYGON);
glColor3ub(kolam);
glVertex2f(570.13,481.63);
glVertex2f(582.61,482.01);
glVertex2f(643.19,519.57);
glVertex2f(642.97,526.81);
glEnd();

//kiri
glBegin(GL_POLYGON);
glColor3ub(kolam);
glVertex2f(666.64,429.54);
glVertex2f(666.42,436.78);
glVertex2f(582.61,482.01);
glVertex2f(570.13,481.63);
glEnd();

//atas
glBegin(GL_POLYGON);
glColor3ub(kolam);
glVertex2f(739.49,474.71);
glVertex2f(727,474.34);
glVertex2f(666.42,436.78);
glVertex2f(666.64,429.54);
glEnd();

//kanan
glBegin(GL_POLYGON);
glColor3ub(kolam);
glVertex2f(642.97,526.81);
glVertex2f(643.19,519.57);
glVertex2f(725.71,475.03);
glVertex2f(739.49,474.71);
glEnd();

//air kolam
glBegin(GL_POLYGON);
glColor3ub(airkolam);
glVertex2f(582.61,482.01);
glVertex2f(666.37,438.23);
glVertex2f(725.71,475.03);
glVertex2f(643.19,519.57);
glEnd();

//exit
glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}

