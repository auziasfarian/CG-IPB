#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define ijo 244, 88, 100
#define ijau 204, 31, 44
#define abut 199, 202, 203
#define dasa 229, 229, 299
#define grabok 209, 209, 209
#define tesa1 191, 191, 191
#define teba 178, 178, 178
#define tangga 217, 217, 217
#define tangga2 204, 204, 204
#define tangga3 128, 128, 128
#define itam 0, 0, 0
#define putih 242, 242, 242

static void error_callback(int error, const char* description)
{
fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
glfwSetWindowShouldClose(window, GL_TRUE);
}
void awan1(){

    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(668.5+cos(x)*21,207.5+sin(x)*21);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(695.5+cos(x)*20,194+sin(x)*20);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(693.5+cos(x)*20,221+sin(x)*20);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(717.5+cos(x)*20,194+sin(x)*20);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(726.5+cos(x)*20,220.5+sin(x)*20);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(751+cos(x)*20,208+sin(x)*20);
    }
    glEnd();
}
void awan2(){
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(379.5+cos(x)*23,144.5+sin(x)*23);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(405+cos(x)*23,131+sin(x)*23);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(406.5+cos(x)*23,158+sin(x)*23);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(430.5+cos(x)*23,131+sin(x)*23);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(439.5+cos(x)*23,157.5+sin(x)*23);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(464+cos(x)*23,144+sin(x)*23);
    }
    glEnd();
}

void awan3(){
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(162.5+cos(x)*25,184.5+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(187+cos(x)*25,171+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(189.5+cos(x)*25,198+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(213.5+cos(x)*25,171+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(222.5+cos(x)*25,197.5+sin(x)*25);
    }
    glEnd();
    glBegin(GL_POLYGON);
    for(int i=0; i<=360; i++){
        glColor3ub(255,255,255);
        float x=i*3.14159/180;
        glVertex2f(247+cos(x)*25,184+sin(x)*25);
    }
    glEnd();
}

void jalan(){
    glTranslatef(glfwGetTime()*-10.0,0,0);
    awan1();
    awan2();
    awan3();
    if(glfwGetTime()*-10<-500){
        glTranslatef(glfwGetTime()*10.0,0,0);
        glfwSetTime(0);
    }
}


void BG(){
    glBegin(GL_POLYGON);
    glColor3ub(185,207,239);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(72,116,160);
    glColor3ub(255,255,255);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();


}
void rumah (){

    glBegin(GL_POLYGON);
    glColor3ub(59,188,74);
    glVertex2f(0,800);
    glVertex2f(0,467);
    glVertex2f(800,467);
    glVertex2f(800,800);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(229,229,229);
    glVertex2f(140.98,481.43);
    glVertex2f(141.98,370.57);
    glVertex2f(521.64,357.72);
    glVertex2f(521.64,482.43);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijo);
    glVertex2f(105.99,366.58);
    glVertex2f(194.98,275.45);
    glVertex2f(596.63,254.3);
    glVertex2f(529.02,352.37);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(147,44,52);
    glVertex2f(307.74,278.16);
    glVertex2f(374.07,283.33);
    glVertex2f(428.97,354.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijau);
    glVertex2f(106.27,372.05);
    glVertex2f(105.27,365.81);
    glVertex2f(528.8,352.98);
    glVertex2f(529.05,358.48);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijau);
    glVertex2f(106.27,372.05);
    glVertex2f(105.27,365.81);
    glVertex2f(529.02,352.37);
    glVertex2f(529.02,358.44);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijau);
    glVertex2f(529.02,358.44);
    glVertex2f(529.02,352.37);
    glVertex2f(596.91,253.57);
    glVertex2f(659.03,357.94);
    glVertex2f(658.97,363.97);
    glVertex2f(596.91,259.71);
    glVertex2f(529.02,358.44);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,128,128);
    glVertex2f(585.41,276.46);
    glVertex2f(596.91,259.71);
    glVertex2f(659,364.03);
    glVertex2f(632.04,364.1);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(abut);
    glVertex2f(521.43,481.71);
    glVertex2f(521.47,358.7);
    glVertex2f(585.41,276.46);
    glVertex2f(632.69,353.12);
    glVertex2f(632.69,487.171);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijau);
    glVertex2f(199.1,362);
    glVertex2f(307.61,277.97);
    glVertex2f(421.11,354.9);
    glVertex2f(410.63,354.86);
    glVertex2f(307.74,286.34);
    glVertex2f(209.96,361.93);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,128,128);
    glVertex2f(220.77,359.07);
    glVertex2f(220.44,349.86);
    glVertex2f(307.91,283.26);
    glVertex2f(390.84,338.6);
    glVertex2f(391.37,353.3);
    glEnd();


    glBegin(GL_POLYGON);
    glColor3ub(abut);
    glVertex2f(227.07,365.24);
    glVertex2f(226.74,356.03);
    glVertex2f(313.34,290.08);
    glVertex2f(313.34,290.08);
    glVertex2f(397.13,344.77);
    glVertex2f(397.66,359.47);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(grabok);
    glVertex2f(240.29,489.02);
    glVertex2f(240.29,393.87);
    glVertex2f(277.55,393.87);
    glVertex2f(277.55,489.02);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(grabok);
    glVertex2f(384.99,481.95);
    glVertex2f(385.1,398.17);
    glVertex2f(412.64,359.07);
    glVertex2f(414.42,481.88);
    glEnd();

     glBegin(GL_POLYGON);
    glColor3ub(ijo);
    glVertex2f(168.05,398.48);
    glVertex2f(215.15,352.37);
    //glVertex2f(247.69,347.16);
    //glVertex2f(223.06,377.84);
    //glVertex2f(361.57,374.77);
    //glVertex2f(387.01,342.11);
    glVertex2f(413.35,359);
    glVertex2f(392.33,392.68);
    glEnd();

    //jendela
     glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(314.96,367.54);
    glVertex2f(314.96,337.33);
    glVertex2f(328.87,337.33);
    glVertex2f(328.87,367.51);
    glEnd();
    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(322.15,360.23);
    glVertex2d(321.82,336.83);
    glEnd();
    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(313.28,349.49);
    glVertex2d(331.6,348.85);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(286.39,362.48);
    glVertex2f(286.39,342.44);
    glVertex2f(295.02,342.44);
    glVertex2f(295.02,362.48);
    glEnd();
    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(284.61,351.54);
    glVertex2d(296.79,351.16);
    glEnd();
    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(349.67,360.44);
    glVertex2f(349.67,340.39);
    glVertex2f(358.3,340.39);
    glVertex2f(358.3,360.44);
    glEnd();
    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(347.89,349.49);
    glVertex2d(360.07,349.11);
    glEnd();


     glBegin(GL_POLYGON);
    glColor3ub(128,128,128);
    glVertex2f(362,377.43);
    glVertex2f(362,348.34);
    glVertex2f(399.13,359);
    glVertex2f(399.13,344.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(128,128,128);
    glVertex2f(223,381.32);
    glVertex2f(223,350.34);
    glVertex2f(362.45,348.34);
    glVertex2f(362.45,376.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tesa1);
    glVertex2f(540.33,478.83);
    glVertex2f(540.33,392.88);
    glVertex2f(589.9,392.88);
    glVertex2f(589.9,478.83);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tesa1);
    glVertex2f(589.9,479.83);
    glVertex2f(589.9,393.88);
    glVertex2f(652.12,393.88);
    glVertex2f(652.47,479.49);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(173,173,173);
    glVertex2f(652.44,478.77);
    glVertex2f(652.11,392.88);
    glVertex2f(687.77,393.2);
    glVertex2f(688.33,477.26);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(ijau);
    glVertex2f(535.67,397.96);
    glVertex2f(538.84,390.8);
    glVertex2f(539.63,387.22);
    glVertex2f(687.54,386.2);
    glVertex2f(689.12,390.55);
    glVertex2f(696.51,395.92);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(teba);
    glVertex2f(140.93,499.16);
    glVertex2f(140.93,480.74);
    glVertex2f(522.01,480.96);
    glVertex2f(522.01,499.16);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(teba);
    glVertex2f(522.26,498.74);
    glVertex2f(522.26,480.58);
    glVertex2f(540.68,478.82);
    glVertex2f(540.72,496.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(176,176,176);
    glVertex2f(540.68,496.53);
    glVertex2f(540.68,478.79);
    glVertex2f(652.91,478.45);
    glVertex2f(652.91,495.51);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(163,163,163);
    glVertex2f(652.87,495.52);
    glVertex2f(652.85,478.48);
    glVertex2f(688.86,477.23);
    glVertex2f(688.86,493.54);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(77,77,77);
    glVertex2f(571.4,500.01);
    glVertex2f(571.33,493.89);
    glVertex2f(575.12,493.32);
    glVertex2f(575.12,488.61);
    glVertex2f(579.56,488.17);
    glVertex2f(579.56,483.46);
    glVertex2f(583.65,483.36);
    glVertex2f(583.73,478.44);
    glVertex2f(587.69,478.16);
    glVertex2f(587.76,495.03);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga);
    glVertex2f(522.36,499.89);
    glVertex2f(522.36,493.96);
    glVertex2f(571.33,493.89);
    glVertex2f(571.4,500.01);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga);
    glVertex2f(527.38,493.32);
    glVertex2f(527.38,488.61);
    glVertex2f(575.12,488.61);
    glVertex2f(575.12,493.32);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga);
    glVertex2f(531.71,488.17);
    glVertex2f(531.71,483.46);
    glVertex2f(579.56,483.46);
    glVertex2f(579.56,488.17);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga);
    glVertex2f(536.16,483.13);
    glVertex2f(536.16,478.42);
    glVertex2f(583.73,478.44);
    glVertex2f(583.65,483.36);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga);
    glVertex2f(170.51,504.63);
    glVertex2f(170.24,502.07);
    glVertex2f(182.91,501.68);
    glVertex2f(182.78,497.28);
    glVertex2f(200.93,496.06);
    glVertex2f(200.84,492.15);
    glVertex2f(216.91,490.94);
    glVertex2f(216.91,487.58);
    glVertex2f(232.93,486.27);
    glVertex2f(232.86,482.72);
    glVertex2f(249.6,480.94);
    glVertex2f(337.93,481.1);
    glVertex2f(346.3,482.57);
    glVertex2f(346.3,485.76);
    glVertex2f(355.36,487.14);
    glVertex2f(355.5,490.56);
    glVertex2f(365.19,491.17);
    glVertex2f(365.19,495);
    glVertex2f(375.17,496.04);
    glVertex2f(375.35,500.3);
    glVertex2f(379.13,501.85);
    glVertex2f(348.21,503.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga2);
    glVertex2f(182.91,501.68);
    glVertex2f(182.91,497.24);
    glVertex2f(348.13,497.24);
    glVertex2f(348.19,501.84);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga2);
    glVertex2f(200.84,496.13);
    glVertex2f(200.84,492.15);
    glVertex2f(345.15,492.13);
    glVertex2f(345.21,496.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga2);
    glVertex2f(216.91,490.98);
    glVertex2f(216.91,487.58);
    glVertex2f(342.29,487.54);
    glVertex2f(342.34,491.06);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga2);
    glVertex2f(232.86,486.11);
    glVertex2f(232.86,482.72);
    glVertex2f(339.13,482.7);
    glVertex2f(339.15,486.22);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga3);
    glVertex2f(348.19,501.84);
    glVertex2f(348.1,497.23);
    glVertex2f(375.17,496.04);
    glVertex2f(375.35,500.3);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga3);
    glVertex2f(345.21,496.22);
    glVertex2f(345.12,492.13);
    glVertex2f(365.19,491.17);
    glVertex2f(365.19,495);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga3);
    glVertex2f(342.34,491.06);
    glVertex2f(342.29,487.54);
    glVertex2f(355.45,487.14);
    glVertex2f(355.5,490.56);
    glEnd();

    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(539.63,387.22);
    glVertex2d(539.63,357.55);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(590.08,386.2);
    glVertex2d(590.08,355.67);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(648.96,386.03);
    glVertex2d(648.96,355.12);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(656.87,385.34);
    glVertex2d(656.87,363.18);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(539.63,357.55);
    glVertex2d(588.85,357.55);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(590.25,357.55);
    glVertex2d(648.08,357.55);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(648.79,358.23);
    glVertex2d(685.17,360.28);
    glEnd();
    glLineWidth(3);
    glColor3ub(itam);
    glBegin(GL_LINE_STRIP);
    glVertex2d(684.82,360.79);
    glVertex2d(655.29,363.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(tangga3);
    glVertex2f(339.15,486.22);
    glVertex2f(339.13,482.7);
    glVertex2f(346.3,482.57);
    glVertex2f(346.27,485.8);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2f(152.88,455.43);
    glVertex2f(152.88,411.38);
    glVertex2f(223.78,409.85);
    glVertex2f(223.78,455.27);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(157.8,450.84);
    glVertex2f(157.65,415.36);
    glVertex2f(173.83,415.30);
    glVertex2f(174.01,450.79);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(166.17,452.3);
    glVertex2d(165.69,414.1);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(155.97,427.14);
    glVertex2d(173.83,427.14);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(157.13,439.25);
    glVertex2d(173.83,439.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(181.19,450.84);
    glVertex2f(181.3,413.88);
    glVertex2f(195.99,413.84);
    glVertex2f(196.16,451.01);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(181.3,427.14);
    glVertex2d(195.99,427.14);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(188.8,451.52);
    glVertex2d(188.88,414);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(181.13,439.25);
    glVertex2d(196.16,439.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(203.09,451.06);
    glVertex2f(202.97,413.6);
    glVertex2f(219.95,414.19);
    glVertex2f(219.63,450.23);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(211.83,453.63);
    glVertex2d(211.68,413.3);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(202.97,427.14);
    glVertex2d(219.94,427.14);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(203.09,439.25);
    glVertex2d(220.95,439.25);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(abut);
    glVertex2f(309.57,473.9);
    glVertex2f(309.06,411.95);
    glVertex2f(337.33,411.81);
    glVertex2f(337.83,473.78);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(314.38,468.76);
    glVertex2f(314.38,417.04);
    glVertex2f(332.52,416.95);
    glVertex2f(332.52,468.68);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(324.23,471.41);
    glVertex2d(323.3,416.27);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(313.44,459.17);
    glVertex2d(334.55,459.1);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(313.19,448.85);
    glVertex2d(334.29,448.42);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(313.19,437.93);
    glVertex2d(334.29,437.5);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(313.01,427.62);
    glVertex2d(334.11,427.36);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(432.63,448.72);
    glVertex2f(432.63,408.72);
    glVertex2f(502.11,408.72);
    glVertex2f(502.11,448.05);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(431.7,436.08);
    glVertex2d(503.06,436.08);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(431.7,422.86);
    glVertex2d(503.06,422.86);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2f(450.56,448.66);
    glVertex2f(450.56,408.4);
    glVertex2f(458.78,408.4);
    glVertex2f(458.78,448.66);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(putih);
    glVertex2f(475.53,448.96);
    glVertex2f(475.53,408.35);
    glVertex2f(483.27,408.35);
    glVertex2f(483.27,448.96);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(441.99,450.31);
    glVertex2d(441.99,408.64);
    glEnd();
    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(467.3,449.46);
    glVertex2d(467.39,408.54);
    glEnd();
    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(492.87,407.77);
    glVertex2d(493.05,451.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(555.46,467.27);
    glVertex2f(555.46,412.98);
    glVertex2f(575.11,412.98);
    glVertex2f(575.11,467.27);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(565.54,468.97);
    glVertex2d(565.54,412.21);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(552.97,423.93);
    glVertex2d(575.28,423.46);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(553.65,434.89);
    glVertex2d(575.28,434.61);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(553.85,445.85);
    glVertex2d(575.57,445.47);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(554.04,456.72);
    glVertex2d(575.76,456.44);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(609.68,448.48);
    glVertex2f(609.68,400.78);
    glVertex2f(631.98,400.28);
    glVertex2f(631.98,448.48);
    glEnd();

    glLineWidth(1.5);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(621.1,449.82);
    glVertex2d(620.56,399.14);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(608.59,412.24);
    glVertex2d(631.98,412.13);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(608.48,424.69);
    glVertex2d(633.39,424.48);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(608.69,436.52);
    glVertex2d(633.07,436.52);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(656.64,447.15);
    glVertex2f(656.64,400.91);
    glVertex2f(666.65,400.91);
    glVertex2f(666.65,447.15);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(661.69,448.67);
    glVertex2d(661.69,399.32);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(656.21,435.72);
    glVertex2d(666.98,435.72);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(656.11,424.21);
    glVertex2d(667.08,424.21);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(656.16,412.07);
    glVertex2d(666.5,412.07);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(itam);
    glVertex2f(674.05,447.37);
    glVertex2f(674.05,400.91);
    glVertex2f(682.89,400.91);
    glVertex2f(682.89,447.15);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(673.66,435.72);
    glVertex2d(683.32,435.72);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(678.57,448.67);
    glVertex2d(678.36,399.32);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(673.61,412.07);
    glVertex2d(682.89,412.07);
    glEnd();

    glLineWidth(1);
    glColor3ub(putih);
    glBegin(GL_LINE_STRIP);
    glVertex2d(673.57,424.21);
    glVertex2d(683.41,424.21);
    glEnd();
}


int main(void)
{
GLFWwindow* window;
glfwSetErrorCallback(error_callback);
if (!glfwInit())
exit(EXIT_FAILURE);
window = glfwCreateWindow(800, 800, "Mia G64160038", NULL, NULL);
if (!window)
{
glfwTerminate();
exit(EXIT_FAILURE);
}
glfwMakeContextCurrent(window);
glfwSwapInterval(1);
glfwSetKeyCallback(window, key_callback);
while (!glfwWindowShouldClose(window))
{
float ratio;
int width, height;
glfwGetFramebufferSize(window, &width, &height);
ratio = width*10 / (float) height;
glViewport(0, 0, width, height);
glClear(GL_COLOR_BUFFER_BIT);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0, 800, 800, 0, 1.f, -1.f);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();


BG();
rumah();
jalan();

glfwSwapBuffers(window);
glfwPollEvents();
}
glfwDestroyWindow(window);
glfwTerminate();
exit(EXIT_SUCCESS);
}
