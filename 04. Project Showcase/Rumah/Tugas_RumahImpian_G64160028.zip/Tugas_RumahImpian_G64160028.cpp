#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int clindex=0,buff=0;
int colorf[3][3]={{147,9,32},{239,80,0},{0,0,0}};


static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE); // close program on ESC key
}

void setup_viewport(GLFWwindow* window)
{
    // setting viewports size, projection etc
    float ratio;
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    ratio = width / (float) height;
    glViewport(0, 0, width, height);

    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 800, 800, 0, 1.f, -1.f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display()
{
    glClear (GL_COLOR_BUFFER_BIT);

    glFlush();
}

void Background()
{
    glBegin(GL_POLYGON);
    glColor3ub(87,205,247);
    glVertex2d(0,0);
    glVertex2d(800,0);
    glColor3ub(255,255,255);
    glVertex2d(800,800);
    glVertex2d(0,800);

    glEnd();

    glBegin(GL_POLYGON);
}

void tanah1()
{
    glBegin(GL_POLYGON);

    glColor3ub(124,52,3);
    glVertex2d(64,534);
    glVertex2d(64,508);
    glVertex2d(400,720);
    glVertex2d(400,745);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(124,52,3);
    glVertex2d(400,720);
    glVertex2d(735,508);
    glVertex2d(735,534);
    glVertex2d(400,745);

    glEnd();

    glBegin(GL_POLYGON);
}

void tanah2()
{
    glBegin(GL_POLYGON);

    glColor3ub(111,193,23);
    glVertex2d(64,508);
    glVertex2d(64,499);
    glVertex2d(400,710);
    glVertex2d(400,720);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(66,147,13);
    glVertex2d(400,720);
    glVertex2d(400,710);
    glVertex2d(735,499);
    glVertex2d(735,508);

    glEnd();
}

void tanah3()
{
    glBegin(GL_POLYGON);

    glColor3ub(136,209,59);
    glVertex2d(64,499);
    glVertex2d(400,287);
    glVertex2d(735,499);
    glVertex2d(400,710);

    glEnd();
}

void bayangan()
{
    glBegin(GL_POLYGON);

    glColor3ub(66,147,13);
    glVertex2d(674,460);
    glVertex2d(735,499);
    glVertex2d(592,589);
    glVertex2d(545,589);
    glVertex2d(382,486);
    glVertex2d(314,530);
    glVertex2d(279,530);
    glVertex2d(342,460);

    glEnd();
}

void pintu()
{
    glBegin(GL_POLYGON);

    glColor3ub(240,245,247);
    glVertex2d(388,490);
    glVertex2d(388,375);
    glVertex2d(438,406);
    glVertex2d(438,521);

    glEnd();
}

void jendelapintu1()
{
    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(396,428);
    glVertex2d(410,436);
    glVertex2d(410,458);
    glVertex2d(396,449);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(400,430);
    glVertex2d(410,436);
    glVertex2d(400,447);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(401,448);
    glVertex2d(410,439);
    glVertex2d(410,441);
    glVertex2d(403,448);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(191,215,221);
    glVertex2d(394,450);
    glVertex2d(396,449);
    glVertex2d(410,458);
    glVertex2d(410,460);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(128,172,183);
    glVertex2d(394,426);
    glVertex2d(396,428);
    glVertex2d(396,449);
    glVertex2d(394,450);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(396,428);
    glVertex2d(398,429);
    glVertex2d(398,448);
    glVertex2d(396,449);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(396,449);
    glVertex2d(398,448);
    glVertex2d(410,455);
    glVertex2d(410,458);

    glEnd();
}

void jendelapintu2()
{
    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(418,441);
    glVertex2d(431,450);
    glVertex2d(431,471);
    glVertex2d(418,462);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(421,443);
    glVertex2d(431,450);
    glVertex2d(421,460);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(423,461);
    glVertex2d(431,452);
    glVertex2d(431,455);
    glVertex2d(424,462);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(191,215,221);
    glVertex2d(416,464);
    glVertex2d(418,462);
    glVertex2d(431,471);
    glVertex2d(431,474);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(128,172,183);
    glVertex2d(416,440);
    glVertex2d(418,441);
    glVertex2d(418,462);
    glVertex2d(416,464);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(418,441);
    glVertex2d(420,442);
    glVertex2d(420,461);
    glVertex2d(418,462);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(418,462);
    glVertex2d(420,461);
    glVertex2d(431,468);
    glVertex2d(431,471);

    glEnd();
}

void v2()
{
    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(605,21);
    glVertex2d(777,21);
    glVertex2d(777,43);
    glVertex2d(605,43);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(127,6,6);
    glVertex2d(779,23);
    glVertex2d(779,195);
    glVertex2d(757,195);
    glVertex2d(757,23);

    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(605,21);
    glVertex2d(777,21);
    glVertex2d(777,43);
    glVertex2d(605,43);


    glBegin(GL_POLYGON);

    glColor3ub(colorf[(clindex)%3][0], colorf[(clindex)%3][1],colorf[(clindex)%3][2]);
    glVertex2d(779,23);
    glVertex2d(779,195);
    glVertex2d(757,195);
    glVertex2d(757,23);

    glEnd();
}

void ruang1()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(248,402);
    glVertex2d(248,302);
    glVertex2d(545,490);
    glVertex2d(545,589);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(545,490);
    glVertex2d(685,401);
    glVertex2d(685,501);
    glVertex2d(545,589);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(248,302);
    glVertex2d(388,214);
    glVertex2d(685,401);
    glVertex2d(545,490);

    glEnd();
}

void ruang12()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(162,330);
    glVertex2d(279,404);
    glVertex2d(279,530);
    glVertex2d(162,456);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(279,404);
    glVertex2d(345,363);
    glVertex2d(345,389);
    glVertex2d(366,403);
    glVertex2d(366,475);
    glVertex2d(279,530);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(162,330);
    glVertex2d(227,289);
    glVertex2d(345,363);
    glVertex2d(279,404);

    glEnd();
}

void ruang13()
{
    glBegin(GL_POLYGON);

    glColor3ub(28,38,45);
    glVertex2d(178,331);
    glVertex2d(227,300);
    glVertex2d(227,307);
    glVertex2d(183,334);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(28,38,45);
    glVertex2d(227,300);
    glVertex2d(329,364);
    glVertex2d(323,367);
    glVertex2d(227,307);

    glEnd();
}

void ruang2()
{
    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(227,316);
    glVertex2d(227,197);
    glVertex2d(524,384);
    glVertex2d(524,503);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(189,193,167);
    glVertex2d(524,384);
    glVertex2d(685,248);
    glVertex2d(685,401);
    glVertex2d(524,503);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(227,197);
    glVertex2d(388,61);
    glVertex2d(685,248);
    glVertex2d(524,384);

    glEnd();
}

void atap()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(217,206);
    glVertex2d(217,198);
    glVertex2d(514,386);
    glVertex2d(514,393);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(514,386);
    glVertex2d(685,241);
    glVertex2d(685,248);
    glVertex2d(514,393);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(48,60,73);
    glVertex2d(217,198);
    glVertex2d(388,54);
    glVertex2d(685,241);
    glVertex2d(514,386);

    glEnd();
}

void cerobong()
{
    glBegin(GL_POLYGON);

    glColor3ub(249,241,230);
    glVertex2d(582,241);
    glVertex2d(582,176);
    glVertex2d(600,187);
    glVertex2d(600,252);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(212,194,171);
    glVertex2d(600,187);
    glVertex2d(629,170);
    glVertex2d(629,235);
    glVertex2d(600,252);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(216,202,188);
    glVertex2d(582,176);
    glVertex2d(600,187);
    glVertex2d(600,211);
    glVertex2d(582,200);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(216,202,188);
    glVertex2d(600,187);
    glVertex2d(629,170);
    glVertex2d(629,194);
    glVertex2d(600,211);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(212,194,171);
    glVertex2d(579,192);
    glVertex2d(579,175);
    glVertex2d(600,187);
    glVertex2d(601,204);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(179,158,130);
    glVertex2d(600,187);
    glVertex2d(633,167);
    glVertex2d(633,185);
    glVertex2d(601,204);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(249,241,230);
    glVertex2d(579,175);
    glVertex2d(612,155);
    glVertex2d(633,167);
    glVertex2d(600,187);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(179,158,130);
    glVertex2d(594,172);
    glVertex2d(610,162);
    glVertex2d(610,175);
    glVertex2d(605,178);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(212,194,171);
    glVertex2d(610,162);
    glVertex2d(621,168);
    glVertex2d(610,175);

    glEnd();

}

void jendelapanjang()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(245,279);
    glVertex2d(245,240);
    glVertex2d(348,304);
    glVertex2d(348,343);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(34,47,58);
    glVertex2d(248,246);
    glVertex2d(345,306);
    glVertex2d(345,337);
    glVertex2d(248,277);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(252,248);
    glVertex2d(345,306);
    glVertex2d(345,333);
    glVertex2d(252,275);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(255,250);
    glVertex2d(345,306);
    glVertex2d(345,329);
    glVertex2d(255,273);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(259,253);
    glVertex2d(345,306);
    glVertex2d(332,319);
    glVertex2d(259,273);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(334,320);
    glVertex2d(345,309);
    glVertex2d(345,312);
    glVertex2d(336,321);

    glEnd();
}

void jendelaa1()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(399,410);
    glVertex2d(399,332);
    glVertex2d(427,349);
    glVertex2d(427,427);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(402,337);
    glVertex2d(424,351);
    glVertex2d(424,422);
    glVertex2d(402,408);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(405,339);
    glVertex2d(424,351);
    glVertex2d(424,418);
    glVertex2d(405,406);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(405,339);
    glVertex2d(424,351);
    glVertex2d(424,418);
    glVertex2d(405,406);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(410,365);
    glVertex2d(410,342);
    glVertex2d(424,351);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(412,366);
    glVertex2d(424,354);
    glVertex2d(424,358);
    glVertex2d(414,368);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(403,363);
    glVertex2d(405,362);
    glVertex2d(424,374);
    glVertex2d(424,376);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(403,365);
    glVertex2d(403,363);
    glVertex2d(424,376);
    glVertex2d(424,378);

    glEnd();
}

void jendelaa2()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(458,447);
    glVertex2d(458,369);
    glVertex2d(485,386);
    glVertex2d(485,464);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(461,445);
    glVertex2d(461,374);
    glVertex2d(483,388);
    glVertex2d(483,459);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(464,443);
    glVertex2d(464,376);
    glVertex2d(483,388);
    glVertex2d(483,455);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(466,378);
    glVertex2d(483,388);
    glVertex2d(483,452);
    glVertex2d(466,442);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(469,379);
    glVertex2d(483,388);
    glVertex2d(469,402);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(471,403);
    glVertex2d(483,391);
    glVertex2d(483,395);
    glVertex2d(473,405);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(462,400);
    glVertex2d(464,399);
    glVertex2d(483,411);
    glVertex2d(483,413);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(462,402);
    glVertex2d(462,400);
    glVertex2d(483,413);
    glVertex2d(483,415);

    glEnd();
}

void jendelaa3()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(570,360);
    glVertex2d(597,343);
    glVertex2d(597,421);
    glVertex2d(570,438);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(573,362);
    glVertex2d(594,348);
    glVertex2d(594,419);
    glVertex2d(573,433);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(573,362);
    glVertex2d(591,350);
    glVertex2d(591,417);
    glVertex2d(573,429);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(573,362);
    glVertex2d(589,352);
    glVertex2d(589,416);
    glVertex2d(573,426);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(573,362);
    glVertex2d(587,353);
    glVertex2d(587,376);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(573,365);
    glVertex2d(584,377);
    glVertex2d(582,379);
    glVertex2d(573,369);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(573,385);
    glVertex2d(591,373);
    glVertex2d(593,374);
    glVertex2d(573,387);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(573,387);
    glVertex2d(593,374);
    glVertex2d(593,376);
    glVertex2d(573,389);

    glEnd();
}

void jendelaa4()
{
    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(631,327);
    glVertex2d(659,310);
    glVertex2d(659,388);
    glVertex2d(631,405);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(634,329);
    glVertex2d(656,315);
    glVertex2d(656,386);
    glVertex2d(634,400);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(634,329);
    glVertex2d(653,317);
    glVertex2d(653,384);
    glVertex2d(634,396);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(634,329);
    glVertex2d(650,319);
    glVertex2d(650,383);
    glVertex2d(634,393);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(634,329);
    glVertex2d(648,320);
    glVertex2d(648,343);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(634,332);
    glVertex2d(646,344);
    glVertex2d(644,344);
    glVertex2d(634,336);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(35,47,58);
    glVertex2d(634,352);
    glVertex2d(653,340);
    glVertex2d(655,341);
    glVertex2d(634,354);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(71,82,96);
    glVertex2d(634,354);
    glVertex2d(655,341);
    glVertex2d(655,343);
    glVertex2d(634,356);

    glEnd();
}

void jendelab1()
{
    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(183,369);
    glVertex2d(210,386);
    glVertex2d(210,464);
    glVertex2d(183,447);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(189,193,167);
    glVertex2d(186,374);
    glVertex2d(189,376);
    glVertex2d(189,443);
    glVertex2d(186,445);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(159,163,129);
    glVertex2d(186,445);
    glVertex2d(189,443);
    glVertex2d(208,455);
    glVertex2d(208,459);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(189,376);
    glVertex2d(208,388);
    glVertex2d(208,455);
    glVertex2d(189,443);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(191,378);
    glVertex2d(208,388);
    glVertex2d(208,452);
    glVertex2d(191,442);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(194,402);
    glVertex2d(194,379);
    glVertex2d(208,388);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(196,403);
    glVertex2d(208,391);
    glVertex2d(208,395);
    glVertex2d(198,405);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(189,193,167);
    glVertex2d(189,399);
    glVertex2d(208,411);
    glVertex2d(208,413);
    glVertex2d(187,400);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(187,402);
    glVertex2d(187,400);
    glVertex2d(208,413);
    glVertex2d(208,415);

    glEnd();
}

void jendelab2()
{
    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(231,399);
    glVertex2d(258,416);
    glVertex2d(258,494);
    glVertex2d(231,477);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(189,193,167);
    glVertex2d(234,404);
    glVertex2d(236,406);
    glVertex2d(236,473);
    glVertex2d(234,475);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(159,163,129);
    glVertex2d(234,475);
    glVertex2d(236,473);
    glVertex2d(255,485);
    glVertex2d(255,489);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,155,191);
    glVertex2d(236,406);
    glVertex2d(255,418);
    glVertex2d(255,485);
    glVertex2d(236,473);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(77,208,225);
    glVertex2d(239,408);
    glVertex2d(255,418);
    glVertex2d(255,482);
    glVertex2d(239,472);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(241,409);
    glVertex2d(255,418);
    glVertex2d(241,432);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(178,235,242);
    glVertex2d(243,433);
    glVertex2d(255,421);
    glVertex2d(255,425);
    glVertex2d(246,435);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(189,193,167);
    glVertex2d(235,430);
    glVertex2d(236,429);
    glVertex2d(255,441);
    glVertex2d(255,443);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(233,234,229);
    glVertex2d(235,432);
    glVertex2d(235,430);
    glVertex2d(255,443);
    glVertex2d(255,445);

    glEnd();
}

void jendelah1()
{
    glBegin(GL_POLYGON);

    glColor3ub(116,210,206);
    glVertex2d(581,537);
    glVertex2d(605,522);
    glVertex2d(613,526);
    glVertex2d(581,546);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(51,160,155);
    glVertex2d(605,477);
    glVertex2d(612,472);
    glVertex2d(613,526);
    glVertex2d(605,522);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(61,192,186);
    glVertex2d(580,492);
    glVertex2d(605,477);
    glVertex2d(605,522);
    glVertex2d(581,537);

    glEnd();

}

void jendelah2()
{
    glBegin(GL_POLYGON);

    glColor3ub(116,210,206);
    glVertex2d(626,509);
    glVertex2d(651,494);
    glVertex2d(658,498);
    glVertex2d(626,518);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(51,160,155);
    glVertex2d(650,449);
    glVertex2d(657,444);
    glVertex2d(658,498);
    glVertex2d(651,494);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(61,192,186);
    glVertex2d(626,464);
    glVertex2d(650,449);
    glVertex2d(651,494);
    glVertex2d(626,509);

    glEnd();
}

void lantai1()
{
    glBegin(GL_POLYGON);

    glColor3ub(232,232,232);
    glVertex2d(369,497);
    glVertex2d(387,489);
    glVertex2d(438,521);
    glVertex2d(420,530);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(199,199,199);
    glVertex2d(369,497);
    glVertex2d(418,529);
    glVertex2d(418,535);
    glVertex2d(369,503);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(153,153,153);
    glVertex2d(418,529);
    glVertex2d(438,519);
    glVertex2d(438,525);
    glVertex2d(418,535);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(207,216,220);
    glVertex2d(308,551);
    glVertex2d(377,508);
    glVertex2d(408,528);
    glVertex2d(340,572);

    glEnd();
}

void pagar()
{
    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(71,432);
    glVertex2d(79,424);
    glVertex2d(83,426);
    glVertex2d(76,434);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(71,432);
    glVertex2d(76,434);
    glVertex2d(75,502);
    glVertex2d(71,500);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(76,434);
    glVertex2d(83,426);
    glVertex2d(90,427);
    glVertex2d(90,495);
    glVertex2d(75,502);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(79,424);
    glVertex2d(83,426);
    glVertex2d(90,427);
    glVertex2d(86,425);

    glEnd();
    //1
    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(94,421);
    glVertex2d(102,413);
    glVertex2d(106,415);
    glVertex2d(98,423);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(94,421);
    glVertex2d(98,423);
    glVertex2d(98,491);
    glVertex2d(93,488);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(98,423);
    glVertex2d(106,415);
    glVertex2d(113,415);
    glVertex2d(112,483);
    glVertex2d(98,491);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(102,413);
    glVertex2d(106,415);
    glVertex2d(113,415);
    glVertex2d(109,413);

    glEnd();
    //2
    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(117,409);
    glVertex2d(124,401);
    glVertex2d(128,403);
    glVertex2d(121,412);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(117,409);
    glVertex2d(121,412);
    glVertex2d(120,479);
    glVertex2d(116,477);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(121,412);
    glVertex2d(128,403);
    glVertex2d(136,404);
    glVertex2d(135,472);
    glVertex2d(120,479);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(124,401);
    glVertex2d(132,402);
    glVertex2d(136,404);
    glVertex2d(128,403);

    glEnd();
    //3
    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(139,398);
    glVertex2d(147,390);
    glVertex2d(151,392);
    glVertex2d(144,400);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(183,26,26);
    glVertex2d(139,398);
    glVertex2d(144,400);
    glVertex2d(143,468);
    glVertex2d(139,465);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(144,400);
    glVertex2d(151,392);
    glVertex2d(158,393);
    glVertex2d(158,460);
    glVertex2d(143,468);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(147,390);
    glVertex2d(154,390);
    glVertex2d(158,393);
    glVertex2d(151,392);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(69,455);
    glVertex2d(162,408);
    glVertex2d(162,415);
    glVertex2d(68,463);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(165,8,8);
    glVertex2d(68,490);
    glVertex2d(162,442);
    glVertex2d(162,450);
    glVertex2d(68,497);

    glEnd();
}

void sampah()
{
    glBegin(GL_POLYGON);

    glColor3ub(209,211,212);
    glVertex2d(84,468);
    glVertex2d(103,479);
    glVertex2d(103,515);
    glVertex2d(89,507);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(188,190,192);
    glVertex2d(103,479);
    glVertex2d(121,468);
    glVertex2d(115,508);
    glVertex2d(103,515);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(230,231,232);
    glVertex2d(84,468);
    glVertex2d(104,459);
    glVertex2d(121,468);
    glVertex2d(103,479);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(88,89,91);
    glVertex2d(87,468);
    glVertex2d(103,461);
    glVertex2d(118,468);
    glVertex2d(103,477);

    glEnd();
}

void bangku()
{
    glBegin(GL_POLYGON);

    glColor3ub(138,68,27);
    glVertex2d(180,425);
    glVertex2d(186,429);
    glVertex2d(186,471);
    glVertex2d(180,468);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(185,429);
    glVertex2d(188,428);
    glVertex2d(188,470);
    glVertex2d(186,471);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(180,425);
    glVertex2d(182,424);
    glVertex2d(188,428);
    glVertex2d(186,429);

    glEnd();
    //1
    glBegin(GL_POLYGON);

    glColor3ub(138,68,27);
    glVertex2d(240,462);
    glVertex2d(246,465);
    glVertex2d(246,506);
    glVertex2d(240,502);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(246,465);
    glVertex2d(248,464);
    glVertex2d(248,504);
    glVertex2d(246,506);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(240,462);
    glVertex2d(242,460);
    glVertex2d(248,464);
    glVertex2d(246,465);

    glEnd();
    //2
    glBegin(GL_POLYGON);

    glColor3ub(138,68,27);
    glVertex2d(174,428);
    glVertex2d(251,475);
    glVertex2d(251,496);
    glVertex2d(174,449);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(174,428);
    glVertex2d(176,427);
    glVertex2d(253,474);
    glVertex2d(251,475);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(251,475);
    glVertex2d(253,474);
    glVertex2d(253,494);
    glVertex2d(251,496);

    glEnd();
    //3
    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(238,503);
    glVertex2d(241,504);
    glVertex2d(241,516);
    glVertex2d(238,514);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(241,504);
    glVertex2d(245,502);
    glVertex2d(245,514);
    glVertex2d(241,516);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(238,503);
    glVertex2d(242,501);
    glVertex2d(245,502);
    glVertex2d(241,504);

    glEnd();
    //4
    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(159,471);
    glVertex2d(161,472);
    glVertex2d(161,487);
    glVertex2d(159,485);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(161,472);
    glVertex2d(165,470);
    glVertex2d(165,485);
    glVertex2d(161,487);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(159,471);
    glVertex2d(162,468);
    glVertex2d(165,470);
    glVertex2d(161,472);

    glEnd();
    //5
    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(222,506);
    glVertex2d(225,508);
    glVertex2d(225,526);
    glVertex2d(222,524);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(100,49,20);
    glVertex2d(225,508);
    glVertex2d(229,506);
    glVertex2d(229,523);
    glVertex2d(225,526);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(136,67,27);
    glVertex2d(222,506);
    glVertex2d(226,504);
    glVertex2d(229,506);
    glVertex2d(225,508);

    glEnd();
    //6
    glBegin(GL_POLYGON);

    glColor3ub(158,79,31);
    glVertex2d(222,506);
    glVertex2d(225,508);
    glVertex2d(225,526);
    glVertex2d(222,524);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(122,60,24);
    glVertex2d(225,508);
    glVertex2d(229,506);
    glVertex2d(229,523);
    glVertex2d(225,526);

    glEnd();
    //1
    glBegin(GL_POLYGON);

    glColor3ub(85,42,17);
    glVertex2d(168,461);
    glVertex2d(245,508);
    glVertex2d(245,511);
    glVertex2d(168,464);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(158,79,31);
    glVertex2d(168,461);
    glVertex2d(174,458);
    glVertex2d(251,505);
    glVertex2d(245,508);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(122,60,24);
    glVertex2d(245,508);
    glVertex2d(251,505);
    glVertex2d(251,507);
    glVertex2d(245,511);

    glEnd();
    //2
     glBegin(GL_POLYGON);

    glColor3ub(85,42,17);
    glVertex2d(162,468);
    glVertex2d(162,465);
    glVertex2d(238,512);
    glVertex2d(238,515);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,79,31);
    glVertex2d(168,462);
    glVertex2d(245,508);
    glVertex2d(238,512);
    glVertex2d(162,465);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(122,60,24);
    glVertex2d(238,512);
    glVertex2d(245,508);
    glVertex2d(245,511);
    glVertex2d(238,515);

    glEnd();
    //3
    glBegin(GL_POLYGON);

    glColor3ub(85,42,17);
    glVertex2d(155,472);
    glVertex2d(155,469);
    glVertex2d(232,516);
    glVertex2d(232,519);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(158,79,31);
    glVertex2d(155,469);
    glVertex2d(161,466);
    glVertex2d(238,512);
    glVertex2d(232,516);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(122,60,24);
    glVertex2d(232,516);
    glVertex2d(238,512);
    glVertex2d(238,515);
    glVertex2d(232,519);

    glEnd();
}

void panah()
{
    glBegin(GL_POLYGON);

    glColor3ub(209,211,212);
    glVertex2d(191,576);
    glVertex2d(218,560);
    glVertex2d(244,576);
    glVertex2d(218,591);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(188,190,192);
    glVertex2d(191,576);
    glVertex2d(218,591);
    glVertex2d(218,596);
    glVertex2d(191,581);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(147,149,152);
    glVertex2d(218,591);
    glVertex2d(244,576);
    glVertex2d(244,581);
    glVertex2d(218,596);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(147,149,152);
    glVertex2d(216,479);
    glVertex2d(223,479);
    glVertex2d(223,575);
    glVertex2d(216,575);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(109,110,113);
    glVertex2d(223,479);
    glVertex2d(223,575);
    glVertex2d(218,576);
    glVertex2d(220,477);

    glEnd();
    //biru
    glBegin(GL_POLYGON);

    glColor3ub(0,161,142);
    glVertex2d(203,502);
    glVertex2d(204,503);
    glVertex2d(204,512);
    glVertex2d(203,511);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(0,174,158);
    glVertex2d(203,502);
    glVertex2d(234,482);
    glVertex2d(236,483);
    glVertex2d(204,503);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(96,197,186);
    glVertex2d(204,503);
    glVertex2d(236,483);
    glVertex2d(242,483);
    glVertex2d(236,492);
    glVertex2d(204,512);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(143,210,202);
    glVertex2d(234,482);
    glVertex2d(241,482);
    glVertex2d(242,483);
    glVertex2d(236,483);

    glEnd();
    //pink
    glBegin(GL_POLYGON);

    glColor3ub(198,0,111);
    glVertex2d(203,518);
    glVertex2d(204,519);
    glVertex2d(204,528);
    glVertex2d(203,527);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(238,128,179);
    glVertex2d(203,518);
    glVertex2d(234,498);
    glVertex2d(236,499);
    glVertex2d(204,519);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(235,83,158);
    glVertex2d(204,519);
    glVertex2d(236,499);
    glVertex2d(242,499);
    glVertex2d(236,508);
    glVertex2d(204,528);
    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(245,162,198);
    glVertex2d(234,498);
    glVertex2d(241,498);
    glVertex2d(242,499);
    glVertex2d(236,499);

    glEnd();
}

void kolam()
{
    glBegin(GL_POLYGON);

    glColor3ub(171,173,176);
    glVertex2d(299,623);
    glVertex2d(350,653);
    glVertex2d(402,692);
    glVertex2d(299,622);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(212,216,219);
    glVertex2d(402,688);
    glVertex2d(534,605);
    glVertex2d(534,608);
    glVertex2d(402,692);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(237,244,249);
    glVertex2d(299,623);
    glVertex2d(430,540);
    glVertex2d(534,605);
    glVertex2d(402,688);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(171,173,176);
    glVertex2d(316,623);
    glVertex2d(430,551);
    glVertex2d(430,553);
    glVertex2d(318,624);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(212,216,219);
    glVertex2d(430,553);
    glVertex2d(430,551);
    glVertex2d(516,605);
    glVertex2d(514,606);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(3,235,255);
    glVertex2d(316,623);
    glVertex2d(430,551);
    glColor3ub(5,5,224);
    glVertex2d(516,605);
    glVertex2d(402,677);

    glEnd();
}

void pohongede()
{
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(712,421);
    glVertex2d(719,422);
    glVertex2d(719,501);
    glVertex2d(712,501);

    glEnd();

    //1
    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(661,424);
    glVertex2d(685,435);
    glVertex2d(685,459);
    glVertex2d(661,447);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(685,435);
    glVertex2d(709,423);
    glVertex2d(709,447);
    glVertex2d(685,459);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(661,424);
    glVertex2d(686,412);
    glVertex2d(709,423);
    glVertex2d(685,435);

    glEnd();
    //batang
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(699,439);
    glVertex2d(732,456);
    glVertex2d(732,460);
    glVertex2d(698,442);

    glEnd();
    //2
    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(679,379);
    glVertex2d(715,397);
    glVertex2d(715,432);
    glVertex2d(679,415);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(715,397);
    glVertex2d(751,379);
    glVertex2d(751,414);
    glVertex2d(715,432);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(679,379);
    glVertex2d(716,362);
    glVertex2d(751,379);
    glVertex2d(715,397);

    glEnd();
    //3
    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(712,466);
    glVertex2d(712,438);
    glVertex2d(740,452);
    glVertex2d(740,480);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(740,452);
    glVertex2d(770,437);
    glVertex2d(770,466);
    glVertex2d(740,480);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(712,438);
    glVertex2d(741,423);
    glVertex2d(770,437);
    glVertex2d(740,452);

    glEnd();
}

void pohon1()
{
glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(698,488);
    glVertex2d(699,521);
    glVertex2d(696,522);
    glVertex2d(696,488);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(683,492);
    glVertex2d(697,499);
    glVertex2d(697,514);
    glVertex2d(683,507);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(697,499);
    glVertex2d(711,491);
    glVertex2d(712,506);
    glVertex2d(697,514);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(683,492);
    glVertex2d(697,484);
    glVertex2d(711,491);
    glVertex2d(697,499);

    glEnd();
    //1
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(672,503);
    glVertex2d(673,536);
    glVertex2d(670,536);
    glVertex2d(669,503);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(657,522);
    glVertex2d(657,507);
    glVertex2d(671,514);
    glVertex2d(671,529);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(671,529);
    glVertex2d(671,514);
    glVertex2d(685,506);
    glVertex2d(685,521);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(657,507);
    glVertex2d(671,499);
    glVertex2d(685,506);
    glVertex2d(671,514);

    glEnd();
    //2
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(645,521);
    glVertex2d(646,555);
    glVertex2d(643,554);
    glVertex2d(642,521);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(630,525);
    glVertex2d(644,532);
    glVertex2d(644,547);
    glVertex2d(630,540);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(644,532);
    glVertex2d(658,524);
    glVertex2d(658,539);
    glVertex2d(644,547);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(630,525);
    glVertex2d(644,517);
    glVertex2d(658,524);
    glVertex2d(644,532);

    glEnd();
}

void pohon2()
{
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(620,538);
    glVertex2d(621,571);
    glVertex2d(618,571);
    glVertex2d(617,538);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(604,542);
    glVertex2d(618,549);
    glVertex2d(619,564);
    glVertex2d(605,557);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(618,549);
    glVertex2d(632,541);
    glVertex2d(633,555);
    glVertex2d(619,564);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(604,542);
    glVertex2d(618,534);
    glVertex2d(632,541);
    glVertex2d(618,549);

    glEnd();
    //4
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(592,553);
    glVertex2d(593,587);
    glVertex2d(590,587);
    glVertex2d(589,553);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(576,558);
    glVertex2d(590,564);
    glVertex2d(591,579);
    glVertex2d(577,572);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(590,564);
    glVertex2d(604,556);
    glVertex2d(605,571);
    glVertex2d(591,579);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(576,558);
    glVertex2d(590,549);
    glVertex2d(604,556);
    glVertex2d(590,564);

    glEnd();
    //5
    glBegin(GL_POLYGON);

    glColor3ub(137,86,33);
    glVertex2d(564,570);
    glVertex2d(565,603);
    glVertex2d(562,603);
    glVertex2d(561,570);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(114,149,26);
    glVertex2d(548,574);
    glVertex2d(562,580);
    glVertex2d(563,595);
    glVertex2d(549,589);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(173,210,79);
    glVertex2d(562,580);
    glVertex2d(576,572);
    glVertex2d(577,587);
    glVertex2d(563,595);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(152,199,35);
    glVertex2d(548,574);
    glVertex2d(562,566);
    glVertex2d(576,572);
    glVertex2d(562,580);

    glEnd();
}

void awan1()
{
    //1
    glBegin(GL_POLYGON);
    glColor3ub(209,211,212);
    glVertex2d(84,468);
    glVertex2d(103,479);
    glVertex2d(103,515);
    glVertex2d(89,507);
    glEnd();
    //2
    glBegin(GL_POLYGON);
    glColor3ub(188,190,192);
    glVertex2d(103,479);
    glVertex2d(121,468);
    glVertex2d(115,508);
    glVertex2d(103,515);
    glEnd();
    //3
    glBegin(GL_POLYGON);

    glColor3ub(230,231,232);
    glVertex2d(84,468);
    glVertex2d(104,459);
    glVertex2d(121,468);
    glVertex2d(103,479);

    glEnd();

    glBegin(GL_POLYGON);

    glColor3ub(88,89,91);
    glVertex2d(87,468);
    glVertex2d(103,461);
    glVertex2d(118,468);
    glVertex2d(103,477);

    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    if (!glfwInit()) exit(EXIT_FAILURE);

    window = glfwCreateWindow(800, 800, "Annisa Monitha - <G64160028>", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);

    while (!glfwWindowShouldClose(window))
    {
        if(buff==0){
            clindex++;
        }
        buff++;
        buff=buff%100;

        setup_viewport(window);

        display();

        Background();
        tanah1();
        tanah2();
        tanah3();
        bayangan();
        ruang1();
        pintu();
        ruang2();
        ruang12();
        ruang13();
        jendelapintu1();
        jendelapintu2();
        atap();
        cerobong();
        jendelapanjang();\
        jendelaa1();
        jendelaa2();
        jendelaa3();
        jendelaa4();
        jendelab1();
        jendelab2();
        jendelah1();
        jendelah2();
        lantai1();
        pagar();
        sampah();
        bangku();
        panah();
        kolam();
        pohongede();
        pohon1();
        pohon2();
        awan1();
        //v2();


        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
