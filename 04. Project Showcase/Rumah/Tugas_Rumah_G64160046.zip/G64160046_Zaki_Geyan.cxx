// g++ -Wall -o "G64160046_Zaki_Geyan" "G64160046_Zaki_Geyan.cxx" -lglfw3 -lGL -lX11 -lXi -lXrandr -lXxf86vm -lXinerama -lXcursor -lrt -lm -pthread
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
static void error_callback(int error, const char* description)
{
    fputs(description, stderr);
}
static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
}

void latar() {
    glBegin(GL_POLYGON);
        glColor3ub(0x4d, 0xd0, 0xe1);
        glVertex2d(-111, 0);
        glVertex2d(1111, 0);
        glVertex2d(1111, 1000);
        glVertex2d(-111, 1000);
    glEnd();
}

void tanah() {
    glBegin(GL_POLYGON);
        glColor3ub(157, 216, 100);
        glVertex2d(500.0, 379.5);
        glVertex2d(925.34, 625.06);
        glVertex2d(500.0, 870.64);
        glVertex2d(74.66, 625.06);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(197, 249, 147);
        glVertex2d(74.66, 625.06);
        glVertex2d(74.66, 636.12);
        glVertex2d(500.0, 881.7);
        glVertex2d(500.0, 870.64);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(97, 147, 63);
        glVertex2d(500.0, 881.7);
        glVertex2d(500.0, 870.64);
        glVertex2d(925.34, 625.06);
        glVertex2d(925.34, 636.12);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(250, 179, 122);
        glVertex2d(74.66, 636.12);
        glVertex2d(74.66, 665.6);
        glVertex2d(500.0, 911.16);
        glVertex2d(500.0, 881.7);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(135, 73, 31);
        glVertex2d(500.0, 911.16);
        glVertex2d(500.0, 881.7);
        glVertex2d(925.34, 636.12);
        glVertex2d(925.34, 665.6);
    glEnd();
}

void jalan() {
    glBegin(GL_POLYGON);
        glColor3ub(220, 234, 239);
        glVertex2d(485.26, 614.94);
        glVertex2d(270.88, 738.36);
        glVertex2d(333.1, 774.28);
        glVertex2d(547.7, 650.74);
    glEnd();
}

void bayangan() {
    glBegin(GL_POLYGON);
        glColor3ub(113, 163, 79);
        glVertex2d(925.34, 625.06);
        glVertex2d(848.1, 580.46);
        glVertex2d(427.78, 580.46);
        glVertex2d(684.54, 729.74);
        glVertex2d(744.04, 729.74);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(113, 163, 79);
        glVertex2d(427.78, 580.46);
        glVertex2d(480.36, 608.7);
        glVertex2d(391.26, 661.32);
        glVertex2d(347.74, 661.32);
    glEnd();
}

void lantai_1() {
    glBegin(GL_POLYGON);
        glColor3ub(48, 60, 73);
        glVertex2d(485.66, 295.22);
        glVertex2d(861.7, 512.32);
        glVertex2d(684.54, 614.66);
        glVertex2d(308.46, 397.54);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(308.46, 397.54);
        glVertex2d(684.54, 614.66);
        glVertex2d(684.54, 729.74);
        glVertex2d(308.46, 512.62);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(684.54, 614.66);
        glVertex2d(684.54, 729.74);
        glVertex2d(861.7, 627.4);
        glVertex2d(861.7, 512.32);
    glEnd();
}

void pintu() {
    glBegin(GL_POLYGON);
        glColor3ub(240, 245, 247);
        glVertex2d(485.06, 481.4);
        glVertex2d(548.86, 518.18);
        glVertex2d(548.86, 651.34);
        glVertex2d(485.06, 614.56);
    glEnd();
}

void jendela_di_pintu_1() {
    glBegin(GL_POLYGON);
        glColor3ub(128, 172, 183);
        glVertex2d(493.46, 505.04);
        glVertex2d(496.04, 506.54);
        glVertex2d(496.04, 531.24);
        glVertex2d(493.44, 532.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(191, 215, 221);
        glVertex2d(496.04, 531.24);
        glVertex2d(513.4, 541.26);
        glVertex2d(513.4, 544.24);
        glVertex2d(493.44, 532.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(496.04, 506.54);
        glVertex2d(498.62, 508.02);
        glVertex2d(498.62, 529.74);
        glVertex2d(496.04, 531.24);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(498.62, 529.74);
        glVertex2d(513.4, 538.28);
        glVertex2d(513.4, 541.26);
        glVertex2d(496.04, 531.24);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(498.62, 508.02);
        glVertex2d(513.4, 516.56);
        glVertex2d(513.4, 538.28);
        glVertex2d(498.62, 529.74);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(500.58, 509.16);
        glVertex2d(513.4, 516.56);
        glVertex2d(500.56, 528.54);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(513.4, 519.44);
        glVertex2d(513.4, 522.42);
        glVertex2d(504.38, 530.74);
        glVertex2d(502.46, 529.64);
    glEnd();
}

void jendela_di_pintu_2() {
    glBegin(GL_POLYGON);
        glColor3ub(128, 172, 183);
        glVertex2d(520.52, 520.68);
        glVertex2d(523.1, 522.18);
        glVertex2d(523.1, 546.88);
        glVertex2d(520.5, 548.36);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(191, 215, 221);
        glVertex2d(523.1, 546.88);
        glVertex2d(540.46, 556.9);
        glVertex2d(540.46, 559.88);
        glVertex2d(520.5, 548.36);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(523.1, 522.18);
        glVertex2d(525.68, 523.66);
        glVertex2d(525.68, 545.38);
        glVertex2d(523.1, 546.88);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(525.68, 545.38);
        glVertex2d(540.46, 553.92);
        glVertex2d(540.46, 556.9);
        glVertex2d(523.1, 546.88);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(525.68, 523.66);
        glVertex2d(540.46, 532.2);
        glVertex2d(540.46, 553.92);
        glVertex2d(525.68, 545.38);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(527.64, 524.8);
        glVertex2d(540.46, 532.2);
        glVertex2d(527.62, 544.18);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(540.46, 535.08);
        glVertex2d(540.46, 538.06);
        glVertex2d(531.44, 546.38);
        glVertex2d(529.52, 545.28);
    glEnd();
}

void jendela_di_pintu_3() {
    glBegin(GL_POLYGON);
        glColor3ub(128, 172, 183);
        glVertex2d(493.46, 541.26);
        glVertex2d(496.04, 542.76);
        glVertex2d(496.04, 567.46);
        glVertex2d(493.44, 568.94);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(191, 215, 221);
        glVertex2d(496.04, 567.46);
        glVertex2d(513.4, 577.48);
        glVertex2d(513.4, 580.46);
        glVertex2d(493.44, 568.94);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(496.04, 542.76);
        glVertex2d(498.62, 544.24);
        glVertex2d(498.62, 565.96);
        glVertex2d(496.04, 567.46);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(498.62, 565.96);
        glVertex2d(513.4, 574.5);
        glVertex2d(513.4, 577.48);
        glVertex2d(496.04, 567.46);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(498.62, 544.24);
        glVertex2d(513.4, 552.78);
        glVertex2d(513.4, 574.5);
        glVertex2d(498.62, 565.96);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(500.58, 545.38);
        glVertex2d(513.4, 552.78);
        glVertex2d(500.56, 564.76);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(513.4, 555.66);
        glVertex2d(513.4, 558.64);
        glVertex2d(504.38, 566.96);
        glVertex2d(502.46, 565.86);
    glEnd();
}

void jendela_di_pintu_4() {
    glBegin(GL_POLYGON);
        glColor3ub(128, 172, 183);
        glVertex2d(520.52, 556.9);
        glVertex2d(523.1, 558.4);
        glVertex2d(523.1, 583.1);
        glVertex2d(520.5, 584.58);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(191, 215, 221);
        glVertex2d(523.1, 583.1);
        glVertex2d(540.46, 593.12);
        glVertex2d(540.46, 596.1);
        glVertex2d(520.5, 584.58);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(523.1, 558.4);
        glVertex2d(525.68, 559.88);
        glVertex2d(525.68, 581.6);
        glVertex2d(523.1, 583.1);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(525.68, 581.6);
        glVertex2d(540.46, 590.14);
        glVertex2d(540.46, 593.12);
        glVertex2d(523.1, 583.1);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(525.68, 559.88);
        glVertex2d(540.46, 568.42);
        glVertex2d(540.46, 590.14);
        glVertex2d(525.68, 581.6);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(527.64, 561.02);
        glVertex2d(540.46, 568.42);
        glVertex2d(527.62, 580.4);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(540.46, 571.3);
        glVertex2d(540.46, 574.28);
        glVertex2d(531.44, 582.6);
        glVertex2d(529.52, 581.5);
    glEnd();
}

void jendela_lantai_1_1() {
    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(572.46, 540.08);
        glVertex2d(607.2, 560.12);
        glVertex2d(607.2, 650.9);
        glVertex2d(572.46, 630.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(576.04, 546.26);
        glVertex2d(579.62, 548.32);
        glVertex2d(579.62, 626.72);
        glVertex2d(576.04, 628.78);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(579.62, 626.72);
        glVertex2d(603.62, 640.58);
        glVertex2d(603.62, 644.7);
        glVertex2d(576.04, 628.78);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(579.62, 548.32);
        glVertex2d(583.18, 550.38);
        glVertex2d(583.18, 624.66);
        glVertex2d(579.62, 626.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(583.18, 624.66);
        glVertex2d(603.62, 636.46);
        glVertex2d(603.62, 640.58);
        glVertex2d(579.62, 626.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(583.18, 550.38);
        glVertex2d(603.62, 562.18);
        glVertex2d(603.62, 636.46);
        glVertex2d(583.18, 624.66);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(585.88, 551.94);
        glVertex2d(603.62, 562.18);
        glVertex2d(585.88, 578.76);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(603.62, 566.16);
        glVertex2d(603.62, 570.3);
        glVertex2d(591.14, 581.78);
        glVertex2d(588.52, 580.26);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(577.46, 576.36);
        glVertex2d(603.62, 591.46);
        glVertex2d(603.62, 593.66);
        glVertex2d(577.46, 578.56);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(579.62, 575.14);
        glVertex2d(603.62, 589.0);
        glVertex2d(603.62, 591.46);
        glVertex2d(577.46, 576.36);
    glEnd();
}

void jendela_lantai_1_2() {
    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(628.54, 572.26);
        glVertex2d(663.28, 592.3);
        glVertex2d(663.28, 683.08);
        glVertex2d(628.54, 663.02);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(632.12, 578.44);
        glVertex2d(635.7, 580.5);
        glVertex2d(635.7, 658.9);
        glVertex2d(632.12, 660.96);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(635.7, 658.9);
        glVertex2d(659.7, 672.76);
        glVertex2d(659.7, 676.88);
        glVertex2d(632.12, 660.96);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(635.7, 580.5);
        glVertex2d(639.26, 582.56);
        glVertex2d(639.26, 656.84);
        glVertex2d(635.7, 658.9);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(639.26, 656.84);
        glVertex2d(659.7, 668.64);
        glVertex2d(659.7, 672.76);
        glVertex2d(635.7, 658.9);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(639.26, 582.56);
        glVertex2d(659.7, 594.36);
        glVertex2d(659.7, 668.64);
        glVertex2d(639.26, 656.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(641.96, 584.12);
        glVertex2d(659.7, 594.36);
        glVertex2d(641.96, 610.94);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(659.7, 598.34);
        glVertex2d(659.7, 602.48);
        glVertex2d(647.22, 613.96);
        glVertex2d(644.6, 612.44);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(633.54, 608.54);
        glVertex2d(659.7, 623.64);
        glVertex2d(659.7, 625.84);
        glVertex2d(633.54, 610.74);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(635.7, 607.32);
        glVertex2d(659.7, 621.18);
        glVertex2d(659.7, 623.64);
        glVertex2d(633.54, 608.54);
    glEnd();
}

void lantai_2() {
    glBegin(GL_POLYGON);
        glColor3ub(217, 221, 199);
        glVertex2d(485.66, 117.84);
        glVertex2d(861.7, 334.94);
        glVertex2d(658.06, 492.72);
        glVertex2d(281.98, 275.6);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(281.98, 275.6);
        glVertex2d(658.06, 492.72);
        glVertex2d(658.06, 629.9);
        glVertex2d(281.98, 412.78);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(658.06, 492.72);
        glVertex2d(658.06, 629.9);
        glVertex2d(861.7, 512.32);
        glVertex2d(861.7, 334.94);
    glEnd();
}

void jendela_tidur() {
    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(304.66, 325.38);
        glVertex2d(434.42, 399.54);
        glVertex2d(434.42, 445.04);
        glVertex2d(304.6, 370.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(308.68, 332.3);
        glVertex2d(430.4, 401.86);
        glVertex2d(430.4, 438.1);
        glVertex2d(308.62, 368.5);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(312.68, 334.58);
        glVertex2d(430.4, 401.86);
        glVertex2d(430.4, 433.46);
        glVertex2d(312.64, 366.16);
    glEnd();

    glBegin(GL_POLYGON);glColor3ub(77, 208, 225);
        glVertex2d(316.7, 336.88);
        glVertex2d(430.4, 401.86);
        glVertex2d(430.4, 428.82);
        glVertex2d(316.66, 363.82);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(322.38, 340.06);
        glVertex2d(430.4, 401.86);
        glVertex2d(414.76, 416.46);
        glVertex2d(322.38, 363.54);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(430.4, 405.36);
        glVertex2d(430.4, 409.0);
        glVertex2d(419.4, 419.14);
        glVertex2d(417.08, 417.8);
    glEnd();
}

void jendela_lantai_2_1() {
    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(499.6, 431.44);
        glVertex2d(534.34, 451.48);
        glVertex2d(534.34, 542.26);
        glVertex2d(499.6, 522.2);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(503.18, 437.62);
        glVertex2d(506.76, 439.68);
        glVertex2d(506.76, 518.08);
        glVertex2d(503.18, 520.14);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(506.76, 518.08);
        glVertex2d(530.76, 531.94);
        glVertex2d(530.76, 536.06);
        glVertex2d(503.18, 520.14);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(506.76, 439.68);
        glVertex2d(510.32, 441.74);
        glVertex2d(510.32, 516.02);
        glVertex2d(506.76, 518.08);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(510.32, 516.02);
        glVertex2d(530.76, 527.82);
        glVertex2d(530.76, 531.94);
        glVertex2d(506.76, 518.08);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(510.32, 441.74);
        glVertex2d(530.76, 453.54);
        glVertex2d(530.76, 527.82);
        glVertex2d(510.32, 516.02);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(513.02, 443.3);
        glVertex2d(530.76, 453.54);
        glVertex2d(513.02, 470.12);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(530.76, 457.52);
        glVertex2d(530.76, 461.66);
        glVertex2d(518.28, 473.14);
        glVertex2d(515.66, 471.62);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(504.6, 467.72);
        glVertex2d(530.76, 482.82);
        glVertex2d(530.76, 485.02);
        glVertex2d(504.6, 469.92);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(506.76, 466.5);
        glVertex2d(530.76, 480.36);
        glVertex2d(530.76, 482.82);
        glVertex2d(504.6, 467.72);
    glEnd();
}

void jendela_lantai_2_2() {
    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(573.94, 474.34);
        glVertex2d(608.68, 494.38);
        glVertex2d(608.68, 585.16);
        glVertex2d(573.94, 565.1);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(577.52, 480.52);
        glVertex2d(581.1, 482.58);
        glVertex2d(581.1, 560.98);
        glVertex2d(577.52, 563.04);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(581.1, 560.98);
        glVertex2d(605.1, 574.84);
        glVertex2d(605.1, 578.96);
        glVertex2d(577.52, 563.04);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(581.1, 482.58);
        glVertex2d(584.66, 484.64);
        glVertex2d(584.66, 558.92);
        glVertex2d(581.1, 560.98);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(584.66, 558.92);
        glVertex2d(605.1, 570.72);
        glVertex2d(605.1, 574.84);
        glVertex2d(581.1, 560.98);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(584.66, 484.64);
        glVertex2d(605.1, 496.44);
        glVertex2d(605.1, 570.72);
        glVertex2d(584.66, 558.92);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(587.36, 486.2);
        glVertex2d(605.1, 496.44);
        glVertex2d(587.36, 513.02);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(605.1, 500.42);
        glVertex2d(605.1, 504.56);
        glVertex2d(592.62, 516.04);
        glVertex2d(590.0, 514.52);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(578.94, 510.62);
        glVertex2d(605.1, 525.72);
        glVertex2d(605.1, 527.92);
        glVertex2d(578.94, 512.82);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(581.1, 509.4);
        glVertex2d(605.1, 523.26);
        glVertex2d(605.1, 525.72);
        glVertex2d(578.94, 510.62);
    glEnd();
}

void kamar() {
    glBegin(GL_POLYGON);
        glColor3ub(48, 60, 73);
        glVertex2d(281.92, 382.32);
        glVertex2d(430.4, 467.88);
        glVertex2d(347.74, 515.58);
        glVertex2d(199.2, 429.98);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(199.2, 429.98);
        glVertex2d(347.74, 515.58);
        glVertex2d(347.74, 661.32);
        glVertex2d(199.2, 575.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(347.74, 515.58);
        glVertex2d(347.74, 661.32);
        glVertex2d(457.0, 598.22);
        glVertex2d(457.0, 513.82);
        glVertex2d(430.4, 498.5);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(430.4, 498.5);
        glVertex2d(430.4, 467.88);
        glVertex2d(347.74, 515.58);
        glVertex2d(347.74, 661.32);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(219.32, 430.74);
        glVertex2d(226.16, 434.68);
        glVertex2d(281.92, 402.54);
        glVertex2d(281.92, 394.66);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(281.92, 402.54);
        glVertex2d(281.92, 394.66);
        glVertex2d(410.28, 468.64);
        glVertex2d(403.46, 472.58);
    glEnd();
}

void jendela_kamar_1() {
    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(225.8, 474.36);
        glVertex2d(260.54, 494.4);
        glVertex2d(260.54, 585.18);
        glVertex2d(225.8, 565.12);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(229.38, 480.54);
        glVertex2d(232.96, 482.6);
        glVertex2d(232.96, 561.0);
        glVertex2d(229.38, 563.06);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(232.96, 561.0);
        glVertex2d(256.96, 574.86);
        glVertex2d(256.96, 578.98);
        glVertex2d(229.38, 563.06);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(232.96, 482.6);
        glVertex2d(236.52, 484.66);
        glVertex2d(236.52, 558.94);
        glVertex2d(232.96, 561.0);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(236.52, 558.94);
        glVertex2d(256.96, 570.74);
        glVertex2d(256.96, 574.86);
        glVertex2d(232.96, 561.0);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(236.52, 484.66);
        glVertex2d(256.96, 496.46);
        glVertex2d(256.96, 570.74);
        glVertex2d(236.52, 558.94);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(239.22, 486.22);
        glVertex2d(256.96, 496.46);
        glVertex2d(239.22, 513.04);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(256.96, 500.44);
        glVertex2d(256.96, 504.58);
        glVertex2d(244.48, 516.06);
        glVertex2d(241.86, 514.54);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(230.8, 510.64);
        glVertex2d(256.96, 525.74);
        glVertex2d(256.96, 527.94);
        glVertex2d(230.8, 512.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(232.96, 509.42);
        glVertex2d(256.96, 523.28);
        glVertex2d(256.96, 525.74);
        glVertex2d(230.8, 510.64);
    glEnd();
}

void jendela_kamar_2() {
    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(286.42, 509.14);
        glVertex2d(321.16, 529.18);
        glVertex2d(321.16, 619.96);
        glVertex2d(286.42, 599.9);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(290.0, 515.32);
        glVertex2d(293.58, 517.38);
        glVertex2d(293.58, 595.78);
        glVertex2d(290.0, 597.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(159, 163, 129);
        glVertex2d(293.58, 595.78);
        glVertex2d(317.58, 609.64);
        glVertex2d(317.58, 613.76);
        glVertex2d(290.0, 597.84);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(293.58, 517.38);
        glVertex2d(297.14, 519.44);
        glVertex2d(297.14, 593.72);
        glVertex2d(293.58, 595.78);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(0, 155, 191);
        glVertex2d(297.14, 593.72);
        glVertex2d(317.58, 605.52);
        glVertex2d(317.58, 609.64);
        glVertex2d(293.58, 595.78);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(77, 208, 225);
        glVertex2d(297.14, 519.44);
        glVertex2d(317.58, 531.24);
        glVertex2d(317.58, 605.52);
        glVertex2d(297.14, 593.72);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(299.84, 521.0);
        glVertex2d(317.58, 531.24);
        glVertex2d(299.84, 547.82);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(178, 235, 242);
        glVertex2d(317.58, 535.22);
        glVertex2d(317.58, 539.36);
        glVertex2d(305.1, 550.84);
        glVertex2d(302.48, 549.32);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(233, 234, 229);
        glVertex2d(291.42, 545.42);
        glVertex2d(317.58, 560.52);
        glVertex2d(317.58, 562.72);
        glVertex2d(291.42, 547.62);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(189, 193, 167);
        glVertex2d(293.58, 544.2);
        glVertex2d(317.58, 558.06);
        glVertex2d(317.58, 560.52);
        glVertex2d(291.42, 545.42);
    glEnd();
}

void atap() {
    glBegin(GL_POLYGON);
        glColor3ub(48, 60, 73);
        glVertex2d(485.66, 109.14);
        glVertex2d(861.7, 326.24);
        glVertex2d(645.04, 494.1);
        glVertex2d(268.96, 276.96);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(71, 82, 96);
        glVertex2d(268.96, 276.96);
        glVertex2d(645.04, 494.1);
        glVertex2d(645.04, 502.8);
        glVertex2d(268.96, 285.68);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3ub(35, 47, 58);
        glVertex2d(645.04, 494.1);
        glVertex2d(645.04, 502.8);
        glVertex2d(861.7, 334.94);
        glVertex2d(861.7, 326.24);
    glEnd();
}

int main(void)
{
    GLFWwindow* window;
    glfwSetErrorCallback(error_callback);
    if (!glfwInit())
        exit(EXIT_FAILURE);
    window = glfwCreateWindow(1000, 1000, "G64160046_Zaki_Geyan", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);
    glfwSetKeyCallback(window, key_callback);
    while (!glfwWindowShouldClose(window))
    {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float) height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-111, 1111, 1000, 0, 1.f, -1.f);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        latar();
        tanah();
        jalan();
        bayangan();

        lantai_1();
        pintu();
        jendela_di_pintu_1();
        jendela_di_pintu_2();
        jendela_di_pintu_3();
        jendela_di_pintu_4();
        jendela_lantai_1_1();
        jendela_lantai_1_2();

        lantai_2();
        jendela_tidur();
        jendela_lantai_2_1();
        jendela_lantai_2_2();

        kamar();
        jendela_kamar_1();
        jendela_kamar_2();

        atap();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
